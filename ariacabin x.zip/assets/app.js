(() => {
  let S = window.BOOT || {};
  const USER = window.USER || {};
  let POLICY = window.POLICY || {};
  let CSRF = window.CSRF || "";
  const API = window.API_URL || "";
  const FIELDS = window.FIELDS || {};
  const INSTANCE_ID = window.INSTANCE_ID || 1;

  let menu = "dashboard";
  let menuHistory = [];
  let editTable = "";
  let editId = 0;

  const MENU_LABELS = {
    dashboard: "داشبورد", customers: "مشتریان", personnel: "پرسنل", finance: "حسابداری",
    warehouse: "انبار", suppliers: "تأمین‌کنندگان", purchases: "خریدها", directives: "دستورات",
    fines: "جریمه و پاداش", salary: "حقوق", chat: "چت", chat_history: "مدیریت چت",
    settings: "تنظیمات", menu_order: "مدیریت منو", roles: "مدیریت نقش‌ها",
    leave: "مرخصی", overtime: "اضافه‌کاری", stock_usage: "اعلام مصرفی / بازگشت انبار",
    emp_dashboard: "خانه من", emp_tasks: "کارهای من", emp_projects: "پروژه‌های من",
    emp_report: "گزارش روزانه", emp_attendance: "ورود / خروج",
    emp_leave: "مرخصی", emp_overtime: "اضافه‌کاری", emp_stock: "اعلام مصرفی", emp_messages: "مکاتبات پروژه",
    installments: "اقساط و اجاره‌ها", expenses: "هزینه‌ها", incomes: "درآمدها",
    treasury: "صندوق و بانک", sales_invoices: "فاکتور فروش",
    work_sites: "نقاط کاری (حضور)",
    att_map: "گزارش حضور روی نقشه",
    cust_home: "خانه من", cust_project: "پروژه من", cust_finance: "وضعیت مالی",
    send_directive: "ارسال دستور", emergency_salary: "درخواست حقوق اضطراری",
    personal_purchase: "خرید از حساب شخصی", invoices: "صدور فاکتور",
    weekly_meetings: "جلسات هفتگی", live_cameras: "پخش زنده",
  };

  const MENU_ICONS = {
    dashboard: "🏠", customers: "👥", personnel: "👷", finance: "💰", warehouse: "📦",
    suppliers: "🏭", purchases: "🛒", directives: "📨", fines: "⚠️", salary: "💵",
    chat: "💬", chat_history: "💬",
    settings: "⚙️", menu_order: "☰", roles: "✦", leave: "☀️", overtime: "➕", stock_usage: "📦",
    emp_dashboard: "🏠", emp_tasks: "✅", emp_projects: "📁",
    emp_report: "📝", emp_attendance: "⏱️", emp_leave: "☀️",
    emp_overtime: "➕", emp_stock: "📦", emp_messages: "✉️",
    installments: "📅",
    work_sites: "📍",
    att_map: "🗺️",
    cust_home: "🏠", cust_project: "📁", cust_finance: "💰",
    send_directive: "📤", emergency_salary: "🆘", personal_purchase: "🛒", invoices: "🧾",
    weekly_meetings: "📅", live_cameras: "📹",
    persons_group: "👤", accounting_group: "📒", attendance_group: "📍",
  };

  // گروه‌های منو (مثل دسته‌های آچاره — فقط آیکن+نام تا باز نشود)
  const MENU_GROUPS = {
    persons_group: {
      label: "اشخاص",
      icon: "👤",
      children: ["customers", "personnel", "suppliers"],
    },
    accounting_group: {
      label: "حسابداری",
      icon: "📒",
      children: ["finance", "salary", "installments", "warehouse", "invoices", "expenses", "incomes", "treasury", "sales_invoices", "purchases"],
    },
    directives: {
      // خود دستورات والد می‌ماند؛ جریمه و ارسال دستور زیرمجموعه‌اش
      label: "دستورات",
      icon: "📨",
      children: ["fines", "send_directive"],
      keepSelf: true,
    },
    attendance_group: {
      label: "حضور و غیاب",
      icon: "📍",
      children: ["work_sites", "att_map", "leave", "overtime", "emp_attendance"],
    },
    settings: {
      label: "تنظیمات",
      icon: "⚙️",
      children: ["roles", "chat_history", "menu_order"],
      keepSelf: true,
    },
  };

  // پیش‌فرض ناوبری پایین موبایل (قابل تغییر در تنظیمات)
  const DEFAULT_BOTTOM_NAV = ["dashboard", "persons_group", "directives", "accounting_group", "settings"];

  const TABLE_FOR = {
    customers: "customers", personnel: "personnel", warehouse: "stock_items",
    suppliers: "suppliers", purchases: "purchases", directives: "directives", fines: "fines",
    leave: "leave_requests", overtime: "overtime", stock_usage: "stock_usage",
    salary: "salary_payments",
    emp_report: "daily_reports", emp_attendance: "attendance", emp_leave: "leave_requests",
    emp_overtime: "overtime", emp_stock: "stock_usage",
  };

  const LABELS = {
    name: "نام", role: "نقش پنل", leave_days: "مانده مرخصی", phone: "تلفن / موبایل", password: "رمز عبور",
    bank_card: "شماره کارت", bank_shaba: "شبا", start_date: "تاریخ شروع", notes: "توضیحات",
    address: "آدرس", status: "وضعیت", balance: "مانده حساب", project_amount: "مبلغ پروژه",
    installer: "نصاب", note: "یادداشت", check_date: "تاریخ سررسید", amount: "مبلغ", discount: "تخفیف", subtotal: "جمع جزء", paid_amount: "پرداخت‌شده", transfer_date: "تاریخ حواله", to_warehouse: "انبار مقصد", from_warehouse: "انبار مبدأ", income_date: "تاریخ درآمد", expense_date: "تاریخ هزینه", account_type: "نوع حساب", account_name: "صندوق/حساب", direction: "جهت", account_no: "شماره حساب", bank_name: "نام بانک", opening_balance: "موجودی اول دوره",
    bank: "بانک", num: "شماره صیاد", payee: "در وجه", for_what: "بابت", approval: "وضعیت", check_status: "وضعیت چک", status_note: "یادداشت وضعیت", passed_date: "تاریخ وصول/پاس",
    kind: "نوع عملیات", ref_no: "شماره ارجاع", shaba: "شبا", description: "شرح",
    category: "انبار مادر", item: "نام کالا", qty: "موجودی", qty_display: "مانده (دو واحدی)", min_qty: "حداقل موجودی (اخطار)", unit: "واحد ۱", unit2: "واحد ۲", unit_ratio: "هر واحد۱ = چند واحد۲", prior_stock: "موجودی از قبل", prior_date: "تاریخ موجودی قبلی", price: "قیمت هر واحد (ریال)",
    project: "پروژه / مشتری", item_name: "نام کالا", stage: "مرحله", used_at: "تاریخ مصرف",
    personnel_name: "پرسنل", supplier: "تأمین‌کننده", invoice_date: "تاریخ فاکتور",
    invoice_no: "شماره فاکتور", warehouse: "انبار", payment_type: "نوع پرداخت", carrier: "حمل توسط",
    hours: "ساعت", report_date: "تاریخ گزارش", check_in: "ورود", check_out: "خروج", att_date: "تاریخ", att_type: "نوع ثبت", att_time: "ساعت", sub_stage: "مرحله جاری",
    site_name: "نقطه کاری", geo_ok: "موقعیت معتبر", lat: "عرض", lng: "طول", accuracy_m: "دقت (م)", ip_addr: "IP",
    from_date: "از تاریخ", to_date: "تا تاریخ", reason: "بابت", ot_date: "تاریخ",
    title: "عنوان", body: "متن", target_name: "مخاطب (کاربر)", target_role: "نقش مخاطب",
    priority: "اولویت", due_date: "مهلت", reminder_count: "تعداد یادآوری", reminder_interval: "بازه هر چند", reminder_unit: "واحد بازه (ساعت/روز)",
    fine_date: "تاریخ", type: "نوع", photo: "تصویر گزارش",
    leave_type: "نوع مرخصی", from_time: "از ساعت", to_time: "تا ساعت", payment_type: "نوع پرداخت",
    salary_amount: "مبلغ حقوق ماهانه", salary_day: "روز سررسید حقوق (۱–۳۱)", pay_date: "تاریخ پرداخت",
    period: "دوره / ماه", amount: "مبلغ", file_path: "فایل", body: "توضیحات / متن", attachment: "پیوست فایل",
    person_type: "نوع شخص", person_name: "نام شخص",
  };

  const DATE_FIELDS = ["start_date","check_date","invoice_date","report_date","att_date","from_date","to_date","ot_date","fine_date","due_date","used_at","move_date","pay_date"];
  const TIME_FIELDS = ["check_in","check_out","from_time","to_time","att_time"];
  const MONEY_FIELDS = ["amount","balance","price","project_amount","salary_amount","opening_balance","subtotal","discount","total","paid_amount"];
  const COMBO_FIELDS = {
    personnel_name: () => (S.personnel || []).map((p) => p.name).filter(Boolean),
    target_name: () => {
      const names = (S.personnel || []).map((p) => p.name).filter(Boolean);
      const custs = (S.customers || []).map((c) => c.name).filter(Boolean);
      return [...new Set([...names, ...custs, "*"])];
    },
    target_role: () => Object.entries(POLICY.role_labels || {}).map(([, v]) => v).concat(["همه"]),
    project: () => (S.customers || []).map((c) => c.name).filter(Boolean),
    supplier: () => (S.suppliers || []).map((s) => s.name).filter(Boolean),
    item: () => (S.stock_items || []).map((i) => i.item).filter(Boolean),
    item_name: () => (S.stock_items || []).map((i) => i.item).filter(Boolean),
    installer: () => (S.personnel || []).map((p) => p.name).filter(Boolean),
    role: () => {
      const labels = POLICY.role_labels || {};
      return Object.entries(labels)
        .filter(([k]) => k !== "management" || POLICY.can_manage_managers || POLICY.is_network_admin || POLICY.is_main_manager)
        .map(([k, v]) => ({ v: k, l: v }));
    },
  };

  const CUSTOMER_STATUSES = [
    { v: "مشتریان جدید", l: "مشتریان جدید" },
    { v: "مشتریان در حال تولید", l: "مشتریان در حال تولید" },
    { v: "مشتریان در حال نصب", l: "مشتریان در حال نصب" },
    { v: "مشتریان تحویل داده شده", l: "مشتریان تحویل داده شده" },
    { v: "مشتریان کنسل شده", l: "مشتریان کنسل شده" },
  ];
  // نگاشت مقادیر قدیمی به فارسی
  const CUSTOMER_STATUS_MAP = {
    new: "مشتریان جدید", "جدید": "مشتریان جدید", info: "مشتریان جدید",
    "دریافت اطلاعات": "مشتریان جدید", "مشتریان جدید": "مشتریان جدید",
    production: "مشتریان در حال تولید", "در حال تولید": "مشتریان در حال تولید", "درحال تولید": "مشتریان در حال تولید",
    install: "مشتریان در حال نصب", "در حال نصب": "مشتریان در حال نصب", "درحال نصب": "مشتریان در حال نصب",
    delivered: "مشتریان تحویل داده شده", "تحویل‌شده": "مشتریان تحویل داده شده", "تحویل شده": "مشتریان تحویل داده شده", "تحویل داده شده": "مشتریان تحویل داده شده",
    cancelled: "مشتریان کنسل شده", "کنسل": "مشتریان کنسل شده", "کنسل شده": "مشتریان کنسل شده",
  };


  // مراحل فرعی مشتریان جدید (تا قبل از ورود به تولید)
  const NEW_CUSTOMER_STAGES = [
    { key: "اندازه‌گیری", label: "اندازه‌گیری", needPhoto: true },
    { key: "طراحی", label: "طراحی", needPhoto: false },
    { key: "فاکتور قیمت", label: "فاکتور قیمت", needPhoto: false },
    { key: "قرارداد", label: "قرارداد", needPhoto: false },
  ];
  // مراحل نصب (درصد پیشرفت)
  const INSTALL_STAGES_WALL = [
    "لولا زدن درب‌ها", "قرار دادن یونیت‌های زمینی", "پایه زدن کابینت قدی و تراز", "سوراخ‌کاری فیتینگ",
    "نصب کابینت دیواری و تراز و بتونه", "نصب تاج", "نصب جک پمپی", "نصب مگنت", "نصب دستگیره مخفی",
    "نصب آبچکان", "برش جای هود", "نصب درب دیواری و رگلاژ",
  ];
  const INSTALL_STAGES_FLOOR = [
    "تراز و فیکس کابینت زمینی به دیوار", "فیکس پایه تا زمین", "نصب ریل کشو", "نصب دستگیره مخفی و مگنت",
    "نصب درب کابینت", "نصب صفحه کابینت", "نصب دستگیره", "نصب پاخور", "چک درب هود و فر",
    "چسب شیشه‌ای سینک و پاخور", "چسب آکواریوم پاخور سینک", "بادگیری و نظافت", "چکاپ نهایی رگلاژ و بتونه",
    "نصب سایر سفارش‌ها", "جمع ابزار و چک جعبه", "نظافت نهایی برای تحویل",
  ];
  // نرخ‌نامه پیش‌فرض فاکتور (قابل ویرایش توسط مدیر)

  // قالب لیست یراق (قابل پر کردن تعداد)
  const HARDWARE_TEMPLATE = [
    { cat: "لولا", items: ["لولا آرام‌بند", "لولا ساده", "لولا ۹۰ درجه", "لولا خم", "لولا ۱۸۰ درجه (خرچنگی)"] },
    { cat: "پایه و پیچ", items: ["پایه", "پیچ ۳", "پیچ ۵", "پیچ ۱/۵", "پیچ فیکس", "پیچ رول‌پلاک ۸", "رول‌پلاک ۶", "پین طبقه"] },
    { cat: "اتصال و چسب", items: ["بست گونیا فلزی", "چسب ۱.۲.۳", "چسب چوب", "چسب کاغذی-شیشه‌ای", "چسب آکواریوم"] },
    { cat: "ریل", items: ["ریل ساچمه‌ای ۳۰", "ریل ساچمه‌ای ۳۵", "ریل ساچمه‌ای ۴۰", "ریل ساچمه‌ای ۴۵", "ریل ساچمه‌ای ۵۰", "ریل تاندومی ۴۵", "ریل تاندومی ۵۰"] },
    { cat: "سایر", items: ["جک پمپی", "کفشک سفید", "بتونه سفید", "دستگیره", "زیرسری و لوله استیل", "سبد اکسسوری"] },
  ];
  // مراحل تولید (متصل به انبار)
  const PROD_STAGES = [
    { key: "اندازه‌ها", label: "اندازه‌ها", roles: ["supervisor", "management"] },
    { key: "لیست یراق", label: "لیست یراق", roles: ["supervisor", "management", "employee"] },
    { key: "برشکاری", label: "برشکاری", roles: ["employee", "supervisor", "management"] },
    { key: "سی‌ان‌سی", label: "سی‌ان‌سی", roles: ["employee", "supervisor", "management"] },
    { key: "نوارکاری", label: "نوارکاری", roles: ["employee", "supervisor", "management"] },
    { key: "روکش وکیوم", label: "روکش وکیوم", roles: ["employee", "supervisor", "management"] },
    { key: "رنگ", label: "رنگ", roles: ["employee", "supervisor", "management"] },
    { key: "مونتاژ", label: "مونتاژ", roles: ["employee", "supervisor", "management"] },
  ];

  const DEFAULT_INVOICE_RATES = {
    partner: [
      { name: "خدمات روکش مدرن ایرانی", price: 57976313 },
      { name: "خدمات روکش مدرن خارجی", price: 66981373 },
      { name: "خدمات ابزار معمولی ایرانی", price: 61976313 },
      { name: "خدمات ابزار معمولی خارجی", price: 70981373 },
      { name: "خدمات ابزار کف‌تراش ایرانی", price: 69176313 },
      { name: "خدمات ابزار کف‌تراش خارجی", price: 78181373 },
      { name: "خدمات رنگ پلی‌اورتان مدرن ایرانی", price: 78328849 },
      { name: "خدمات رنگ پلی‌اورتان مدرن خارجی", price: 105168909 },
      { name: "خدمات رنگ پلی‌اورتان ابزار معمولی کلاسیک ایرانی", price: 82328849 },
      { name: "خدمات رنگ پلی‌اورتان ابزار معمولی کلاسیک خارجی", price: 109168909 },
      { name: "خدمات رنگ پلی‌اورتان نئوکلاسیک ایرانی", price: 89528849 },
      { name: "خدمات رنگ پلی‌اورتان نئوکلاسیک خارجی", price: 116368909 },
      { name: "برشکاری ام دی اف", price: 4000000 },
      { name: "برشکاری لترون", price: 4500000 },
      { name: "برشکاری ام دی اف ۱۲۲×۲۸۰", price: 2200000 },
      { name: "برشکاری فیبر", price: 1200000 },
      { name: "نوارکاری ۱ میل", price: 330000 },
      { name: "نوارکاری ۲ میل", price: 395000 },
      { name: "زاویه‌کاری (متری)", price: 120000 },
      { name: "شیارکاری (متری)", price: 70000 },
      { name: "سوراخ‌کاری لولا گازور", price: 7500 },
      { name: "خدمات هر سینی وکیوم درب کابینت", price: 18000000 },
      { name: "خدمات وکیوم هر سینی درب اتاقی", price: 12000000 },
      { name: "نصب درب اتاقی ملامینه", price: 5500000 },
      { name: "نصب درب اتاقی وکیوم", price: 7000000 },
      { name: "پرس درب ملامینه", price: 4000000 },
      { name: "دوراهه درب", price: 1500000 },
    ],
    customer_cabinet: [
      { name: "ام دی اف معمولی — زمینی", price: 198766477 },
      { name: "ام دی اف معمولی — دیواری", price: 134977712 },
      { name: "هایگلاس — زمینی", price: 213002763 },
      { name: "هایگلاس — دیواری", price: 150795808 },
      { name: "ممبران مدرن ایرانی — زمینی", price: 236440110 },
      { name: "ممبران مدرن ایرانی — دیواری", price: 176837305 },
      { name: "ممبران مدرن خارجی — زمینی", price: 246327666 },
      { name: "ممبران مدرن خارجی — دیواری", price: 187823478 },
      { name: "ممبران ابزار معمولی ایرانی — زمینی", price: 240142510 },
      { name: "ممبران ابزار معمولی ایرانی — دیواری", price: 180951082 },
      { name: "ممبران ابزار معمولی خارجی — زمینی", price: 253163470 },
      { name: "ممبران ابزار معمولی خارجی — دیواری", price: 191757154 },
      { name: "ممبران نئوکلاسیک ایرانی — زمینی", price: 246689709 },
      { name: "ممبران نئوکلاسیک ایرانی — دیواری", price: 188225748 },
      { name: "ممبران نئوکلاسیک خارجی — زمینی", price: 256857945 },
      { name: "ممبران نئوکلاسیک خارجی — دیواری", price: 198761668 },
      { name: "رنگ پلی‌اورتان مدرن ایرانی — زمینی", price: 251899571 },
      { name: "رنگ پلی‌اورتان مدرن ایرانی — دیواری", price: 194014484 },
      { name: "رنگ پلی‌اورتان مدرن خارجی — زمینی", price: 277988109 },
      { name: "رنگ پلی‌اورتان مدرن خارجی — دیواری", price: 223001748 },
      { name: "رنگ پلی‌اورتان ابزار معمولی ایرانی — زمینی", price: 254731625 },
      { name: "رنگ پلی‌اورتان ابزار معمولی ایرانی — دیواری", price: 197161210 },
      { name: "رنگ پلی‌اورتان ابزار معمولی خارجی — زمینی", price: 280337042 },
      { name: "رنگ پلی‌اورتان ابزار معمولی خارجی — دیواری", price: 225611673 },
      { name: "رنگ پلی‌اورتان کف‌تراش نئوکلاسیک ایرانی — زمینی", price: 260414879 },
      { name: "رنگ پلی‌اورتان کف‌تراش نئوکلاسیک ایرانی — دیواری", price: 203475937 },
      { name: "رنگ پلی‌اورتان کف‌تراش نئوکلاسیک خارجی — زمینی", price: 285537175 },
      { name: "رنگ پلی‌اورتان کف‌تراش نئوکلاسیک خارجی — دیواری", price: 231389599 },
    ],
    customer_closet: [
      { name: "کمد لترون", price: 131794681 },
      { name: "کمد بدنه لترون درب ام دی اف", price: 154976123 },
      { name: "کمد ام دی اف معمولی", price: 154680193 },
      { name: "کمد هایگلاس", price: 170498288 },
      { name: "کمد ممبران مدرن", price: 197569120 },
      { name: "کمد ممبران ابزار معمولی", price: 202569120 },
      { name: "کمد ممبران نئوکلاسیک", price: 211569120 },
      { name: "کمد رنگ مدرن", price: 223009789 },
      { name: "کمد رنگ ابزار معمولی", price: 228009789 },
      { name: "کمد رنگ نئوکلاسیک", price: 154680193 },
    ],
  };


  const SELECTS = {
    role: () => {
      const labels = POLICY.role_labels || { employee: "پرسنل / نصاب", management: "مدیر", warehouse: "حسابدار / انباردار", supervisor: "سرپرست کارگاه", customer: "مشتری" };
      return Object.entries(labels)
        .filter(([k]) => {
          // فقط مدیر شبکه یا مدیر کل می‌توانند نقش «مدیر» را به دیگران بدهند
          if (k === "management" && !(POLICY.can_manage_managers || POLICY.is_network_admin || POLICY.is_main_manager)) {
            return false;
          }
          return true;
        })
        .map(([k, v]) => ({ v: k, l: v }));
    },
    status: () => [
      { v: "باز", l: "باز" }, { v: "انجام شد", l: "انجام شد" }, { v: "رد شد", l: "رد شد" },
      { v: "در انتظار", l: "در انتظار" }, { v: "تأیید", l: "تأیید" }, { v: "تأییدشده", l: "تأییدشده" },
      { v: "در انتظار تأیید", l: "در انتظار تأیید" }, { v: "رد", l: "رد" },
    ],
    customer_status: () => CUSTOMER_STATUSES.slice(),
    approval: () => [
      { v: "pending", l: "در انتظار تأیید" },
      { v: "in_hand", l: "نزد ما" },
      { v: "deposited", l: "واگذار به بانک" },
      { v: "cleared", l: "وصول / پاس شده" },
      { v: "returned", l: "برگشت خورده" },
      { v: "spent", l: "خرج / واگذار شده" },
      { v: "issued", l: "صادر شده" },
      { v: "approved", l: "تأیید (نزد ما)" },
      { v: "rejected", l: "رد / باطل" },
    ],
    account_type: () => [{ v: "cash", l: "صندوق" }, { v: "bank", l: "بانک" }],
    direction: () => [{ v: "in", l: "دریافت" }, { v: "out", l: "پرداخت" }],
    method: () => [{ v: "cash", l: "نقد / صندوق" }, { v: "bank", l: "بانک / کارت" }],
    check_status: () => [
      { v: "pending", l: "در انتظار تأیید" },
      { v: "in_hand", l: "نزد ما" },
      { v: "deposited", l: "واگذار به بانک" },
      { v: "cleared", l: "وصول / پاس شده" },
      { v: "returned", l: "برگشت خورده" },
      { v: "spent", l: "خرج / واگذار شده" },
      { v: "issued", l: "صادر شده" },
      { v: "rejected", l: "رد / باطل" },
    ],
    kind: () => [
      { v: "برداشت", l: "برداشت از انبار" },
      { v: "بازگشت", l: "بازگشت به انبار" },
    ],
    check_kind: () => [
      { v: "check", l: "چک" },
      { v: "خرید دین", l: "خرید دین" },
    ],
    payment_type: () => [
      { v: "نقدی", l: "نقدی" },
      { v: "چکی", l: "چکی" },
      { v: "سایر", l: "سایر" },
    ],
    leave_type: () => [{ v: "روزانه", l: "مرخصی روزانه" }, { v: "ساعتی", l: "مرخصی ساعتی" }],
    reason: () => [
      { v: "تولید", l: "تولید" },
      { v: "نصب", l: "نصب" },
      { v: "تخلیه", l: "تخلیه" },
    ],
    type: () => [{ v: "fine", l: "جریمه" }, { v: "bonus", l: "پاداش" }],
    att_type: () => [{ v: "check_in", l: "ورود" }, { v: "check_out", l: "خروج" }],
    priority: () => [{ v: "critical", l: "بحرانی (اجباری)" }, { v: "important", l: "مهم" }, { v: "normal", l: "عادی" }],
  };

  const COLS = {
    customers: ["name", "phone", "status", "balance", "project_amount"],
    personnel: ["name", "role", "leave_days", "phone", "salary_amount", "salary_day"],
    salary_payments: ["personnel_name", "amount", "pay_date", "payment_type", "period"],
    messages: ["sender_name", "project", "payment_type", "amount", "body"],
    checks_received: ["name", "check_date", "amount", "bank", "num", "payee", "for_what", "check_status", "passed_date"],
    checks_paid: ["name", "payee", "check_date", "amount", "bank", "num", "shaba", "check_status", "passed_date"],
    cash_boxes: ["name", "opening_balance", "notes"],
    bank_accounts: ["name", "bank_name", "account_no", "shaba", "opening_balance"],
    expenses: ["title", "category", "amount", "expense_date", "account_type", "account_name", "party_name"],
    incomes: ["title", "category", "amount", "income_date", "account_type", "account_name", "party_name"],
    sales_invoices: ["customer_name", "invoice_date", "invoice_no", "total", "paid_amount", "status", "warehouse"],
    stock_transfers: ["item_name", "qty", "from_warehouse", "to_warehouse", "transfer_date"],
    debt_purchases: ["name", "check_date", "amount", "bank", "num", "payee", "approval", "note"],
    account_payments: ["person_type", "person_name", "amount", "pay_date", "notes"],
    stock_items: ["category", "item", "qty_display", "min_qty", "unit", "unit2", "unit_ratio", "price"],
    suppliers: ["name", "phone"],
    purchases: ["supplier", "item", "qty", "amount", "invoice_date"],
    directives: ["title", "target_name", "target_role", "status", "priority", "due_date"],
    fines: ["personnel_name", "amount", "type", "reason", "fine_date"],
    daily_reports: ["personnel_name", "project", "hours", "report_date"],
    attendance: ["personnel_name", "check_in", "check_out", "att_date", "site_name", "geo_ok", "notes"],
    leave_requests: ["personnel_name", "leave_type", "from_date", "to_date", "hours", "reason", "status"],
    overtime: ["personnel_name", "project", "from_time", "to_time", "hours", "reason", "status", "ot_date"],
    stock_usage: ["kind", "project", "item_name", "qty", "personnel_name", "prod_stage"],
    hardware_lists: ["customer_name", "list_date", "personnel_name", "status"],
  };

  function menus() {
    let ids = (POLICY.menus || Object.keys(MENU_LABELS)).slice();
    if (POLICY.is_manager || POLICY.role === "warehouse") {
      ["invoices", "send_directive", "weekly_meetings"].forEach((m) => {
        if (!ids.includes(m) && MENU_LABELS[m]) ids.push(m);
      });
    }
    if (POLICY.is_employee || POLICY.role === "employee") {
      ["emp_tasks", "emp_projects", "emergency_salary", "personal_purchase"].forEach((m) => {
        if (!ids.includes(m) && MENU_LABELS[m]) ids.push(m);
      });
      if (ids.includes("emp_dashboard")) {
        ids = ["emp_dashboard", ...ids.filter((id) => id !== "emp_dashboard")];
      }
    }
    if (POLICY.is_manager || POLICY.role === "warehouse") {
      if (!ids.includes("installments") && MENU_LABELS.installments) ids.push("installments");
      if (!ids.includes("work_sites") && MENU_LABELS.work_sites) ids.push("work_sites");
      if (!ids.includes("att_map") && MENU_LABELS.att_map) ids.push("att_map");
    }
    if (!POLICY.is_manager) {
      ids = ids.filter((id) => id !== "settings" && id !== "roles");
    }
    if (!ids.includes("menu_order")) ids.push("menu_order");
    ids = ids.filter((id) => MENU_LABELS[id] && id !== "chat");

    // زیرمنوهای داخل گروه را از سطح اول حذف کن
    const nestedHide = new Set();
    Object.keys(MENU_GROUPS).forEach((gid) => {
      const g = MENU_GROUPS[gid];
      (g.children || []).forEach((c) => nestedHide.add(c));
    });
    // برای پرسنل/کارمند گروه‌های مدیریتی را ساده نگه دار
    const isEmp = POLICY.is_employee || POLICY.role === "employee";
    let topIds = ids.filter((id) => !nestedHide.has(id));

    // درج گروه‌ها به‌جای فرزندان (مدیر / حسابدار)
    if (!isEmp) {
      const inject = [];
      if (ids.some((id) => (MENU_GROUPS.persons_group.children || []).includes(id))) inject.push("persons_group");
      if (ids.some((id) => (MENU_GROUPS.accounting_group.children || []).includes(id)) || ids.includes("finance") || ids.includes("warehouse")) inject.push("accounting_group");
      if (ids.some((id) => (MENU_GROUPS.attendance_group.children || []).includes(id))) inject.push("attendance_group");
      // directives و settings خودشان در لیست هستند
      inject.forEach((g) => {
        if (!topIds.includes(g)) topIds.push(g);
      });
    }

    const order = Array.isArray(PREFS.menuOrder) ? PREFS.menuOrder : [];
    if (order.length) {
      const rank = {};
      order.forEach((id, i) => { rank[id] = i; });
      topIds = topIds.slice().sort((a, b) => {
        const ra = rank.hasOwnProperty(a) ? rank[a] : 1000;
        const rb = rank.hasOwnProperty(b) ? rank[b] : 1000;
        if (ra !== rb) return ra - rb;
        return 0;
      });
    }
    return topIds.map((id) => {
      if (MENU_GROUPS[id] && !MENU_GROUPS[id].keepSelf) {
        return { id, label: MENU_GROUPS[id].label, isGroup: true };
      }
      if (MENU_GROUPS[id] && MENU_GROUPS[id].keepSelf) {
        return { id, label: MENU_LABELS[id] || MENU_GROUPS[id].label, isGroup: true, keepSelf: true };
      }
      return { id, label: MENU_LABELS[id] };
    });
  }

  function groupChildren(groupId) {
    const g = MENU_GROUPS[groupId];
    if (!g) return [];
    let ids = (POLICY.menus || Object.keys(MENU_LABELS)).slice();
    return (g.children || []).filter((c) => MENU_LABELS[c] && (ids.includes(c) || POLICY.is_manager || POLICY.role === "warehouse"));
  }

  const MENU_COLORS = {
    dashboard: "blue", customers: "green", personnel: "orange", finance: "teal",
    warehouse: "amber", suppliers: "purple", purchases: "pink", directives: "indigo",
    fines: "red", salary: "lime", chat_history: "cyan", settings: "slate", menu_order: "indigo", roles: "purple",
    leave: "teal", overtime: "orange", stock_usage: "amber",
    emp_dashboard: "blue", emp_tasks: "green", emp_projects: "purple",
    emp_report: "indigo", emp_attendance: "green", emp_leave: "teal",
    emp_overtime: "orange", emp_stock: "amber", emp_messages: "cyan",
    installments: "teal",
    work_sites: "green",
    cust_home: "blue", cust_project: "purple", cust_finance: "teal",
  };

  function faToEnDigits(str) {
    return String(str || "").replace(/[۰-۹]/g, (d) => "۰۱۲۳۴۵۶۷۸۹".indexOf(d)).replace(/[٠-٩]/g, (d) => "٠١٢٣٤٥٦٧٨٩".indexOf(d));
  }

  /** تبدیل خودکار ارقام فارسی/عربی به انگلیسی هنگام تایپ در همه input/textarea */
  function bindAutoEnglishDigits(root) {
    const el = root || document;
    const handler = (e) => {
      const t = e.target;
      if (!t || !t.tagName) return;
      const tag = t.tagName.toUpperCase();
      if (tag !== "INPUT" && tag !== "TEXTAREA") return;
      if (t.type === "password" || t.type === "file" || t.type === "checkbox" || t.type === "radio" || t.type === "button" || t.type === "submit" || t.type === "hidden") {
        // رمز هم باید ارقام انگلیسی شود
        if (t.type !== "password") return;
      }
      const val = t.value;
      if (val == null || val === "") return;
      const next = faToEnDigits(val);
      if (next !== val) {
        const start = t.selectionStart;
        const end = t.selectionEnd;
        t.value = next;
        try {
          if (typeof start === "number" && typeof end === "number") {
            t.setSelectionRange(start, end);
          }
        } catch (err) {}
      }
    };
    el.addEventListener("input", handler, true);
    el.addEventListener("blur", handler, true);
    el.addEventListener("paste", (e) => {
      setTimeout(() => handler(e), 0);
    }, true);
  }

  function api(action, data = {}) {
    const fd = new FormData();
    fd.append("action", action);
    fd.append("_wpnonce", CSRF);
    fd.append("instance", String(INSTANCE_ID));
    Object.keys(data).forEach((k) => {
      if (k === "payload") fd.append(k, JSON.stringify(data[k]));
      else if (k === "file") fd.append("file", data[k]);
      else fd.append(k, data[k]);
    });
    return fetch(API + (API.includes("?") ? "&" : "?") + "action=" + encodeURIComponent(action), {
      method: "POST", body: fd, credentials: "same-origin",
    }).then((r) => r.json());
  }

  function reload(tables) {
    // اگر لیست جداول داده شود → بارگذاری جزئی (سریع‌تر)
    let url = API + (API.includes("?") ? "&" : "?") + "instance=" + INSTANCE_ID;
    if (tables && tables.length) {
      url += "&action=tables&tables=" + encodeURIComponent(tables.join(","));
    } else {
      url += "&action=all";
    }
    return fetch(url, { credentials: "same-origin" })
      .then((r) => r.json())
      .then((res) => {
        if (res.ok) {
          if (res.partial && tables && tables.length) {
            // ادغام جزئی در state موجود
            const incoming = res.data || {};
            Object.keys(incoming).forEach((k) => { S[k] = incoming[k]; });
          } else {
            S = res.data || {};
          }
          if (res.csrf) CSRF = res.csrf;
          if (res.policy) POLICY = res.policy;
          window.BOOT = S;
        }
        return res;
      });
  }

  /** بارگذاری سبک فقط جداول مورد نیاز منوی فعلی */
  function reloadForMenu(m) {
    const map = {
      warehouse: ["stock_items", "stock_usage", "purchases", "suppliers", "stock_transfers"],
      stock_usage: ["stock_usage", "stock_items"],
      purchases: ["purchases", "stock_items", "suppliers"],
      finance: ["checks_received", "checks_paid", "debt_purchases", "account_payments", "cash_boxes", "bank_accounts", "expenses", "incomes", "sales_invoices"],
      customers: ["customers"],
      personnel: ["personnel"],
      salary: ["salary_payments", "personnel"],
      leave: ["leave_requests", "personnel"],
      overtime: ["overtime", "personnel"],
      directives: ["directives"],
      fines: ["fines"],
      dashboard: null, // کامل
    };
    const tables = map[m];
    if (tables) return reload(tables);
    return reload();
  }

  function fmtMoney(v) {
    const n = Number(String(v).replace(/,/g, ""));
    if (isNaN(n)) return String(v);
    return n.toLocaleString("fa-IR");
  }

  function fmt(v, field) {
    if (v === null || v === undefined || v === "") return "—";
    if (field && MONEY_FIELDS.includes(field)) return fmtMoney(v);
    if (typeof v === "number") {
      if (MONEY_FIELDS.includes(field)) return fmtMoney(v);
      return v.toLocaleString("fa-IR");
    }
    // اعداد پولی ذخیره‌شده به‌صورت رشته
    if (field && MONEY_FIELDS.includes(field) && /^-?\d+(\.\d+)?$/.test(String(v))) return fmtMoney(v);
    if (field === "geo_ok") return (v === 1 || v === "1" || v === true) ? "✓ معتبر" : "—";
    if (field === "check_status" || field === "approval") return checkStatusLabel(normalizeCheckStatus({ check_status: v, approval: v }), false);
    if (field === "status" && CUSTOMER_STATUS_MAP[v]) return CUSTOMER_STATUS_MAP[v];
    if (v === "new" || v === "دریافت اطلاعات") return "مشتریان جدید";
    if (v === "production") return "در حال تولید";
    if (v === "install") return "در حال نصب";
    if (v === "delivered") return "تحویل داده شده";
    if (v === "cancelled") return "کنسل";
    if (v === "critical" || v === "فوری") return "بحرانی";
    if (v === "important" || v === "مهم") return "مهم";
    if (v === "normal" || v === "عادی") return "عادی";
    const rl = (POLICY.role_labels || {})[v];
    return rl || String(v);
  }

  // —— کمک‌کننده‌های دو واحدی انبار (سمت کلاینت) ——
  const StockHelper = {
    parseQty(raw) {
      if (raw == null || raw === "") return 0;
      const s = String(raw).replace(/[۰-۹]/g, (d) => "۰۱۲۳۴۵۶۷۸۹".indexOf(d))
        .replace(/[٠-٩]/g, (d) => "٠١٢٣٤٥٦٧٨٩".indexOf(d))
        .replace(/[,،\s]/g, "").replace(",", ".");
      const n = parseFloat(s);
      return isNaN(n) ? 0 : n;
    },
    parseRatio(raw) {
      const n = this.parseQty(raw);
      return n > 0 ? n : 0;
    },
    formatQty(n) {
      if (!isFinite(n)) return "0";
      let s = n.toFixed(4).replace(/\.?0+$/, "");
      return s || "0";
    },
    formatRemaining(item) {
      if (!item) return "—";
      if (item.qty_display) return item.qty_display;
      const primary = this.parseQty(item.qty);
      const unit1 = (item.unit || "عدد").trim();
      const unit2 = (item.unit2 || "").trim();
      const ratio = this.parseRatio(item.unit_ratio);
      let s = this.formatQty(primary) + " " + unit1;
      if (unit2 && ratio > 0) {
        s += " (" + this.formatQty(primary * ratio) + " " + unit2 + ")";
      }
      return s;
    },
    isLow(item) {
      if (item && typeof item._is_low === "boolean") return item._is_low;
      const qty = this.parseQty(item && item.qty);
      const min = this.parseQty(item && item.min_qty);
      return min > 0 && qty <= min;
    },
    toPrimary(qty, usedUnit, item) {
      const unit1 = (item.unit || "").trim();
      const unit2 = (item.unit2 || "").trim();
      const ratio = this.parseRatio(item.unit_ratio);
      if (!usedUnit || usedUnit === unit1 || !unit2 || ratio <= 0) return qty;
      if (usedUnit === unit2) return qty / ratio;
      return qty;
    }
  };

  // —— مبدل شمسی ——
  const J = {
    toJalali(gy, gm, gd) {
      const g_d_m = [0,31,59,90,120,151,181,212,243,273,304,334];
      let gy2 = (gm > 2) ? (gy + 1) : gy;
      let days = 355666 + (365 * gy) + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) + gd + g_d_m[gm - 1];
      let jy = -1595 + (33 * Math.floor(days / 12053));
      days %= 12053;
      jy += 4 * Math.floor(days / 1461);
      days %= 1461;
      if (days > 365) { jy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
      let jm, jd;
      if (days < 186) { jm = 1 + Math.floor(days / 31); jd = 1 + (days % 31); }
      else { jm = 7 + Math.floor((days - 186) / 30); jd = 1 + ((days - 186) % 30); }
      return [jy, jm, jd];
    },
    toGregorian(jy, jm, jd) {
      jy += 1595;
      let days = -355668 + (365 * jy) + Math.floor(jy / 33) * 8 + Math.floor(((jy % 33) + 3) / 4) + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30 + 186));
      let gy = 400 * Math.floor(days / 146097);
      days %= 146097;
      if (days > 36524) { gy += 100 * Math.floor(--days / 36524); days %= 36524; if (days >= 365) days++; }
      gy += 4 * Math.floor(days / 1461);
      days %= 1461;
      if (days > 365) { gy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
      let gd = days + 1;
      const sal_a = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
      let gm = 1;
      for (; gm <= 12 && gd > sal_a[gm]; gm++) gd -= sal_a[gm];
      return [gy, gm, gd];
    },
    todayStr() {
      const n = new Date();
      const [jy, jm, jd] = this.toJalali(n.getFullYear(), n.getMonth() + 1, n.getDate());
      return jy + "/" + String(jm).padStart(2, "0") + "/" + String(jd).padStart(2, "0");
    },
    todayJalali() { return this.todayStr(); },
    isLeapJalali(jy) {
      const breaks = [1, 5, 9, 13, 17, 22, 26, 30];
      const cy = jy - 979;
      const left = cy % 33;
      return breaks.indexOf(left) >= 0;
    },
    daysInJalaliMonth(jy, jm) {
      if (jm <= 6) return 31;
      if (jm <= 11) return 30;
      return this.isLeapJalali(jy) ? 30 : 29;
    },
    monthName(jm) {
      const names = ["", "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"];
      return names[jm] || "";
    },
    padDate(jy, jm, jd) {
      return jy + "/" + String(jm).padStart(2, "0") + "/" + String(jd).padStart(2, "0");
    },
    /** روز هفته شمسی: ۰=شنبه … ۶=جمعه */
    jalaliWeekday(jy, jm, jd) {
      const [gy, gm, gd] = this.toGregorian(jy, jm, jd);
      const d = new Date(gy, gm - 1, gd);
      const wd = d.getDay(); // 0=Sun … 6=Sat
      return (wd + 1) % 7; // 0=Sat
    },
    nowTime24() {
      const n = new Date();
      return String(n.getHours()).padStart(2, "0") + ":" + String(n.getMinutes()).padStart(2, "0");
    },
    /** اختلاف روز تا تاریخ شمسی YYYY/MM/DD — منفی = گذشته */
    daysUntil(jdate) {
      if (!jdate) return null;
      const p = String(jdate).trim().split(/[\/\-.]/);
      if (p.length < 3) return null;
      const jy = parseInt(p[0], 10), jm = parseInt(p[1], 10), jd = parseInt(p[2], 10);
      if (!jy || !jm || !jd) return null;
      const [gy, gm, gd] = this.toGregorian(jy, jm, jd);
      const target = new Date(gy, gm - 1, gd);
      const now = new Date();
      now.setHours(0, 0, 0, 0);
      target.setHours(0, 0, 0, 0);
      return Math.round((target - now) / 86400000);
    },
    formatChatDate(raw) {
      if (!raw) return "";
      const s = String(raw).trim();
      let d = null;
      const m = s.match(/(\d{4})-(\d{1,2})-(\d{1,2})[ T](\d{1,2})?:?(\d{1,2})?/);
      if (m) {
        d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4] || 0), Number(m[5] || 0));
      } else if (/^\d{4}\/\d{1,2}\/\d{1,2}/.test(s)) {
        return s;
      } else {
        const t = Date.parse(s);
        if (!isNaN(t)) d = new Date(t);
      }
      if (!d || isNaN(d.getTime())) return s;
      const [jy, jm, jd] = this.toJalali(d.getFullYear(), d.getMonth() + 1, d.getDate());
      const hh = String(d.getHours()).padStart(2, "0");
      const mm = String(d.getMinutes()).padStart(2, "0");
      return jy + "/" + String(jm).padStart(2, "0") + "/" + String(jd).padStart(2, "0") + " " + hh + ":" + mm;
    },
  };
  window.J = J;

  // —— تنظیمات شخصی هر کاربر (localStorage — پاک نمی‌شود) ——
  const PREFS_KEY = "samaneh_prefs_" + (USER.id || USER.user_id || USER.login || "guest") + "_" + (INSTANCE_ID || 1);
  function loadPrefs() {
    try {
      const raw = localStorage.getItem(PREFS_KEY);
      if (raw) {
        const p = Object.assign({ theme: "light", fontSize: 16, fontFamily: "zar", helpMode: false, tourDone: false, notifGranted: false, statOrder: [] }, JSON.parse(raw));
        if (p.theme === "classic" || p.theme === "beta" || p.theme === "night") p.theme = p.theme === "night" || p.theme === "dark" ? "dark" : "light";
        if (p.theme !== "dark") p.theme = "light";
        return p;
      }
    } catch (e) {}
    return { theme: "light", fontSize: 16, fontFamily: "zar", helpMode: false, tourDone: false, notifGranted: false, statOrder: [] };
  }
  function savePrefs(p) {
    try { localStorage.setItem(PREFS_KEY, JSON.stringify(p)); } catch (e) {}
    // کلید تم جدا برای سازگاری با نسخه قبلی
    try { localStorage.setItem("samaneh_theme", p.theme === "dark" ? "dark" : "light"); } catch (e) {}
  }
  let PREFS = loadPrefs();

  const FONT_MAP = {
    zar: '"B ZAR", "B Zar", "BZar", Tahoma, Arial, sans-serif',
    "b zar": '"B ZAR", "B Zar", "BZar", Tahoma, Arial, sans-serif',
    tahoma: 'Tahoma, "B ZAR", Arial, sans-serif',
    vazir: 'Vazirmatn, "B ZAR", Tahoma, sans-serif',
    system: 'system-ui, "B ZAR", Tahoma, sans-serif',
  };

  function applyPrefs() {
    const t = PREFS.theme === "dark" ? "dark" : "light";
    ["theme-dark", "theme-light", "theme-night", "theme-classic", "layout-classic-desk", "layout-modir-desk"].forEach((c) => {
      document.documentElement.classList.remove(c);
      document.body.classList.remove(c);
    });
    // همیشه layout سایدبار دسکتاپ مثل پنل فروشگاه
    document.documentElement.classList.add("layout-modir-desk");
    document.body.classList.add("layout-modir-desk");
    if (t === "dark") {
      document.documentElement.classList.add("theme-dark");
      document.body.classList.add("theme-dark");
      document.body.setAttribute("data-theme", "dark");
    } else {
      document.body.setAttribute("data-theme", "light");
    }
    const icons = { light: "☀️", dark: "🌙" };
    const themeBtn = document.getElementById("btn-theme-toggle");
    const themeBtnH = document.getElementById("btn-theme-toggle-header");
    if (themeBtn) themeBtn.textContent = icons[t] || icons.light;
    if (themeBtnH) themeBtnH.textContent = icons[t] || icons.light;

    const fs = Number(PREFS.fontSize) || 15;
    // مقیاس یکدست: همه remها از ریشه پیروی می‌کنند
    document.documentElement.style.fontSize = fs + "px";
    document.documentElement.style.setProperty("--font-size-base", fs + "px");
    if (!PREFS.fontFamily) PREFS.fontFamily = "zar";
    const ff = FONT_MAP[PREFS.fontFamily] || FONT_MAP.zar;
    document.documentElement.style.setProperty("--font-family", ff);
    document.body.style.fontFamily = ff;
    document.body.style.fontSize = ""; // از html ارث ببرد تا همه یکدست بزرگ/کوچک شوند
    const fsd = document.getElementById("font-size-display");
    if (fsd) fsd.textContent = String(fs);
  }

  // —— نوتیفیکیشن‌های زیبا (in-app toast) ——
  function ensureToastContainer() {
    let c = document.getElementById("toast-container");
    if (!c) {
      c = document.createElement("div");
      c.id = "toast-container";
      document.body.appendChild(c);
    }
    return c;
  }
  function showToast(title, msg, type) {
    const c = ensureToastContainer();
    const icons = { danger: "🔴", warn: "🟠", ok: "🟢", info: "🔵" };
    const el = document.createElement("div");
    el.className = "toast toast-" + (type || "info");
    el.innerHTML = `<span class="toast-icon">${icons[type] || icons.info}</span>
      <div class="toast-body"><div class="toast-title">${title || ""}</div><div class="toast-msg">${msg || ""}</div></div>
      <button type="button" class="toast-close" aria-label="بستن">×</button>`;
    el.querySelector(".toast-close").onclick = () => el.remove();
    c.appendChild(el);
    setTimeout(() => { if (el.parentNode) el.remove(); }, 8000);
  }

  // —— نوتیف سیستمی (مرورگر / گوشی) ——
  function requestNotifPermission() {
    if (!("Notification" in window)) return Promise.resolve(false);
    if (Notification.permission === "granted") return Promise.resolve(true);
    if (Notification.permission === "denied") return Promise.resolve(false);
    return Notification.requestPermission().then((p) => {
      PREFS.notifGranted = p === "granted";
      savePrefs(PREFS);
      return p === "granted";
    });
  }
  function sysNotify(title, body, tag) {
    showToast(title, body, tag && tag.includes("check") ? "danger" : "info");
    if (!("Notification" in window) || Notification.permission !== "granted") return;
    try {
      const n = new Notification(title, {
        body: body || "",
        tag: tag || "samaneh-" + Date.now(),
        dir: "rtl",
        lang: "fa",
        icon: (S.settings && S.settings.logo) || undefined,
      });
      setTimeout(() => n.close(), 10000);
    } catch (e) {}
  }

  // —— بررسی چک‌های نزدیک سررسید (۳ روز) ——
  function checkDueSoonNotifs() {
    const recv = S.checks_received || [];
    const paid = S.checks_paid || [];
    const dueRecv = [];
    const duePaid = [];
    recv.forEach((c) => {
      const d = J.daysUntil(c.check_date);
      if (d !== null && d >= 0 && d <= 3) dueRecv.push(c);
    });
    paid.forEach((c) => {
      const d = J.daysUntil(c.check_date);
      if (d !== null && d >= 0 && d <= 3) duePaid.push(c);
    });
    // فقط برای حسابدار / مدیر / انباردار
    const isAcc = POLICY.is_manager || POLICY.role === "warehouse" || POLICY.role === "accountant" || (POLICY.role_labels && String(POLICY.role).includes("حسابدار"));
    if (!isAcc) return;
    if (dueRecv.length) {
      sysNotify(
        "چک دریافتنی نزدیک سررسید",
        dueRecv.length + " چک مشتری تا ۳ روز دیگر سررسید دارد",
        "check-recv"
      );
    }
    if (duePaid.length) {
      sysNotify(
        "چک پرداختنی نزدیک سررسید",
        duePaid.length + " چک کارگاه تا ۳ روز دیگر سررسید دارد",
        "check-paid"
      );
    }
  }

  // —— تور راهنمای مرحله‌ای ——
  const TOUR_STEPS = [
    { title: "سلام! خوش آمدی 👋", body: "این برنامه مثل یک دفتر بزرگ برای کارگاه است. من قدم‌به‌قدم بهت نشان می‌دهم هر دکمه برای چیست. می‌توانی «رد کردن» را بزنی یا با «بعدی» جلو بروی." },
    { title: "صفحه اول (داشبورد)", body: "اینجا مثل تخته‌سیاه کلاس است. عددهای مهم را یک‌جا می‌بینی. اگر روی یک عدد قرمز کلیک کنی، می‌روی همان بخش را ببینی." },
    { title: "مشتریان", body: "اینجا اسم کسانی را می‌نویسی که از تو کار می‌خرند. مثل دفترچه تلفن دوست‌ها. هر نفر یک صفحه دارد." },
    { title: "تأمین‌کنندگان", body: "اینجا کسانی هستند که جنس به تو می‌فروشند. وقتی در انبار جنس جدید می‌گذاری، از همین لیست یکی را انتخاب می‌کنی. پس اول اینجا اسم‌شان را بنویس." },
    { title: "انبار", body: "اینجا جعبه‌ها و جنس‌هایت هستند. اگر چیزی کم شود، برنامه به تو می‌گوید برو بخر." },
    { title: "پول و چک‌ها", body: "چک‌هایی که مشتری داده قرمز تیره می‌شوند وقتی نزدیک روز نقد شدن باشند. چک‌هایی که تو داده‌ای قرمز روشن می‌شوند. حواست باشد!" },
    { title: "دستورات مدیر", body: "مدیر اینجا برای کارگرها کار تعیین می‌کند. مثل تکلیف مدرسه. کارگر باید انجام دهد و بگوید تمام شد." },
    { title: "تنظیمات خودت", body: "می‌توانی رنگ صفحه و اندازه نوشته را برای خودت عوض کنی. این تنظیمات فقط مال توست و پاک نمی‌شود." },
    { title: "علامت سؤال قرمز ؟", body: "اگر «حالت راهنمای زنده» را روشن کنی، کنار هر باکس یک علامت سؤال قرمز می‌آید. روی آن بزن تا بفهمی آن قسمت چیست — خیلی ساده توضیح می‌دهد!" },
  ];
  let tourIndex = 0;
  function showTourStep(i) {
    tourIndex = i;
    const old = document.getElementById("tour-overlay");
    if (old) old.remove();
    if (i >= TOUR_STEPS.length) {
      PREFS.tourDone = true;
      savePrefs(PREFS);
      showToast("راهنما تمام شد", "هر وقت خواستید دوباره از دکمه ؟ شروع کنید", "ok");
      return;
    }
    const step = TOUR_STEPS[i];
    const ov = document.createElement("div");
    ov.id = "tour-overlay";
    ov.className = "tour-overlay";
    const dots = TOUR_STEPS.map((_, di) => `<span class="tour-step-dot${di === i ? " active" : ""}"></span>`).join("");
    ov.innerHTML = `<div class="tour-card">
      <h3>${step.title}</h3>
      <p>${step.body}</p>
      <div style="margin-bottom:16px">${dots}</div>
      <div class="tour-actions">
        <button type="button" class="btn btn-outline" id="tour-skip">رد کردن همه</button>
        <button type="button" class="btn btn-outline" id="tour-prev" ${i === 0 ? "disabled" : ""}>قبلی</button>
        <button type="button" class="btn" id="tour-next">${i === TOUR_STEPS.length - 1 ? "پایان" : "بعدی"}</button>
      </div>
    </div>`;
    document.body.appendChild(ov);
    ov.querySelector("#tour-skip").onclick = () => {
      PREFS.tourDone = true;
      savePrefs(PREFS);
      ov.remove();
      showToast("راهنما رد شد", "حالت علامت‌سؤال را از تنظیمات یا پایین منو فعال کنید", "info");
    };
    ov.querySelector("#tour-next").onclick = () => showTourStep(i + 1);
    const prev = ov.querySelector("#tour-prev");
    if (prev) prev.onclick = () => showTourStep(Math.max(0, i - 1));
  }
  function startTour() { showTourStep(0); }

  function toggleHelpMode() {
    PREFS.helpMode = !PREFS.helpMode;
    savePrefs(PREFS);
    showToast(PREFS.helpMode ? "حالت راهنما فعال" : "حالت راهنما خاموش", PREFS.helpMode ? "کنار هر بخش علامت ؟ ظاهر می‌شود" : "علامت‌های سؤال مخفی شدند", "info");
    render();
  }

  /** توضیحات خیلی ساده — مثل حرف زدن با بچه هفت‌ساله */
  const HELP_TEXTS = {
    dashboard: "نمای کلی وضعیت کارگاه. آمار حیاتی، هشدارها و موارد نیازمند اقدام در یک صفحه نمایش داده می‌شود. با انتخاب هر شاخص به بخش مرتبط هدایت می‌شوید.",
    customers: "مدیریت مشتریان و پروژه‌ها. امکان ثبت مشتری جدید، پیگیری وضعیت پروژه و مشاهده وضعیت مالی هر مشتری.",
    personnel: "فهرست پرسنل همراه با نقش، شماره تماس، حقوق و مرخصی.\nتوجه: در صورت مرخصی بودن فرد، ردیف مربوطه با رنگ قرمز مشخص می‌شود.",
    finance: "چک دریافتنی/پرداختنی با چرخه کامل، طرف‌حساب، صندوق/بانک، فاکتور فروش، هزینه، درآمد و دریافت/پرداخت. وصول چک به خزانه وصل است.",
    warehouse: "موجودی، مصرف، خرید، حواله بین انبارها و کاردکس ساده کالا.",
    suppliers: "فهرست تأمین‌کنندگان. هنگام ثبت کالا در انبار، تأمین‌کننده از این فهرست انتخاب می‌شود.",
    purchases: "ثبت و پیگیری خریدها شامل کالا، تأمین‌کننده، تعداد و مبلغ.",
    directives: "صدور دستور برای پرسنل و پیگیری وضعیت اجرا. پرسنل می‌توانند وضعیت را به‌روزرسانی کنند.",
    fines: "ثبت جریمه و پاداش پرسنل.",
    salary: "حقوق ماهانه و روز پرداخت. نزدیک بودن سررسید پرداخت در فهرست مشخص می‌شود.",
    settings: "تنظیمات عمومی کارگاه (نام، لوگو) و تنظیمات شخصی رابط کاربری (تم و اندازه متن).",
    roles: "تعریف نقش‌ها و سطح دسترسی منوها برای هر نقش.",
    leave: "درخواست و تأیید مرخصی. پرسنل در حال مرخصی در فهرست با رنگ قرمز نمایش داده می‌شوند.",
    overtime: "ثبت و تأیید اضافه‌کاری پرسنل.",
    stock_usage: "اعلام مصرف کالا از انبار یا بازگشت کالا به انبار.",
    chat_history: "مشاهده و جستجوی تاریخچه پیام‌های چت — ویژه مدیر.",
    checks_received: "چک‌های دریافتی از مشتری. تا سه روز قبل از سررسید با رنگ قرمز تیره مشخص می‌شوند.",
    checks_paid: "چک‌های پرداختی کارگاه. تا سه روز قبل از سررسید با رنگ قرمز روشن مشخص می‌شوند.",
    stat: "شاخص آماری وضعیت کارگاه. با انتخاب آن به بخش مرتبط می‌روید. مدیر مجموعه: ۳ ثانیه روی باکس نگه دارید تا بتوانید ترتیب را جابه‌جا کنید.",
    table: "جدول داده‌ها. امکان افزودن، ویرایش و بایگانی رکوردها.",
    add_btn: "افزودن رکورد جدید.",
    search: "جستجو در فهرست و جداول.",
    theme: "تغییر حالت نمایش: روشن، تیره یا شب.",
    menu: "فهرست بخش‌های پنل. هر کاشی یک بخش جداگانه است.",
    menu_order: "ترتیب منوی کناری را فقط برای خودتان جابه‌جا کنید. روی دیگران اثر ندارد.",
  };

  function closeHelpPopover() {
    const old = document.getElementById("help-popover");
    if (old) old.remove();
  }

  function showHelpPopover(btn, text, title) {
    closeHelpPopover();
    const pop = document.createElement("div");
    pop.id = "help-popover";
    pop.className = "help-popover";
    pop.innerHTML = `<button type="button" class="help-popover-close" aria-label="بستن">×</button>
      <div class="help-popover-title">❓ ${title || "این چیه؟"}</div>
      <div>${text}</div>`;
    document.body.appendChild(pop);
    const r = btn.getBoundingClientRect();
    let top = r.bottom + 8;
    let left = r.left;
    if (left + 300 > window.innerWidth) left = window.innerWidth - 310;
    if (left < 8) left = 8;
    if (top + 160 > window.innerHeight) top = r.top - 160;
    if (top < 8) top = 8;
    pop.style.top = top + "px";
    pop.style.left = left + "px";
    pop.querySelector(".help-popover-close").onclick = closeHelpPopover;
    const closer = (e) => {
      if (!pop.contains(e.target) && e.target !== btn) {
        closeHelpPopover();
        document.removeEventListener("click", closer);
      }
    };
    setTimeout(() => document.addEventListener("click", closer), 50);
  }

  function makeHelpBtn(key, extra, title) {
    const q = document.createElement("button");
    q.type = "button";
    q.className = "help-q";
    q.textContent = "؟";
    q.setAttribute("aria-label", "توضیح");
    q.title = "کلیک کن تا بفهمی این چیه";
    q.onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      const text = extra || HELP_TEXTS[key] || "این یک قسمت از برنامه است. باهاش کار می‌کنی تا کارگاه را مدیریت کنی.";
      showHelpPopover(q, text, title || "این چیه؟");
    };
    return q;
  }

  function attachHelpQ(el, key, extra) {
    if (!PREFS.helpMode || !el) return;
    if (el.querySelector && el.querySelector(":scope > .help-q, .help-q")) return;
    const q = makeHelpBtn(key, extra);
    if (el.tagName === "H2") {
      const span = el.querySelector("span") || el;
      if (span !== el && span.firstChild) span.insertBefore(q, span.firstChild);
      else el.insertBefore(q, el.firstChild);
    } else {
      el.style.position = el.style.position || "relative";
      el.appendChild(q);
    }
  }

  /** بعد از هر رندر: روی همه کارت‌ها، استت‌ها، عناوین و منو علامت قرمز بگذار */
  function injectHelpIcons() {
    closeHelpPopover();
    document.querySelectorAll(".help-q").forEach((el) => el.remove());
    if (!PREFS.helpMode) {
      const hm = document.getElementById("btn-help-mode");
      if (hm) hm.classList.remove("btn-help-mode-active");
      return;
    }
    const hm = document.getElementById("btn-help-mode");
    if (hm) hm.classList.add("btn-help-mode-active");

    // کارت‌ها
    document.querySelectorAll("#content .card").forEach((card) => {
      if (card.querySelector(":scope > .help-q")) return;
      const h2 = card.querySelector("h2");
      let key = "table";
      const txt = ((h2 && h2.textContent) || "").toLowerCase();
      if (txt.includes("چک") || txt.includes("مالی") || txt.includes("خلاصه")) key = "finance";
      else if (txt.includes("انبار") || txt.includes("موجودی")) key = "warehouse";
      else if (txt.includes("تأمین") || txt.includes("تامین")) key = "suppliers";
      else if (txt.includes("مشتری")) key = "customers";
      else if (txt.includes("پرسنل") || txt.includes("کارمند")) key = "personnel";
      else if (txt.includes("دستور")) key = "directives";
      else if (txt.includes("حقوق")) key = "salary";
      else if (txt.includes("مرخصی")) key = "leave";
      else if (txt.includes("اضافه")) key = "overtime";
      else if (txt.includes("خرید")) key = "purchases";
      else if (txt.includes("جریمه") || txt.includes("پاداش")) key = "fines";
      else if (txt.includes("تنظیمات") || txt.includes("شخصی")) key = "settings";
      else if (txt.includes("نقش")) key = "roles";
      else if (txt.includes("مصرفی") || txt.includes("بازگشت")) key = "stock_usage";
      const q = makeHelpBtn(key);
      card.style.position = "relative";
      card.appendChild(q);
    });

    // استت‌ها (کارت‌های عددی)
    document.querySelectorAll("#content .stat").forEach((st) => {
      if (st.querySelector(".help-q")) return;
      const label = (st.querySelector("span") && st.querySelector("span").textContent) || "";
      let extra = HELP_TEXTS.stat;
      if (label.includes("سررسید") && label.includes("مشتری")) extra = "این تعداد چک‌هایی است که مشتری داده و تا ۳ روز دیگر باید نقد شوند. قرمز یعنی حواست باشد!";
      else if (label.includes("سررسید") && label.includes("کارگاه")) extra = "این تعداد چک‌هایی است که تو داده‌ای و تا ۳ روز دیگر باید پرداخت شوند.";
      else if (label.includes("در انتظار")) extra = "چیزهایی که هنوز تأیید نشده‌اند. باید یکی تصمیم بگیرد قبول است یا نه.";
      else if (label.includes("کمبود")) extra = "جنس‌هایی که در انبار کم شده‌اند. وقت خرید دوباره است.";
    const q = makeHelpBtn("stat", st.dataset.help || extra, label || "عدد مهم");
      st.style.position = "relative";
      st.appendChild(q);
    });

    // آیتم‌های منو
    document.querySelectorAll("#nav a").forEach((a) => {
      if (a.querySelector(".help-q")) return;
      const id = a.dataset.m || "";
      const q = makeHelpBtn(id, HELP_TEXTS[id] || HELP_TEXTS.menu, a.dataset.label || "منو");
      a.appendChild(q);
    });
  }

  // —— جستجوی فازی فارسی (حیدر / در / عل → علی حیدری) ——
  function fuzzyMatch(query, text) {
    if (!query) return true;
    const q = String(query).trim().toLowerCase().replace(/ي/g, "ی").replace(/ك/g, "ک");
    const t = String(text).toLowerCase().replace(/ي/g, "ی").replace(/ك/g, "ک");
    if (t.includes(q)) return true;
    // تطبیق حرف‌به‌حرف پشت‌سرهم
    let i = 0;
    for (const ch of t) {
      if (ch === q[i]) i++;
      if (i >= q.length) return true;
    }
    return false;
  }

  function createCombo(name, options, currentVal, isObjectOptions) {
    const wrap = document.createElement("div");
    wrap.className = "combo-wrap";
    const inp = document.createElement("input");
    inp.type = "text";
    inp.className = "combo-input";
    inp.name = name;
    inp.autocomplete = "off";
    inp.placeholder = "جستجو یا انتخاب...";
    if (isObjectOptions) {
      const found = (options || []).find((o) => String(o.v) === String(currentVal));
      inp.value = found ? found.l : (currentVal || "");
      inp.dataset.value = currentVal || "";
    } else {
      inp.value = currentVal || "";
    }
    const list = document.createElement("div");
    list.className = "combo-list";

    function closeList() {
      list.classList.remove("open");
      wrap.classList.remove("combo-open");
      list.innerHTML = "";
    }

    function renderList(filter) {
      list.innerHTML = "";
      const opts = options || [];
      let shown = 0;
      opts.forEach((o) => {
        const label = isObjectOptions ? o.l : o;
        const val = isObjectOptions ? o.v : o;
        if (filter && !fuzzyMatch(filter, label)) return;
        const item = document.createElement("div");
        item.className = "combo-item";
        item.textContent = label;
        item.dataset.val = val;
        item.onmousedown = (e) => {
          e.preventDefault();
          e.stopPropagation();
          if (isObjectOptions) {
            inp.value = label;
            inp.dataset.value = val;
          } else {
            inp.value = label;
          }
          closeList();
          inp.blur();
        };
        list.appendChild(item);
        shown++;
      });
      if (!shown) {
        const empty = document.createElement("div");
        empty.className = "combo-empty";
        empty.textContent = filter ? "موردی یافت نشد — می‌توانید تایپ کنید" : "لیست خالی است — تایپ کنید";
        list.appendChild(empty);
      }
      list.classList.add("open");
      wrap.classList.add("combo-open");
    }

    inp.onfocus = () => renderList(inp.value);
    inp.oninput = () => {
      if (isObjectOptions) inp.dataset.value = "";
      renderList(inp.value);
    };
    inp.onblur = () => setTimeout(closeList, 180);
    // بستن با کلیک بیرون
    document.addEventListener("mousedown", (ev) => {
      if (!wrap.contains(ev.target)) closeList();
    });
    wrap.appendChild(inp);
    wrap.appendChild(list);
    return wrap;
  }

  let openMenuGroup = null; // گروه بازشده در منو (مثل دسته‌های آچاره)

  function goMenu(id) {
    if (!id) return;
    // گروه منو → صفحه دسته‌بندی (مثل آچاره)، نه کشوی زیر منو
    if (MENU_GROUPS[id] && !String(id).startsWith("cat:")) {
      if (id !== menu) {
        menuHistory.push(menu);
        if (menuHistory.length > 20) menuHistory.shift();
      }
      menu = "cat:" + id;
      openMenuGroup = null;
      if (!(window.matchMedia && window.matchMedia("(min-width: 801px)").matches)) {
        closeDrawer();
      }
      renderNav();
      renderBottomNav();
      render();
      return;
    }
    if (id !== menu) {
      menuHistory.push(menu);
      if (menuHistory.length > 20) menuHistory.shift();
    }
    menu = id;
    openMenuGroup = null;
    if (!(window.matchMedia && window.matchMedia("(min-width: 801px)").matches)) {
      closeDrawer();
    }
    renderNav();
    renderBottomNav();
    const heavyMenus = ["warehouse", "stock_usage", "purchases", "finance", "customers", "personnel"];
    if (heavyMenus.includes(menu)) {
      reloadForMenu(menu).then(() => render());
    } else {
      render();
    }
  }

  function renderNav() {
    const nav = document.getElementById("nav");
    if (!nav) return;
    const list = menus();
    const parts = [];
    const currentCat = String(menu).startsWith("cat:") ? menu.slice(4) : "";
    list.forEach((m) => {
      const icon = (MENU_GROUPS[m.id] && MENU_GROUPS[m.id].icon) || MENU_ICONS[m.id] || "◆";
      const c = MENU_COLORS[m.id] || "blue";
      const isGroup = !!(MENU_GROUPS[m.id]);
      const kids = isGroup ? groupChildren(m.id) : [];
      const active = (!isGroup && m.id === menu) || (isGroup && (currentCat === m.id || kids.includes(menu) || (m.keepSelf && m.id === menu))) ? "active" : "";
      // گروه: کلیک → صفحه دسته، بدون باز شدن زیرمنو در سایدبار
      if (isGroup) {
        parts.push(`<a href="#" data-m="${m.id}" class="nav-group ${active}" data-label="${m.label}" data-c="${c}" style="position:relative"><span class="nav-icon">${icon}</span><span class="nav-label">${m.label}</span></a>`);
      } else {
        parts.push(`<a href="#" data-m="${m.id}" class="${active}" data-label="${m.label}" data-c="${c}" style="position:relative"><span class="nav-icon">${icon}</span><span class="nav-label">${m.label}</span></a>`);
      }
    });
    nav.innerHTML = parts.join("");
    nav.querySelectorAll("a").forEach((a) => {
      a.onclick = (e) => {
        if (e.target && e.target.classList && e.target.classList.contains("help-q")) return;
        e.preventDefault();
        if (a.dataset.m) goMenu(a.dataset.m);
      };
    });
    filterMenuSearch();
    if (PREFS.helpMode) setTimeout(injectHelpIcons, 30);
  }

  function getBottomNavItems() {
    let items = Array.isArray(PREFS.bottomNav) && PREFS.bottomNav.length
      ? PREFS.bottomNav.slice(0, 5)
      : DEFAULT_BOTTOM_NAV.slice();
    // پرسنل: ناوبری ساده‌تر
    if (POLICY.is_employee || POLICY.role === "employee") {
      items = ["emp_dashboard", "emp_tasks", "emp_attendance", "emp_messages", "emp_leave"].filter((id) => MENU_LABELS[id] || MENU_GROUPS[id]);
    }
    return items.slice(0, 5);
  }

  function renderBottomNav() {
    let bar = document.getElementById("bottom-nav");
    if (!bar) {
      bar = document.createElement("nav");
      bar.id = "bottom-nav";
      bar.className = "bottom-nav";
      bar.setAttribute("aria-label", "ناوبری اصلی");
      document.body.appendChild(bar);
    }
    const items = getBottomNavItems();
    bar.innerHTML = items.map((id) => {
      const g = MENU_GROUPS[id];
      const label = (g && g.label) || MENU_LABELS[id] || id;
      const icon = (g && g.icon) || MENU_ICONS[id] || "◆";
      const kids = g ? groupChildren(id) : [];
      const active = menu === id || kids.includes(menu) ? "active" : "";
      return `<a href="#" data-bn="${id}" class="${active}"><span class="bn-icon">${icon}</span><span class="bn-label">${label}</span></a>`;
    }).join("");
    bar.querySelectorAll("a").forEach((a) => {
      a.onclick = (e) => {
        e.preventDefault();
        const id = a.dataset.bn;
        goMenu(id);
      };
    });
  }

  function openDrawer() {
    const d = document.getElementById("drawer");
    const o = document.getElementById("drawer-overlay");
    if (d) { d.classList.add("open"); d.setAttribute("aria-hidden", "false"); }
    if (o) { o.classList.add("open"); o.setAttribute("aria-hidden", "false"); }
    document.body.classList.add("drawer-open");
    // قفل اسکرول فقط وقتی منوی موبایل باز است
    const mobile = !(window.matchMedia && window.matchMedia("(min-width: 801px)").matches);
    if (mobile) {
      document.body.style.overflow = "hidden";
      document.documentElement.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
      document.documentElement.style.overflow = "";
    }
    const s = document.getElementById("menu-search");
    if (s) { s.value = ""; filterMenuSearch(); setTimeout(() => s.focus(), 200); }
  }

  function closeDrawer() {
    const d = document.getElementById("drawer");
    const o = document.getElementById("drawer-overlay");
    if (d) { d.classList.remove("open"); d.setAttribute("aria-hidden", "true"); }
    if (o) { o.classList.remove("open"); o.setAttribute("aria-hidden", "true"); }
    document.body.classList.remove("drawer-open");
    document.body.style.overflow = "";
    document.documentElement.style.overflow = "";
  }

  function normFa(s) {
    return String(s || "")
      .toLowerCase()
      .replace(/ي/g, "ی").replace(/ك/g, "ک")
      .replace(/\u200c/g, "")
      .replace(/\s+/g, " ")
      .trim();
  }
  function filterMenuSearch() {
    const s = document.getElementById("menu-search");
    const q = normFa(s && s.value ? s.value : "");
    document.querySelectorAll("#nav a, .drawer-nav-grid a").forEach((a) => {
      const label = normFa(a.dataset.label || "");
      const id = normFa(a.dataset.m || "");
      const text = normFa((a.querySelector(".nav-label") || {}).textContent || a.textContent || "");
      const show = !q || label.indexOf(q) !== -1 || id.indexOf(q) !== -1 || text.indexOf(q) !== -1;
      a.classList.toggle("hidden-menu", !show);
      if (show) {
        a.style.removeProperty("display");
      } else {
        a.style.setProperty("display", "none", "important");
      }
    });
  }

  function applyTheme(mode) {
    let m = mode || "light";
    if (m === "classic" || m === "beta" || m === "night") m = (m === "night" ? "dark" : "light");
    if (m !== "dark") m = "light";
    PREFS.theme = m;
    savePrefs(PREFS);
    applyPrefs();
  }

  function initTheme() {
    try {
      const old = localStorage.getItem("samaneh_theme");
      if (old && !localStorage.getItem(PREFS_KEY)) {
        PREFS.theme = old === "dark" ? "dark" : "light";
        savePrefs(PREFS);
      }
    } catch (e) {}
    if (PREFS.theme === "classic" || PREFS.theme === "beta" || PREFS.theme === "night") {
      PREFS.theme = PREFS.theme === "night" ? "dark" : "light";
    }
    if (PREFS.theme !== "dark") PREFS.theme = "light";
    applyPrefs();
  }

  function toggleTheme() {
    const cur = PREFS.theme === "dark" ? "dark" : "light";
    applyTheme(cur === "dark" ? "light" : "dark");
  }


  
  async function saveMotherWarehouses(list) {
    list = (list || []).map((x) => String(x || "").trim()).filter(Boolean);
    if (!S.settings) S.settings = {};
    S.settings.warehouse_mothers = list;
    try {
      const res = await api("settings", { payload: { warehouse_mothers: list } });
      if (res && res.ok) return true;
    } catch (e) {}
    return false;
  }

function getMotherWarehouses() {
    let list = [];
    try {
      if (S.settings && S.settings.warehouse_mothers) {
        const raw = S.settings.warehouse_mothers;
        list = typeof raw === "string" ? JSON.parse(raw) : raw;
      }
    } catch (e) {}
    if (!Array.isArray(list)) list = [];
    // فقط نام‌هایی که مدیر خودش ذخیره کرده — هیچ پیش‌فرضی نداریم
    return list.map((x) => String(x || "").trim()).filter(Boolean);
  }

  function mothersConfigured() {
    return getMotherWarehouses().length > 0;
  }

  function canManageStock() {
    return !!(POLICY.is_manager || POLICY.role === "warehouse" || POLICY.role === "accountant" ||
      (POLICY.role_labels && /حسابدار|انبار/.test(String(POLICY.role_labels[POLICY.role] || POLICY.role || ""))));
  }

  function openModal(table, row) {
    editTable = table;
    editId = row && row.id ? Number(row.id) : 0;
    let fields = FIELDS[table] || [];
    // پرسنل در گزارش روزانه فقط خودش
    if (POLICY.is_employee && table === "daily_reports") {
      fields = fields.filter((f) => f !== "personnel_name");
    }
    if ((POLICY.is_employee || !POLICY.is_manager) && ["leave_requests", "overtime", "attendance", "stock_usage"].includes(table)) {
      fields = fields.filter((f) => f !== "personnel_name");
    }
    // مرخصی: بدون وضعیت — نوع اول + بابت (تکست‌باکس آزاد)
    if (table === "leave_requests") {
      const order = ["leave_type", "from_date", "to_date", "hours", "reason"];
      if (POLICY.is_manager) order.push("personnel_name");
      fields = order.slice();
    }
    // اعلام مصرفی: پروژه، کالا، تعداد، واحد مصرف (دو واحدی)، نوع (برداشت/بازگشت)
    if (table === "stock_usage") {
      const order = ["kind", "project", "item_name", "qty", "unit", "notes", "used_at"];
      if (POLICY.is_manager) order.push("personnel_name");
      fields = order.slice();
    }
    if (table === "cash_boxes") { fields = ["name", "opening_balance", "notes"]; }
    if (table === "bank_accounts") { fields = ["name", "bank_name", "account_no", "shaba", "opening_balance", "notes"]; }
    if (table === "expenses") { fields = ["title", "category", "amount", "expense_date", "account_type", "account_name", "party_name", "notes", "photo"]; }
    if (table === "incomes") { fields = ["title", "category", "amount", "income_date", "account_type", "account_name", "party_name", "notes", "photo"]; }
    if (table === "sales_invoices") { fields = ["customer_name", "invoice_date", "invoice_no", "warehouse", "subtotal", "discount", "total", "paid_amount", "status", "items_json", "notes"]; }
    if (table === "stock_transfers") { fields = ["item_name", "qty", "unit", "from_warehouse", "to_warehouse", "transfer_date", "notes", "personnel_name"]; }
    if (table === "account_payments") { fields = ["direction", "method", "account_name", "person_type", "person_name", "amount", "pay_date", "notes"]; }
    if (table === "checks_received") {
      const order = ["name", "check_date", "amount", "bank", "num", "payee", "for_what", "check_status", "note", "photo"];
      fields = order.filter((f) => (FIELDS[table] || []).includes(f) || true);
      // keep only known fields that exist in FIELDS or always
      fields = order;
    }
    if (table === "checks_paid") {
      fields = ["name", "payee", "check_date", "amount", "bank", "num", "shaba", "check_status", "description", "photo"];
    }
    if (table === "directives") {

      const order = ["title", "body", "target_name", "target_role", "project", "priority", "due_date", "reminder_count", "reminder_interval", "reminder_unit", "status", "attachment"];
      fields = order.filter((f) => (FIELDS[table] || []).includes(f) || ["attachment", "reminder_interval", "reminder_unit"].includes(f));
    }
    // مشتری: وضعیت‌های پروژه + فایل طراحی
    if (table === "customers") {
      if (!editId) {
        // افزودن مشتری جدید: فقط نام، آدرس، شماره تماس (طبق مستند)
        fields = ["name", "phone", "address"];
      } else {
        const order = ["name", "phone", "password", "address", "status", "project_amount", "balance", "installer", "design_files", "note", "sub_stage"];
        fields = order.filter((f) => (FIELDS[table] || []).includes(f) || f === "design_files" || f === "sub_stage");
      }
    }
    // پرسنل: نام، نقش، موبایل، رمز — برای ورود الزامی (بدون وردپرس)
    if (table === "personnel") {
      const order = ["name", "role", "phone", "password", "leave_days", "salary_amount", "salary_day", "bank_card", "bank_shaba", "start_date", "notes"];
      fields = order.filter((f) => (FIELDS[table] || []).includes(f) && f !== "is_main" && f !== "wp_user_id");
    }
    // حضور: ورود و خروج جداگانه ثبت می‌شوند
    if (table === "attendance") {
      const order = ["att_type", "att_time", "att_date", "notes"];
      if (POLICY.is_manager) order.unshift("personnel_name");
      fields = order.slice();
    }
    // اضافه‌کاری: از ساعت / تا ساعت (بدون فیلد ساعت عددی در افزودن)
    if (table === "overtime") {
      const order = ["project", "from_time", "to_time", "reason", "ot_date", "notes"];
      if (POLICY.is_manager) order.unshift("personnel_name");
      if (editId && (POLICY.is_manager || POLICY.role === "warehouse")) order.push("status");
      fields = order.slice();
    }
    document.getElementById("modal-title").textContent = editId ? "ویرایش" : "افزودن";
    const form = document.getElementById("modal-form");
    form.innerHTML = "";
    if (table === "stock_items") {
      if (!canManageStock() && !row) {
        alert("فقط مدیر، حسابدار و انباردار می‌توانند کالا اضافه کنند.");
        closeModal();
        return;
      }
      if (!mothersConfigured() && !row) {
        alert("ابتدا در صفحه انبار، نام انبارهای مادر را تعریف کنید.");
        closeModal();
        return;
      }
      const mt = document.getElementById("modal-title");
      if (mt) mt.textContent = row ? "ویرایش کالا" : "افزودن کالا به انبار";
      buildStockItemForm(form, row || null);
      document.getElementById("modal").classList.remove("hidden");
      return;
    }


    function toggleLeaveFields() {
      const typeSel = form.querySelector('[name="leave_type"]');
      const type = typeSel ? typeSel.value : "روزانه";
      const hourField = form.querySelector('[data-leave-field="hours"]');
      const toDateField = form.querySelector('[data-leave-field="to_date"]');
      if (hourField) hourField.style.display = type === "ساعتی" ? "" : "none";
      if (toDateField) toDateField.style.display = type === "ساعتی" ? "none" : "";
      // ساعتی: فقط یک تاریخ (from_date) + ساعت
      const fromLabel = form.querySelector('[data-leave-field="from_date"] label');
      if (fromLabel) fromLabel.textContent = type === "ساعتی" ? "تاریخ" : "از تاریخ";
    }

    fields.forEach((f) => {
      if (f === "wp_user_id") return;
      const val = row && row[f] != null ? row[f] : "";
      const wrap = document.createElement("div");
      wrap.className = "field";
      if (table === "leave_requests" && ["hours", "to_date", "from_date"].includes(f)) {
        wrap.setAttribute("data-leave-field", f);
      }
      wrap.innerHTML = `<label>${LABELS[f] || f}</label>`;

      // انبار در خرید: فقط انبارهای مجاز کاربر
      if (f === "warehouse" && table === "purchases") {
        let opts = getMotherWarehouses().slice();
        (S.stock_items || []).forEach((i) => {
          const c = i.category || i.warehouse || "";
          if (c && !opts.includes(c)) opts.push(c);
        });
        if (!opts.length) opts = getMotherWarehouses().length ? getMotherWarehouses() : ["انبار"];
        const allowed = POLICY.my_warehouses || [];
        if (allowed.length && !allowed.includes("*")) {
          opts = opts.filter((w) => allowed.includes(w));
          if (!opts.length) opts = allowed.slice();
        }
        if (POLICY.is_manager) opts.push("+ انبار جدید...");
        const combo = createCombo(f, opts, val || opts[0] || (opts[0] || ""), false);
        wrap.appendChild(combo);
        form.appendChild(wrap);
        return;
      }

      // Combo searchable
      if (COMBO_FIELDS[f] && f !== "role") {
        const opts = COMBO_FIELDS[f]();
        const isObj = f === "role";
        const combo = createCombo(f, opts, val, isObj);
        if (POLICY.is_employee && f === "personnel_name" && !val) {
          combo.querySelector("input").value = USER.name || "";
        }
        wrap.appendChild(combo);
        form.appendChild(wrap);
        return;
      }

      // نوع چک / خرید دین
      if ((table === "checks_received" || table === "checks_paid") && f === "kind") {
        const sel = document.createElement("select");
        sel.name = f;
        (SELECTS.check_kind ? SELECTS.check_kind() : [{v:"check",l:"چک"},{v:"خرید دین",l:"خرید دین"}]).forEach((o) => {
          const opt = document.createElement("option");
          opt.value = o.v; opt.textContent = o.l;
          if (String(val) === String(o.v)) opt.selected = true;
          sel.appendChild(opt);
        });
        wrap.appendChild(sel);
        form.appendChild(wrap);
        return;
      }
      // وضعیت مشتری: مشتریان جدید (قبل اجرا) / در حال تولید / در حال نصب / تحویل داده شده
      if (table === "customers" && f === "status") {
        const sel = document.createElement("select");
        sel.name = f;
        let cur = val || "مشتریان جدید";
        if (CUSTOMER_STATUS_MAP[cur]) cur = CUSTOMER_STATUS_MAP[cur];
        CUSTOMER_STATUSES.forEach((o) => {
          const opt = document.createElement("option");
          opt.value = o.v;
          opt.textContent = o.l;
          if (String(cur) === String(o.v)) opt.selected = true;
          sel.appendChild(opt);
        });
        wrap.appendChild(sel);
        form.appendChild(wrap);
        return;
      }
      // فایل‌های طراحی مشتری
      if (table === "customers" && f === "design_files") {
        const hint = document.createElement("div");
        hint.className = "hint";
        hint.textContent = "فایل‌های طراحی برای مرحله بعد (تولید/نصب). می‌توانید چند فایل اضافه کنید.";
        wrap.appendChild(hint);
        // لیست فایل‌های فعلی
        let files = [];
        try {
          if (val) files = typeof val === "string" ? JSON.parse(val) : (Array.isArray(val) ? val : []);
        } catch (e) { files = []; }
        if (!Array.isArray(files)) files = [];
        const list = document.createElement("div");
        list.className = "design-files-list";
        list.style.cssText = "margin:8px 0;display:flex;flex-direction:column;gap:6px";
        function redrawFiles() {
          list.innerHTML = files.map((u, i) => {
            const name = String(u).split("/").pop() || u;
            return `<div style="display:flex;align-items:center;gap:8px;font-size:.9rem">
              <a href="${u}" target="_blank" rel="noopener">${name}</a>
              <button type="button" class="btn btn-sm btn-danger" data-rm-df="${i}">حذف</button>
            </div>`;
          }).join("") || '<span class="hint">هنوز فایلی نیست</span>';
          list.querySelectorAll("[data-rm-df]").forEach((btn) => {
            btn.onclick = () => {
              files.splice(Number(btn.dataset.rmDf), 1);
              hidden.value = JSON.stringify(files);
              redrawFiles();
            };
          });
        }
        const hidden = document.createElement("input");
        hidden.type = "hidden";
        hidden.name = "design_files";
        hidden.value = JSON.stringify(files);
        wrap.appendChild(hidden);
        wrap.appendChild(list);
        redrawFiles();
        const up = document.createElement("input");
        up.type = "file";
        up.accept = ".pdf,.jpg,.jpeg,.png,.dwg,.dxf,.zip,.rar,image/*,application/pdf";
        up.multiple = true;
        up.style.marginTop = "8px";
        up.onchange = async () => {
          if (!up.files || !up.files.length) return;
          for (let i = 0; i < up.files.length; i++) {
            const fd = new FormData();
            fd.append("action", "upload");
            fd.append("_wpnonce", CSRF);
            fd.append("instance", String(INSTANCE_ID));
            fd.append("file", up.files[i]);
            fd.append("table", "photos");
            fd.append("payload", JSON.stringify({ project: (row && row.name) || "", stage: "design", caption: "فایل طراحی" }));
            const res = await fetch(API + (API.includes("?") ? "&" : "?") + "action=upload", { method: "POST", body: fd, credentials: "same-origin" }).then((r) => r.json());
            if (res.ok && res.data && (res.data.url || (res.data.filename && window.UPLOADS))) {
              const url = res.data.url || (window.UPLOADS + res.data.filename);
              files.push(url);
            } else {
              alert(res.error || "خطا در آپلود فایل");
            }
          }
          hidden.value = JSON.stringify(files);
          redrawFiles();
          up.value = "";
        };
        wrap.appendChild(up);
        form.appendChild(wrap);
        return;
      }
      // بابت در مرخصی = تکست‌باکس آزاد؛ در اضافه‌کاری = لیست تولید/نصب/تخلیه
      if (SELECTS[f] && !(table === "leave_requests" && f === "reason")) {
        const sel = document.createElement("select");
        sel.name = f;
        SELECTS[f]().forEach((o) => {
          const opt = document.createElement("option");
          opt.value = o.v;
          opt.textContent = o.l;
          if (String(val) === String(o.v)) opt.selected = true;
          sel.appendChild(opt);
        });
        wrap.appendChild(sel);
      } else if (table === "leave_requests" && f === "reason") {
        const ta = document.createElement("textarea");
        ta.name = f;
        ta.value = val || "";
        ta.placeholder = "بابت مرخصی را بنویسید...";
        ta.style.minHeight = "70px";
        wrap.appendChild(ta);
      } else if (f === "attachment") {
        const file = document.createElement("input");
        file.type = "file";
        file.name = "attachment_file";
        file.accept = "*/*";
        const hint = document.createElement("div");
        hint.className = "hint";
        hint.textContent = "فایل پیوست دستور (اختیاری)";
        if (val) {
          const prev = document.createElement("div");
          prev.innerHTML = `<a href="${val}" target="_blank">فایل فعلی</a>`;
          wrap.appendChild(prev);
        }
        const hidden = document.createElement("input");
        hidden.type = "hidden";
        hidden.name = "attachment";
        hidden.value = val || "";
        wrap.appendChild(hidden);
        wrap.appendChild(file);
        wrap.appendChild(hint);
        form.appendChild(wrap);
        return;
      } else if (f === "photo") {
        const file = document.createElement("input");
        file.type = "file";
        file.name = "photo";
        file.accept = "image/*";
        const hint = document.createElement("div");
        hint.className = "hint";
        hint.style.marginTop = "4px";
        hint.textContent = "تصویر گزارش را آپلود کنید (نه تایپ).";
        wrap.appendChild(file);
        wrap.appendChild(hint);
        if (val) {
          const prev = document.createElement("div");
          prev.style.marginTop = "6px";
          prev.innerHTML = `<a href="${val}" target="_blank">تصویر فعلی</a>`;
          wrap.appendChild(prev);
        }
      } else if (["notes", "note", "body", "reason", "address", "description", "for_what"].includes(f)) {
        const ta = document.createElement("textarea");
        ta.name = f; ta.value = val; wrap.appendChild(ta);
      } else if (DATE_FIELDS.includes(f)) {
        const rowEl = document.createElement("div");
        rowEl.className = "date-row";
        const inp = document.createElement("input");
        inp.name = f;
        inp.type = "text";
        inp.className = "date-field";
        inp.readOnly = true;
        inp.style.cursor = "pointer";
        inp.placeholder = "انتخاب از تقویم";
        let d = String(val || "");
        if (!d && typeof J !== "undefined") d = J.todayStr();
        inp.value = d;
        rowEl.appendChild(inp);
        const todayBtn = document.createElement("button");
        todayBtn.type = "button";
        todayBtn.className = "btn btn-sm btn-outline";
        todayBtn.textContent = "امروز";
        todayBtn.onclick = () => { inp.value = J.todayStr(); };
        rowEl.appendChild(todayBtn);
        const pickBtn = document.createElement("button");
        pickBtn.type = "button";
        pickBtn.className = "btn btn-sm btn-outline";
        pickBtn.textContent = "انتخاب";
        const openDatePick = () => {
          const parts = (inp.value || J.todayStr()).split("/");
          let y = parseInt(parts[0], 10) || 1404;
          let m = parseInt(parts[1], 10) || 1;
          let day = parseInt(parts[2], 10) || 1;
          const ny = prompt("سال شمسی:", y);
          if (ny === null) return;
          const nm = prompt("ماه (۱–۱۲):", m);
          if (nm === null) return;
          const nd = prompt("روز:", day);
          if (nd === null) return;
          inp.value = String(ny).padStart(4, "0") + "/" + String(nm).padStart(2, "0") + "/" + String(nd).padStart(2, "0");
        };
        pickBtn.onclick = openDatePick;
        inp.onclick = openDatePick;
        rowEl.appendChild(pickBtn);
        wrap.appendChild(rowEl);
      } else if (TIME_FIELDS.includes(f)) {
        const rowEl = document.createElement("div");
        rowEl.className = "time-row";
        const inp = document.createElement("input");
        inp.name = f;
        inp.type = "text";
        inp.className = "time-field";
        inp.readOnly = true;
        inp.style.cursor = "pointer";
        inp.placeholder = "انتخاب ساعت";
        let t = String(val || "");
        if (!t) t = J.nowTime24();
        // اطمینان از فرمت ۲۴ ساعته
        if (t && t.includes(" ")) t = t.split(" ").pop().slice(0, 5);
        inp.value = t;
        rowEl.appendChild(inp);
        const nowBtn = document.createElement("button");
        nowBtn.type = "button";
        nowBtn.className = "btn btn-sm btn-outline";
        nowBtn.textContent = "الان";
        nowBtn.onclick = () => { inp.value = J.nowTime24(); };
        rowEl.appendChild(nowBtn);
        const pickBtn = document.createElement("button");
        pickBtn.type = "button";
        pickBtn.className = "btn btn-sm btn-outline";
        pickBtn.textContent = "انتخاب";
        pickBtn.onclick = () => {
          const h = prompt("ساعت (۰–۲۳):", (inp.value || "12").split(":")[0]);
          if (h === null) return;
          const m = prompt("دقیقه (۰–۵۹):", (inp.value || "00").split(":")[1] || "00");
          if (m === null) return;
          inp.value = String(Math.min(23, Math.max(0, parseInt(h, 10) || 0))).padStart(2, "0") + ":" +
            String(Math.min(59, Math.max(0, parseInt(m, 10) || 0))).padStart(2, "0");
        };
        rowEl.appendChild(pickBtn);
        wrap.appendChild(rowEl);
      } else {
        const inp = document.createElement("input");
        inp.name = f;
        if (f === "password") {
          inp.type = "password";
          inp.value = "";
          inp.placeholder = val === "********" || val ? "برای تغییر رمز، رمز جدید وارد کنید" : "رمز ورود با موبایل";
          inp.autocomplete = "new-password";
        } else if (MONEY_FIELDS.includes(f)) {
          inp.type = "text";
          inp.inputMode = "numeric";
          inp.value = val !== "" && val != null ? fmtMoney(val) : "";
          inp.placeholder = "مثال: ۱,۵۰۰,۰۰۰";
          inp.addEventListener("blur", () => {
            const n = Number(String(inp.value).replace(/[,،\s]/g, ""));
            if (!isNaN(n) && inp.value !== "") inp.value = n.toLocaleString("en-US");
          });
          inp.addEventListener("focus", () => {
            inp.value = String(inp.value).replace(/,/g, "");
          });
        } else {
          inp.value = val;
          if (["leave_days", "hours", "reminder_count", "qty", "min_qty"].includes(f)) inp.type = "number";
        }
        wrap.appendChild(inp);
      }
      form.appendChild(wrap);
    });
    document.getElementById("modal").classList.remove("hidden");
    if (table === "directives" && !editId) {
      const pr = form.querySelector('[name="priority"]');
      if (pr) pr.value = "critical";
      const st = form.querySelector('[name="status"]');
      if (st) st.value = "باز";
    }
    if (table === "overtime" && !editId) {
      const ft = form.querySelector('[name="from_time"]');
      const tt = form.querySelector('[name="to_time"]');
      if (ft && !ft.value) ft.value = J.nowTime24();
      if (tt && !tt.value) tt.value = J.nowTime24();
    }
    if (table === "leave_requests") {
      const typeSel = form.querySelector('[name="leave_type"]');
      if (typeSel) {
        typeSel.addEventListener("change", toggleLeaveFields);
        toggleLeaveFields();
      }
    }
  }

  function buildStockItemForm(form, row) {
    form.innerHTML = "";
    const mothers = getMotherWarehouses();
    const isMgr = !!POLICY.is_manager;
    if (!mothers.length) {
      form.innerHTML = '<div class="empty">ابتدا مدیر باید در صفحه انبار، نام انبارهای مادر را تعریف کند. سپس می‌توانید کالا اضافه کنید.</div>';
      return;
    }

    // انبار مادر — فقط از لیست مادرهای تعریف‌شده
    const catF = document.createElement("div");
    catF.className = "field";
    catF.innerHTML = "<label>انبار مادر</label>";
    const catSel = document.createElement("select");
    catSel.name = "category";
    catSel.required = true;
    // اگر فیلتر انبار فعال است، همان را پیش‌فرض کن
    const preCat = (row && row.category) || (window.__whFilter && window.__whFilter !== "__low_stock__" ? window.__whFilter : "") || mothers[0];
    mothers.forEach((m) => {
      const o = document.createElement("option");
      o.value = m; o.textContent = m;
      if (m === preCat) o.selected = true;
      catSel.appendChild(o);
    });
    catF.appendChild(catSel);
    if (isMgr) {
      const addCat = document.createElement("button");
      addCat.type = "button";
      addCat.className = "btn btn-sm btn-outline";
      addCat.style.marginTop = "6px";
      addCat.textContent = "+ افزودن انبار مادر";
      addCat.onclick = async () => {
        const name = prompt("نام انبار مادر جدید:");
        if (!name || !name.trim()) return;
        const list = getMotherWarehouses();
        if (list.includes(name.trim())) { alert("این نام از قبل هست"); return; }
        list.push(name.trim());
        await saveMotherWarehouses(list);
        const o = document.createElement("option");
        o.value = name.trim(); o.textContent = name.trim(); o.selected = true;
        catSel.appendChild(o);
      };
      catF.appendChild(addCat);
      const renBtn = document.createElement("button");
      renBtn.type = "button";
      renBtn.className = "btn btn-sm btn-outline";
      renBtn.style.margin = "6px 6px 0 0";
      renBtn.textContent = "ویرایش نام انبار مادر";
      renBtn.onclick = async () => {
        const cur = catSel.value;
        const nn = prompt("نام جدید برای «" + cur + "»:", cur);
        if (!nn || !nn.trim() || nn.trim() === cur) return;
        let list = getMotherWarehouses().map((x) => x === cur ? nn.trim() : x);
        await saveMotherWarehouses(list);
        for (const it of (S.stock_items || []).filter((i) => i.category === cur)) {
          await api("save", { table: "stock_items", payload: { id: it.id, category: nn.trim() } });
        }
        await reload();
        alert("نام انبار مادر به‌روز شد");
        // بازسازی فرم با نام جدید
        buildStockItemForm(form, Object.assign({}, row || {}, { category: nn.trim() }));
      };
      catF.appendChild(renBtn);
    }
    form.appendChild(catF);

    // نام کالا — فقط متن آزاد
    const itemF = document.createElement("div");
    itemF.className = "field";
    itemF.innerHTML = "<label>نام کالا</label>";
    const itemInp = document.createElement("input");
    itemInp.type = "text";
    itemInp.name = "item";
    itemInp.required = true;
    itemInp.placeholder = "نام کالا را بنویسید...";
    itemInp.value = (row && row.item) || "";
    itemF.appendChild(itemInp);
    form.appendChild(itemF);

    // واحد ۱: عدد . متر . کیلو . جدید
    const u1F = document.createElement("div");
    u1F.className = "field";
    u1F.innerHTML = "<label>واحد ۱</label>";
    const u1Sel = document.createElement("select");
    u1Sel.name = "unit";
    ["عدد", "متر", "کیلو"].forEach((u) => {
      const o = document.createElement("option");
      o.value = u; o.textContent = u;
      if (row && row.unit === u) o.selected = true;
      u1Sel.appendChild(o);
    });
    const u1Custom = document.createElement("option");
    u1Custom.value = "__new__"; u1Custom.textContent = "جدید (بنویسید)...";
    u1Sel.appendChild(u1Custom);
    if (row && row.unit && !["عدد", "متر", "کیلو"].includes(row.unit)) {
      const o = document.createElement("option");
      o.value = row.unit; o.textContent = row.unit; o.selected = true;
      u1Sel.insertBefore(o, u1Custom);
    }
    u1Sel.onchange = () => {
      if (u1Sel.value === "__new__") {
        const n = prompt("نام واحد جدید:");
        if (n && n.trim()) {
          const o = document.createElement("option");
          o.value = n.trim(); o.textContent = n.trim(); o.selected = true;
          u1Sel.insertBefore(o, u1Custom);
        } else {
          u1Sel.value = "عدد";
        }
      }
    };
    u1F.appendChild(u1Sel);
    form.appendChild(u1F);

    // واحد ۲ اختیاری: عدد . متر . کیلو . اضافه کردن
    // ratioF را اول می‌سازیم تا در onchange قابل ارجاع باشد
    const ratioF = document.createElement("div");
    ratioF.className = "field";
    ratioF.style.display = (row && row.unit2) ? "" : "none";
    ratioF.innerHTML = "<label>هر واحد ۱ برابر است با چند واحد ۲</label>";
    const ratioInp = document.createElement("input");
    ratioInp.type = "text";
    ratioInp.name = "unit_ratio";
    ratioInp.placeholder = "مثال: 2.5";
    ratioInp.value = (row && row.unit_ratio) || "";
    ratioF.appendChild(ratioInp);

    const u2F = document.createElement("div");
    u2F.className = "field";
    u2F.innerHTML = "<label>واحد ۲ <span class=\"hint\">(در صورت داشتن)</span></label>";
    const u2Sel = document.createElement("select");
    u2Sel.name = "unit2";
    const empty2 = document.createElement("option");
    empty2.value = ""; empty2.textContent = "— ندارد —";
    u2Sel.appendChild(empty2);
    ["عدد", "متر", "کیلو"].forEach((u) => {
      const o = document.createElement("option");
      o.value = u; o.textContent = u;
      if (row && row.unit2 === u) o.selected = true;
      u2Sel.appendChild(o);
    });
    const u2Custom = document.createElement("option");
    u2Custom.value = "__new__"; u2Custom.textContent = "اضافه کردن...";
    u2Sel.appendChild(u2Custom);
    if (row && row.unit2 && !["عدد", "متر", "کیلو"].includes(row.unit2)) {
      const o = document.createElement("option");
      o.value = row.unit2; o.textContent = row.unit2; o.selected = true;
      u2Sel.insertBefore(o, u2Custom);
    }
    u2Sel.onchange = () => {
      if (u2Sel.value === "__new__") {
        const n = prompt("نام واحد ۲:");
        if (n && n.trim()) {
          const o = document.createElement("option");
          o.value = n.trim(); o.textContent = n.trim(); o.selected = true;
          u2Sel.insertBefore(o, u2Custom);
        } else {
          u2Sel.value = "";
        }
      }
      ratioF.style.display = u2Sel.value ? "" : "none";
      if (!u2Sel.value) ratioInp.value = "";
    };
    u2F.appendChild(u2Sel);
    form.appendChild(u2F);
    form.appendChild(ratioF);

    // موجودی از قبل — پیش‌فرض ندارد
    const priorF = document.createElement("div");
    priorF.className = "field";
    priorF.innerHTML = "<label>موجودی از قبل</label>";
    const priorSel = document.createElement("select");
    priorSel.name = "prior_stock";
    [["ندارد", "ندارد"], ["دارد", "دارد"]].forEach(([v, l]) => {
      const o = document.createElement("option");
      o.value = v; o.textContent = l;
      if (row && (row.prior_stock || "ندارد") === v) o.selected = true;
      priorSel.appendChild(o);
    });
    priorF.appendChild(priorSel);
    form.appendChild(priorF);

    const qtyF = document.createElement("div");
    qtyF.className = "field";
    qtyF.style.display = (row && row.prior_stock === "دارد") || (row && parseFloat(row.qty) > 0) ? "" : "none";
    qtyF.innerHTML = "<label>تعداد موجود</label>";
    const qtyInp = document.createElement("input");
    qtyInp.type = "text";
    qtyInp.name = "qty";
    qtyInp.value = (row && row.qty) || "0";
    qtyF.appendChild(qtyInp);
    form.appendChild(qtyF);

    const pdateF = document.createElement("div");
    pdateF.className = "field";
    pdateF.style.display = qtyF.style.display;
    pdateF.innerHTML = "<label>تاریخ موجودی</label>";
    const pdateInp = document.createElement("input");
    pdateInp.type = "text";
    pdateInp.name = "prior_date";
    pdateInp.readOnly = true;
    pdateInp.style.cursor = "pointer";
    pdateInp.value = (row && row.prior_date) || ((window.J && J.todayStr) ? J.todayStr() : "");
    pdateInp.onclick = () => {
      const parts = (pdateInp.value || (window.J && J.todayStr ? J.todayStr() : "")).split("/");
      const ny = prompt("سال:", parts[0] || "1404");
      if (ny === null) return;
      const nm = prompt("ماه:", parts[1] || "1");
      if (nm === null) return;
      const nd = prompt("روز:", parts[2] || "1");
      if (nd === null) return;
      pdateInp.value = String(ny).padStart(4, "0") + "/" + String(nm).padStart(2, "0") + "/" + String(nd).padStart(2, "0");
    };
    pdateF.appendChild(pdateInp);
    form.appendChild(pdateF);

    priorSel.onchange = () => {
      const show = priorSel.value === "دارد";
      qtyF.style.display = show ? "" : "none";
      pdateF.style.display = show ? "" : "none";
      if (!show) qtyInp.value = "0";
    };

    // حداقل اخطار
    const minF = document.createElement("div");
    minF.className = "field";
    minF.innerHTML = "<label>حداقل مقدار موجودی برای اخطار</label>";
    const minInp = document.createElement("input");
    minInp.type = "text";
    minInp.name = "min_qty";
    minInp.value = (row && row.min_qty) || "0";
    minF.appendChild(minInp);
    const minHint = document.createElement("div");
    minHint.className = "hint";
    minHint.textContent = "وقتی موجودی به این عدد یا کمتر برسد در داشبورد هشدار می‌آید.";
    minF.appendChild(minHint);
    form.appendChild(minF);

    // قیمت ریال — جداکننده سه‌رقمی هنگام تایپ
    const priceF = document.createElement("div");
    priceF.className = "field";
    priceF.innerHTML = "<label>قیمت هر واحد (ریال)</label>";
    const priceInp = document.createElement("input");
    priceInp.type = "text";
    priceInp.name = "price";
    priceInp.inputMode = "numeric";
    priceInp.placeholder = "مثال: 1,250,000";
    function formatPriceGroups(raw) {
      const digits = String(raw || "").replace(/[^\d]/g, "");
      if (!digits) return "";
      return digits.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    priceInp.value = formatPriceGroups((row && row.price) || "");
    priceInp.addEventListener("input", () => {
      const pos = priceInp.selectionStart;
      const before = priceInp.value.length;
      priceInp.value = formatPriceGroups(priceInp.value);
      const after = priceInp.value.length;
      try { priceInp.setSelectionRange(pos + (after - before), pos + (after - before)); } catch (e) {}
    });
    priceF.appendChild(priceInp);
    form.appendChild(priceF);

    if (!canManageStock()) {
      form.querySelectorAll("input, select, button").forEach((el) => { el.disabled = true; });
      const warn = document.createElement("div");
      warn.className = "hint";
      warn.style.color = "#b91c1c";
      warn.textContent = "فقط مدیر، حسابدار و انباردار می‌توانند کالا اضافه یا ویرایش کنند.";
      form.appendChild(warn);
    }
  }

  function closeModal() {
    const modal = document.getElementById("modal");
    if (modal) {
      modal.classList.add("hidden");
      modal._trashMode = false;
    }
    const saveBtn = document.getElementById("modal-save");
    if (saveBtn) saveBtn.style.display = "";
    editTable = ""; editId = 0;
  }

  let _saving = false;
  async function saveModal() {
    // جلوگیری از ثبت چندباره با کلیک سریع یا Enter تکراری
    if (_saving) return;
    const btn = document.getElementById("modal-save");
    if (btn && btn.disabled) return;
    _saving = true;
    if (btn) {
      btn.disabled = true;
      btn.dataset._oldText = btn.textContent;
      btn.textContent = "در حال ذخیره...";
    }
    try {
      const form = document.getElementById("modal-form");
      const payload = {};
      form.querySelectorAll("input, textarea, select").forEach((el) => {
        if (el.type === "file") return;
        let v;
        if (el.classList.contains("combo-input") && el.dataset.value) {
          v = el.dataset.value || el.value;
        } else {
          v = el.value;
        }
        // حذف جداکننده هزارگان از مبالغ
        if (MONEY_FIELDS.includes(el.name) && v != null) {
          v = String(v).replace(/[,،\s]/g, "");
        }
        payload[el.name] = v;
      });
      if (!POLICY.is_manager) {
        if (!payload.personnel_name) payload.personnel_name = USER.name || "";
      }
      if (editId) payload.id = editId;
      // همه مقادیر دارای رقم: ارقام فارسی/عربی → انگلیسی قبل از ذخیره
      Object.keys(payload).forEach((k) => {
        if (payload[k] != null && typeof payload[k] === "string") {
          payload[k] = faToEnDigits(payload[k]);
        }
      });
      // پرداخت از حساب: تاریخ + زمان
      if (editTable === "account_payments" && payload.pay_time) {
        payload.pay_date = ((payload.pay_date || "") + " " + payload.pay_time).trim();
        delete payload.pay_time;
      }
      // پرسنل جدید بدون رمز نمی‌تواند وارد شود
      if (payload.phone) payload.phone = faToEnDigits(payload.phone).replace(/\D+/g, "");
      if (payload.password) payload.password = faToEnDigits(payload.password);
      if (editTable === "personnel" && !editId) {
        const pw = (payload.password || "").trim();
        if (!pw) {
          alert("برای پرسنل جدید حتماً رمز عبور وارد کنید تا بتواند وارد پنل شود.");
          return;
        }
        if (!(payload.name || "").trim()) {
          alert("نام پرسنل الزامی است.");
          return;
        }
        if (!(payload.phone || "").trim()) {
          alert("برای ورود بعدی، شماره موبایل را هم وارد کنید.");
          return;
        }
      }
      
      if (editTable === "stock_items") {
        if (!(payload.item || "").trim()) { alert("نام کالا الزامی است"); return; }
        if (!(payload.category || "").trim()) { alert("انبار مادر را انتخاب کنید"); return; }
        if (!(payload.unit || "").trim()) { alert("واحد ۱ الزامی است"); return; }
        if (payload.prior_stock !== "دارد") { payload.qty = "0"; }
        const pr = parseFloat(String(payload.price || "0").replace(/[^\d.]/g, "")) || 0;
        payload.price = String(Math.round(pr));
        if (pr <= 0 && !editId) {
          if (!confirm("قیمت صفر است. کالا بدون قیمت ثبت شود؟")) return;
        }
      }
if (editTable === "customers" && !editId) {
        if (!(payload.name || "").trim()) {
          alert("نام مشتری الزامی است.");
          return;
        }
        if (!(payload.phone || "").trim()) {
          alert("شماره تماس مشتری الزامی است.");
          return;
        }
        if (!(payload.address || "").trim()) {
          alert("آدرس مشتری الزامی است.");
          return;
        }
        if (!payload.status) payload.status = "مشتریان جدید";
        if (!payload.sub_stage) payload.sub_stage = "اندازه‌گیری";
        payload.stage_action = "";
        // رمز اختیاری برای مشتری در این نسخه (پنل مشتری کنار گذاشته شده)
        if (!payload.password) payload.password = String(Math.floor(100000 + Math.random() * 900000));
        const cpw = (payload.password || "").trim();
        if (!cpw) {
          alert("برای مشتری جدید حتماً رمز عبور وارد کنید تا بتواند با موبایل وارد پنل شود.");
          return;
        }
        if (!(payload.phone || "").trim()) {
          alert("شماره موبایل مشتری برای ورود الزامی است.");
          return;
        }
      }
      if (editTable === "leave_requests" && !editId) {
        payload.status = "در انتظار";
        // ساعتی: فقط یک تاریخ + ساعت — to_date خالی
        if (payload.leave_type === "ساعتی") {
          payload.to_date = payload.from_date || "";
          if (!payload.hours) payload.hours = "1";
        } else {
          payload.hours = "0";
        }
      }
      if (editTable === "overtime" && !editId) {
        payload.status = "در انتظار";
      }
      // ورود/خروج جدا: att_type + att_time → check_in یا check_out
      if (editTable === "attendance" && !editId) {
        const t = payload.att_type || "check_in";
        const tm = payload.att_time || "";
        if (t === "check_out") {
          payload.check_out = tm;
          payload.check_in = "";
        } else {
          payload.check_in = tm;
          payload.check_out = "";
        }
        delete payload.att_type;
        delete payload.att_time;
      }

      const fileInput = form.querySelector('input[type=file][name=photo]');
      if (fileInput && fileInput.files && fileInput.files[0]) {
        const fd = new FormData();
        fd.append("action", "upload");
        fd.append("_wpnonce", CSRF);
        fd.append("instance", String(INSTANCE_ID));
        fd.append("file", fileInput.files[0]);
        const up = await fetch(API + (API.includes("?") ? "&" : "?") + "action=upload", { method: "POST", body: fd, credentials: "same-origin" }).then((r) => r.json());
        if (up.ok && up.data && up.data.url) payload.photo = up.data.url;
        else if (!up.ok) { alert(up.error || "خطا در آپلود تصویر"); return; }
      }

      let res = await api("save", { table: editTable, payload });
      // کالای تکراری انبار → پیشنهاد ادغام موجودی
      if (!res.ok && editTable === "stock_items" && res.error && res.error.indexOf("تکراری") !== -1) {
        if (confirm(res.error + "\n\nآیا به موجودی قبلی اضافه شود؟")) {
          payload.merge_stock = 1;
          res = await api("save", { table: editTable, payload });
        } else {
          return;
        }
      }
      if (!res.ok) { alert(res.error || "خطا"); return; }
      closeModal();
      await reload();
      render();
    } finally {
      _saving = false;
      if (btn) {
        btn.disabled = false;
        if (btn.dataset._oldText) btn.textContent = btn.dataset._oldText;
      }
    }
  }

  function downloadTemplate(table) {
    let fields = (FIELDS[table] || COLS[table] || []).filter((f) => f !== "password" && f !== "photo");
    // وضعیت را در قالب‌های ورودی کاربر نگذار (سیستم ست می‌کند)
    if (["leave_requests", "stock_usage", "overtime"].includes(table)) {
      fields = fields.filter((f) => f !== "status");
    }
    if (table === "stock_usage") {
      fields = ["kind", "project", "item_name", "qty", "notes", "used_at", "personnel_name"];
    }
    if (table === "overtime") {
      fields = ["personnel_name", "project", "from_time", "to_time", "reason", "ot_date", "notes"];
    }
    if (table === "leave_requests") {
      fields = ["personnel_name", "leave_type", "from_date", "to_date", "hours", "reason"];
    }
    const keys = fields.join(",");
    const labels = fields.map((f) => LABELS[f] || f).join(",");
    const sample = fields.map(() => "").join(",");
    const bom = "\uFEFF";
    const csv = bom + keys + "\n" + labels + "\n" + sample + "\n";
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "template_" + table + ".csv";
    a.click();
    URL.revokeObjectURL(a.href);
  }

  /** راهنمای کامل همه جداول برای مدیر */
  function downloadFullExcelGuide() {
    const tables = [
      ["personnel", "پرسنل"], ["customers", "مشتریان"], ["stock_items", "انبار"],
      ["suppliers", "تأمین‌کنندگان"], ["purchases", "خریدها"], ["directives", "دستورات"],
      ["fines", "جریمه و پاداش"], ["daily_reports", "گزارش روزانه"],
      ["leave_requests", "مرخصی"], ["overtime", "اضافه‌کاری"],
      ["stock_usage", "اعلام مصرفی"], ["attendance", "ورود و خروج"],
      ["checks_received", "چک دریافتنی"], ["checks_paid", "چک پرداختنی"],
    ];
    const bom = "\uFEFF";
    let csv = bom + "جدول (کلید),نام فارسی,ستون‌های مجاز (کلید انگلیسی),معنی فارسی ستون‌ها\n";
    tables.forEach(([tbl, label]) => {
      let fields = (FIELDS[tbl] || COLS[tbl] || []).filter((f) => f !== "password" && f !== "photo");
      if (["leave_requests", "stock_usage", "overtime"].includes(tbl)) {
        fields = fields.filter((f) => f !== "status");
      }
      if (tbl === "stock_usage") fields = ["kind", "project", "item_name", "qty", "notes", "used_at", "personnel_name"];
      if (tbl === "overtime") fields = ["personnel_name", "project", "from_time", "to_time", "reason", "ot_date", "notes"];
      if (tbl === "leave_requests") fields = ["personnel_name", "leave_type", "from_date", "to_date", "hours", "reason"];
      const fa = fields.map((f) => LABELS[f] || f).join(" | ");
      csv += tbl + "," + label + ',"' + fields.join(" | ") + '","' + fa + '"\n';
    });
    csv += "\nراهنما:\n";
    csv += "1. برای هر بخش از تنظیمات → درون‌ریزی و برون‌ریزی اکسل → دکمه «قالب Excel» همان بخش را بگیرید\n";
    csv += "2. ردیف اول فایل قالب = کلید انگلیسی (عوض نکنید)\n";
    csv += "3. ردیف دوم = معنی فارسی (فقط راهنما)\n";
    csv += "4. از ردیف سوم به بعد داده وارد کنید و فایل را با درون‌ریزی همان بخش آپلود کنید\n";
    csv += "5. بکاپ کامل JSON برای بازیابی یکجای کل پنل است؛ برای ورود داده‌ی جدولی از قالب CSV هر بخش استفاده کنید\n";
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "rahnama_excel_jadvavel.csv";
    a.click();
    URL.revokeObjectURL(a.href);
  }

  async function archiveRows(table, ids) {
    if (!ids || !ids.length) { alert("حداقل یک ردیف را انتخاب کنید"); return; }
    if (!confirm(ids.length + " رکورد در بایگانی ثبت شود؟ (داده اصلی حذف نمی‌شود)")) return;
    const res = await api("archive", { table, ids: JSON.stringify(ids) });
    if (!res.ok) { alert(res.error || "خطا در بایگانی"); return; }
    alert((res.data && res.data.count ? res.data.count : ids.length) + " مورد در بایگانی ثبت شد.");
  }

  let _deleting = false;
  async function deleteRows(table, ids) {
    if (_deleting) return;
    if (!POLICY.is_manager && !POLICY.can_delete) {
      alert("فقط مدیر مجموعه می‌تواند حذف کند");
      return;
    }
    if (!ids || !ids.length) { alert("حداقل یک ردیف را انتخاب کنید"); return; }
    if (!confirm(ids.length + " مورد به صندوق حذف‌شده‌ها منتقل شود؟\n\nاز لیست اصلی حذف می‌شود ولی داده و گزارش‌ها حفظ می‌مانند. می‌توانید بعداً از صندوق حذف‌شده‌ها بازگردانی کنید.")) return;
    _deleting = true;
    try {
      const res = await api("delete", { table, ids: JSON.stringify(ids) });
      if (!res.ok) { alert(res.error || "خطا در حذف"); return; }
      alert((res.data && res.data.count ? res.data.count : ids.length) + " مورد به صندوق حذف‌شده‌ها منتقل شد.");
      await reload();
      render();
    } finally {
      _deleting = false;
    }
  }

  async function restoreRow(table, id) {
    if (!POLICY.is_manager && !POLICY.is_network_admin) {
      alert("فقط مدیر مجموعه می‌تواند بازگردانی کند");
      return;
    }
    if (!confirm("این مورد دوباره در لیست اصلی نمایش داده شود؟")) return;
    const res = await api("restore", { table, id: String(id) });
    if (!res.ok) { alert(res.error || "خطا در بازگردانی"); return; }
    alert("با موفقیت بازگردانی شد");
    await reload();
    render();
  }

  async function openTrashBox(table, title) {
    const res = await api("trash_list", { table });
    if (!res.ok) { alert(res.error || "خطا در دریافت صندوق حذف"); return; }
    const rows = (res.data && res.data.rows) || [];
    const modal = document.getElementById("modal");
    const form = document.getElementById("modal-form");
    const mt = document.getElementById("modal-title");
    if (!modal || !form) return;
    if (mt) mt.textContent = "صندوق حذف‌شده‌ها — " + (title || table);
    form.innerHTML = "";
    if (!rows.length) {
      form.innerHTML = '<div class="empty">مورد حذف‌شده‌ای نیست.</div>';
    } else {
      const wrap = document.createElement("div");
      wrap.className = "table-wrap trash-box";
      let html = "<table><thead><tr><th>شناسه</th><th>عنوان / نام</th><th>حذف توسط</th><th>زمان حذف</th><th>عملیات</th></tr></thead><tbody>";
      rows.forEach((r) => {
        const name = r.name || r.title || r.item || r.item_name || r.phone || r.personnel_name || ("#" + r.id);
        html += `<tr>
          <td>${r.id}</td>
          <td><strong>${name}</strong></td>
          <td>${r.deleted_by || "—"}</td>
          <td>${r.deleted_at || "—"}</td>
          <td class="actions">
            <button type="button" class="btn btn-sm btn-outline" data-trash-view="${r.id}">مشاهده</button>
            <button type="button" class="btn btn-sm" data-trash-restore="${r.id}">بازگردانی</button>
          </td>
        </tr>`;
      });
      html += "</tbody></table>";
      wrap.innerHTML = html;
      form.appendChild(wrap);
      wrap.querySelectorAll("[data-trash-view]").forEach((btn) => {
        btn.onclick = () => {
          const row = rows.find((x) => String(x.id) === String(btn.dataset.trashView));
          if (row) openModal(table, row);
        };
      });
      wrap.querySelectorAll("[data-trash-restore]").forEach((btn) => {
        btn.onclick = () => restoreRow(table, Number(btn.dataset.trashRestore));
      });
    }
    // مخفی کردن دکمه ذخیره مودال در حالت صندوق
    const saveBtn = document.getElementById("modal-save");
    if (saveBtn) saveBtn.style.display = "none";
    modal.classList.remove("hidden");
    modal._trashMode = true;
  }

  function crudTable(table, title, opts = {}) {
    let rows = (S[table] || []).filter((r) => {
      // همیشه حذف‌شده‌ها از لیست اصلی پنهان
      if (r._deleted) return false;
      if (r.deleted_at && r.deleted_at !== "" && r.deleted_at !== "0000-00-00 00:00:00") return false;
      return true;
    });
    if (opts.filterFn) rows = rows.filter(opts.filterFn);
    const cols = COLS[table] || (FIELDS[table] || []).slice(0, 5);
    const card = document.createElement("div");
    card.className = "card";
    const head = document.createElement("h2");
    head.innerHTML = `<span>${title}</span>`;
    const actionsWrap = document.createElement("span");
    actionsWrap.style.cssText = "display:inline-flex;gap:6px;flex-wrap:wrap;align-items:center";

    // فقط مدیر و سرپرست کارگاه می‌توانند دستور اضافه کنند
    const canAdd = !opts.noAdd && !(table === "directives" && !(POLICY.is_manager || POLICY.role === "supervisor")) && !(table === "stock_items" && !canManageStock());
    if (canAdd) {
      const addBtn = document.createElement("button");
      addBtn.className = "btn btn-sm";
      addBtn.textContent = "+ افزودن";
      addBtn.onclick = () => openModal(table, null);
      actionsWrap.appendChild(addBtn);
    }

    // بایگانی گروهی — فقط آیکن
    if (POLICY.is_manager || POLICY.role === "warehouse") {
      const bulkArch = document.createElement("button");
      bulkArch.type = "button";
      bulkArch.className = "btn btn-sm btn-archive btn-icon-only";
      bulkArch.title = "بایگانی انتخاب‌شده‌ها";
      bulkArch.setAttribute("aria-label", "بایگانی انتخاب‌شده‌ها");
      bulkArch.textContent = "📥";
      bulkArch.onclick = () => {
        const checked = card.querySelectorAll("input.row-check:checked");
        const ids = Array.from(checked).map((c) => Number(c.value)).filter((n) => n > 0);
        archiveRows(table, ids);
      };
      actionsWrap.appendChild(bulkArch);
    }
    // حذف گروهی — فقط آیکن
    if (POLICY.is_manager || POLICY.can_delete) {
      const bulkDel = document.createElement("button");
      bulkDel.type = "button";
      bulkDel.className = "btn btn-sm btn-danger btn-icon-only";
      bulkDel.title = "حذف انتخاب‌شده‌ها";
      bulkDel.setAttribute("aria-label", "حذف انتخاب‌شده‌ها");
      bulkDel.textContent = "🗑";
      bulkDel.onclick = () => {
        const checked = card.querySelectorAll("input.row-check:checked");
        const ids = Array.from(checked).map((c) => Number(c.value)).filter((n) => n > 0);
        deleteRows(table, ids);
      };
      actionsWrap.appendChild(bulkDel);
    }
    // صندوق حذف‌شده‌ها — فقط آیکن
    if (POLICY.is_manager || POLICY.is_network_admin) {
      const trashBtn = document.createElement("button");
      trashBtn.type = "button";
      trashBtn.className = "btn btn-sm btn-outline btn-icon-only";
      trashBtn.title = "صندوق حذف‌شده‌ها";
      trashBtn.setAttribute("aria-label", "صندوق حذف‌شده‌ها");
      trashBtn.textContent = "♻️";
      trashBtn.onclick = () => openTrashBox(table, title);
      actionsWrap.appendChild(trashBtn);
    }

    // ورود/خروج: بدون خروجی و درون‌ریزی
    const noIO = table === "attendance";
    // export — فقط آیکن
    if (!POLICY.is_employee && !POLICY.is_customer && !noIO) {
      const ddWrap = document.createElement("span");
      ddWrap.className = "export-dropdown";
      ddWrap.style.cssText = "position:relative;display:inline-block";
      const ddBtn = document.createElement("button");
      ddBtn.type = "button";
      ddBtn.className = "btn btn-sm btn-outline btn-icon-only";
      ddBtn.title = "خروجی / درون‌ریزی";
      ddBtn.setAttribute("aria-label", "خروجی / درون‌ریزی");
      ddBtn.textContent = "⇅";
      ddBtn.setAttribute("aria-haspopup", "true");
      const ddMenu = document.createElement("div");
      ddMenu.className = "export-dropdown-menu";
      ddMenu.style.cssText = "display:none;position:absolute;top:100%;left:0;z-index:50;min-width:180px;background:var(--card,#fff);border:1px solid var(--b,#e2e8f0);border-radius:10px;box-shadow:0 8px 24px rgba(15,23,42,.12);padding:6px;margin-top:4px";
      function doExport(fmt) {
        const url = API + (API.includes("?") ? "&" : "?") + "action=export&table=" + encodeURIComponent(table) + "&format=" + fmt + "&instance=" + INSTANCE_ID;
        const f = document.createElement("form");
        f.method = "POST"; f.action = url; f.target = "_blank";
        const n = document.createElement("input"); n.name = "_wpnonce"; n.value = CSRF; f.appendChild(n);
        const a = document.createElement("input"); a.name = "action"; a.value = "export"; f.appendChild(a);
        document.body.appendChild(f); f.submit(); f.remove();
      }
      [["csv","Excel"],["json","JSON"],["pdf","PDF"]].forEach(([fmt, label]) => {
        const item = document.createElement("button");
        item.type = "button";
        item.className = "btn btn-sm btn-outline";
        item.style.cssText = "display:block;width:100%;text-align:right;margin:2px 0";
        item.textContent = label;
        item.onclick = (e) => { e.stopPropagation(); doExport(fmt); ddMenu.style.display = "none"; };
        ddMenu.appendChild(item);
      });
      const tplBtn = document.createElement("button");
      tplBtn.type = "button";
      tplBtn.className = "btn btn-sm btn-outline";
      tplBtn.style.cssText = "display:block;width:100%;text-align:right;margin:2px 0";
      tplBtn.textContent = "دانلود قالب Excel";
      tplBtn.title = "فایل خام با ستون‌های درست برای درون‌ریزی";
      tplBtn.onclick = (e) => { e.stopPropagation(); downloadTemplate(table); ddMenu.style.display = "none"; };
      ddMenu.appendChild(tplBtn);
      const impBtn = document.createElement("button");
      impBtn.type = "button";
      impBtn.className = "btn btn-sm btn-outline";
      impBtn.style.cssText = "display:block;width:100%;text-align:right;margin:2px 0";
      impBtn.textContent = "درون‌ریزی";
      impBtn.onclick = (e) => {
        e.stopPropagation();
        ddMenu.style.display = "none";
        const inp = document.createElement("input");
        inp.type = "file";
        inp.accept = ".json,.csv,.txt,.xlsx,application/json,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        inp.onchange = async () => {
          if (!inp.files || !inp.files[0]) return;
          if (!confirm("درون‌ریزی در جدول «" + table + "» انجام شود؟")) return;
          const fd = new FormData();
          fd.append("action", "import");
          fd.append("_wpnonce", CSRF);
          fd.append("instance", String(INSTANCE_ID));
          fd.append("table", table);
          fd.append("file", inp.files[0]);
          try {
            const res = await fetch(API + (API.includes("?") ? "&" : "?") + "action=import", { method: "POST", body: fd, credentials: "same-origin" }).then((r) => r.json());
            if (!res.ok) { alert(res.error || "خطا در درون‌ریزی"); return; }
            let msg = (res.message || "") + "\n";
            if (res.data) {
              msg += "وارد شد: " + (res.data.rows || 0) + " ردیف";
              if (res.data.skipped) msg += " | ردشد (تکراری): " + res.data.skipped;
              if (res.data.replaced) msg += " | جایگزین: " + res.data.replaced;
              if (res.data.duplicates && res.data.duplicates.length) {
                msg += "\n\nلیست تکراری‌ها:\n" + res.data.duplicates.slice(0, 15).join("\n");
                msg += "\n\nبرای جایگزینی، تیک «جایگزینی کامل» را در تنظیمات بزنید یا دوباره با گزینه replace آپلود کنید.";
              }
              if (res.data.errors && res.data.errors.length) msg += "\n\nخطاها:\n" + res.data.errors.slice(0, 5).join("\n");
            }
            alert(msg || "انجام شد");
            await reload();
            render();
          } catch (err) {
            alert("خطای شبکه: " + err);
          }
        };
        inp.click();
      };
      ddMenu.appendChild(impBtn);
      ddBtn.onclick = (e) => {
        e.stopPropagation();
        const open = ddMenu.style.display === "block";
        document.querySelectorAll(".export-dropdown-menu").forEach((m) => { m.style.display = "none"; });
        ddMenu.style.display = open ? "none" : "block";
      };
      document.addEventListener("click", () => { ddMenu.style.display = "none"; });
      ddWrap.appendChild(ddBtn);
      ddWrap.appendChild(ddMenu);
      actionsWrap.appendChild(ddWrap);
    }

    head.appendChild(actionsWrap);
    const helpKeyMap = { checks_received: "finance", checks_paid: "finance", stock_items: "warehouse", suppliers: "suppliers", customers: "customers", personnel: "personnel", purchases: "purchases", directives: "directives", fines: "fines", leave_requests: "leave", overtime: "overtime", stock_usage: "stock_usage", salary_payments: "salary" };
    if (helpKeyMap[table]) attachHelpQ(head, helpKeyMap[table]);
    const searchInp = document.createElement("input");
    searchInp.type = "search";
    searchInp.placeholder = "جستجو در جدول...";
    searchInp.className = "table-search";
    searchInp.style.cssText = "width:100%;max-width:280px;margin:8px 0;padding:8px;border:1px solid #e2e8f0;border-radius:8px;font-family:inherit";
    card.appendChild(searchInp);
    searchInp.oninput = () => {
      const q = (searchInp.value || "").trim().toLowerCase();
      card.querySelectorAll("tbody tr").forEach((tr) => {
        const txt = (tr.textContent || "").toLowerCase();
        tr.style.display = !q || txt.includes(q) ? "" : "none";
      });
    };
    card.appendChild(head);
    if (!rows.length) {
      const e = document.createElement("div");
      e.className = "empty";
      if (table === "directives") {
        e.textContent = "دستوری ثبت نشده است.";
      } else {
        e.textContent = "خالی است — با دکمه افزودن شروع کنید.";
      }
      card.appendChild(e);
      return card;
    }
    const wrap = document.createElement("div");
    wrap.className = "table-wrap";
    let html = "<table><thead><tr><th><input type='checkbox' class='check-all' title='انتخاب همه'></th>";
    cols.forEach((c) => { html += `<th>${LABELS[c] || c}</th>`; });
    html += "<th>عملیات</th></tr></thead><tbody>";
    rows.forEach((r) => {
      let rowCls = "";
      if (table === "checks_received" || table === "checks_paid") {
        const d = J.daysUntil(r.check_date);
        if (d !== null && d >= 0 && d <= 3) {
          rowCls += table === "checks_received" ? " check-due-customer" : " check-due-workshop";
        }
      }
      if (table === "stock_items" && StockHelper.isLow(r)) rowCls += " row-low-stock";
      html += `<tr class="${rowCls.trim()}"><td><input type="checkbox" class="row-check" value="${r.id}"></td>`;
      cols.forEach((c) => {
        let cell = r[c];
        if (c === "qty_display") cell = StockHelper.formatRemaining(r);
        else if (c === "qty" && table === "stock_items") cell = StockHelper.formatRemaining(r);
        html += `<td>${fmt(cell, c)}</td>`;
      });
      html += `<td class="actions">`;
      // ویرایش دستور فقط مدیر و سرپرست
      const canEdit = !opts.noEdit && !(table === "directives" && !(POLICY.is_manager || POLICY.role === "supervisor"));
      if (canEdit) html += `<button type="button" class="btn btn-sm btn-outline" data-edit="${table}" data-id="${r.id}">ویرایش</button> `;
      // وضعیت دستور برای گیرنده
      if (table === "directives" && !POLICY.is_manager) {
        html += `<button type="button" class="btn btn-sm" data-dir-st="${r.id}" data-st="در حال انجام">در حال انجام</button> `;
        html += `<button type="button" class="btn btn-sm" data-dir-st="${r.id}" data-st="انجام شد">انجام شد</button> `;
        html += `<button type="button" class="btn btn-sm btn-danger" data-dir-st="${r.id}" data-st="رد شد">رد</button> `;
      }
      // تأیید بازگشت انبار برای مدیر/حسابدار
      if (table === "stock_usage" && (r.kind === "بازگشت") && (r.status === "در انتظار تأیید" || r.status === "در انتظار") && (POLICY.is_manager || POLICY.role === "warehouse")) {
        html += `<button type="button" class="btn btn-sm" data-approve-return="${r.id}">تأیید بازگشت</button> `;
      }
      // تأیید مرخصی فقط مدیر
      if (table === "leave_requests" && (r.status === "در انتظار") && POLICY.is_manager) {
        html += `<button type="button" class="btn btn-sm" data-approve-leave="${r.id}">تأیید</button> `;
        html += `<button type="button" class="btn btn-sm btn-danger" data-reject-leave="${r.id}">رد</button> `;
      }
      // تأیید اضافه‌کاری مدیر یا حسابدار
      if (table === "overtime" && (r.status === "در انتظار" || !r.status) && (POLICY.is_manager || POLICY.role === "warehouse")) {
        html += `<button type="button" class="btn btn-sm" data-approve-ot="${r.id}">تأیید</button> `;
        html += `<button type="button" class="btn btn-sm btn-danger" data-reject-ot="${r.id}">رد</button> `;
      }
      if (POLICY.is_manager || POLICY.role === "warehouse") {
        html += `<button type="button" class="btn btn-sm btn-archive" data-arch="${table}" data-id="${r.id}">بایگانی</button> `;
      }
      if (POLICY.is_manager || POLICY.can_delete) {
        html += `<button type="button" class="btn btn-sm btn-danger" data-del="${table}" data-id="${r.id}">حذف از نمایش</button>`;
      }
      html += `</td></tr>`;
    });
    html += "</tbody></table>";
    wrap.innerHTML = html;
    const checkAll = wrap.querySelector(".check-all");
    if (checkAll) {
      checkAll.onchange = () => {
        wrap.querySelectorAll(".row-check").forEach((c) => { c.checked = checkAll.checked; });
      };
    }
    wrap.querySelectorAll("[data-edit]").forEach((btn) => {
      btn.onclick = () => openModal(btn.dataset.edit, rows.find((x) => String(x.id) === String(btn.dataset.id)));
    });
    wrap.querySelectorAll("[data-arch]").forEach((btn) => {
      btn.onclick = () => archiveRows(btn.dataset.arch, [Number(btn.dataset.id)]);
    });
    wrap.querySelectorAll("[data-dir-st]").forEach((btn) => {
      btn.onclick = async () => {
        const res = await api("save", { table: "directives", payload: { id: Number(btn.dataset.dirSt), status: btn.dataset.st } });
        if (!res.ok) { alert(res.error || "خطا"); return; }
        await reload(); render();
      };
    });
    wrap.querySelectorAll("[data-del]").forEach((btn) => {
      btn.onclick = () => deleteRows(btn.dataset.del, [Number(btn.dataset.id)]);
    });
    wrap.querySelectorAll("[data-approve-return]").forEach((btn) => {
      btn.onclick = async () => {
        const res = await api("save", { table: "stock_usage", payload: { id: Number(btn.dataset.approveReturn), status: "تأییدشده" } });
        if (!res.ok) { alert(res.error || "خطا"); return; }
        await reload(); render();
      };
    });
    wrap.querySelectorAll("[data-approve-leave]").forEach((btn) => {
      btn.onclick = async () => {
        const res = await api("save", { table: "leave_requests", payload: { id: Number(btn.dataset.approveLeave), status: "تأیید" } });
        if (!res.ok) { alert(res.error || "خطا"); return; }
        await reload(); render();
      };
    });
    wrap.querySelectorAll("[data-reject-leave]").forEach((btn) => {
      btn.onclick = async () => {
        const res = await api("save", { table: "leave_requests", payload: { id: Number(btn.dataset.rejectLeave), status: "رد" } });
        if (!res.ok) { alert(res.error || "خطا"); return; }
        await reload(); render();
      };
    });
    wrap.querySelectorAll("[data-approve-ot]").forEach((btn) => {
      btn.onclick = async () => {
        const res = await api("save", { table: "overtime", payload: { id: Number(btn.dataset.approveOt), status: "تأیید" } });
        if (!res.ok) { alert(res.error || "خطا"); return; }
        await reload(); render();
      };
    });
    wrap.querySelectorAll("[data-reject-ot]").forEach((btn) => {
      btn.onclick = async () => {
        const res = await api("save", { table: "overtime", payload: { id: Number(btn.dataset.rejectOt), status: "رد" } });
        if (!res.ok) { alert(res.error || "خطا"); return; }
        await reload(); render();
      };
    });
    card.appendChild(wrap);
    return card;
  }

  function renderEmpDashboard(root) {
    const name = USER.name || "";
    const leaveLeft = (() => {
      const p = (S.personnel || []).find((x) => x.name === name);
      return p ? (parseFloat(p.leave_days) || 0) : 0;
    })();
    const openDirs = (typeof myOpenDirectives === "function") ? myOpenDirectives() : [];
    const myOtRows = (S.overtime || []).filter((o) => o.personnel_name === name);
    const otHoursMonth = myOtRows.reduce((s, o) => s + (parseFloat(o.hours) || 0), 0);
    const otH = Math.floor(otHoursMonth);
    const otM = Math.round((otHoursMonth - otH) * 60);
    const otLabel = otH + ":" + String(otM).padStart(2, "0");

    // پروژه‌های فعال از دستورات / مصرف انبار
    const projectNames = new Set();
    openDirs.forEach((d) => { if (d.project) projectNames.add(d.project); });
    (S.stock_usage || []).filter((s) => s.personnel_name === name && s.project).forEach((s) => projectNames.add(s.project));
    const activeProjects = Array.from(projectNames);
    const waitingReport = openDirs.filter((d) => {
      const st = d.status || "باز";
      return st === "باز" || st === "در حال انجام" || st === "pending";
    }).length;

    const greet = document.createElement("div");
    greet.className = "emp-home-greet";
    greet.innerHTML = `<h2>سلام 👋 امروز چه کارهایی داری؟</h2>`;
    root.appendChild(greet);

    const grid = document.createElement("div");
    grid.className = "emp-home-grid";
    const cards = [
      { l: "کارهای امروز", v: openDirs.length, sub: waitingReport + " مورد منتظر گزارش", go: "emp_tasks" },
      { l: "پروژه فعال", v: activeProjects.length || "—", sub: activeProjects[0] || "پروژه‌ای نیست", go: "emp_projects" },
      { l: "مرخصی مانده", v: leaveLeft + " روز", sub: "مانده مرخصی شما", go: "emp_leave" },
      { l: "اضافه‌کاری ثبت‌شده", v: otLabel, sub: "این ماه", go: "emp_overtime" },
    ];
    cards.forEach((c) => {
      const d = document.createElement("div");
      d.className = "emp-home-card";
      d.innerHTML = `<span class="ehc-label">${c.l}</span><strong class="ehc-val">${c.v}</strong><span class="ehc-sub">${c.sub}</span>`;
      d.onclick = () => { menu = c.go; renderNav(); render(); };
      grid.appendChild(d);
    });
    root.appendChild(grid);

    // میانبر سریع
    const quick = document.createElement("div");
    quick.className = "card emp-quick";
    quick.innerHTML = "<h3>میانبرها</h3>";
    const qbar = document.createElement("div");
    qbar.className = "emp-quick-bar";
    [
      { l: "کارهای من", m: "emp_tasks" },
      { l: "پروژه‌های من", m: "emp_projects" },
      { l: "گزارش روزانه", m: "emp_report" },
      { l: "ورود / خروج", m: "emp_attendance" },
    ].forEach((q) => {
      const b = document.createElement("button");
      b.type = "button"; b.className = "btn btn-sm btn-outline"; b.textContent = q.l;
      b.onclick = () => { menu = q.m; renderNav(); render(); };
      qbar.appendChild(b);
    });
    quick.appendChild(qbar);
    root.appendChild(quick);
  }

  function renderEmpTasks(root) {
    const name = USER.name || "";
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = "<h2>کارهای من</h2>";
    const dirs = (S.directives || []).filter((d) => {
      const tn = (d.target_name || "").trim();
      const tr = (d.target_role || "").trim();
      if (tn && (tn === name || tn === "*")) return true;
      if (!tn && tr) return true;
      return false;
    });
    if (!dirs.length) {
      card.innerHTML += '<p class="empty-hint">کاری برای شما ثبت نشده.</p>';
      root.appendChild(card);
      return;
    }
    const wrap = document.createElement("div");
    wrap.className = "table-wrap";
    let html = `<table><thead><tr>
      <th>اولویت</th><th>پروژه</th><th>وظیفه</th><th>مهلت</th><th>وضعیت</th><th></th>
    </tr></thead><tbody>`;
    const prioOrder = { "فوری": 0, "critical": 0, "مهم": 1, "important": 1, "عادی": 2, "normal": 2 };
    dirs.slice().sort((a, b) => (prioOrder[a.priority] ?? 3) - (prioOrder[b.priority] ?? 3)).forEach((d) => {
      const prio = fmt(d.priority, "priority") || "عادی";
      const st = d.status || "باز";
      html += `<tr>
        <td>${prio}</td>
        <td>${d.project || "—"}</td>
        <td>${d.title || d.body || "—"}</td>
        <td>${d.due_date || "—"}</td>
        <td>${st}</td>
        <td class="actions">
          <button type="button" class="btn btn-sm" data-done="${d.id}">ثبت انجام</button>
        </td>
      </tr>`;
    });
    html += "</tbody></table>";
    wrap.innerHTML = html;
    wrap.querySelectorAll("[data-done]").forEach((btn) => {
      btn.onclick = async () => {
        const res = await api("save", { table: "directives", payload: { id: Number(btn.dataset.done), status: "انجام شد" } });
        if (res.ok) { await reload(); render(); } else alert(res.error || "خطا");
      };
    });
    card.appendChild(wrap);
    root.appendChild(card);
  }

  function renderEmpProjects(root) {
    const name = USER.name || "";
    const projects = new Map();
    (S.directives || []).forEach((d) => {
      const tn = (d.target_name || "").trim();
      if (tn && tn !== name && tn !== "*") return;
      const p = d.project || "بدون پروژه";
      if (!projects.has(p)) projects.set(p, { name: p, tasks: 0, open: 0 });
      const row = projects.get(p);
      row.tasks++;
      const st = d.status || "باز";
      if (st === "باز" || st === "در حال انجام" || st === "pending") row.open++;
    });
    (S.stock_usage || []).filter((s) => s.personnel_name === name && s.project).forEach((s) => {
      const p = s.project;
      if (!projects.has(p)) projects.set(p, { name: p, tasks: 0, open: 0 });
    });
    (S.customers || []).forEach((c) => {
      if (c.installer === name && c.name) {
        if (!projects.has(c.name)) projects.set(c.name, { name: c.name, tasks: 0, open: 0, customer: true });
      }
    });

    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = "<h2>پروژه‌های من</h2>";
    if (!projects.size) {
      card.innerHTML += '<p class="empty-hint">پروژه‌ای به شما وصل نیست.</p>';
      root.appendChild(card);
      return;
    }
    const list = document.createElement("div");
    list.className = "emp-project-list";
    projects.forEach((p) => {
      const row = document.createElement("div");
      row.className = "emp-project-row";
      row.innerHTML = `<strong>${p.name}</strong>
        <span class="hint">${p.open} کار باز از ${p.tasks} وظیفه</span>`;
      list.appendChild(row);
    });
    card.appendChild(list);
    root.appendChild(card);
  }

  /** افزودن ماه جلالی به تاریخ yyyy/mm/dd */
  function addJalaliMonths(jdate, months) {
    const raw = faToEnDigits(String(jdate || "")).replace(/-/g, "/");
    const parts = raw.split("/").map((x) => parseInt(x, 10));
    if (parts.length < 3 || !parts[0]) return jdate;
    let y = parts[0], m = parts[1], d = parts[2];
    m += months;
    while (m > 12) { m -= 12; y += 1; }
    while (m < 1) { m += 12; y -= 1; }
    // طول ماه‌های جلالی تقریبی
    const maxDay = m <= 6 ? 31 : (m <= 11 ? 30 : 29);
    if (d > maxDay) d = maxDay;
    const pad = (n) => String(n).padStart(2, "0");
    return y + "/" + pad(m) + "/" + pad(d);
  }

  function getInstallmentsList() {
    const list = (S.installments || (S.settings && S.settings.installments) || []);
    return Array.isArray(list) ? list.slice() : [];
  }

  async function saveInstallmentsList(next) {
    const res = await api("settings", { payload: { installments: next } });
    if (res.ok) {
      if (!S.settings) S.settings = {};
      S.settings.installments = next;
      S.installments = next;
    }
    return res;
  }

  function installmentStatusInfo(x) {
    const st = (x.status || "فعال").trim();
    if (st === "پرداخت‌شده" || st === "paid") {
      return { key: "paid", label: "پرداخت‌شده", cls: "inst-paid" };
    }
    const days = (typeof J !== "undefined" && J.daysUntil) ? J.daysUntil(x.due_date) : null;
    const remind = parseInt(x.remind_days, 10);
    const rDays = isNaN(remind) ? 3 : remind;
    if (days !== null && days < 0) return { key: "overdue", label: "معوق (" + Math.abs(days) + " روز)", cls: "inst-overdue", days };
    if (days !== null && days <= rDays) return { key: "soon", label: days === 0 ? "امروز سررسید" : days + " روز تا سررسید", cls: "inst-soon", days };
    return { key: "active", label: "فعال", cls: "inst-active", days };
  }

  function renderInstallments(root) {
    const canEdit = POLICY.is_manager || POLICY.role === "warehouse";
    const items = getInstallmentsList();
    const filter = window.__instFilter || "all";

    // خلاصه
    let overdueN = 0, soonN = 0, paidN = 0, activeN = 0;
    let sumOverdue = 0, sumSoon = 0;
    items.forEach((x) => {
      const info = installmentStatusInfo(x);
      const amt = parseFloat(String(x.amount || "0").replace(/,/g, "")) || 0;
      if (info.key === "paid") paidN++;
      else if (info.key === "overdue") { overdueN++; sumOverdue += amt; }
      else if (info.key === "soon") { soonN++; sumSoon += amt; }
      else activeN++;
    });

    const summary = document.createElement("div");
    summary.className = "stats inst-summary";
    [
      { l: "معوق", v: overdueN, sub: fmt(sumOverdue, "amount"), alert: overdueN > 0, f: "overdue" },
      { l: "نزدیک سررسید", v: soonN, sub: fmt(sumSoon, "amount"), alert: soonN > 0, f: "soon" },
      { l: "فعال", v: activeN, f: "active" },
      { l: "پرداخت‌شده", v: paidN, f: "paid" },
    ].forEach((s) => {
      const d = document.createElement("div");
      d.className = "stat" + (s.alert ? " stat-alert" : "") + (filter === s.f ? " stat-alert" : "");
      d.style.cursor = "pointer";
      d.innerHTML = `<b>${s.v}</b><span>${s.l}</span>${s.sub != null ? `<span class="hint">${s.sub}</span>` : ""}`;
      d.onclick = () => { window.__instFilter = s.f; render(); };
      summary.appendChild(d);
    });
    const allBtn = document.createElement("div");
    allBtn.className = "stat" + (filter === "all" ? " stat-alert" : "");
    allBtn.style.cursor = "pointer";
    allBtn.innerHTML = `<b>${items.length}</b><span>همه</span>`;
    allBtn.onclick = () => { window.__instFilter = "all"; render(); };
    summary.appendChild(allBtn);
    root.appendChild(summary);

    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = '<h2>اقساط و اجاره‌ها</h2><p class="hint">یادآوری روی داشبورد بر اساس «روزهای یادآوری» هر مورد نمایش داده می‌شود. با علامت پرداخت‌شده، اگر تکرار ماهانه/فصلی/سالانه باشد سررسید بعدی خودکار ساخته می‌شود.</p>';

    const filtered = items.filter((x) => {
      if (filter === "all") return true;
      return installmentStatusInfo(x).key === filter;
    }).sort((a, b) => {
      const da = J.daysUntil(a.due_date); const db = J.daysUntil(b.due_date);
      if (da === null && db === null) return 0;
      if (da === null) return 1;
      if (db === null) return -1;
      return da - db;
    });

    if (!filtered.length) {
      const empty = document.createElement("p");
      empty.className = "empty-hint";
      empty.textContent = items.length ? "موردی در این فیلتر نیست." : "هنوز قسط یا اجاره‌ای ثبت نشده. نوع پرداخت را مشخص کنید.";
      card.appendChild(empty);
    } else {
      const wrap = document.createElement("div");
      wrap.className = "table-wrap";
      let html = `<table><thead><tr>
        <th>نوع</th><th>عنوان</th><th>مبلغ</th><th>سررسید</th><th>تکرار</th><th>یادآوری</th><th>وضعیت</th><th>عملیات</th>
      </tr></thead><tbody>`;
      const recLabel = { none: "بدون تکرار", monthly: "ماهانه", quarterly: "فصلی", yearly: "سالانه" };
      filtered.forEach((x) => {
        const info = installmentStatusInfo(x);
        const rec = recLabel[x.recurrence] || recLabel.none;
        html += `<tr class="${info.cls}">
          <td>${x.kind || "—"}</td>
          <td><strong>${x.title || x.name || "—"}</strong>${x.note ? `<div class="hint">${x.note}</div>` : ""}</td>
          <td>${fmt(x.amount, "amount")}</td>
          <td>${x.due_date || "—"}</td>
          <td>${rec}</td>
          <td>${(x.remind_days != null ? x.remind_days : 3)} روز قبل</td>
          <td><span class="inst-status ${info.cls}">${info.label}</span>${x.paid_at ? `<div class="hint">پرداخت: ${x.paid_at}</div>` : ""}</td>
          <td class="actions" data-id="${x.id}"></td>
        </tr>`;
      });
      html += "</tbody></table>";
      wrap.innerHTML = html;

      if (canEdit) {
        wrap.querySelectorAll("td.actions[data-id]").forEach((td) => {
          const id = Number(td.dataset.id);
          const x = items.find((r) => Number(r.id) === id);
          if (!x) return;
          const info = installmentStatusInfo(x);
          if (info.key !== "paid") {
            const pay = document.createElement("button");
            pay.type = "button"; pay.className = "btn btn-sm"; pay.textContent = "پرداخت شد";
            pay.onclick = async () => {
              const today = (J.todayStr && J.todayStr()) || "";
              const hist = Array.isArray(x.history) ? x.history.slice() : [];
              hist.push({ paid_at: today, amount: x.amount, due_date: x.due_date });
              const rec = x.recurrence || "none";
              const next = items.map((r) => {
                if (Number(r.id) !== id) return r;
                if (rec === "monthly" || rec === "quarterly" || rec === "yearly") {
                  const add = rec === "monthly" ? 1 : (rec === "quarterly" ? 3 : 12);
                  return Object.assign({}, r, {
                    status: "فعال",
                    paid_at: today,
                    due_date: addJalaliMonths(r.due_date, add),
                    history: hist.slice(-24),
                  });
                }
                return Object.assign({}, r, { status: "پرداخت‌شده", paid_at: today, history: hist.slice(-24) });
              });
              const res = await saveInstallmentsList(next);
              if (res.ok) {
                showToast("ثبت شد", rec !== "none" ? "سررسید بعدی تنظیم شد" : "به‌عنوان پرداخت‌شده علامت خورد", "ok");
                render();
              } else alert(res.error || "خطا");
            };
            td.appendChild(pay);
          } else {
            const reactivate = document.createElement("button");
            reactivate.type = "button"; reactivate.className = "btn btn-sm btn-outline"; reactivate.textContent = "فعال‌سازی مجدد";
            reactivate.onclick = async () => {
              const next = items.map((r) => Number(r.id) === id ? Object.assign({}, r, { status: "فعال", paid_at: "" }) : r);
              const res = await saveInstallmentsList(next);
              if (res.ok) render(); else alert(res.error || "خطا");
            };
            td.appendChild(reactivate);
          }
          const del = document.createElement("button");
          del.type = "button"; del.className = "btn btn-sm btn-danger"; del.textContent = "حذف";
          del.onclick = async () => {
            if (!confirm("این مورد حذف شود؟")) return;
            const next = items.filter((r) => Number(r.id) !== id);
            const res = await saveInstallmentsList(next);
            if (res.ok) render(); else alert(res.error || "خطا");
          };
          td.appendChild(del);
        });
      }
      card.appendChild(wrap);
    }

    if (canEdit) {
      const form = document.createElement("div");
      form.className = "install-form";
      form.style.marginTop = "16px";
      const today = (J.todayStr && J.todayStr()) || "";
      form.innerHTML = `<h3>ثبت مورد جدید</h3>
        <div class="field"><label>نوع پرداخت</label>
          <select id="inst-kind"><option value="قسط">قسط</option><option value="اجاره">اجاره</option><option value="سایر">سایر</option></select>
        </div>
        <div class="field"><label>عنوان</label><input type="text" id="inst-title" placeholder="مثلاً اجاره سوله / قسط دستگاه"></div>
        <div class="field"><label>مبلغ (ریال)</label><input type="text" id="inst-amount" placeholder="0"></div>
        <div class="field"><label>تاریخ سررسید</label><input type="text" id="inst-due" placeholder="${today}" value="${today}"></div>
        <div class="field"><label>تکرار</label>
          <select id="inst-rec">
            <option value="none">بدون تکرار (یک‌بار)</option>
            <option value="monthly">ماهانه</option>
            <option value="quarterly">فصلی (هر ۳ ماه)</option>
            <option value="yearly">سالانه</option>
          </select>
        </div>
        <div class="field"><label>یادآوری از چند روز قبل</label>
          <input type="number" id="inst-remind" min="0" max="90" value="3">
        </div>
        <div class="field"><label>یادداشت</label><input type="text" id="inst-note" placeholder="اختیاری"></div>
        <button type="button" class="btn" id="inst-save">ذخیره</button>`;
      card.appendChild(form);
      form.querySelector("#inst-save").onclick = async () => {
        const kind = form.querySelector("#inst-kind").value;
        const title = (form.querySelector("#inst-title").value || "").trim();
        const amount = (form.querySelector("#inst-amount").value || "").trim();
        const due = faToEnDigits((form.querySelector("#inst-due").value || "").trim());
        const recurrence = form.querySelector("#inst-rec").value;
        const remind_days = parseInt(form.querySelector("#inst-remind").value, 10);
        const note = (form.querySelector("#inst-note").value || "").trim();
        if (!title || !due) { alert("عنوان و سررسید الزامی است"); return; }
        const next = items.slice();
        next.push({
          id: Date.now(),
          kind, title, name: title, amount, due_date: due,
          status: "فعال", paid_at: "", note,
          recurrence: recurrence || "none",
          remind_days: isNaN(remind_days) ? 3 : remind_days,
          history: [],
        });
        const res = await saveInstallmentsList(next);
        if (res.ok) {
          showToast("ثبت شد", title + " اضافه شد", "ok");
          window.__instFilter = "all";
          render();
        } else alert(res.error || "خطا در ذخیره");
      };
    }
    root.appendChild(card);
  }

  // —— حضور هوشمند مکانی ——
  function getWorkSites() {
    const list = (S.settings && S.settings.work_sites) || S.work_sites || [];
    return Array.isArray(list) ? list.slice() : [];
  }

  async function saveWorkSites(next) {
    const res = await api("settings", { payload: { work_sites: next } });
    if (res.ok) {
      if (!S.settings) S.settings = {};
      S.settings.work_sites = next;
      S.work_sites = next;
    }
    return res;
  }

  function haversineM(lat1, lng1, lat2, lng2) {
    const toRad = (d) => (d * Math.PI) / 180;
    const R = 6371000;
    const dLat = toRad(lat2 - lat1);
    const dLng = toRad(lng2 - lng1);
    const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(a));
  }

  function matchWorkSite(lat, lng) {
    const sites = getWorkSites().filter((s) => s.active !== 0 && s.lat && s.lng);
    let best = null;
    let bestDist = Infinity;
    sites.forEach((s) => {
      const d = haversineM(lat, lng, parseFloat(s.lat), parseFloat(s.lng));
      const r = parseInt(s.radius_m, 10) || 150;
      if (d <= r && d < bestDist) {
        bestDist = d;
        best = Object.assign({}, s, { _dist: Math.round(d) });
      }
    });
    return best;
  }

  function getCurrentPosition() {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error("مرورگر موقعیت مکانی را پشتیبانی نمی‌کند"));
        return;
      }
      navigator.geolocation.getCurrentPosition(
        (pos) => resolve({
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
        }),
        (err) => reject(err),
        { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 }
      );
    });
  }

  function neshanApiKey() {
    const k = (S.settings && S.settings.neshan_api_key) || "";
    return (k && String(k).trim()) || "d90b40adc14e4e8f8f3887631881cc7e";
  }

  function ensureNeshan(cb) {
    if (window.L && window.__neshanReady) { cb(); return; }
    if (document.getElementById("neshan-sdk-js")) {
      const t = setInterval(() => {
        if (window.L) { window.__neshanReady = true; clearInterval(t); cb(); }
      }, 100);
      return;
    }
    const link = document.createElement("link");
    link.id = "neshan-sdk-css";
    link.rel = "stylesheet";
    link.href = "https://static.neshan.org/sdk/leaflet/v1.9.4/neshan-sdk/v1.0.8/index.css";
    document.head.appendChild(link);
    const script = document.createElement("script");
    script.id = "neshan-sdk-js";
    script.src = "https://static.neshan.org/sdk/leaflet/v1.9.4/neshan-sdk/v1.0.8/index.js";
    script.onload = () => { window.__neshanReady = true; cb(); };
    script.onerror = () => { alert("بارگذاری نقشه نشان ناموفق بود."); };
    document.head.appendChild(script);
  }

  function createNeshanMap(elId, opts) {
    const el = typeof elId === "string" ? document.getElementById(elId) : elId;
    if (!el || !window.L) return null;
    const o = opts || {};
    return new L.Map(el, {
      key: neshanApiKey(),
      maptype: o.maptype || "neshan",
      poi: o.poi != null ? o.poi : false,
      traffic: false,
      center: o.center || [35.699756, 51.338076],
      zoom: o.zoom || 13,
    });
  }

  function renderWorkSites(root) {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `<h2>📍 نقاط کاری (حضور هوشمند)</h2>
      <p class="hint">نقاط کارگاه، دفتر و محل‌های نصب را تعریف کنید. پرسنل هنگام ورود/خروج با موقعیت گوشی ثبت می‌شوند؛ اگر داخل شعاع نقطه باشند «معتبر» علامت می‌خورد.</p>`;

    const sites = getWorkSites();
    const listWrap = document.createElement("div");
    listWrap.className = "work-sites-list";
    if (!sites.length) {
      listWrap.innerHTML = '<p class="empty-hint">هنوز نقطه‌ای تعریف نشده. از فرم زیر یا نقشه اضافه کنید.</p>';
    } else {
      sites.forEach((s) => {
        const row = document.createElement("div");
        row.className = "work-site-row" + (s.active === 0 ? " ws-off" : "");
        row.innerHTML = `<div>
          <strong>${s.name || "—"}</strong>
          <span class="hint">${s.kind || "کارگاه"} — شعاع ${s.radius_m || 150}م — ${s.lat}, ${s.lng}</span>
          ${s.address ? `<div class="hint">${s.address}</div>` : ""}
        </div>`;
        const acts = document.createElement("div");
        acts.className = "ws-acts";
        const tog = document.createElement("button");
        tog.type = "button"; tog.className = "btn btn-sm btn-outline";
        tog.textContent = s.active === 0 ? "فعال" : "غیرفعال";
        tog.onclick = async () => {
          const next = sites.map((x) => Number(x.id) === Number(s.id) ? Object.assign({}, x, { active: s.active === 0 ? 1 : 0 }) : x);
          const res = await saveWorkSites(next);
          if (res.ok) render(); else alert(res.error || "خطا");
        };
        const del = document.createElement("button");
        del.type = "button"; del.className = "btn btn-sm btn-danger"; del.textContent = "حذف";
        del.onclick = async () => {
          if (!confirm("حذف این نقطه؟")) return;
          const next = sites.filter((x) => Number(x.id) !== Number(s.id));
          const res = await saveWorkSites(next);
          if (res.ok) render(); else alert(res.error || "خطا");
        };
        acts.appendChild(tog); acts.appendChild(del);
        row.appendChild(acts);
        listWrap.appendChild(row);
      });
    }
    card.appendChild(listWrap);

    const mapBox = document.createElement("div");
    mapBox.id = "work-sites-map";
    mapBox.className = "work-sites-map";
    card.appendChild(mapBox);

    const form = document.createElement("div");
    form.className = "install-form";
    form.innerHTML = `<h3>افزودن نقطه</h3>
      <div class="field"><label>نام نقطه</label><input type="text" id="ws-name" placeholder="کارگاه اصلی / پروژه محمدیان"></div>
      <div class="field"><label>نوع</label>
        <select id="ws-kind"><option>کارگاه</option><option>نصب</option><option>دفتر</option><option>سایر</option></select>
      </div>
      <div class="field"><label>عرض جغرافیایی (lat)</label><input type="text" id="ws-lat" placeholder="35.6892"></div>
      <div class="field"><label>طول جغرافیایی (lng)</label><input type="text" id="ws-lng" placeholder="51.3890"></div>
      <div class="field"><label>شعاع مجاز (متر)</label><input type="number" id="ws-radius" value="150" min="20" max="5000"></div>
      <div class="field"><label>آدرس / توضیح</label><input type="text" id="ws-addr" placeholder="اختیاری"></div>
      <button type="button" class="btn btn-outline" id="ws-my-loc">موقعیت فعلی من</button>
      <button type="button" class="btn" id="ws-save">ذخیره نقطه</button>
      <p class="hint" style="grid-column:1/-1">روی نقشه کلیک کنید تا مختصات پر شود، یا «موقعیت فعلی من» را بزنید.</p>`;
    card.appendChild(form);
    root.appendChild(card);

    const fillFromPos = (lat, lng) => {
      form.querySelector("#ws-lat").value = String(lat);
      form.querySelector("#ws-lng").value = String(lng);
    };

    form.querySelector("#ws-my-loc").onclick = async () => {
      try {
        const p = await getCurrentPosition();
        fillFromPos(p.lat.toFixed(6), p.lng.toFixed(6));
        showToast("موقعیت دریافت شد", "دقت حدود " + Math.round(p.accuracy) + " متر", "ok");
      } catch (e) {
        alert("موقعیت در دسترس نیست. لوکیشن گوشی/مرورگر را روشن کنید.\n" + (e.message || e));
      }
    };

    form.querySelector("#ws-save").onclick = async () => {
      const name = (form.querySelector("#ws-name").value || "").trim();
      const lat = (form.querySelector("#ws-lat").value || "").trim();
      const lng = (form.querySelector("#ws-lng").value || "").trim();
      const radius_m = parseInt(form.querySelector("#ws-radius").value, 10) || 150;
      const kind = form.querySelector("#ws-kind").value;
      const address = (form.querySelector("#ws-addr").value || "").trim();
      if (!name || !lat || !lng) { alert("نام و مختصات الزامی است"); return; }
      const next = sites.slice();
      next.push({ id: Date.now(), name, kind, lat, lng, radius_m, address, active: 1 });
      const res = await saveWorkSites(next);
      if (res.ok) { showToast("نقطه ذخیره شد", name, "ok"); render(); }
      else alert(res.error || "خطا");
    };

    ensureNeshan(() => {
      try {
        const el = document.getElementById("work-sites-map");
        if (!el || !window.L) return;
        const center = sites.length
          ? [parseFloat(sites[0].lat), parseFloat(sites[0].lng)]
          : [35.699756, 51.338076];
        const map = createNeshanMap(el, { center, zoom: sites.length ? 13 : 11, maptype: "neshan" });
        if (!map) return;
        sites.forEach((s) => {
          if (!s.lat || !s.lng) return;
          const m = L.marker([parseFloat(s.lat), parseFloat(s.lng)]).addTo(map);
          m.bindPopup(`<b>${s.name}</b><br>${s.kind || ""} — ${s.radius_m || 150}م`);
          L.circle([parseFloat(s.lat), parseFloat(s.lng)], {
            radius: parseInt(s.radius_m, 10) || 150,
            color: s.active === 0 ? "#94a3b8" : "#0a7cff",
            fillOpacity: 0.12,
          }).addTo(map);
        });
        map.on("click", (e) => {
          fillFromPos(e.latlng.lat.toFixed(6), e.latlng.lng.toFixed(6));
        });
        setTimeout(() => map.invalidateSize(), 250);
      } catch (err) {
        console.warn("neshan map error", err);
      }
    });
  }

  function renderSmartAttendance(root) {
    const name = USER.name || "";
    const isEmp = POLICY.is_employee || POLICY.role === "employee";
    const canManage = POLICY.is_manager || POLICY.role === "warehouse";

    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `<h2>⏱️ ورود / خروج هوشمند</h2>
      <p class="hint">با روشن بودن لوکیشن، ساعت همراه با مختصات شما ثبت می‌شود. اگر داخل یکی از نقاط کاری تعریف‌شده باشید، حضور «معتبر» خواهد بود.</p>`;

    if (isEmp || canManage) {
      const bar = document.createElement("div");
      bar.className = "smart-att-bar";
      const statusEl = document.createElement("div");
      statusEl.className = "smart-att-status";
      statusEl.textContent = "آماده ثبت — لوکیشن را روشن نگه دارید";
      bar.appendChild(statusEl);

      const doPunch = async (type) => {
        statusEl.textContent = "در حال دریافت موقعیت...";
        statusEl.className = "smart-att-status loading";
        let geo = null;
        try {
          geo = await getCurrentPosition();
        } catch (e) {
          statusEl.className = "smart-att-status err";
          statusEl.textContent = "موقعیت دریافت نشد: " + (e.message || "لوکیشن را روشن کنید");
          if (!confirm("بدون موقعیت ثبت شود؟ (حضور نامعتبر)")) return;
        }
        const site = geo ? matchWorkSite(geo.lat, geo.lng) : null;
        const now = new Date();
        const pad = (n) => String(n).padStart(2, "0");
        const timeStr = pad(now.getHours()) + ":" + pad(now.getMinutes());
        const dateStr = (J.todayStr && J.todayStr()) || "";
        const payload = {
          personnel_name: isEmp ? name : (prompt("نام پرسنل:", name) || name),
          att_date: dateStr,
          notes: site ? ("نقطه: " + site.name + " — فاصله " + site._dist + "م") : (geo ? "خارج از نقاط تعریف‌شده" : "بدون موقعیت"),
          lat: geo ? String(geo.lat) : "",
          lng: geo ? String(geo.lng) : "",
          accuracy_m: geo ? String(Math.round(geo.accuracy)) : "",
          site_name: site ? site.name : "",
          site_id: site ? site.id : 0,
          geo_ok: site ? 1 : 0,
          device_info: (navigator.userAgent || "").slice(0, 180),
        };
        if (type === "in") payload.check_in = timeStr;
        else payload.check_out = timeStr;

        const todayRows = (S.attendance || []).filter((a) =>
          a.personnel_name === payload.personnel_name && a.att_date === dateStr
        );
        if (todayRows.length && type === "out") {
          const last = todayRows[todayRows.length - 1];
          payload.id = last.id;
          if (!payload.check_in && last.check_in) payload.check_in = last.check_in;
        }

        statusEl.textContent = "در حال ذخیره...";
        const res = await api("save", { table: "attendance", payload });
        if (!res.ok) {
          statusEl.className = "smart-att-status err";
          statusEl.textContent = res.error || "خطا در ثبت";
          return;
        }
        statusEl.className = "smart-att-status ok";
        statusEl.textContent = (type === "in" ? "ورود" : "خروج") + " ثبت شد" +
          (site ? " ✓ در «" + site.name + "»" : " ⚠ خارج از محدوده نقاط");
        await reload();
        render();
      };

      const btnIn = document.createElement("button");
      btnIn.type = "button"; btnIn.className = "btn smart-att-in"; btnIn.textContent = "ثبت ورود";
      btnIn.onclick = () => doPunch("in");
      const btnOut = document.createElement("button");
      btnOut.type = "button"; btnOut.className = "btn btn-outline smart-att-out"; btnOut.textContent = "ثبت خروج";
      btnOut.onclick = () => doPunch("out");
      bar.appendChild(btnIn);
      bar.appendChild(btnOut);
      card.appendChild(bar);

      const sites = getWorkSites().filter((s) => s.active !== 0);
      if (sites.length) {
        const tip = document.createElement("p");
        tip.className = "hint";
        tip.textContent = "نقاط فعال: " + sites.map((s) => s.name + " (" + (s.radius_m || 150) + "م)").join("، ");
        card.appendChild(tip);
      } else if (canManage) {
        const tip = document.createElement("p");
        tip.className = "hint";
        tip.innerHTML = 'هنوز نقطه کاری تعریف نشده. از منوی <a href="#" id="go-ws">نقاط کاری</a> اضافه کنید.';
        card.appendChild(tip);
        tip.querySelector("#go-ws").onclick = (e) => { e.preventDefault(); menu = "work_sites"; renderNav(); render(); };
      }
    }

    root.appendChild(card);
    const filterName = isEmp && !canManage ? name : null;
    root.appendChild(crudTable("attendance", "سوابق ورود و خروج", {
      noAdd: true,
      filterFn: filterName ? (a) => a.personnel_name === filterName : null,
    }));
  }

  function renderAttendanceMap(root) {
    const today = (J.todayStr && J.todayStr()) || "";
    const filterDate = window.__attMapDate || today;
    const filterName = window.__attMapName || "";

    const head = document.createElement("div");
    head.className = "card";
    head.innerHTML = `<h2>🗺️ گزارش حضور روی نقشه (نشان)</h2>
      <p class="hint">مارکر سبز = موقعیت معتبر داخل نقطه کاری · قرمز = خارج از محدوده یا بدون نقطه · خاکستری = بدون مختصات</p>`;

    const filters = document.createElement("div");
    filters.className = "att-map-filters";
    filters.innerHTML = `
      <div class="field"><label>تاریخ</label><input type="text" id="att-map-date" value="${filterDate}" placeholder="${today}"></div>
      <div class="field"><label>پرسنل</label>
        <select id="att-map-name"><option value="">همه</option></select>
      </div>
      <button type="button" class="btn" id="att-map-go">نمایش</button>
      <button type="button" class="btn btn-outline" id="att-map-sites">نقاط کاری</button>`;
    head.appendChild(filters);

    const names = [...new Set((S.attendance || []).map((a) => a.personnel_name).filter(Boolean))].sort();
    const sel = filters.querySelector("#att-map-name");
    names.forEach((n) => {
      const o = document.createElement("option");
      o.value = n; o.textContent = n;
      if (n === filterName) o.selected = true;
      sel.appendChild(o);
    });
    filters.querySelector("#att-map-go").onclick = () => {
      window.__attMapDate = (filters.querySelector("#att-map-date").value || "").trim() || today;
      window.__attMapName = filters.querySelector("#att-map-name").value || "";
      render();
    };
    filters.querySelector("#att-map-sites").onclick = () => { menu = "work_sites"; renderNav(); render(); };
    root.appendChild(head);

    let rows = (S.attendance || []).filter((a) => {
      if (filterDate && a.att_date !== filterDate) return false;
      if (filterName && a.personnel_name !== filterName) return false;
      return true;
    });

    const stats = document.createElement("div");
    stats.className = "stats";
    const withGeo = rows.filter((a) => a.lat && a.lng);
    const okGeo = withGeo.filter((a) => a.geo_ok == 1 || a.geo_ok === "1");
    const badGeo = withGeo.filter((a) => !(a.geo_ok == 1 || a.geo_ok === "1"));
    [
      { l: "ثبت‌ها", v: rows.length },
      { l: "با موقعیت", v: withGeo.length },
      { l: "معتبر", v: okGeo.length },
      { l: "خارج محدوده", v: badGeo.length },
    ].forEach((s) => {
      const d = document.createElement("div");
      d.className = "stat";
      d.innerHTML = `<b>${s.v}</b><span>${s.l}</span>`;
      stats.appendChild(d);
    });
    root.appendChild(stats);

    const mapCard = document.createElement("div");
    mapCard.className = "card";
    const mapBox = document.createElement("div");
    mapBox.id = "att-report-map";
    mapBox.className = "work-sites-map att-report-map";
    mapCard.appendChild(mapBox);
    root.appendChild(mapCard);

    // جدول کنار نقشه
    const tableCard = document.createElement("div");
    tableCard.className = "card";
    tableCard.innerHTML = "<h3>جزئیات ثبت‌ها</h3>";
    if (!rows.length) {
      tableCard.innerHTML += '<p class="empty-hint">برای این فیلتر ثبتی نیست.</p>';
    } else {
      const wrap = document.createElement("div");
      wrap.className = "table-wrap";
      let html = `<table><thead><tr>
        <th>پرسنل</th><th>ورود</th><th>خروج</th><th>نقطه</th><th>موقعیت</th><th>دقت</th><th>IP</th>
      </tr></thead><tbody>`;
      rows.slice().reverse().forEach((a) => {
        const ok = a.geo_ok == 1 || a.geo_ok === "1";
        html += `<tr class="${a.lat ? (ok ? "inst-active" : "inst-overdue") : ""}">
          <td>${a.personnel_name || "—"}</td>
          <td>${a.check_in || "—"}</td>
          <td>${a.check_out || "—"}</td>
          <td>${a.site_name || "—"}</td>
          <td>${a.lat ? (ok ? "✓ معتبر" : "خارج محدوده") : "بدون GPS"}</td>
          <td>${a.accuracy_m ? a.accuracy_m + "م" : "—"}</td>
          <td>${a.ip_addr || "—"}</td>
        </tr>`;
      });
      html += "</tbody></table>";
      wrap.innerHTML = html;
      tableCard.appendChild(wrap);
    }
    root.appendChild(tableCard);

    ensureNeshan(() => {
      try {
        const sites = getWorkSites();
        let center = [35.699756, 51.338076];
        if (withGeo.length) center = [parseFloat(withGeo[0].lat), parseFloat(withGeo[0].lng)];
        else if (sites.length && sites[0].lat) center = [parseFloat(sites[0].lat), parseFloat(sites[0].lng)];

        const map = createNeshanMap("att-report-map", { center, zoom: 13, maptype: "neshan" });
        if (!map) return;

        // دایره نقاط کاری
        sites.forEach((s) => {
          if (!s.lat || !s.lng) return;
          L.circle([parseFloat(s.lat), parseFloat(s.lng)], {
            radius: parseInt(s.radius_m, 10) || 150,
            color: "#0a7cff",
            fillOpacity: 0.08,
            weight: 1,
          }).addTo(map);
          L.marker([parseFloat(s.lat), parseFloat(s.lng)]).addTo(map)
            .bindPopup(`<b>نقطه: ${s.name}</b><br>${s.kind || ""} — ${s.radius_m || 150}م`);
        });

        // مارکر حضورها
        const bounds = [];
        withGeo.forEach((a) => {
          const lat = parseFloat(a.lat);
          const lng = parseFloat(a.lng);
          if (isNaN(lat) || isNaN(lng)) return;
          bounds.push([lat, lng]);
          const ok = a.geo_ok == 1 || a.geo_ok === "1";
          const color = ok ? "#16a34a" : "#dc2626";
          const circle = L.circleMarker([lat, lng], {
            radius: 9,
            color,
            fillColor: color,
            fillOpacity: 0.85,
            weight: 2,
          }).addTo(map);
          circle.bindPopup(
            `<b>${a.personnel_name || "—"}</b><br>` +
            `ورود: ${a.check_in || "—"} · خروج: ${a.check_out || "—"}<br>` +
            `نقطه: ${a.site_name || "—"}<br>` +
            `${ok ? "✓ معتبر" : "⚠ خارج محدوده"} · دقت ${a.accuracy_m || "?"}م<br>` +
            `IP: ${a.ip_addr || "—"}`
          );
        });
        if (bounds.length > 1) {
          try { map.fitBounds(bounds, { padding: [40, 40] }); } catch (e) {}
        }
        setTimeout(() => map.invalidateSize(), 250);
      } catch (err) {
        console.warn("att map", err);
      }
    });
  }

  function bindStatReorder(container) {
    if (!container || !POLICY.is_manager) return;
    // روی لمسی جابه‌جایی باکس غیرفعال — مانع اسکرول داشبورد نشود
    const coarse = (window.matchMedia && window.matchMedia("(pointer: coarse)").matches)
      || ("ontouchstart" in window)
      || (navigator.maxTouchPoints > 0);
    if (coarse) return;
    const HOLD_MS = 900;
    container.querySelectorAll(".stat").forEach((el) => {
      let timer = null;
      let armed = false;
      let sx = 0;
      let sy = 0;
      const clearHold = () => { if (timer) { clearTimeout(timer); timer = null; } };
      el.addEventListener("pointerdown", (e) => {
        if (e.pointerType === "mouse" && e.button !== 0) return;
        // روی داده (دکمه لینک) long-press جابه‌جایی نگیر
        if (e.target && e.target.closest && e.target.closest(".stat-go")) return;
        sx = e.clientX;
        sy = e.clientY;
        armed = false;
        clearHold();
        timer = setTimeout(() => {
          armed = true;
          container.dataset.skipClick = "1";
          container.classList.add("stats-reordering");
          el.classList.add("stat-dragging");
          try { el.setPointerCapture(e.pointerId); } catch (err) {}
          showToast("جابه‌جایی دایره‌ها", "نگه داشتید — بکشید تا اولویت عوض شود. این چیدمان فقط برای شما ذخیره می‌شود.", "info");
        }, HOLD_MS);
      });
      el.addEventListener("pointermove", (e) => {
        // اسکرول عمودی: با کمی حرکت، تایمر long-press لغو شود
        if (timer && !armed && Math.hypot(e.clientX - sx, e.clientY - sy) > 8) {
          clearHold();
        }
        if (!armed) return;
        e.preventDefault();
        const under = document.elementFromPoint(e.clientX, e.clientY);
        const target = under && under.closest ? under.closest(".stat") : null;
        if (target && target !== el && target.parentElement === container) {
          const nodes = [...container.querySelectorAll(".stat")];
          const a = nodes.indexOf(el);
          const b = nodes.indexOf(target);
          if (a < 0 || b < 0) return;
          if (a < b) container.insertBefore(el, target.nextSibling);
          else container.insertBefore(el, target);
        }
      });
      const finish = () => {
        clearHold();
        if (!armed) return;
        armed = false;
        el.classList.remove("stat-dragging");
        PREFS.statOrder = [...container.querySelectorAll(".stat")].map((n) => n.dataset.key).filter(Boolean);
        savePrefs(PREFS);
        showToast("ترتیب ذخیره شد", "چیدمان باکس‌ها فقط برای حساب شماست.", "ok");
        setTimeout(() => {
          container.classList.remove("stats-reordering");
          container.dataset.skipClick = "0";
        }, 400);
      };
      el.addEventListener("pointerup", finish);
      el.addEventListener("pointercancel", finish);
    });
  }

  /** تقویم داشبورد: یادداشت روز + چک‌ها + مرخصی‌های همان روز */
  function renderDashCalendar(root) {
    if (!window.__calState) {
      const t = (J.todayStr() || "1403/01/01").split("/");
      window.__calState = {
        jy: parseInt(t[0], 10) || 1403,
        jm: parseInt(t[1], 10) || 1,
        selected: J.todayStr(),
      };
    }
    const st = window.__calState;
    const card = document.createElement("div");
    card.className = "card dash-cal-card";
    card.innerHTML = `<h2>تقویم روز</h2>
      <p class="hint">روی هر روز کلیک کنید تا یادداشت، چک‌ها و مرخصی‌های همان روز را ببینید و مدیریت کنید.</p>
      <div class="dash-cal-wrap">
        <div class="dash-cal-main"></div>
        <div class="dash-cal-side"></div>
      </div>`;
    root.appendChild(card);
    const main = card.querySelector(".dash-cal-main");
    const side = card.querySelector(".dash-cal-side");

    function noteDatesSet() {
      const set = {};
      const _my = (USER && USER.name) || "";
      (S.day_notes || []).forEach((n) => {
        if (!n.note_date) return;
        if (_my && n.created_by && n.created_by !== _my) return;
        if (_my && !n.created_by) return;
        set[String(n.note_date).trim()] = true;
      });
      return set;
    }

    function paintCalendar() {
      const jy = st.jy;
      const jm = st.jm;
      const daysIn = J.daysInJalaliMonth(jy, jm);
      const firstWd = J.jalaliWeekday(jy, jm, 1);
      const today = J.todayStr();
      const notesSet = noteDatesSet();
      const dows = ["ش", "ی", "د", "س", "چ", "پ", "ج"];

      main.innerHTML = "";
      const nav = document.createElement("div");
      nav.className = "dash-cal-nav";
      nav.innerHTML = `
        <button type="button" class="btn btn-sm btn-outline" data-cal-y="-1" title="سال قبل">« سال</button>
        <button type="button" class="btn btn-sm btn-outline" data-cal-m="-1" title="ماه قبل">‹</button>
        <span class="cal-title">${J.monthName(jm)} ${jy}</span>
        <button type="button" class="btn btn-sm btn-outline" data-cal-m="1" title="ماه بعد">›</button>
        <button type="button" class="btn btn-sm btn-outline" data-cal-y="1" title="سال بعد">سال »</button>
        <button type="button" class="btn btn-sm btn-outline" data-cal-today>امروز</button>`;
      main.appendChild(nav);

      nav.querySelector("[data-cal-m=\"-1\"]").onclick = () => {
        st.jm -= 1;
        if (st.jm < 1) { st.jm = 12; st.jy -= 1; }
        paintCalendar();
      };
      nav.querySelector("[data-cal-m=\"1\"]").onclick = () => {
        st.jm += 1;
        if (st.jm > 12) { st.jm = 1; st.jy += 1; }
        paintCalendar();
      };
      nav.querySelector("[data-cal-y=\"-1\"]").onclick = () => { st.jy -= 1; paintCalendar(); };
      nav.querySelector("[data-cal-y=\"1\"]").onclick = () => { st.jy += 1; paintCalendar(); };
      nav.querySelector("[data-cal-today]").onclick = () => {
        const p = (J.todayStr() || "").split("/");
        st.jy = parseInt(p[0], 10) || st.jy;
        st.jm = parseInt(p[1], 10) || st.jm;
        st.selected = J.todayStr();
        paintCalendar();
        paintSide();
      };

      const grid = document.createElement("div");
      grid.className = "dash-cal-grid";
      dows.forEach((d) => {
        const el = document.createElement("div");
        el.className = "cal-dow";
        el.textContent = d;
        grid.appendChild(el);
      });
      for (let i = 0; i < firstWd; i++) {
        const empty = document.createElement("div");
        empty.className = "cal-day other-month";
        empty.textContent = "";
        empty.style.visibility = "hidden";
        grid.appendChild(empty);
      }
      for (let d = 1; d <= daysIn; d++) {
        const dateStr = J.padDate(jy, jm, d);
        const cell = document.createElement("div");
        cell.className = "cal-day";
        if (dateStr === today) cell.classList.add("today");
        if (dateStr === st.selected) cell.classList.add("selected");
        if (notesSet[dateStr]) cell.classList.add("has-note");
        cell.textContent = String(d);
        cell.title = dateStr;
        cell.onclick = () => {
          st.selected = dateStr;
          paintCalendar();
          paintSide();
        };
        grid.appendChild(cell);
      }
      main.appendChild(grid);
    }

    function dayOverlapsLeave(r, day) {
      const f = (r.from_date || "").trim();
      const t = (r.to_date || f).trim();
      if (!f) return false;
      return f <= day && day <= t;
    }

    function paintSide() {
      const day = st.selected || J.todayStr();
      const myName = (USER && USER.name) || "";
      const notes = (S.day_notes || []).filter((n) => {
        if (String(n.note_date || "").trim() !== day) return false;
        // فقط یادداشت‌های خود کاربر
        if (myName && n.created_by && n.created_by !== myName) return false;
        if (myName && !n.created_by) return false; // بدون مالک را نشان نده
        return true;
      });
      const recv = (S.checks_received || []).filter((c) => String(c.check_date || "").trim() === day);
      const paid = (S.checks_paid || []).filter((c) => String(c.check_date || "").trim() === day);
      const leaves = (S.leave_requests || []).filter((r) => dayOverlapsLeave(r, day));

      side.innerHTML = `<h3>روز ${day}</h3>`;

      // یادداشت‌ها
      const secNote = document.createElement("div");
      secNote.className = "cal-section";
      secNote.innerHTML = `<h3>📝 یادداشت روز</h3>`;
      const form = document.createElement("div");
      form.className = "cal-note-form";
      form.innerHTML = `
        <textarea id="cal-note-body" placeholder="متن یادداشت این روز..."></textarea>
        <div class="field" style="margin:8px 0">
          <label>نوع یادداشت</label>
          <select id="cal-note-kind">
            <option value="remind">فقط یادآوری در تاریخ</option>
            <option value="action">پیگیری و انجام</option>
          </select>
        </div>
        <p class="hint" style="margin:4px 0 8px">یادآوری از روز قبل (حدود ۱۲ ساعت مانده) روی داشبورد شما می‌آید — فقط برای خودتان.</p>
        <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center">
          <input type="file" id="cal-note-file" accept=".pdf,.jpg,.jpeg,.png,.gif,.webp,image/*,application/pdf" style="font-size:.8rem;max-width:100%">
          <button type="button" class="btn btn-sm" id="cal-note-save">ثبت یادداشت</button>
        </div>`;
      secNote.appendChild(form);
      const ulNotes = document.createElement("ul");
      ulNotes.className = "cal-note-list";
      if (!notes.length) {
        const p = document.createElement("p");
        p.className = "empty-hint";
        p.textContent = "یادداشتی برای این روز ثبت نشده.";
        secNote.appendChild(p);
      } else {
        notes.forEach((n) => {
          const li = document.createElement("li");
          const text = document.createElement("div");
          text.style.flex = "1";
          text.style.minWidth = "120px";
          const kindL = (n.note_kind === "action") ? "پیگیری" : "یادآوری";
          const stL = (n.status === "done") ? " ✓ انجام‌شده" : (n.status === "snoozed" ? " (یادآوری مجدد)" : "");
          text.innerHTML = `<span class="hint">[${kindL}${stL}]</span> ` + (n.body || "—");
          li.appendChild(text);
          if (n.file_path) {
            const a = document.createElement("a");
            a.href = n.file_path;
            a.target = "_blank";
            a.rel = "noopener";
            a.className = "btn btn-sm btn-outline";
            a.textContent = "فایل";
            li.appendChild(a);
          }
          const del = document.createElement("button");
          del.type = "button";
          del.className = "btn btn-sm btn-danger";
          del.textContent = "حذف";
          del.onclick = async () => {
            if (!confirm("یادداشت حذف شود؟")) return;
            const res = await api("delete", { table: "day_notes", id: n.id });
            if (res && res.ok) {
              S.day_notes = (S.day_notes || []).filter((x) => String(x.id) !== String(n.id));
              paintCalendar();
              paintSide();
            } else alert((res && res.error) || "خطا در حذف");
          };
          li.appendChild(del);
          ulNotes.appendChild(li);
        });
        secNote.appendChild(ulNotes);
      }
      form.querySelector("#cal-note-save").onclick = async () => {
        const body = (form.querySelector("#cal-note-body").value || "").trim();
        if (!body) { alert("متن یادداشت را بنویسید"); return; }
        let filePath = "";
        const fileInp = form.querySelector("#cal-note-file");
        if (fileInp && fileInp.files && fileInp.files[0]) {
          const fd = new FormData();
          fd.append("action", "upload");
          fd.append("_wpnonce", CSRF);
          fd.append("instance", String(INSTANCE_ID));
          fd.append("file", fileInp.files[0]);
          fd.append("table", "photos");
          fd.append("payload", JSON.stringify({ project: "day_note", stage: "note", caption: day }));
          try {
            const up = await fetch(API + (API.includes("?") ? "&" : "?") + "action=upload", { method: "POST", body: fd, credentials: "same-origin" }).then((r) => r.json());
            if (up.ok && up.data) {
              filePath = up.data.url || (window.UPLOADS ? window.UPLOADS + (up.data.filename || "") : "");
            } else {
              alert((up && up.error) || "آپلود فایل ناموفق بود");
              return;
            }
          } catch (e) {
            alert("خطا در آپلود فایل");
            return;
          }
        }
        const noteKind = (form.querySelector("#cal-note-kind") || {}).value || "remind";
        const payload = {
          note_date: day,
          body,
          file_path: filePath,
          created_by: (USER && USER.name) || "",
          note_kind: noteKind,
          status: "pending",
          snooze_until: "",
        };
        const res = await api("save", { table: "day_notes", payload });
        if (res && res.ok) {
          if (!S.day_notes) S.day_notes = [];
          if (res.data) S.day_notes.push(res.data);
          else S.day_notes.push(Object.assign({ id: Date.now() }, payload));
          paintCalendar();
          paintSide();
        } else alert((res && res.error) || "ذخیره ناموفق");
      };
      side.appendChild(secNote);

      // چک‌ها
      const secChk = document.createElement("div");
      secChk.className = "cal-section";
      secChk.innerHTML = `<h3>💳 چک‌های این روز</h3>`;
      const ulChk = document.createElement("ul");
      ulChk.className = "cal-check-list";
      if (!recv.length && !paid.length) {
        const p = document.createElement("p");
        p.className = "empty-hint";
        p.textContent = "چکی با سررسید این روز نیست.";
        secChk.appendChild(p);
      } else {
        recv.forEach((c) => {
          const li = document.createElement("li");
          li.innerHTML = `<span style="flex:1"><strong>دریافتنی</strong> — ${c.name || c.payee || "—"} — ${fmt(c.amount, "amount")}</span>
            <span class="hint">${c.approval === "approved" || c.approval === "تأیید" ? "تأییدشده" : (c.approval === "rejected" || c.approval === "رد" ? "رد" : "در انتظار")}</span>`;
          ulChk.appendChild(li);
        });
        paid.forEach((c) => {
          const li = document.createElement("li");
          li.innerHTML = `<span style="flex:1"><strong>پرداختی</strong> — ${c.name || c.payee || "—"} — ${fmt(c.amount, "amount")}</span>
            <span class="hint">${c.approval === "approved" || c.approval === "تأیید" ? "تأییدشده" : (c.approval === "rejected" || c.approval === "رد" ? "رد" : "در انتظار")}</span>`;
          ulChk.appendChild(li);
        });
        secChk.appendChild(ulChk);
      }
      side.appendChild(secChk);

      // مرخصی‌ها
      const secLeave = document.createElement("div");
      secLeave.className = "cal-section";
      secLeave.innerHTML = `<h3>☀️ مرخصی‌های این روز</h3>`;
      const ulLeave = document.createElement("ul");
      ulLeave.className = "cal-leave-list";
      if (!leaves.length) {
        const p = document.createElement("p");
        p.className = "empty-hint";
        p.textContent = "مرخصی ثبت‌شده‌ای برای این روز نیست.";
        secLeave.appendChild(p);
      } else {
        leaves.forEach((r) => {
          const stLabel = r.status || "در انتظار";
          const li = document.createElement("li");
          const info = document.createElement("div");
          info.style.flex = "1";
          info.style.minWidth = "140px";
          info.innerHTML = `<strong>${r.personnel_name || "—"}</strong> — ${r.leave_type || ""}<br>
            <span class="hint">${r.from_date || ""} تا ${r.to_date || r.from_date || ""} — وضعیت: ${stLabel}</span>`;
          li.appendChild(info);
          const acts = document.createElement("div");
          acts.className = "leave-actions";
          const makeBtn = (label, newStatus, cls) => {
            const b = document.createElement("button");
            b.type = "button";
            b.className = "btn btn-sm " + (cls || "");
            b.textContent = label;
            b.onclick = async () => {
              const res = await api("save", { table: "leave_requests", payload: { id: Number(r.id), status: newStatus } });
              if (res && res.ok) {
                r.status = newStatus;
                const idx = (S.leave_requests || []).findIndex((x) => String(x.id) === String(r.id));
                if (idx >= 0) S.leave_requests[idx].status = newStatus;
                paintSide();
              } else alert((res && res.error) || "خطا در تغییر وضعیت");
            };
            return b;
          };
          if (stLabel === "در انتظار" || !stLabel) {
            acts.appendChild(makeBtn("تأیید", "تأیید", ""));
            acts.appendChild(makeBtn("رد", "رد", "btn-danger"));
          } else if (stLabel === "تأیید" || stLabel === "تأییدشده") {
            acts.appendChild(makeBtn("برگرد به انتظار", "در انتظار", "btn-outline"));
            acts.appendChild(makeBtn("رد", "رد", "btn-danger"));
          } else {
            acts.appendChild(makeBtn("برگرد به انتظار", "در انتظار", "btn-outline"));
            acts.appendChild(makeBtn("تأیید", "تأیید", ""));
          }
          li.appendChild(acts);
          ulLeave.appendChild(li);
        });
        secLeave.appendChild(ulLeave);
      }
      side.appendChild(secLeave);
    }

    paintCalendar();
    paintSide();
  }

  
  /** یادداشت‌های نیازمند یادآوری برای کاربر فعلی (روز قبل یا همان روز، و snooze گذشته) */
  function myDueDayNotes() {
    const myName = (USER && USER.name) || "";
    if (!myName) return [];
    const today = (window.J && J.todayStr) ? J.todayStr() : "";
    return (S.day_notes || []).filter((n) => {
      if ((n.created_by || "") !== myName) return false;
      if ((n.status || "pending") === "done") return false;
      const nd = String(n.note_date || "").trim();
      if (!nd) return false;
      // snooze: اگر هنوز به تاریخ snooze نرسیده‌ایم نشان نده
      const sn = String(n.snooze_until || "").trim();
      if (sn && today) {
        const ds = J.daysUntil(sn);
        if (ds !== null && ds > 0) return false; // snooze در آینده
      }
      const d = J.daysUntil(nd);
      if (d === null) return false;
      // ۱۲ ساعت مانده / روز قبل یا همان روز یا معوق (برای پیگیری)
      if ((n.note_kind || "remind") === "action") {
        return d <= 1; // تا یک روز قبل و بعد تا انجام
      }
      return d >= 0 && d <= 1; // فقط روز قبل و روز موعد
    });
  }

  function renderMyNoteReminders(root) {
    const due = myDueDayNotes();
    if (!due.length) return;
    const card = document.createElement("div");
    card.className = "card dash-note-reminders";
    card.innerHTML = `<h2>📝 یادداشت‌های من — نیازمند توجه <span class="att-badge">${due.length}</span></h2>`;
    const list = document.createElement("div");
    list.className = "dash-attention-list";
    due.forEach((n) => {
      const d = J.daysUntil(n.note_date);
      const when = d === 0 ? "امروز" : (d === 1 ? "فردا (یادآوری روز قبل)" : (d < 0 ? Math.abs(d) + " روز گذشته" : d + " روز مانده"));
      const kind = (n.note_kind === "action") ? "پیگیری و انجام" : "یادآوری";
      const row = document.createElement("div");
      row.className = "dash-att-row att-level-" + (d <= 0 ? "0" : "1");
      row.innerHTML = `<span class="dat-icon">📝</span>
        <span class="dat-text"><strong>${when}</strong> — [${kind}] ${n.body || "—"}
        <div class="hint">تاریخ: ${n.note_date || "—"}</div></span>`;
      const acts = document.createElement("span");
      acts.style.cssText = "display:inline-flex;gap:6px;flex-wrap:wrap";
      const done = document.createElement("button");
      done.type = "button"; done.className = "btn btn-sm"; done.textContent = "انجام شد";
      done.onclick = async () => {
        const res = await api("save", { table: "day_notes", payload: { id: n.id, status: "done" } });
        if (res.ok) {
          const idx = (S.day_notes || []).findIndex((x) => String(x.id) === String(n.id));
          if (idx >= 0) S.day_notes[idx].status = "done";
          showToast("ثبت شد", "یادداشت انجام‌شده علامت خورد", "ok");
          render();
        } else alert(res.error || "خطا");
      };
      const again = document.createElement("button");
      again.type = "button"; again.className = "btn btn-sm btn-outline"; again.textContent = "یادآوری مجدد";
      again.onclick = async () => {
        // فردا دوباره نشان بده
        let snooze = n.note_date || "";
        try {
          if (window.J && J.todayStr) {
            // snooze تا فردا: از امروز یک روز جلو
            const parts = (J.todayStr() || "").split("/").map(Number);
            if (parts.length >= 3) {
              let y = parts[0], m = parts[1], d = parts[2] + 1;
              const maxD = m <= 6 ? 31 : (m <= 11 ? 30 : 29);
              if (d > maxD) { d = 1; m += 1; }
              if (m > 12) { m = 1; y += 1; }
              const pad = (x) => String(x).padStart(2, "0");
              snooze = y + "/" + pad(m) + "/" + pad(d);
            }
          }
        } catch (e) {}
        const res = await api("save", { table: "day_notes", payload: { id: n.id, status: "snoozed", snooze_until: snooze } });
        if (res.ok) {
          const idx = (S.day_notes || []).findIndex((x) => String(x.id) === String(n.id));
          if (idx >= 0) {
            S.day_notes[idx].status = "snoozed";
            S.day_notes[idx].snooze_until = snooze;
          }
          showToast("یادآوری مجدد", "فردا دوباره در داشبورد می‌آید", "info");
          render();
        } else alert(res.error || "خطا");
      };
      acts.appendChild(done);
      acts.appendChild(again);
      row.appendChild(acts);
      list.appendChild(row);
    });
    card.appendChild(list);
    root.appendChild(card);
  }


  function renderDashboard(root) {
    if (POLICY.is_employee || menu === "emp_dashboard") {
      renderEmpDashboard(root);
      return;
    }

    // —— ساعت دیجیتال بزرگ بالای داشبورد ——
    const clockWrap = document.createElement("div");
    clockWrap.className = "dash-digital-clock";
    clockWrap.id = "dash-digital-clock";
    clockWrap.innerHTML = `
      <div class="ddc-time" id="ddc-time">--:--:--</div>
      <div class="ddc-date" id="ddc-date"></div>
    `;
    root.appendChild(clockWrap);

    const pad = (n) => String(n).padStart(2, "0");
    const faDigits = (s) => String(s).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[d]);
    const tickClock = () => {
      const now = new Date();
      const h = pad(now.getHours());
      const m = pad(now.getMinutes());
      const s = pad(now.getSeconds());
      const timeEl = document.getElementById("ddc-time");
      const dateEl = document.getElementById("ddc-date");
      if (timeEl) timeEl.textContent = faDigits(h + ":" + m + ":" + s);
      if (dateEl) {
        try {
          if (window.J && J.toJalali) {
            const j = J.toJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
            const weekDays = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنج‌شنبه", "جمعه", "شنبه"];
            const wd = weekDays[now.getDay()];
            dateEl.textContent = faDigits(wd + "  " + j[0] + "/" + pad(j[1]) + "/" + pad(j[2]));
          } else {
            dateEl.textContent = faDigits(now.toLocaleDateString("fa-IR"));
          }
        } catch (e) {
          dateEl.textContent = faDigits(now.toLocaleDateString("fa-IR"));
        }
      }
    };
    tickClock();
    if (window.__ddcTimer) clearInterval(window.__ddcTimer);
    window.__ddcTimer = setInterval(tickClock, 1000);

    // —— دکمه پخش زنده مجموعه ——
    const liveUrl = (S.settings && S.settings.cameras_url) || "";
    const liveBar = document.createElement("div");
    liveBar.className = "dash-live-bar";
    const liveBtn = document.createElement("button");
    liveBtn.type = "button";
    liveBtn.className = "btn dash-live-btn";
    liveBtn.innerHTML = "📹 پخش زنده دوربین‌های مجموعه";
    liveBtn.onclick = () => {
      if (liveUrl) {
        window.open(liveUrl, "_blank", "noopener");
      } else {
        alert("لینک پخش زنده هنوز تنظیم نشده.\nاز تنظیمات → لینک پخش زنده دوربین‌ها را وارد کنید.");
        if (POLICY.is_manager) {
          menu = "settings";
          renderNav();
          renderBottomNav();
          render();
        }
      }
    };
    liveBar.appendChild(liveBtn);
    root.appendChild(liveBar);

    // —— باکس کارهای محوله (زیر ساعت) ——
    const inbox = document.createElement("div");
    inbox.className = "dash-inbox";
    const inboxTitle = document.createElement("h2");
    inboxTitle.className = "dash-inbox-title";
    inboxTitle.textContent = "کارهای محوله و یادآوری‌ها";
    inbox.appendChild(inboxTitle);

    const inboxItems = [];

    (S.directives || []).filter((d) => {
      const st = d.status || "باز";
      return st === "باز" || st === "pending" || st === "در حال انجام" || st === "";
    }).slice(0, 8).forEach((d) => {
      inboxItems.push({
        type: "directive", icon: "📨",
        title: d.title || "دستور",
        meta: (d.target_name || d.target_role || "") + (d.due_date ? " — مهلت " + d.due_date : ""),
        actions: [
          { l: "انجام شد", cls: "", fn: async () => {
            const res = await api("save", { table: "directives", payload: { id: Number(d.id), status: "انجام شد" } });
            if (res.ok) { await reload(); render(); } else alert(res.error || "خطا");
          }},
          { l: "یادآوری مجدد", cls: "btn-outline", fn: async () => {
            const res = await api("save", { table: "directives", payload: { id: Number(d.id), status: "باز", reminders_sent: "0" } });
            if (res.ok) { alert("یادآوری ریست شد"); await reload(); render(); } else alert(res.error || "خطا");
          }},
        ],
      });
    });

    [...(S.checks_received || []).map((c) => Object.assign({}, c, { _kind: "recv" })),
      ...(S.checks_paid || []).map((c) => Object.assign({}, c, { _kind: "paid" }))
    ].filter((c) => {
      const d = J.daysUntil(c.check_date);
      return d !== null && d >= 0 && d <= 3;
    }).slice(0, 6).forEach((c) => {
      const days = J.daysUntil(c.check_date);
      inboxItems.push({
        type: "check", icon: "💳",
        title: (c._kind === "recv" ? "دریافتنی: " : "پرداختی: ") + (c.name || c.payee || "—"),
        meta: fmt(c.amount, "amount") + " — سررسید " + (c.check_date || "") + (days === 0 ? " (امروز)" : " (" + days + " روز)"),
        actions: [
          { l: "تأیید", cls: "", fn: async () => {
            const tbl = c._kind === "recv" ? "checks_received" : "checks_paid";
            const res = await api("save", { table: tbl, payload: { id: Number(c.id), approval: "approved" } });
            if (res.ok) { await reload(); render(); } else alert(res.error || "خطا");
          }},
          { l: "رد", cls: "btn-danger", fn: async () => {
            const tbl = c._kind === "recv" ? "checks_received" : "checks_paid";
            const res = await api("save", { table: tbl, payload: { id: Number(c.id), approval: "rejected" } });
            if (res.ok) { await reload(); render(); } else alert(res.error || "خطا");
          }},
        ],
      });
    });

    (S.leave_requests || []).filter((r) => r.status === "در انتظار" || !r.status).slice(0, 5).forEach((r) => {
      inboxItems.push({
        type: "leave", icon: "☀️",
        title: "مرخصی: " + (r.personnel_name || "—"),
        meta: (r.leave_type || "") + " — " + (r.from_date || "") + (r.to_date ? " تا " + r.to_date : ""),
        actions: [
          { l: "تأیید", cls: "", fn: async () => {
            const res = await api("save", { table: "leave_requests", payload: { id: Number(r.id), status: "تأیید" } });
            if (res.ok) { await reload(); render(); } else alert(res.error || "خطا");
          }},
          { l: "رد", cls: "btn-danger", fn: async () => {
            const res = await api("save", { table: "leave_requests", payload: { id: Number(r.id), status: "رد" } });
            if (res.ok) { await reload(); render(); } else alert(res.error || "خطا");
          }},
        ],
      });
    });

    (S.stock_usage || []).filter((r) => r.kind === "بازگشت" && (r.status === "در انتظار تأیید" || r.status === "در انتظار")).slice(0, 5).forEach((r) => {
      inboxItems.push({
        type: "return", icon: "📦",
        title: "بازگشت انبار: " + (r.item_name || "—"),
        meta: "تعداد " + (r.qty || "") + (r.project ? " — " + r.project : ""),
        actions: [
          { l: "تأیید بازگشت", cls: "", fn: async () => {
            const res = await api("save", { table: "stock_usage", payload: { id: Number(r.id), status: "تأییدشده" } });
            if (res.ok) { await reload(); render(); } else alert(res.error || "خطا");
          }},
        ],
      });
    });

    (S.daily_reports || []).slice().sort((a, b) => {
      const da = a.report_date || a.created_at || "";
      const db = b.report_date || b.created_at || "";
      return db.localeCompare(da);
    }).slice(0, 5).forEach((r) => {
      inboxItems.push({
        type: "report", icon: "📝",
        title: "گزارش: " + (r.personnel_name || "—"),
        meta: (r.project || "") + (r.report_date ? " — " + r.report_date : "") + (r.stage ? " — " + r.stage : ""),
        actions: [
          { l: "مشاهده", cls: "btn-outline", fn: () => openModal("daily_reports", r) },
        ],
      });
    });

    if (!inboxItems.length) {
      const empty = document.createElement("p");
      empty.className = "empty-hint";
      empty.textContent = "کار معلقی نیست — همه چیز به‌روز است.";
      inbox.appendChild(empty);
    } else {
      const list = document.createElement("div");
      list.className = "dash-inbox-list";
      inboxItems.forEach((it) => {
        const row = document.createElement("div");
        row.className = "dash-inbox-item dash-inbox-" + it.type;
        row.innerHTML = `<span class="dii-icon">${it.icon}</span>
          <div class="dii-body"><strong>${it.title}</strong><span class="dii-meta">${it.meta || ""}</span></div>`;
        const acts = document.createElement("div");
        acts.className = "dii-actions";
        (it.actions || []).forEach((a) => {
          const b = document.createElement("button");
          b.type = "button";
          b.className = "btn btn-sm " + (a.cls || "");
          b.textContent = a.l;
          b.onclick = (e) => { e.stopPropagation(); a.fn(); };
          acts.appendChild(b);
        });
        row.appendChild(acts);
        list.appendChild(row);
      });
      inbox.appendChild(list);
    }
    root.appendChild(inbox);

    const pendingLeave = (S.leave_requests || []).filter((r) => r.status === "در انتظار" || !r.status);
    const pendingOt = (S.overtime || []).filter((r) => r.status === "در انتظار" || !r.status);
    const pendingReturn = (S.stock_usage || []).filter((r) => r.kind === "بازگشت" && (r.status === "در انتظار تأیید" || r.status === "در انتظار"));
    const openDirs = (S.directives || []).filter((d) => d.status === "باز" || !d.status);
    const lowStock = (S.stock_items || []).filter((i) => StockHelper.isLow(i));
    // keep original parse for compatibility below if needed
    const _lowStockCompat = (S.stock_items || []).filter((i) => {
      const qty = parseFloat(i.qty) || 0;
      const min = parseFloat(i.min_qty) || 0;
      return min > 0 && qty <= min;
    });
    const pendingChecks = [...(S.checks_received || []), ...(S.checks_paid || [])].filter((c) => normalizeCheckStatus(c) === "pending");
    const exhaustedDirs = (S.directives || []).filter((d) => {
      const st = d.status || "باز";
      if (st !== "باز" && st !== "pending" && st !== "") return false;
      const rc = parseInt(d.reminder_count, 10) || 0;
      const sent = parseInt(d.reminders_sent, 10) || 0;
      return rc > 0 && sent >= rc;
    });

    // چک‌های نزدیک سررسید (۳ روز)
    const dueRecv = (S.checks_received || []).filter((c) => {
      const d = J.daysUntil(c.check_date);
      return d !== null && d >= 0 && d <= 3;
    });
    const duePaid = (S.checks_paid || []).filter((c) => {
      const d = J.daysUntil(c.check_date);
      return d !== null && d >= 0 && d <= 3;
    });
    const onLeaveNow = (S.personnel || []).filter((p) => personOnLeave(p.name));
    const sumRecvAll = sumChecks(S.checks_received || []);
    const sumPaidAll = sumChecks(S.checks_paid || []);
    const unreadChat = (typeof countUnread === "function") ? countUnread() : 0;
    const totalPersonnel = (S.personnel || []).filter((p) => !(p._deleted || (p.deleted_at && p.deleted_at !== "0000-00-00 00:00:00"))).length;
    const todayStr = (window.J && J.todayStr) ? J.todayStr() : "";
    const presentToday = (S.attendance || []).filter((a) => {
      const d = a.att_date || a.check_in || "";
      return d && todayStr && String(d).indexOf(todayStr) === 0;
    });
    const presentNames = new Set(presentToday.map((a) => a.personnel_name).filter(Boolean));
    const presentCount = presentNames.size || Math.max(0, totalPersonnel - onLeaveNow.length);
    const absentCount = Math.max(0, totalPersonnel - presentCount);
    const uncheckedReports = (S.daily_reports || []).filter((r) => {
      const st = (r.status || "").trim();
      return !st || st === "در انتظار" || st === "بررسی‌نشده" || st === "pending";
    }).length;
    const installments = (S.installments || (S.settings && S.settings.installments) || []);
    const dueInstallments = (Array.isArray(installments) ? installments : []).filter((x) => {
      const st = (x.status || "فعال").trim();
      if (st === "پرداخت‌شده" || st === "paid") return false;
      const d = J.daysUntil(x.due_date || x.check_date || "");
      if (d === null) return false;
      const remind = parseInt(x.remind_days, 10);
      const rDays = isNaN(remind) ? 3 : remind;
      // معوق یا داخل بازه یادآوری
      return d < 0 || d <= rDays;
    });

    // —— کادر نیازمند توجه (مرتب‌شده بر اساس فوریت) ——
    // level: 0 فوری / 1 هشدار / 2 اطلاع
    const attItems = [];

    const allDueChecks = [...dueRecv.map((c) => Object.assign({}, c, { _t: "recv" })), ...duePaid.map((c) => Object.assign({}, c, { _t: "paid" }))]
      .map((c) => Object.assign({}, c, { _days: J.daysUntil(c.check_date) }))
      .filter((c) => c._days !== null)
      .sort((a, b) => a._days - b._days);
    allDueChecks.slice(0, 3).forEach((c) => {
      const dayTxt = c._days === 0 ? "امروز سررسید چک" : (c._days === 1 ? "یک روز تا سررسید چک" : c._days + " روز تا سررسید چک");
      attItems.push({
        level: c._days <= 1 ? 0 : 1,
        icon: "💳",
        text: `<strong>${dayTxt}</strong> — ${c.name || c.payee || "—"} — ${fmt(c.amount, "amount")}`,
        btn: "مشاهده",
        go: () => { menu = "finance"; renderNav(); render(); },
      });
    });

    dueInstallments.slice(0, 2).forEach((x) => {
      const d = J.daysUntil(x.due_date || x.check_date || "");
      if (d === null) return;
      const dayTxt = d === 0 ? "امروز سررسید" : (d === 1 ? "یک روز تا سررسید" : d + " روز تا سررسید");
      attItems.push({
        level: d <= 1 ? 0 : 1,
        icon: "🏠",
        text: `<strong>${dayTxt} ${x.kind || "قسط/اجاره"}</strong> — ${x.title || x.name || "—"}`,
        btn: "اقساط و اجاره‌ها",
        go: () => { menu = "installments"; renderNav(); render(); },
      });
    });
    if (!dueInstallments.length) {
      attItems.push({
        level: 2,
        icon: "🏠",
        text: `<strong>سررسید اجاره / اقساط</strong> — موردی ثبت نشده؛ از حسابداری ثبت کنید`,
        btn: "اقساط و اجاره‌ها",
        go: () => { menu = "installments"; renderNav(); render(); },
      });
    }

    lowStock.slice(0, 4).forEach((item) => {
      attItems.push({
        level: 0,
        icon: "📦",
        text: `<strong>${item.item || "کالا"} — کمبود</strong> — مانده: ${StockHelper.formatRemaining(item)}`,
        btn: "انبار",
        go: () => { window.__whFilter = "low_stock"; menu = "warehouse"; renderNav(); render(); },
      });
    });

    if (uncheckedReports > 0) {
      attItems.push({
        level: 1,
        icon: "📝",
        text: `<strong>${uncheckedReports} گزارش روزانه بررسی‌نشده</strong>`,
        btn: "مشاهده",
        go: () => { menu = "personnel"; renderNav(); render(); },
      });
    }
    if (pendingReturn.length > 0) {
      attItems.push({
        level: 1,
        icon: "↩️",
        text: `<strong>${pendingReturn.length} بازگشت انبار در انتظار تأیید</strong>`,
        btn: "تأیید",
        go: () => { menu = "stock_usage"; renderNav(); render(); },
      });
    }
    if (openDirs.length > 0) {
      attItems.push({
        level: 2,
        icon: "📨",
        text: `<strong>${openDirs.length} دستور باز</strong> — پیگیری وضعیت`,
        btn: "دستورات",
        go: () => { menu = "directives"; renderNav(); render(); },
      });
    }

    attItems.sort((a, b) => a.level - b.level);

    const attention = document.createElement("div");
    attention.className = "dash-attention card";
    const urgentCount = attItems.filter((x) => x.level <= 1).length;
    attention.innerHTML = `<h2 class="dash-attention-title">⚠️ نیازمند توجه ${urgentCount ? `<span class="att-badge">${urgentCount}</span>` : ""}</h2>`;
    const attList = document.createElement("div");
    attList.className = "dash-attention-list";

    if (!attItems.length) {
      attList.innerHTML = `<p class="empty-hint">مورد فوری برای توجه نیست — همه‌چیز آرام است.</p>`;
    } else {
      attItems.forEach((it) => {
        const row = document.createElement("div");
        row.className = "dash-att-row att-level-" + it.level;
        row.innerHTML = `<span class="dat-icon">${it.icon}</span><span class="dat-text">${it.text}</span>`;
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "btn btn-sm" + (it.level === 0 ? "" : " btn-outline");
        btn.textContent = it.btn;
        btn.onclick = it.go;
        row.appendChild(btn);
        attList.appendChild(row);
      });
    }
    attention.appendChild(attList);
    root.appendChild(attention);

    // —— کادر یکپارچه پرسنل ——
    const persCard = document.createElement("div");
    persCard.className = "dash-personnel-card card";
    persCard.innerHTML = `
      <h2>👷 پرسنل</h2>
      <div class="dpc-grid">
        <div class="dpc-item"><span class="dpc-label">حضور امروز</span><strong>${presentCount} از ${totalPersonnel} نفر</strong></div>
        <div class="dpc-item${(onLeaveNow.length || absentCount) > 0 ? " dpc-warn" : ""}"><span class="dpc-label">مرخصی / غایب</span><strong>${onLeaveNow.length || absentCount} نفر</strong></div>
        <div class="dpc-item dpc-link${pendingLeave.length ? " dpc-alert" : ""}" data-go="leave"><span class="dpc-label">درخواست مرخصی در انتظار</span><strong>${pendingLeave.length}</strong></div>
        <div class="dpc-item dpc-link${pendingOt.length ? " dpc-alert" : ""}" data-go="overtime"><span class="dpc-label">اضافه‌کاری در انتظار</span><strong>${pendingOt.length}</strong></div>
      </div>
    `;
    persCard.querySelectorAll("[data-go]").forEach((el) => {
      el.style.cursor = "pointer";
      el.onclick = () => { menu = el.dataset.go; renderNav(); render(); };
    });
    const attMapBtn = document.createElement("button");
    attMapBtn.type = "button";
    attMapBtn.className = "btn btn-sm btn-outline";
    attMapBtn.style.marginTop = "10px";
    attMapBtn.textContent = "گزارش حضور روی نقشه";
    attMapBtn.onclick = () => { menu = "att_map"; renderNav(); render(); };
    persCard.appendChild(attMapBtn);
    root.appendChild(persCard);

    const stats = document.createElement("div");
    stats.className = "stats stats-kpis stats-circles";

    const STAT_HELP = {
      pending_return: "بازگشت کالا به انبار که هنوز تأیید نشده.",
      open_dirs: "دستورهایی که هنوز بسته نشده‌اند.",
      low_stock: "کالاهایی که موجودی‌شان به حداقل رسیده و باید تهیه شوند.",
      pending_checks: "چک‌هایی که منتظر تأیید شما هستند.",
      due_checks: "چک‌های دریافتنی و پرداختنی که تا ۳ روز دیگر سررسید می‌شوند.",
      new_stages: "مشتریان جدیدی که مرحله‌شان عقب افتاده یا یادآور دارند.",
      active_customers: "مشتریانی که پروژه‌شان هنوز تحویل نشده.",
      stock_count: "تعداد اقلام تعریف‌شده در انبار.",
      salary_due: "پرسنلی که تا ۳ روز دیگر موعد پرداخت حقوق دارند.",
    };

    // مرخصی/اضافه‌کاری/پرسنل از باکس‌های جدا حذف شدند — داخل کادر پرسنل هستند
    // color: red | amber | blue | green | purple | teal
    const statsItems = [
      { key: "pending_return", l: "بازگشت انبار", v: pendingReturn.length, alert: pendingReturn.length > 0, menu: "stock_usage", filter: "pending_return", color: "amber" },
      { key: "open_dirs", l: "دستورات باز", v: openDirs.length, alert: openDirs.length > 0, menu: "directives", filter: "open_dirs", color: "purple" },
      { key: "low_stock", l: "کمبود موجودی", v: lowStock.length, alert: lowStock.length > 0, menu: "warehouse", filter: "low_stock", color: "red" },
      { key: "pending_checks", l: "چک در انتظار", v: pendingChecks.length, alert: pendingChecks.length > 0, menu: "finance", color: "blue" },
      { key: "due_checks", l: "سررسید چک", v: (dueRecv.length + duePaid.length), alert: (dueRecv.length + duePaid.length) > 0, menu: "finance", color: "teal" },
      { key: "new_stages", l: "مراحل عقب‌مانده", v: (S.customers || []).filter(c => {
        const st = normalizeCustomerStatus(c.status);
        return st === "مشتریان جدید" && (c.stage_action === "later" || !c.sub_stage || c.sub_stage === "اندازه‌گیری");
      }).length, alert: true, menu: "customers", filter: "new_stages", color: "amber" },
      { key: "active_customers", l: "مشتریان فعال", v: (S.customers || []).filter((c) => normalizeCustomerStatus(c.status) !== "تحویل داده شده" && normalizeCustomerStatus(c.status) !== "تحویل شده").length, menu: "customers", color: "green" },
      { key: "stock_count", l: "کالای انبار", v: (S.stock_items || []).length, menu: "warehouse", color: "blue" },
    ];
    if (POLICY.role === "warehouse") {
      const day = new Date().getDate();
      const n = (S.personnel || []).filter((p) => {
        const sd = parseInt(p.salary_day, 10) || 0;
        return sd > 0 && Math.abs(sd - day) <= 3;
      }).length;
      statsItems.push({ key: "salary_due", l: "سررسید حقوق", v: n, alert: n > 0, menu: "salary" });
    }
    const savedOrder = Array.isArray(PREFS.statOrder) ? PREFS.statOrder : [];
    if (savedOrder.length) {
      statsItems.sort((a, b) => {
        const ia = savedOrder.indexOf(a.key);
        const ib = savedOrder.indexOf(b.key);
        if (ia < 0 && ib < 0) return 0;
        if (ia < 0) return 1;
        if (ib < 0) return -1;
        return ia - ib;
      });
    }
    // راهنمای جابه‌جایی دایره‌ها
    if (POLICY.is_manager) {
      const hint = document.createElement("p");
      hint.className = "stats-reorder-hint";
      hint.textContent = "برای تغییر اولویت دایره‌ها: یک ثانیه نگه دارید و بکشید (ترتیب فقط برای شما ذخیره می‌شود).";
      root.appendChild(hint);
    }

    // دایره‌های صفر (غیرحیاتی) را پنهان کن تا داشبورد خلوت‌تر باشد
    const alwaysShow = ["active_customers", "stock_count"];
    statsItems.filter((i) => alwaysShow.includes(i.key) || (Number(i.v) > 0) || i.alert).forEach((i) => {
      const d = document.createElement("div");
      d.className = "stat" + (i.alert ? " stat-alert" : "") + (i.color ? " stat-c-" + i.color : "");
      d.dataset.key = i.key || i.l;
      d.dataset.help = STAT_HELP[i.key] || HELP_TEXTS.stat;
      if (i.menu) {
        d.innerHTML = `<button type="button" class="stat-go" title="رفتن به ${i.l}"><b>${i.v}</b></button><span>${i.l}</span>`;
        const go = d.querySelector(".stat-go");
        const navigate = () => {
          if (stats.classList.contains("stats-reordering") || stats.dataset.skipClick === "1") return;
          window.__dashFilter = i.filter || null;
          menu = i.menu;
          const allowed = (POLICY.menus || []).map(String);
          if (allowed.length && !allowed.includes(menu)) {
            const fallback = { leave: "emp_leave", overtime: "emp_overtime", stock_usage: "emp_stock" };
            if (fallback[menu] && allowed.includes(fallback[menu])) menu = fallback[menu];
          }
          renderNav();
          renderBottomNav();
          render();
          window.scrollTo({ top: 0, behavior: "smooth" });
        };
        go.onclick = (e) => {
          e.preventDefault();
          e.stopPropagation();
          navigate();
        };
        // لمس کوتاه روی عدد = لینک؛ حرکت انگشت = اسکرول صفحه (باکس pointer-events:none)
        go.addEventListener("touchend", (e) => {
          // اجازه بده click مصنوعی مرورگر هم کار کند؛ فقط جلوی double-fire را نگیر
        }, { passive: true });
      } else {
        d.innerHTML = `<b>${i.v}</b><span>${i.l}</span>`;
      }
      stats.appendChild(d);
    });
    root.appendChild(stats);
    bindStatReorder(stats);

    // هشدار لید مشتری — چندتایی پشت‌سرهم + نوتیف‌های کنار هم
    if (POLICY.is_manager || POLICY.role === "warehouse") {
      let leads = [];
      if (S.settings && Array.isArray(S.settings.new_leads) && S.settings.new_leads.length) {
        leads = S.settings.new_leads.slice();
      } else if (S.settings && S.settings.new_lead && S.settings.new_lead.phone) {
        leads = [S.settings.new_lead];
      }
      if (window.__newLeads && window.__newLeads.length) {
        window.__newLeads.forEach((L) => {
          if (L && L.phone && !leads.some((x) => String(x.id) === String(L.id) && x.phone === L.phone)) leads.push(L);
        });
      } else if (window.__newLead && window.__newLead.phone) {
        if (!leads.some((x) => x.phone === window.__newLead.phone)) leads.push(window.__newLead);
      }
      leads = leads.filter((L) => L && L.phone);
      if (leads.length) {
        const stack = document.createElement("div");
        stack.className = "lead-stack";
        stack.style.cssText = "display:flex;flex-direction:column;gap:10px;margin-bottom:14px";
        leads.forEach((lead, idx) => {
          const alert = document.createElement("div");
          alert.className = "card lead-alert";
          alert.style.cssText = "background:#fef2f2;border:2px solid #ef4444;box-shadow:0 8px 24px rgba(239,68,68,.2);margin:0";
          const lid = lead.id || "";
          alert.innerHTML = `<h2 style="color:#b91c1c;margin:0 0 8px">🔔 مشتری درخواست کار${leads.length > 1 ? " (" + (idx + 1) + "/" + leads.length + ")" : ""}</h2>
            <p style="font-size:1.05rem;margin:0">شماره تماس:</p>
            <p style="margin:4px 0 10px"><strong style="font-size:1.35rem;letter-spacing:1px">${lead.phone}</strong></p>
            ${lead.time ? `<p class="hint" style="margin:0 0 8px">${lead.time}</p>` : ""}
            <p style="display:flex;flex-wrap:wrap;gap:8px;margin:0">
              <a class="btn" href="tel:${lead.phone}">📞 تماس</a>
              <button type="button" class="btn btn-outline btn-dismiss-lead" data-lead-id="${lid}" data-lead-phone="${lead.phone}">متوجه شدم</button>
            </p>`;
          stack.appendChild(alert);
        });
        root.insertBefore(stack, root.firstChild);
        stack.querySelectorAll(".btn-dismiss-lead").forEach((btn) => {
          btn.onclick = async () => {
            const payload = {};
            if (btn.dataset.leadId) payload.lead_id = btn.dataset.leadId;
            if (btn.dataset.leadPhone) payload.phone = btn.dataset.leadPhone;
            await api("dismiss_lead", payload);
            // به‌روز کردن محلی
            if (S.settings && Array.isArray(S.settings.new_leads)) {
              S.settings.new_leads = S.settings.new_leads.filter((L) =>
                String(L.id || "") !== String(btn.dataset.leadId || "x") && L.phone !== btn.dataset.leadPhone
              );
              if (!S.settings.new_leads.length) S.settings.new_lead = null;
            }
            render();
          };
        });
        // نوتیف‌های شناور کنار هم (ستونی از پایین چپ)
        let wrap = document.getElementById("lead-toast-wrap");
        if (!wrap) {
          wrap = document.createElement("div");
          wrap.id = "lead-toast-wrap";
          wrap.style.cssText = "position:fixed;bottom:20px;left:20px;z-index:9999;display:flex;flex-direction:column;gap:8px;max-width:min(340px,92vw);pointer-events:none";
          document.body.appendChild(wrap);
        }
        wrap.innerHTML = "";
        leads.slice().reverse().forEach((lead) => {
          const toast = document.createElement("div");
          toast.className = "lead-toast-item";
          toast.style.cssText = "pointer-events:auto;background:#b91c1c;color:#fff;padding:12px 14px;border-radius:14px;box-shadow:0 10px 28px rgba(0,0,0,.28);font-family:inherit";
          toast.innerHTML = `<strong>درخواست کار</strong><div style="margin-top:4px;font-size:1.05rem;font-weight:700;letter-spacing:.5px">${lead.phone}</div>
            <div style="margin-top:8px;display:flex;gap:8px;align-items:center">
              <a href="tel:${lead.phone}" style="color:#fff;font-weight:700;text-decoration:none">تماس</a>
              <button type="button" class="lead-toast-dismiss" data-lead-id="${lead.id || ""}" data-lead-phone="${lead.phone}" style="background:rgba(255,255,255,.2);border:none;color:#fff;border-radius:8px;padding:4px 10px;cursor:pointer;font-family:inherit">بستن</button>
            </div>`;
          wrap.appendChild(toast);
        });
        wrap.querySelectorAll(".lead-toast-dismiss").forEach((btn) => {
          btn.onclick = async () => {
            const payload = {};
            if (btn.dataset.leadId) payload.lead_id = btn.dataset.leadId;
            if (btn.dataset.leadPhone) payload.phone = btn.dataset.leadPhone;
            await api("dismiss_lead", payload);
            if (S.settings && Array.isArray(S.settings.new_leads)) {
              S.settings.new_leads = S.settings.new_leads.filter((L) =>
                String(L.id || "") !== String(btn.dataset.leadId || "x") && L.phone !== btn.dataset.leadPhone
              );
            }
            render();
          };
        });
      } else {
        const wrap = document.getElementById("lead-toast-wrap");
        if (wrap) wrap.innerHTML = "";
      }
    }

    // تقویم روز + یادداشت / چک / مرخصی
    if (POLICY.is_manager) {
      renderDashCalendar(root);
    }

    // چشم‌انداز مدیر
    if (POLICY.is_manager) {
      const outCard = document.createElement("div");
      outCard.className = "card";
      outCard.innerHTML = `<h2>چشم‌انداز روز / بازه</h2>
        <p class="hint">پیش‌فرض امروز تا امروز است. بازه را عوض کنید و فیلترها را اعمال کنید.</p>
        <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:end;margin-bottom:10px">
          <div class="field" style="margin:0"><label>از تاریخ</label>
            <div class="date-row"><input id="outlook-from" class="date-field" placeholder="1403/01/01">
            <button type="button" class="btn btn-sm btn-outline" id="outlook-today-from">امروز</button></div>
          </div>
          <div class="field" style="margin:0"><label>تا تاریخ</label>
            <div class="date-row"><input id="outlook-to" class="date-field" placeholder="1403/01/01">
            <button type="button" class="btn btn-sm btn-outline" id="outlook-today-to">امروز</button></div>
          </div>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px" id="outlook-filters">
          <label class="hint" style="display:flex;align-items:center;gap:4px"><input type="checkbox" id="of-cash" checked> نقدی</label>
          <label class="hint" style="display:flex;align-items:center;gap:4px"><input type="checkbox" id="of-check" checked> چک</label>
          <label class="hint" style="display:flex;align-items:center;gap:4px"><input type="checkbox" id="of-paid" checked> پرداخت‌شده</label>
          <label class="hint" style="display:flex;align-items:center;gap:4px"><input type="checkbox" id="of-recv" checked> جمع طلب</label>
          <label class="hint" style="display:flex;align-items:center;gap:4px"><input type="checkbox" id="of-debt" checked> جمع بدهی</label>
        </div>
        <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:8px">
          <button type="button" class="btn" id="outlook-go">نمایش</button>
          <button type="button" class="btn btn-outline" id="outlook-calc">محاسبه موجودی مصرفی انبار در پروژه‌ها</button>
        </div>
        <div id="outlook-result" style="margin-top:12px"></div>
        <div id="outlook-calc-box" class="hidden" style="margin-top:14px;padding:14px;border:1px solid var(--b);border-radius:12px;background:var(--bg)"></div>`;
      root.appendChild(outCard);

      const today = () => (window.J && J.todayJalali) ? J.todayJalali() : "";
      const setToday = () => {
        const d = today();
        const f = document.getElementById("outlook-from");
        const to = document.getElementById("outlook-to");
        if (f) f.value = d;
        if (to) to.value = d;
      };
      outCard.querySelector("#outlook-today-from").onclick = () => {
        const d = today();
        document.getElementById("outlook-from").value = d;
      };
      outCard.querySelector("#outlook-today-to").onclick = () => {
        document.getElementById("outlook-to").value = today();
      };
      setToday();

      function inRange(dateStr, from, to) {
        if (!dateStr) return false;
        if (from && dateStr < from) return false;
        if (to && dateStr > to) return false;
        return true;
      }
      function isApproved(c) {
        const a = (c.approval || "").toString();
        return a === "approved" || a === "تأیید" || a === "تایید";
      }
      function isCheckKind(c) {
        const k = (c.kind || "check").toString();
        return k === "check" || k === "چک" || k === "";
      }
      function isCashKind(c) {
        // پرداخت‌های نقدی از checks با kind خاص یا از پیام‌های مالی
        const k = (c.kind || "").toString();
        return k === "نقدی" || k === "cash" || (c.payment_type || "") === "نقدی";
      }

      outCard.querySelector("#outlook-go").onclick = () => {
        const from = (document.getElementById("outlook-from").value || "").trim();
        const to = (document.getElementById("outlook-to").value || "").trim() || from;
        const box = document.getElementById("outlook-result");
        const useCash = document.getElementById("of-cash").checked;
        const useCheck = document.getElementById("of-check").checked;
        const usePaid = document.getElementById("of-paid").checked;
        const useRecv = document.getElementById("of-recv").checked;
        const useDebt = document.getElementById("of-debt").checked;

        let recv = (S.checks_received || []).filter((c) => inRange(c.check_date || "", from, to));
        let paid = (S.checks_paid || []).filter((c) => inRange(c.check_date || "", from, to));

        // فیلتر نوع
        const filterType = (list) => list.filter((c) => {
          const chk = isCheckKind(c);
          const cash = isCashKind(c);
          if (chk && useCheck) return true;
          if (cash && useCash) return true;
          if (!chk && !cash && (useCheck || useCash)) return true; // سایر
          return false;
        });
        recv = filterType(recv);
        paid = filterType(paid);

        if (usePaid) {
          // فقط تأییدشده‌ها اگر گزینه پرداخت‌شده روشن است — اما اگر فقط این نباشد همه
        }
        // اگر فقط پرداخت‌شده: فقط approved
        // منطق: چک‌باکس پرداخت‌شده یعنی فقط موارد تأییدشده
        if (usePaid && !(useCash || useCheck || useRecv || useDebt)) {
          recv = recv.filter(isApproved);
          paid = paid.filter(isApproved);
        }

        const sumR = useRecv ? recv.reduce((s, c) => s + (parseFloat(c.amount) || 0), 0) : 0;
        const sumP = useDebt ? paid.reduce((s, c) => s + (parseFloat(c.amount) || 0), 0) : 0;
        const profit = sumR - sumP;
        const leaves = (S.leave_requests || []).filter((r) => {
          if (r.status !== "تأیید" && r.status !== "تأییدشده" && r.status !== "approved") return false;
          const f = r.from_date || "";
          const tt = r.to_date || f;
          // همپوشانی بازه
          if (to && f > to) return false;
          if (from && tt < from) return false;
          return true;
        });
        const kh = [...recv, ...paid].filter((c) => (c.kind || "") === "خرید دین");

        let html = `<div class="stats" style="margin-bottom:10px">`;
        if (useRecv) html += `<div class="stat"><b>${fmt(sumR, "amount")}</b><span>جمع طلب (دریافتنی)</span></div>`;
        if (useDebt) html += `<div class="stat"><b>${fmt(sumP, "amount")}</b><span>جمع بدهی (پرداختی)</span></div>`;
        html += `<div class="stat ${profit >= 0 ? "" : "stat-alert"}"><b>${fmt(profit, "amount")}</b><span>سود / ضرر</span></div>`;
        html += `</div>`;
        html += `<p class="hint">بازه: ${from || "—"} تا ${to || "—"} — دریافتنی: ${recv.length} مورد — پرداختی: ${paid.length} مورد</p>`;
        if (kh.length) {
          html += `<p style="color:#b45309"><strong>خرید دین (${kh.length}):</strong> ` +
            kh.map((c) => `${c.name || c.payee || "—"} ${fmt(c.amount, "amount")}`).join("، ") + `</p>`;
        }
        if (leaves.length) {
          html += `<p><strong>مرخصی تأییدشده در بازه:</strong></p><ul style="margin:6px 18px">` +
            leaves.map((r) => `<li>${r.personnel_name || "—"} — ${r.leave_type || ""} ${r.from_date || ""} تا ${r.to_date || ""}</li>`).join("") + `</ul>`;
        }
        box.innerHTML = html;
      };

      // ماشین‌حساب مواد مصرفی + هزینه کارگاه
      outCard.querySelector("#outlook-calc").onclick = () => {
        const box = document.getElementById("outlook-calc-box");
        box.classList.remove("hidden");
        // محاسبه خودکار مواد مصرفی از stock_usage در بازه
        const from = (document.getElementById("outlook-from").value || "").trim();
        const to = (document.getElementById("outlook-to").value || "").trim() || from;
        let materials = 0;
        (S.stock_usage || []).forEach((u) => {
          if ((u.kind || "") === "بازگشت") return;
          const d = u.used_at || "";
          if (from && d && d < from) return;
          if (to && d && d > to) return;
          const item = (S.stock_items || []).find((i) => i.item === u.item_name);
          const price = item ? (parseFloat(item.price) || 0) : 0;
          const qty = parseFloat(u.qty) || 0;
          materials += price * qty;
        });
        box.innerHTML = `<h3 style="margin-bottom:10px">محاسبه هزینه پروژه / کارگاه</h3>
          <div class="field"><label>مواد مصرفی (از انبار × قیمت کالا)</label>
            <input id="calc-mat" type="text" value="${materials}"></div>
          <div class="field"><label>هزینه کارگاه</label>
            <input id="calc-shop" type="text" value="0" placeholder="مبلغ هزینه کارگاه"></div>
          <button type="button" class="btn" id="calc-sum">جمع کن</button>
          <div id="calc-out" style="margin-top:12px;font-size:1.1rem;font-weight:700"></div>
          <p class="hint">اگر قیمت کالا در انبار خالی باشد، در محاسبه صفر لحاظ می‌شود — ابتدا در انبار به کالا قیمت بدهید.</p>`;
        const money = (v) => fmt(String(v).replace(/[,،\\s]/g, ""), "amount");
        box.querySelector("#calc-sum").onclick = () => {
          const m = parseFloat(String(document.getElementById("calc-mat").value || "0").replace(/[,،\\s]/g, "")) || 0;
          const s = parseFloat(String(document.getElementById("calc-shop").value || "0").replace(/[,،\\s]/g, "")) || 0;
          document.getElementById("calc-out").innerHTML =
            `مواد مصرفی: ${money(m)} + هزینه کارگاه: ${money(s)} = <span style="color:var(--p)">${money(m + s)}</span>`;
        };
      };
    }

    // اعلان‌های نیازمند اقدام
    if (pendingLeave.length || pendingOt.length || pendingReturn.length || lowStock.length || exhaustedDirs.length) {
      const alertCard = document.createElement("div");
      alertCard.className = "card";
      alertCard.innerHTML = "<h2>نیازمند بررسی و اقدام</h2>";
      const list = document.createElement("div");
      list.style.cssText = "display:flex;flex-direction:column;gap:8px";

      pendingLeave.forEach((r) => {
        const row = document.createElement("div");
        row.className = "hint";
        row.style.display = "flex";
        row.style.justifyContent = "space-between";
        row.style.alignItems = "center";
        row.style.flexWrap = "wrap";
        row.style.gap = "8px";
        const type = r.leave_type || "روزانه";
        const when = type === "ساعتی"
          ? `${r.from_date || "—"} — ${r.hours || "—"} ساعت`
          : `${r.from_date || "—"} تا ${r.to_date || "—"}`;
        row.innerHTML = `<span><strong>مرخصی ${type}</strong> — ${r.personnel_name || "—"} — ${when}${r.reason ? " — " + r.reason : ""}</span>`;
        const acts = document.createElement("span");
        acts.style.cssText = "display:inline-flex;gap:6px";
        const ok = document.createElement("button");
        ok.className = "btn btn-sm";
        ok.textContent = "تأیید";
        ok.onclick = async () => {
          const res = await api("save", { table: "leave_requests", payload: { id: r.id, status: "تأیید" } });
          if (!res.ok) { alert(res.error || "خطا"); return; }
          await reload(); render();
        };
        const hold = document.createElement("button");
        hold.className = "btn btn-sm btn-outline";
        hold.textContent = "در انتظار";
        hold.onclick = async () => {
          const note = prompt("یادداشت مدیر (اختیاری):") || "";
          const body = note ? ((r.reason || "") + "\n[یادداشت مدیر: " + note + "]") : (r.reason || "");
          const res = await api("save", { table: "leave_requests", payload: { id: r.id, status: "در انتظار", reason: body } });
          if (!res.ok) { alert(res.error || "خطا"); return; }
          await reload(); render();
        };
        const no = document.createElement("button");
        no.className = "btn btn-sm btn-danger";
        no.textContent = "رد";
        no.onclick = async () => {
          const note = prompt("دلیل رد (اختیاری):") || "";
          const body = note ? ((r.reason || "") + "\n[رد: " + note + "]") : (r.reason || "");
          const res = await api("save", { table: "leave_requests", payload: { id: r.id, status: "رد", reason: body } });
          if (!res.ok) { alert(res.error || "خطا"); return; }
          await reload(); render();
        };
        acts.appendChild(ok);
        acts.appendChild(hold);
        acts.appendChild(no);
        row.appendChild(acts);
        list.appendChild(row);
      });

      pendingOt.forEach((r) => {
        const row = document.createElement("div");
        row.className = "hint";
        row.style.display = "flex";
        row.style.justifyContent = "space-between";
        row.style.alignItems = "center";
        row.style.flexWrap = "wrap";
        row.style.gap = "8px";
        row.innerHTML = `<span><strong>اضافه‌کاری</strong> — ${r.personnel_name || "—"} — ${r.from_time || ""} تا ${r.to_time || ""} (${r.hours || "—"} س) — بابت: ${r.reason || "—"}</span>`;
        const acts = document.createElement("span");
        acts.style.cssText = "display:inline-flex;gap:6px";
        const ok = document.createElement("button");
        ok.className = "btn btn-sm";
        ok.textContent = "تأیید";
        ok.onclick = async () => {
          const res = await api("save", { table: "overtime", payload: { id: r.id, status: "تأیید" } });
          if (!res.ok) { alert(res.error || "خطا"); return; }
          await reload(); render();
        };
        const no = document.createElement("button");
        no.className = "btn btn-sm btn-danger";
        no.textContent = "رد";
        no.onclick = async () => {
          const res = await api("save", { table: "overtime", payload: { id: r.id, status: "رد" } });
          if (!res.ok) { alert(res.error || "خطا"); return; }
          await reload(); render();
        };
        acts.appendChild(ok);
        acts.appendChild(no);
        row.appendChild(acts);
        list.appendChild(row);
      });

      pendingReturn.forEach((r) => {
        const row = document.createElement("div");
        row.className = "hint";
        row.style.display = "flex";
        row.style.justifyContent = "space-between";
        row.style.alignItems = "center";
        row.style.flexWrap = "wrap";
        row.style.gap = "8px";
        row.innerHTML = `<span><strong>بازگشت به انبار</strong> — ${r.item_name || "—"} × ${r.qty || "—"} — ${r.personnel_name || "—"}</span>`;
        const acts = document.createElement("span");
        const ok = document.createElement("button");
        ok.className = "btn btn-sm";
        ok.textContent = "تأیید بازگشت";
        ok.onclick = async () => {
          const res = await api("save", { table: "stock_usage", payload: { id: r.id, status: "تأییدشده" } });
          if (!res.ok) { alert(res.error || "خطا"); return; }
          await reload(); render();
        };
        acts.appendChild(ok);
        row.appendChild(acts);
        list.appendChild(row);
      });

      if (lowStock.length) {
        const lowTitle = document.createElement("div");
        lowTitle.style.cssText = "margin-top:8px;font-weight:600;color:#b45309";
        if (exhaustedDirs.length) {
          const exTitle = document.createElement("div");
          exTitle.style.cssText = "margin-top:8px;font-weight:600;color:#b91c1c";
          exTitle.textContent = "یادآوری دستور تمام شده — جریمه لازم است:";
          list.appendChild(exTitle);
          exhaustedDirs.forEach((d) => {
            const row = document.createElement("div");
            row.className = "hint";
            row.style.background = "#fef2f2";
            row.innerHTML = `<strong>${d.title || "دستور"}</strong> — ${d.target_name || d.target_role || "—"} — وضعیت: ${d.status || "باز"}
              <button type="button" class="btn btn-sm btn-danger" data-fine-dir="${d.id}" data-who="${d.target_name || ""}">ثبت جریمه</button>`;
            list.appendChild(row);
          });
          list.querySelectorAll("[data-fine-dir]").forEach((btn) => {
            btn.onclick = async () => {
              const who = btn.dataset.who || "";
              const res = await api("save", { table: "fines", payload: { personnel_name: who, amount: (S.settings && S.settings.report_fine) || "250000", reason: "عدم انجام دستور پس از اتمام یادآوری‌ها", fine_date: (window.J && J.todayJalali) ? J.todayJalali() : "", type: "fine", status: "ثبت‌شده" } });
              if (!res.ok) { alert(res.error || "خطا"); return; }
              alert("جریمه ثبت شد");
              await reload(); render();
            };
          });
        }
        lowTitle.textContent = "کالاهای زیر حداقل موجودی:";
        list.appendChild(lowTitle);
        lowStock.forEach((i) => {
          const row = document.createElement("div");
          row.className = "hint";
          row.style.background = "#fff7ed";
          row.style.borderColor = "#fed7aa";
          row.innerHTML = `<strong>${i.item || "—"}</strong> — موجودی: ${i.qty || 0} / حداقل: ${i.min_qty || 0} ${i.unit || ""} — دسته: ${i.category || "—"}`;
          list.appendChild(row);
        });
      }

      alertCard.appendChild(list);
      root.appendChild(alertCard);
    }

    // ─── داشبورد کامل مدیر: همه چیز در یک نگاه ───
    if (POLICY.is_manager) {
      // خلاصه مالی فوری
      const finCard = document.createElement("div");
      finCard.className = "card";
      finCard.innerHTML = `<h2>خلاصه مالی</h2>
        <div class="stats" style="margin:0">
          <div class="stat"><b>${fmt(sumRecvAll, "amount")}</b><span>جمع دریافتنی</span></div>
          <div class="stat"><b>${fmt(sumPaidAll, "amount")}</b><span>جمع پرداختی</span></div>
          <div class="stat ${(sumRecvAll - sumPaidAll) < 0 ? "stat-alert" : ""}"><b>${fmt(sumRecvAll - sumPaidAll, "amount")}</b><span>مانده (طلب − بدهی)</span></div>
          <div class="stat ${dueRecv.length ? "stat-alert" : ""}"><b>${dueRecv.length}</b><span>چک مشتری تا ۳ روز</span></div>
          <div class="stat ${duePaid.length ? "stat-alert" : ""}"><b>${duePaid.length}</b><span>چک کارگاه تا ۳ روز</span></div>
        </div>
        <p class="hint" style="margin-top:10px">برای جزئیات و تأیید به «حسابداری» بروید.</p>`;
      root.appendChild(finCard);

      // پرسنل در مرخصی امروز
      if (onLeaveNow.length) {
        const lvCard = document.createElement("div");
        lvCard.className = "card";
        lvCard.innerHTML = "<h2>پرسنل در مرخصی (امروز)</h2>";
        const ul = document.createElement("div");
        ul.style.cssText = "display:flex;flex-direction:column;gap:6px";
        onLeaveNow.forEach((p) => {
          const row = document.createElement("div");
          row.className = "row-on-leave";
          row.style.cssText = "padding:10px 12px;border-radius:10px;font-weight:600";
          row.textContent = (p.name || "—") + " — " + (fmt(p.role, "role") || "") + (p.phone ? " — " + p.phone : "");
          ul.appendChild(row);
        });
        lvCard.appendChild(ul);
        root.appendChild(lvCard);
      }

      // چک‌های نزدیک سررسید
      if (dueRecv.length || duePaid.length) {
        const ckCard = document.createElement("div");
        ckCard.className = "card";
        ckCard.innerHTML = "<h2>چک‌های نزدیک سررسید (۳ روز)</h2>";
        const wrap = document.createElement("div");
        wrap.style.cssText = "display:flex;flex-direction:column;gap:6px";
        dueRecv.forEach((c) => {
          const d = J.daysUntil(c.check_date);
          const row = document.createElement("div");
          row.className = "hint";
          row.style.cssText = "padding:8px 10px;border-radius:8px;background:#fef2f2;border-right:3px solid #991b1b;color:#991b1b;font-weight:600";
          row.textContent = `مشتری: ${c.name || "—"} — ${fmt(c.amount, "amount")} — سررسید ${c.check_date || "—"} (${d === 0 ? "امروز" : d + " روز"})`;
          wrap.appendChild(row);
        });
        duePaid.forEach((c) => {
          const d = J.daysUntil(c.check_date);
          const row = document.createElement("div");
          row.className = "hint";
          row.style.cssText = "padding:8px 10px;border-radius:8px;background:#fee2e2;border-right:3px solid #fca5a5;color:#b91c1c;font-weight:600";
          row.textContent = `کارگاه: ${c.payee || "—"} — ${fmt(c.amount, "amount")} — سررسید ${c.check_date || "—"} (${d === 0 ? "امروز" : d + " روز"})`;
          wrap.appendChild(row);
        });
        ckCard.appendChild(wrap);
        root.appendChild(ckCard);
      }

      // میانبرهای سریع
      const qa = document.createElement("div");
      qa.className = "card";
      qa.innerHTML = "<h2>دسترسی سریع</h2>";
      const qaRow = document.createElement("div");
      qaRow.style.cssText = "display:flex;flex-wrap:wrap;gap:8px";
      [
        ["customers", "مشتریان"], ["personnel", "پرسنل"], ["finance", "حسابداری"],
        ["warehouse", "انبار"], ["directives", "دستورات"], ["salary", "حقوق"],
        ["chat_history", "تاریخچه چت"], ["settings", "تنظیمات"],
      ].forEach(([id, label]) => {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "btn btn-outline btn-sm";
        b.textContent = label;
        b.onclick = () => {
          if (id === "chat_history" && typeof openChatOverlay === "function") {
            // history is menu; chat is FAB
          }
          menu = id;
          closeDrawer();
          renderNav();
          renderBottomNav();
          render();
          window.scrollTo({ top: 0, behavior: "smooth" });
        };
        qaRow.appendChild(b);
      });
      const chatB = document.createElement("button");
      chatB.type = "button";
      chatB.className = "btn btn-sm";
      chatB.textContent = "باز کردن چت" + (unreadChat ? ` (${unreadChat})` : "");
      chatB.onclick = () => { if (typeof openChatOverlay === "function") openChatOverlay(); };
      qaRow.appendChild(chatB);
      qa.appendChild(qaRow);
      root.appendChild(qa);
    }

    // یادداشت‌های شخصی نیازمند توجه
    if (typeof renderMyNoteReminders === "function") renderMyNoteReminders(root);

    // دستورات — اول بازها، اگر خالی همه
    const dirOpen = crudTable("directives", "دستورات باز / اخیر", {
      filterFn: (d) => {
        const st = String(d.status || "باز").trim();
        return !st || st === "باز" || st === "در حال انجام" || st === "pending" || st === "باز است";
      },
    });
    root.appendChild(dirOpen);
    if ((!S.directives || !S.directives.length)) {
      const emptyD = document.createElement("div");
      emptyD.className = "card";
      emptyD.innerHTML = "<h2>دستورات</h2><p class=\"empty-hint\">دستوری ثبت نشده. از منوی دستورات می‌توانید اضافه کنید.</p>";
      root.appendChild(emptyD);
    } else if (dirOpen.querySelectorAll("tbody tr").length === 0) {
      root.appendChild(crudTable("directives", "همه دستورات", {}));
    }

    // جداول مدیریتی کامل
    root.appendChild(crudTable("leave_requests", "مرخصی‌ها (همه)", {}));
    if (pendingOt.length) {
      root.appendChild(crudTable("overtime", "اضافه‌کاری‌های در انتظار", {
        filterFn: (r) => r.status === "در انتظار" || !r.status,
      }));
    }
    if (lowStock.length) {
      root.appendChild(crudTable("stock_items", "کالاهای زیر حداقل موجودی", {
        filterFn: (i) => {
          const qty = parseFloat(i.qty) || 0;
          const min = parseFloat(i.min_qty) || 0;
          return min > 0 && qty <= min;
        },
      }));
    }
    // چک‌های در انتظار تأیید
    if (pendingChecks.length && POLICY.is_manager) {
      root.appendChild(crudTable("checks_received", "چک دریافتنی در انتظار تأیید", {
        filterFn: (c) => c.approval === "pending" || c.approval === "در انتظار",
      }));
    }
    // چک‌های نزدیک سررسید (حتی بدون pending)
    const _dueRecv = (S.checks_received || []).filter((c) => {
      const d = J.daysUntil(c.check_date);
      return d !== null && d >= 0 && d <= 3;
    });
    const _duePaid = (S.checks_paid || []).filter((c) => {
      const d = J.daysUntil(c.check_date);
      return d !== null && d >= 0 && d <= 3;
    });
    if (_dueRecv.length) {
      root.appendChild(crudTable("checks_received", "چک دریافتنی نزدیک سررسید (۳ روز)", {
        filterFn: (c) => { const d = J.daysUntil(c.check_date); return d !== null && d >= 0 && d <= 3; },
      }));
    }
    if (_duePaid.length) {
      root.appendChild(crudTable("checks_paid", "چک پرداختنی نزدیک سررسید (۳ روز)", {
        filterFn: (c) => { const d = J.daysUntil(c.check_date); return d !== null && d >= 0 && d <= 3; },
      }));
    }
    // اگر هیچ چکی نبود ولی جدول داده دارد، لینک به حسابداری
    if (!(S.checks_received || []).length && !(S.checks_paid || []).length && POLICY.is_manager) {
      const chkHint = document.createElement("div");
      chkHint.className = "card";
      chkHint.innerHTML = "<h2>چک‌ها</h2><p class=\"empty-hint\">چکی ثبت نشده. از منوی حسابداری می‌توانید چک دریافتنی/پرداختنی اضافه کنید.</p>";
      const goFin = document.createElement("button");
      goFin.type = "button"; goFin.className = "btn btn-sm"; goFin.textContent = "رفتن به حسابداری";
      goFin.onclick = () => { menu = "finance"; renderNav(); render(); };
      chkHint.appendChild(goFin);
      root.appendChild(chkHint);
    }
    root.appendChild(crudTable("customers", "آخرین مشتریان"));

    // لیست کوتاه پرسنل با وضعیت مرخصی
    if (POLICY.is_manager) {
      const pCard = document.createElement("div");
      pCard.className = "card";
      pCard.innerHTML = "<h2>وضعیت پرسنل</h2>";
      const tw = document.createElement("div");
      tw.className = "table-wrap";
      let html = "<table><thead><tr><th>نام</th><th>نقش</th><th>تلفن</th><th>وضعیت</th></tr></thead><tbody>";
      (S.personnel || []).forEach((p) => {
        const onLv = personOnLeave(p.name);
        html += `<tr class="${onLv ? "row-on-leave" : ""}"><td>${p.name || "—"}</td><td>${fmt(p.role, "role")}</td><td>${p.phone || "—"}</td><td>${onLv ? "در مرخصی" : "حاضر"}</td></tr>`;
      });
      html += "</tbody></table>";
      tw.innerHTML = html;
      pCard.appendChild(tw);
      root.appendChild(pCard);
    }
  }


  function sumChecks(rows) {
    return (rows || []).reduce((s, r) => s + (parseFloat(r.amount) || 0), 0);
  }

  function openAccountPaymentModal(prefName, forceDir) {
    const modal = document.getElementById("modal");
    const form = document.getElementById("modal-form");
    const title = document.getElementById("modal-title");
    if (!modal || !form) return;
    editTable = "account_payments";
    editId = 0;
    const dir0 = forceDir || "out";
    if (title) title.textContent = (dir0 === "in" ? "ثبت دریافت" : "ثبت پرداخت") + (prefName ? (" — " + prefName) : "");
    form.innerHTML = "";
    // نوع شخص
    const typeField = document.createElement("div");
    typeField.className = "field";
    typeField.innerHTML = `<label>نوع شخص</label>
      <select name="person_type" id="ap-person-type">
        <option value="customer">مشتری</option>
        <option value="supplier">تأمین‌کننده</option>
        <option value="personnel">پرسنل</option>
        <option value="other">سایر</option>
      </select>`;
    form.appendChild(typeField);

    const dirField = document.createElement("div");
    dirField.className = "field";
    dirField.innerHTML = `<label>جهت</label>
      <select name="direction" id="ap-direction">
        <option value="out">پرداخت</option>
        <option value="in">دریافت</option>
      </select>`;
    form.appendChild(dirField);
    if (forceDir) dirField.querySelector("select").value = forceDir;
    const methodField = document.createElement("div");
    methodField.className = "field";
    methodField.innerHTML = `<label>روش</label>
      <select name="method" id="ap-method">
        <option value="cash">نقد / صندوق</option>
        <option value="bank">بانک / کارت</option>
      </select>`;
    form.appendChild(methodField);
    const accField = document.createElement("div");
    accField.className = "field";
    accField.innerHTML = `<label>صندوق یا حساب</label><select name="account_name" id="ap-account"></select>`;
    form.appendChild(accField);
    function fillAccounts() {
      const m = (document.getElementById("ap-method") || {}).value || "cash";
      const sel = document.getElementById("ap-account");
      if (!sel) return;
      sel.innerHTML = "";
      const list = m === "bank" ? (S.bank_accounts || []) : (S.cash_boxes || []);
      if (!list.length) {
        const o = document.createElement("option");
        o.value = ""; o.textContent = m === "bank" ? "ابتدا حساب بانکی تعریف کنید" : "ابتدا صندوق تعریف کنید";
        sel.appendChild(o);
      } else {
        list.forEach((a) => {
          const o = document.createElement("option");
          o.value = a.name || ""; o.textContent = a.name || "—";
          sel.appendChild(o);
        });
      }
    }
    fillAccounts();
    methodField.querySelector("select").onchange = fillAccounts;
    // also customer option in person type

    // نام شخص
    const nameField = document.createElement("div");
    nameField.className = "field";
    nameField.innerHTML = `<label>نام شخص</label>`;
    const nameWrap = document.createElement("div");
    nameWrap.id = "ap-name-wrap";
    form.appendChild(nameField);
    nameField.appendChild(nameWrap);
    function fillNames(ptype, preset) {
      nameWrap.innerHTML = "";
      if (ptype === "other") {
        const inp = document.createElement("input");
        inp.type = "text";
        inp.name = "person_name";
        inp.placeholder = "نام را وارد کنید";
        inp.required = true;
        if (preset) inp.value = preset;
        nameWrap.appendChild(inp);
        return;
      }
      let list = [];
      if (ptype === "supplier") list = (S.suppliers || []).map((s) => s.name).filter(Boolean);
      else if (ptype === "customer") list = (S.customers || []).map((c) => c.name).filter(Boolean);
      else if (ptype === "personnel") list = (S.personnel || []).map((p) => p.name).filter(Boolean);
      const sel = document.createElement("select");
      sel.name = "person_name";
      sel.required = true;
      const empty = document.createElement("option");
      empty.value = ""; empty.textContent = "انتخاب کنید...";
      sel.appendChild(empty);
      list.forEach((n) => {
        const o = document.createElement("option");
        o.value = n; o.textContent = n;
        sel.appendChild(o);
      });
      nameWrap.appendChild(sel);
    }
    if (prefName) {
      const selType = document.getElementById("ap-person-type");
      if (selType) selType.value = "other";
      fillNames("other", prefName);
    } else {
      fillNames("supplier");
    };
    typeField.querySelector("select").onchange = (e) => fillNames(e.target.value);
    // مبلغ
    const amountField = document.createElement("div");
    amountField.className = "field";
    amountField.innerHTML = `<label>مبلغ</label><input type="text" name="amount" inputmode="decimal" placeholder="مبلغ" required>`;
    form.appendChild(amountField);
    // تاریخ و زمان (پیش‌فرض مثل بقیه فیلدهای تاریخ)
    const dateField = document.createElement("div");
    dateField.className = "field";
    const defaultDate = (window.J && J.todayJalali) ? J.todayJalali() : "";
    const now = new Date();
    const defaultTime = String(now.getHours()).padStart(2, "0") + ":" + String(now.getMinutes()).padStart(2, "0");
    dateField.innerHTML = `<label>تاریخ و زمان</label>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <input type="text" name="pay_date" value="${defaultDate}" placeholder="مثال: ۱۴۰۴/۰۷/۰۲" style="flex:1;min-width:120px">
        <input type="text" name="pay_time" value="${defaultTime}" placeholder="۱۴:۳۰" style="width:90px">
      </div>`;
    form.appendChild(dateField);
    // توضیحات
    const notesField = document.createElement("div");
    notesField.className = "field";
    notesField.innerHTML = `<label>توضیحات</label><textarea name="notes" rows="2"></textarea>`;
    form.appendChild(notesField);
    modal.classList.add("open");
    modal.setAttribute("aria-hidden", "false");
  }


  /**
   * ساخت دفتر طرف‌حساب‌ها از مشتریان، چک‌ها، پرداخت‌ها، خرید دین
   * balance > 0 = بدهکار به ما | balance < 0 = ما بستانکاریم (بدهکار به او)
   */
  
  /** وضعیت نرمال چک (سازگار با approval قدیمی) */
  function normalizeCheckStatus(c) {
    const s = String((c && (c.check_status || c.approval)) || "pending").trim();
    if (s === "approved" || s === "تأیید" || s === "تأییدشده") return "in_hand";
    if (s === "در انتظار" || s === "pending") return "pending";
    if (s === "رد" || s === "rejected") return "rejected";
    if (s === "نزد ما") return "in_hand";
    if (s === "واگذار به بانک" || s === "deposited") return "deposited";
    if (s === "وصول" || s === "وصول شده" || s === "پاس شده" || s === "cleared") return "cleared";
    if (s === "برگشت" || s === "برگشت خورده" || s === "returned") return "returned";
    if (s === "خرج" || s === "spent") return "spent";
    if (s === "صادر شده" || s === "issued") return "issued";
    return s || "pending";
  }

  function checkStatusLabel(st, isPaid) {
    const map = {
      pending: "در انتظار تأیید",
      in_hand: "نزد ما",
      deposited: "واگذار به بانک",
      cleared: isPaid ? "پاس شده" : "وصول شده",
      returned: "برگشت خورده",
      spent: "خرج / واگذار شده",
      issued: "صادر شده",
      rejected: "رد / باطل",
      approved: "نزد ما",
    };
    return map[st] || st || "—";
  }

  /** چک هنوز «باز» است و روی مانده اثر دارد */
  function checkIsOpen(c) {
    const st = normalizeCheckStatus(c);
    return ["pending", "in_hand", "deposited", "issued", "spent"].includes(st);
  }

  /** اقدامات مجاز بعدی برای وضعیت چک */
  function checkNextActions(c, isPaid) {
    const st = normalizeCheckStatus(c);
    if (isPaid) {
      if (st === "pending") return [
        { to: "issued", l: "تأیید صدور" },
        { to: "rejected", l: "باطل", danger: true },
      ];
      if (st === "issued") return [
        { to: "deposited", l: "تحویل بانک" },
        { to: "cleared", l: "پاس شد" },
        { to: "returned", l: "برگشت", danger: true },
      ];
      if (st === "deposited") return [
        { to: "cleared", l: "پاس شد" },
        { to: "returned", l: "برگشت", danger: true },
      ];
      if (st === "returned") return [
        { to: "issued", l: "عودت به جریان" },
        { to: "rejected", l: "باطل", danger: true },
      ];
      return [];
    }
    // دریافتنی
    if (st === "pending") return [
      { to: "in_hand", l: "تأیید (نزد ما)" },
      { to: "rejected", l: "رد", danger: true },
    ];
    if (st === "in_hand") return [
      { to: "deposited", l: "واگذار به بانک" },
      { to: "spent", l: "خرج / واگذار" },
      { to: "cleared", l: "وصول شد" },
      { to: "returned", l: "برگشت", danger: true },
    ];
    if (st === "deposited") return [
      { to: "cleared", l: "وصول شد" },
      { to: "returned", l: "برگشت", danger: true },
    ];
    if (st === "spent") return [
      { to: "cleared", l: "تسویه شد" },
      { to: "returned", l: "برگشت", danger: true },
    ];
    if (st === "returned") return [
      { to: "in_hand", l: "عودت نزد ما" },
      { to: "rejected", l: "بایگانی رد", danger: true },
    ];
    return [];
  }

  async function setCheckStatus(table, row, toStatus) {
    const payload = {
      id: row.id,
      check_status: toStatus,
      approval: toStatus,
    };
    if (toStatus === "cleared") {
      payload.passed_date = (window.J && J.todayStr) ? J.todayStr() : "";
    }
    const res = await api("save", { table, payload });
    if (!res.ok) { alert(res.error || "خطا در تغییر وضعیت"); return false; }
    // وصول/پاس → ثبت خودکار در دریافت/پرداخت حسابداری
    if (toStatus === "cleared") {
      const isPaid = table === "checks_paid";
      const amt = parseFloat(row.amount) || 0;
      const party = isPaid ? (row.payee || row.name || "") : (row.name || row.payee || "");
      const already = (S.account_payments || []).some((pay) =>
        String(pay.ref_type || "") === table && String(pay.ref_id || "") === String(row.id)
      );
      if (amt > 0 && !already) {
        const payPayload = {
          direction: isPaid ? "out" : "in",
          method: "bank",
          account_name: ((S.bank_accounts || [])[0] && (S.bank_accounts || [])[0].name) || (row.bank || ""),
          person_type: isPaid ? "supplier" : "customer",
          person_name: party,
          amount: amt,
          pay_date: payload.passed_date || ((window.J && J.todayStr) ? J.todayStr() : ""),
          notes: "وصول چک " + (row.num || row.id) + " — " + (row.bank || ""),
          ref_type: table,
          ref_id: row.id,
        };
        const pr = await api("save", { table: "account_payments", payload: payPayload });
        if (pr && pr.ok) {
          if (!S.account_payments) S.account_payments = [];
          if (pr.data) S.account_payments.push(pr.data);
          else S.account_payments.push(Object.assign({ id: Date.now() }, payPayload));
        }
      }
    }
    return true;
  }

  function attachCheckActionButtons(cardEl, table, isPaid) {
    if (!cardEl) return;
    const can = POLICY.is_manager || POLICY.role === "warehouse";
    if (!can) return;
    cardEl.querySelectorAll("tbody tr").forEach((tr) => {
      const idEl = tr.querySelector(".row-check");
      const id = idEl ? Number(idEl.value) : 0;
      if (!id) return;
      const rows = table === "checks_received" ? (S.checks_received || []) : (S.checks_paid || []);
      const row = rows.find((x) => Number(x.id) === id);
      if (!row) return;
      const td = tr.querySelector("td.actions");
      if (!td) return;
      // برچسب وضعیت
      const st = normalizeCheckStatus(row);
      const badge = document.createElement("span");
      badge.className = "check-status-badge st-" + st;
      badge.textContent = checkStatusLabel(st, isPaid);
      badge.style.cssText = "display:inline-block;margin-left:6px;font-size:0.75rem;font-weight:600";
      td.insertBefore(badge, td.firstChild);

      checkNextActions(row, isPaid).forEach((act) => {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "btn btn-sm" + (act.danger ? " btn-danger" : "");
        b.textContent = act.l;
        b.onclick = async (e) => {
          e.preventDefault();
          e.stopPropagation();
          if (act.danger && !confirm(act.l + " — مطمئن هستید؟")) return;
          const ok = await setCheckStatus(table, row, act.to);
          if (ok) { await reload(); render(); }
        };
        td.appendChild(b);
      });
    });
  }


  function buildPartyLedger() {
    const map = {};
    function ensure(name, type) {
      const key = (name || "—").trim();
      if (!key) return null;
      if (!map[key]) map[key] = { name: key, type: type || "سایر", balance: 0, items: [] };
      return map[key];
    }
    // مشتریان: مانده حساب
    (S.customers || []).forEach((c) => {
      const p = ensure(c.name, "مشتری");
      if (!p) return;
      const bal = parseFloat(c.balance) || 0;
      if (bal !== 0) {
        p.balance += bal;
        p.items.push({ kind: "مانده مشتری", amount: bal, date: "", note: c.status || "" });
      }
      const proj = parseFloat(c.project_amount) || 0;
      if (proj > 0 && bal === 0) {
        // فقط برای نمایش اطلاعاتی
      }
    });
    // چک دریافتنی باز = هنوز وصول‌نشده
    (S.checks_received || []).forEach((c) => {
      if ((c.kind || "") === "خرید دین") return;
      if (!checkIsOpen(c)) return;
      const p = ensure(c.name, "مشتری");
      if (!p) return;
      const amt = parseFloat(c.amount) || 0;
      p.balance += amt;
      p.items.push({ kind: "چک دریافتنی (" + checkStatusLabel(normalizeCheckStatus(c), false) + ")", amount: amt, date: c.check_date || "", note: (c.bank || "") + " " + (c.num || "") });
    });
    // چک پرداختنی باز = هنوز پاس‌نشده
    (S.checks_paid || []).forEach((c) => {
      if ((c.kind || "") === "خرید دین") return;
      if (!checkIsOpen(c)) return;
      const p = ensure(c.payee || c.name, "تأمین‌کننده/سایر");
      if (!p) return;
      const amt = parseFloat(c.amount) || 0;
      p.balance -= amt;
      p.items.push({ kind: "چک پرداختنی (" + checkStatusLabel(normalizeCheckStatus(c), true) + ")", amount: -amt, date: c.check_date || "", note: (c.bank || "") + " " + (c.num || "") });
    });
    // خرید دین
    (S.debt_purchases || []).forEach((c) => {
      const p = ensure(c.name || c.payee, "خرید دین");
      if (!p) return;
      const amt = parseFloat(c.amount) || 0;
      p.balance -= amt;
      p.items.push({ kind: "خرید دین", amount: -amt, date: c.check_date || "", note: c.note || "" });
    });
    // پرداخت/دریافت از حساب
    (S.account_payments || []).forEach((c) => {
      const p = ensure(c.person_name, c.person_type || "طرف‌حساب");
      if (!p) return;
      const amt = parseFloat(c.amount) || 0;
      const dir = (c.direction || "out");
      if (dir === "in") {
        p.balance -= amt; // دریافت از طرف = کاهش بدهی او
        p.items.push({ kind: "دریافت", amount: -amt, date: c.pay_date || "", note: (c.method || "") + " " + (c.notes || "") });
      } else {
        p.balance += amt; // پرداخت به طرف اگر بستانکار بوده یا پیش‌پرداخت
        p.items.push({ kind: "پرداخت", amount: amt, date: c.pay_date || "", note: (c.method || "") + " " + (c.notes || "") });
      }
    });
    // فاکتور فروش
    (S.sales_invoices || []).forEach((inv) => {
      if ((inv.status || "") === "cancelled") return;
      const p = ensure(inv.customer_name, "مشتری");
      if (!p) return;
      const total = parseFloat(inv.total) || 0;
      const paid = parseFloat(inv.paid_amount) || 0;
      const debt = total - paid;
      if (Math.abs(debt) < 0.5) return;
      p.balance += debt;
      p.items.push({ kind: "فاکتور فروش " + (inv.invoice_no || ""), amount: debt, date: inv.invoice_date || "", note: inv.status || "" });
    });
    // هزینه‌های دارای طرف
    (S.expenses || []).forEach((e) => {
      if (!(e.party_name || "").trim()) return;
      const p = ensure(e.party_name, "هزینه");
      if (!p) return;
      const amt = parseFloat(e.amount) || 0;
      p.balance -= amt;
      p.items.push({ kind: "هزینه: " + (e.title || e.category || ""), amount: -amt, date: e.expense_date || "", note: e.notes || "" });
    });
    // درآمدهای دارای طرف
    (S.incomes || []).forEach((e) => {
      if (!(e.party_name || "").trim()) return;
      const p = ensure(e.party_name, "درآمد");
      if (!p) return;
      const amt = parseFloat(e.amount) || 0;
      p.balance -= amt;
      p.items.push({ kind: "درآمد: " + (e.title || e.category || ""), amount: -amt, date: e.income_date || "", note: e.notes || "" });
    });
    return Object.values(map).filter((p) => Math.abs(p.balance) > 0.5).sort((a, b) => Math.abs(b.balance) - Math.abs(a.balance));
  }

  function renderPartyBalances(root, list, isDebtor) {
    const title = isDebtor ? "بدهکاران (طلب ما از دیگران)" : "بستانکاران (بدهی ما به دیگران)";
    const card = document.createElement("div");
    card.className = "card";
    const total = list.reduce((s, p) => s + Math.abs(p.balance), 0);
    card.innerHTML = `<h2>${title}</h2>
      <p class="hint">روی هر ردیف کلیک کنید تا ریز گزارش همان شخص را ببینید. جمع: <strong>${fmt(total, "amount")}</strong> ریال</p>`;
    root.appendChild(card);

    if (!list.length) {
      root.appendChild(Object.assign(document.createElement("div"), { className: "empty", textContent: isDebtor ? "بدهکاری ثبت نشده." : "بستانکاری ثبت نشده." }));
      return;
    }

    const table = document.createElement("table");
    table.innerHTML = `<thead><tr><th>نام</th><th>نوع</th><th>مانده (ریال)</th><th>تعداد سند</th></tr></thead>`;
    const tb = document.createElement("tbody");
    list.forEach((p) => {
      const tr = document.createElement("tr");
      tr.style.cursor = "pointer";
      tr.innerHTML = `<td><strong>${p.name}</strong></td>
        <td>${p.type || "—"}</td>
        <td style="direction:ltr;text-align:left;color:${isDebtor ? "#b91c1c" : "#0369a1"}">${fmt(Math.abs(p.balance), "amount")}</td>
        <td>${(p.items || []).length}</td>`;
      tr.onclick = () => renderPartyDetail(root, p, isDebtor);
      tb.appendChild(tr);
    });
    table.appendChild(tb);
    const wrap = document.createElement("div");
    wrap.className = "card";
    wrap.appendChild(table);
    root.appendChild(wrap);
  }

  function renderPartyDetail(root, party, isDebtor) {
    // پاک کردن و نمایش جزئیات
    root.innerHTML = "";
    const back = document.createElement("button");
    back.type = "button";
    back.className = "btn btn-outline btn-sm";
    back.textContent = "← بازگشت به لیست";
    back.onclick = () => {
      window.__financeSection = isDebtor ? "debtors" : "creditors";
      render();
    };
    root.appendChild(back);

    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `<h2>ریز حساب: ${party.name}</h2>
      <p>نوع: <strong>${party.type || "—"}</strong> — مانده: <strong style="color:${party.balance > 0 ? "#b91c1c" : "#0369a1"}">${fmt(party.balance, "amount")}</strong> ریال
      ${party.balance > 0 ? " (بدهکار به ما)" : " (ما بدهکاریم)"}</p>`;
    root.appendChild(card);

    const table = document.createElement("table");
    table.innerHTML = `<thead><tr><th>نوع سند</th><th>مبلغ</th><th>تاریخ</th><th>توضیح</th></tr></thead>`;
    const tb = document.createElement("tbody");
    (party.items || []).forEach((it) => {
      const tr = document.createElement("tr");
      const amt = parseFloat(it.amount) || 0;
      tr.innerHTML = `<td>${it.kind || "—"}</td>
        <td style="direction:ltr;color:${amt >= 0 ? "#b91c1c" : "#0369a1"}">${fmt(amt, "amount")}</td>
        <td>${it.date || "—"}</td>
        <td>${it.note || ""}</td>`;
      tb.appendChild(tr);
    });
    table.appendChild(tb);
    const wrap = document.createElement("div");
    wrap.className = "card";
    wrap.appendChild(table);
    root.appendChild(wrap);

    // دکمه پرداخت سریع
    if (POLICY.is_manager || POLICY.role === "warehouse") {
      const act = document.createElement("div");
      act.className = "card";
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "btn";
      btn.textContent = isDebtor ? "ثبت دریافت از این بدهکار" : "ثبت پرداخت به این بستانکار";
      btn.onclick = () => openAccountPaymentModal(party.name);
      act.appendChild(btn);
      root.appendChild(act);
    }
  }

    function renderFinancePage(root) {
    const recvAll = S.checks_received || [];
    const paidAll = S.checks_paid || [];
    // فقط چک (نه خرید دین قدیمی)
    const recv = recvAll.filter((c) => (c.kind || "check") !== "خرید دین");
    const paid = paidAll.filter((c) => (c.kind || "check") !== "خرید دین");
    const debts = S.debt_purchases || [];
    // مهاجرت نمایشی: خرید دین‌های قدیمی داخل checks
    const oldDebts = [...recvAll, ...paidAll].filter((c) => (c.kind || "") === "خرید دین");

    // دکمه پرداخت از حساب + اقساط و اجاره — بالای صفحه
    const topBar = document.createElement("div");
    topBar.className = "card";
    topBar.style.cssText = "display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between";
    topBar.innerHTML = `<h2 style="margin:0"><span>حسابداری</span></h2>`;
    const topActs = document.createElement("div");
    topActs.style.cssText = "display:flex;flex-wrap:wrap;gap:8px";
    const instBtn = document.createElement("button");
    instBtn.type = "button";
    instBtn.className = "btn btn-sm btn-outline";
    instBtn.textContent = "اقساط و اجاره‌ها";
    instBtn.onclick = () => { menu = "installments"; renderNav(); render(); };
    topActs.appendChild(instBtn);
    const payBtn = document.createElement("button");
    payBtn.type = "button";
    payBtn.className = "btn btn-sm";
    payBtn.textContent = "پرداخت از حساب";
    payBtn.onclick = () => openAccountPaymentModal();
    topActs.appendChild(payBtn);
    topBar.appendChild(topActs);
    root.appendChild(topBar);
    attachHelpQ(topBar.querySelector("h2"), "finance");

    // باکس انتخاب بخش: مالی و چک‌ها
    let section = window.__financeSection || "checks";
    const sectionBar = document.createElement("div");
    sectionBar.className = "stats";
    // محاسبه بدهکاران و بستانکاران
    const ledger = buildPartyLedger();
    const debtors = ledger.filter((p) => p.balance > 0);
    const creditors = ledger.filter((p) => p.balance < 0);
    const sections = [
      { id: "checks", label: "چک‌ها", count: recv.length + paid.length },
      { id: "parties", label: "طرف‌حساب‌ها", count: ledger.length },
      { id: "treasury", label: "صندوق و بانک", count: (S.cash_boxes || []).length + (S.bank_accounts || []).length },
      { id: "sales", label: "فاکتور فروش", count: (S.sales_invoices || []).length },
      { id: "expenses", label: "هزینه‌ها", count: (S.expenses || []).length },
      { id: "incomes", label: "درآمدها", count: (S.incomes || []).length },
      { id: "debtors", label: "بدهکاران", count: debtors.length },
      { id: "creditors", label: "بستانکاران", count: creditors.length },
      { id: "debt", label: "خرید دین", count: debts.length + oldDebts.length },
      { id: "payments", label: "دریافت/پرداخت", count: (S.account_payments || []).length },
    ];
    sections.forEach((s) => {
      const d = document.createElement("div");
      d.className = "stat stat-link" + (section === s.id ? " stat-alert" : "");
      d.innerHTML = `<b>${s.count}</b><span>${s.label}</span>`;
      d.onclick = () => { window.__financeSection = s.id; render(); };
      sectionBar.appendChild(d);
    });
    root.appendChild(sectionBar);


    if (section === "parties") {
      const all = buildPartyLedger();
      const card = document.createElement("div");
      card.className = "card";
      card.innerHTML = `<h2>طرف‌حساب‌های یکپارچه</h2>
        <p class="hint">گردش مشتری، تأمین‌کننده، چک، فاکتور، دریافت/پرداخت و هزینه/درآمد در یک نما.</p>`;
      root.appendChild(card);
      renderPartyBalances(root, all.filter((p) => p.balance > 0), true);
      renderPartyBalances(root, all.filter((p) => p.balance < 0), false);
      if (!all.length) {
        const e = document.createElement("div");
        e.className = "card";
        e.innerHTML = `<p class="empty-hint">هنوز گردش طرف‌حسابی ثبت نشده.</p>`;
        root.appendChild(e);
      }
      return;
    }

    if (section === "treasury") {
      root.appendChild(crudTable("cash_boxes", "صندوق‌ها", {}));
      root.appendChild(crudTable("bank_accounts", "حساب‌های بانکی", {}));
      const hint = document.createElement("div");
      hint.className = "card";
      hint.innerHTML = `<h2>راهنما</h2><p class="hint">ابتدا صندوق و حساب بانکی تعریف کنید. سپس از بخش «دریافت/پرداخت» یا هنگام ثبت هزینه/درآمد، صندوق یا بانک را انتخاب کنید.</p>`;
      root.appendChild(hint);
      // خلاصه موجودی تقریبی
      const sumCard = document.createElement("div");
      sumCard.className = "card";
      let cashOpen = (S.cash_boxes || []).reduce((s, c) => s + (parseFloat(c.opening_balance) || 0), 0);
      let bankOpen = (S.bank_accounts || []).reduce((s, c) => s + (parseFloat(c.opening_balance) || 0), 0);
      let inAmt = 0, outAmt = 0;
      (S.account_payments || []).forEach((p) => {
        const a = parseFloat(p.amount) || 0;
        if ((p.direction || "out") === "in") inAmt += a; else outAmt += a;
      });
      (S.incomes || []).forEach((x) => { inAmt += parseFloat(x.amount) || 0; });
      (S.expenses || []).forEach((x) => { outAmt += parseFloat(x.amount) || 0; });
      let chkIn = 0, chkOut = 0, chkOpenIn = 0, chkOpenOut = 0;
      (S.checks_received || []).forEach((c) => {
        if ((c.kind || "") === "خرید دین") return;
        const a = parseFloat(c.amount) || 0;
        const st = normalizeCheckStatus(c);
        if (st === "cleared") chkIn += a;
        else if (checkIsOpen(c)) chkOpenIn += a;
      });
      (S.checks_paid || []).forEach((c) => {
        if ((c.kind || "") === "خرید دین") return;
        const a = parseFloat(c.amount) || 0;
        const st = normalizeCheckStatus(c);
        if (st === "cleared") chkOut += a;
        else if (checkIsOpen(c)) chkOpenOut += a;
      });
      sumCard.innerHTML = `<h2>خلاصه خزانه (تقریبی)</h2>
        <div class="stats" style="margin:0">
          <div class="stat"><b>${fmt(cashOpen, "amount")}</b><span>اول دوره صندوق</span></div>
          <div class="stat"><b>${fmt(bankOpen, "amount")}</b><span>اول دوره بانک</span></div>
          <div class="stat"><b>${fmt(inAmt + chkIn, "amount")}</b><span>دریافت+وصول چک</span></div>
          <div class="stat"><b>${fmt(outAmt + chkOut, "amount")}</b><span>پرداخت+پاس چک</span></div>
          <div class="stat"><b>${fmt(chkOpenIn, "amount")}</b><span>چک دریافتنی باز</span></div>
          <div class="stat"><b>${fmt(chkOpenOut, "amount")}</b><span>چک پرداختنی باز</span></div>
          <div class="stat"><b>${fmt(cashOpen + bankOpen + inAmt + chkIn - outAmt - chkOut, "amount")}</b><span>مانده تقریبی</span></div>
        </div>`;
      root.appendChild(sumCard);
      return;
    }

    if (section === "sales") {
      const info = document.createElement("div");
      info.className = "card";
      info.innerHTML = `<h2>فاکتور فروش</h2>
        <p class="hint">با ثبت فاکتور، موجودی انبار کسر و مانده مشتری افزایش می‌یابد (به اندازه مبلغ منهای پرداخت‌شده). فیلد «اقلام» را به صورت JSON وارد کنید یا از دکمه صدور سریع استفاده کنید.</p>`;
      root.appendChild(info);
      // دکمه صدور سریع
      const quick = document.createElement("div");
      quick.className = "card";
      quick.innerHTML = `<h3>صدور سریع فاکتور</h3>`;
      const qf = document.createElement("div");
      qf.style.cssText = "display:grid;gap:8px;grid-template-columns:1fr 1fr";
      qf.innerHTML = `
        <div class="field"><label>مشتری</label><input id="si-cust" list="si-cust-list" placeholder="نام مشتری"><datalist id="si-cust-list"></datalist></div>
        <div class="field"><label>تاریخ</label><input id="si-date" placeholder="1403/07/01"></div>
        <div class="field"><label>کالا</label><input id="si-item" list="si-item-list" placeholder="نام کالا"><datalist id="si-item-list"></datalist></div>
        <div class="field"><label>تعداد</label><input id="si-qty" type="number" step="any" value="1"></div>
        <div class="field"><label>قیمت واحد</label><input id="si-price" inputmode="decimal" placeholder="ریال"></div>
        <div class="field"><label>انبار</label><input id="si-wh" list="si-wh-list"><datalist id="si-wh-list"></datalist></div>
        <div class="field"><label>تخفیف</label><input id="si-disc" inputmode="decimal" value="0"></div>
        <div class="field"><label>پرداخت‌شده الان</label><input id="si-paid" inputmode="decimal" value="0"></div>`;
      quick.appendChild(qf);
      (S.customers || []).forEach((c) => {
        const o = document.createElement("option"); o.value = c.name || "";
        quick.querySelector("#si-cust-list").appendChild(o);
      });
      (S.stock_items || []).forEach((i) => {
        const o = document.createElement("option"); o.value = i.item || "";
        quick.querySelector("#si-item-list").appendChild(o);
      });
      (typeof listWarehouses === "function" ? listWarehouses() : []).forEach((w) => {
        const o = document.createElement("option"); o.value = w;
        quick.querySelector("#si-wh-list").appendChild(o);
      });
      if (window.J && J.todayStr) quick.querySelector("#si-date").value = J.todayStr();
      const btn = document.createElement("button");
      btn.type = "button"; btn.className = "btn"; btn.textContent = "ثبت فاکتور فروش";
      btn.onclick = async () => {
        const cust = quick.querySelector("#si-cust").value.trim();
        const item = quick.querySelector("#si-item").value.trim();
        const qty = parseFloat(quick.querySelector("#si-qty").value) || 0;
        const price = parseFloat(String(quick.querySelector("#si-price").value).replace(/,/g, "")) || 0;
        const disc = parseFloat(String(quick.querySelector("#si-disc").value).replace(/,/g, "")) || 0;
        const paid = parseFloat(String(quick.querySelector("#si-paid").value).replace(/,/g, "")) || 0;
        const wh = quick.querySelector("#si-wh").value.trim();
        const date = quick.querySelector("#si-date").value.trim();
        if (!cust || !item || qty <= 0) { alert("مشتری، کالا و تعداد الزامی است"); return; }
        const sub = Math.round(qty * price);
        const total = Math.max(0, sub - disc);
        const items = [{ item, qty, unit: "", price, amount: sub }];
        const payload = {
          customer_name: cust,
          invoice_date: date,
          invoice_no: "S-" + Date.now().toString().slice(-8),
          items_json: JSON.stringify(items),
          subtotal: sub,
          discount: disc,
          total,
          paid_amount: paid,
          status: paid >= total ? "paid" : (paid > 0 ? "partial" : "open"),
          warehouse: wh,
        };
        const res = await api("save", { table: "sales_invoices", payload });
        if (!res.ok) { alert(res.error || "خطا"); return; }
        await reload(); render();
      };
      quick.appendChild(btn);
      root.appendChild(quick);
      root.appendChild(crudTable("sales_invoices", "فاکتورهای فروش", {}));
      return;
    }

    if (section === "expenses") {
      root.appendChild(crudTable("expenses", "هزینه‌ها", {}));
      return;
    }
    if (section === "incomes") {
      root.appendChild(crudTable("incomes", "درآمدها", {}));
      return;
    }


    if (section === "debtors" || section === "creditors") {
      renderPartyBalances(root, section === "debtors" ? debtors : creditors, section === "debtors");
      return;
    }

    if (section === "checks") {
      const openRecv = recv.filter(checkIsOpen);
      const openPaid = paid.filter(checkIsOpen);
      const sumRecv = sumChecks(openRecv);
      const sumPaid = sumChecks(openPaid);
      const pendRecv = recv.filter((c) => normalizeCheckStatus(c) === "pending").length;
      const dueRecv = openRecv.filter((c) => { const d = J.daysUntil(c.check_date); return d !== null && d >= 0 && d <= 3; }).length;
      const duePaid = openPaid.filter((c) => { const d = J.daysUntil(c.check_date); return d !== null && d >= 0 && d <= 3; }).length;
      const clearedRecv = recv.filter((c) => normalizeCheckStatus(c) === "cleared");
      const returnedN = [...recv, ...paid].filter((c) => normalizeCheckStatus(c) === "returned").length;

      const sumCard = document.createElement("div");
      sumCard.className = "card";
      sumCard.innerHTML = `<h2><span>خلاصه چک‌ها</span></h2>
        <div class="stats" style="margin:0">
          <div class="stat"><b>${fmt(sumRecv, "amount")}</b><span>باز دریافتنی</span></div>
          <div class="stat"><b>${fmt(sumPaid, "amount")}</b><span>باز پرداختنی</span></div>
          <div class="stat ${pendRecv ? "stat-alert" : ""}"><b>${pendRecv}</b><span>در انتظار تأیید</span></div>
          <div class="stat ${dueRecv ? "stat-alert" : ""}"><b>${dueRecv}</b><span>سررسید ۳روز دریافتنی</span></div>
          <div class="stat ${duePaid ? "stat-alert" : ""}"><b>${duePaid}</b><span>سررسید ۳روز پرداختنی</span></div>
          <div class="stat"><b>${clearedRecv.length}</b><span>وصول‌شده</span></div>
          <div class="stat ${returnedN ? "stat-alert" : ""}"><b>${returnedN}</b><span>برگشتی</span></div>
        </div>
        <p class="hint" style="margin-top:10px">چرخه دریافتنی: در انتظار → نزد ما → واگذار بانک → وصول | چرخه پرداختنی: در انتظار → صادر → بانک → پاس</p>`;
      root.appendChild(sumCard);

      // نوار ثبت سریع چک در حسابداری
      const quickBar = document.createElement("div");
      quickBar.className = "card";
      quickBar.style.cssText = "display:flex;flex-wrap:wrap;gap:8px;align-items:center";
      const qh = document.createElement("div");
      qh.style.cssText = "flex:1;min-width:180px";
      qh.innerHTML = `<h2 style="margin:0">چک‌های حسابداری</h2>
        <p class="hint" style="margin:4px 0 0">با «وصول/پاس» سند دریافت یا پرداخت در خزانه ثبت می‌شود و از مانده طرف‌حساب کم می‌شود.</p>`;
      quickBar.appendChild(qh);
      const addRecv = document.createElement("button");
      addRecv.type = "button";
      addRecv.className = "btn btn-sm";
      addRecv.textContent = "+ چک دریافتنی";
      addRecv.onclick = () => openModal("checks_received");
      const addPaid = document.createElement("button");
      addPaid.type = "button";
      addPaid.className = "btn btn-sm btn-outline";
      addPaid.textContent = "+ چک پرداختنی";
      addPaid.onclick = () => openModal("checks_paid");
      quickBar.appendChild(addRecv);
      quickBar.appendChild(addPaid);
      root.appendChild(quickBar);

      // فیلتر وضعیت
      const stFilter = window.__checkStatusFilter || "open";
      const filterBar = document.createElement("div");
      filterBar.className = "check-filter-bar";
      filterBar.style.cssText = "display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px";
      [
        { id: "open", l: "بازها" },
        { id: "pending", l: "در انتظار" },
        { id: "due", l: "سررسید ۳روز" },
        { id: "cleared", l: "وصول/پاس" },
        { id: "returned", l: "برگشتی" },
        { id: "all", l: "همه" },
      ].forEach((f) => {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "btn btn-sm" + (stFilter === f.id ? "" : " btn-outline");
        b.textContent = f.l;
        b.onclick = () => { window.__checkStatusFilter = f.id; render(); };
        filterBar.appendChild(b);
      });
      root.appendChild(filterBar);

      const matchFilter = (c) => {
        if ((c.kind || "check") === "خرید دین") return false;
        const st = normalizeCheckStatus(c);
        if (stFilter === "all") return true;
        if (stFilter === "open") return checkIsOpen(c);
        if (stFilter === "pending") return st === "pending";
        if (stFilter === "cleared") return st === "cleared";
        if (stFilter === "returned") return st === "returned";
        if (stFilter === "due") {
          if (!checkIsOpen(c)) return false;
          const d = J.daysUntil(c.check_date);
          return d !== null && d >= 0 && d <= 3;
        }
        return true;
      };

      const recvCard = crudTable("checks_received", "چک‌های دریافتنی", { filterFn: matchFilter });
      root.appendChild(recvCard);
      attachCheckActionButtons(recvCard, "checks_received", false);

      const paidCard = crudTable("checks_paid", "چک‌های پرداختنی", { filterFn: matchFilter });
      root.appendChild(paidCard);
      attachCheckActionButtons(paidCard, "checks_paid", true);

      const foot = document.createElement("div");
      foot.className = "card";
      foot.innerHTML = `<h2>جمع مبالغ (فقط چک‌های باز)</h2>
        <p>جمع دریافتنی باز: <strong>${fmt(sumRecv, "amount")}</strong></p>
        <p>جمع پرداختنی باز: <strong>${fmt(sumPaid, "amount")}</strong></p>
        <p>مانده (دریافتنی − پرداختی): <strong>${fmt(sumRecv - sumPaid, "amount")}</strong></p>
        <p class="hint">وصول‌شده و رد/باطل در مانده طرف‌حساب لحاظ نمی‌شوند.</p>`;
      root.appendChild(foot);
    } else if (section === "debt") {
      root.appendChild(crudTable("debt_purchases", "خرید دین", {}));
      if (oldDebts.length) {
        const hint = document.createElement("div");
        hint.className = "card";
        hint.innerHTML = `<p class="hint">توجه: ${oldDebts.length} مورد خرید دین قدیمی هنوز در جداول چک ذخیره شده‌اند. موارد جدید را در جدول «خرید دین» ثبت کنید.</p>`;
        root.appendChild(hint);
      }
    } else if (section === "payments") {
      const bar = document.createElement("div");
      bar.className = "card";
      bar.style.cssText = "display:flex;flex-wrap:wrap;gap:8px;align-items:center";
      bar.innerHTML = `<h2 style="margin:0;flex:1">دریافت و پرداخت</h2>`;
      const bIn = document.createElement("button");
      bIn.type = "button"; bIn.className = "btn btn-sm"; bIn.textContent = "ثبت دریافت";
      bIn.onclick = () => openAccountPaymentModal(null, "in");
      const bOut = document.createElement("button");
      bOut.type = "button"; bOut.className = "btn btn-sm btn-outline"; bOut.textContent = "ثبت پرداخت";
      bOut.onclick = () => openAccountPaymentModal(null, "out");
      bar.appendChild(bIn); bar.appendChild(bOut);
      root.appendChild(bar);
      root.appendChild(crudTable("account_payments", "اسناد دریافت و پرداخت", {}));
    } else {
      root.appendChild(crudTable("account_payments", "دریافت/پرداخت", {}));
    }
  }

  function listWarehouses() {
    // فقط انبارهای مادر تعریف‌شده توسط مدیر + دسته‌های واقعی کالاها
    const set = new Set(getMotherWarehouses());
    (S.stock_items || []).forEach((i) => {
      if (i.category) set.add(i.category);
    });
    return [...set];
  }

  function renderWarehousePage(root) {
    // راه‌اندازی انبارهای مادر — فقط مدیر، بدون هیچ نام از پیش‌پر
    if (!mothersConfigured()) {
      const setup = document.createElement("div");
      setup.className = "card";
      if (POLICY.is_manager) {
        setup.innerHTML = `<h2>راه‌اندازی انبارهای مادر</h2>
          <p class="hint">هنوز هیچ انبار مادری تعریف نشده. سه نام را خودتان بنویسید (مثلاً ورق، یراق، رنگ). بعداً می‌توانید انبار مادر بیشتری اضافه کنید. فقط مدیر می‌تواند نام انبار مادر را تغییر دهد.</p>`;
        const inputs = [];
        for (let i = 0; i < 3; i++) {
          const f = document.createElement("div");
          f.className = "field";
          f.innerHTML = `<label>انبار مادر ${i + 1}</label>`;
          const inp = document.createElement("input");
          inp.type = "text";
          inp.placeholder = "نام را بنویسید...";
          inp.value = "";
          f.appendChild(inp);
          setup.appendChild(f);
          inputs.push(inp);
        }
        const moreWrap = document.createElement("div");
        moreWrap.style.cssText = "margin:8px 0";
        const addMore = document.createElement("button");
        addMore.type = "button";
        addMore.className = "btn btn-sm btn-outline";
        addMore.textContent = "+ افزودن فیلد انبار مادر بیشتر";
        addMore.onclick = () => {
          const f = document.createElement("div");
          f.className = "field";
          f.innerHTML = `<label>انبار مادر ${inputs.length + 1}</label>`;
          const inp = document.createElement("input");
          inp.type = "text";
          inp.placeholder = "نام را بنویسید...";
          f.appendChild(inp);
          setup.insertBefore(f, moreWrap);
          inputs.push(inp);
        };
        moreWrap.appendChild(addMore);
        setup.appendChild(moreWrap);
        const saveBtn = document.createElement("button");
        saveBtn.type = "button";
        saveBtn.className = "btn";
        saveBtn.textContent = "ذخیره انبارهای مادر";
        saveBtn.onclick = async () => {
          const list = inputs.map((i) => i.value.trim()).filter(Boolean);
          if (list.length < 1) { alert("حداقل یک نام انبار مادر وارد کنید"); return; }
          await saveMotherWarehouses(list);
          alert("انبارهای مادر ذخیره شد: " + list.join("، "));
          render();
        };
        setup.appendChild(saveBtn);
      } else {
        setup.innerHTML = `<h2>انبار</h2><p class="empty">هنوز انبار مادری تعریف نشده. لطفاً از مدیر مجموعه بخواهید ابتدا نام انبارهای مادر را در این بخش وارد کند.</p>`;
      }
      root.appendChild(setup);
      return; // تا وقتی مادر تعریف نشده، بقیه انبار نشان داده نشود
    }

    const mothers = getMotherWarehouses();
    const warehouses = listWarehouses();
    let current = window.__whFilter || "";
    const lowStockItems = (S.stock_items || []).filter((i) => StockHelper.isLow(i));

    // باکس‌های انبار مادر — کلیک = باز شدن لیست کالاهای همان انبار (قابل ویرایش فقط توسط مدیر)
    const boxes = document.createElement("div");
    boxes.className = "stats";
    const allBox = document.createElement("div");
    allBox.className = "stat stat-link" + (!current ? " stat-alert" : "");
    allBox.style.cursor = "pointer";
    allBox.title = "نمایش همه کالاها";
    allBox.innerHTML = `<b>${(S.stock_items || []).length}</b><span>همه کالاها</span>`;
    allBox.onclick = () => { window.__whFilter = ""; render(); };
    boxes.appendChild(allBox);

    mothers.forEach((w) => {
      const cnt = (S.stock_items || []).filter((i) => (i.category || "") === w).length;
      const d = document.createElement("div");
      d.className = "stat stat-link" + (current === w ? " stat-alert" : "");
      d.style.cursor = "pointer";
      d.style.position = "relative";
      d.title = "کلیک برای باز کردن کالاهای «" + w + "»";
      d.innerHTML = `<b>${cnt}</b><span>${w}</span>`;
      d.onclick = (ev) => {
        if (ev.target && ev.target.closest && ev.target.closest("[data-rename-wh]")) return;
        window.__whFilter = w;
        render();
      };
      if (POLICY.is_manager) {
        const ren = document.createElement("button");
        ren.type = "button";
        ren.setAttribute("data-rename-wh", "1");
        ren.className = "btn btn-sm btn-outline";
        ren.style.cssText = "margin-top:6px;font-size:0.75rem;padding:2px 8px";
        ren.textContent = "ویرایش نام";
        ren.onclick = async (ev) => {
          ev.stopPropagation();
          const nn = prompt("نام جدید برای انبار مادر «" + w + "»:", w);
          if (!nn || !nn.trim() || nn.trim() === w) return;
          const list = getMotherWarehouses().map((x) => x === w ? nn.trim() : x);
          await saveMotherWarehouses(list);
          for (const it of (S.stock_items || []).filter((i) => i.category === w)) {
            await api("save", { table: "stock_items", payload: { id: it.id, category: nn.trim() } });
          }
          if (window.__whFilter === w) window.__whFilter = nn.trim();
          await reload();
          render();
        };
        d.appendChild(ren);
      }
      boxes.appendChild(d);
    });

    const needBox = document.createElement("div");
    needBox.className = "stat stat-link" + (current === "__low_stock__" ? " stat-alert" : "") + (lowStockItems.length ? " stat-alert" : "");
    needBox.style.cursor = "pointer";
    needBox.title = "کالاهای زیر حداقل موجودی";
    needBox.innerHTML = `<b>${lowStockItems.length}</b><span>کمبود موجودی</span>`;
    needBox.onclick = () => { window.__whFilter = "__low_stock__"; render(); };
    boxes.appendChild(needBox);

    if (POLICY.is_manager) {
      const addBox = document.createElement("div");
      addBox.className = "stat stat-link";
      addBox.style.cursor = "pointer";
      addBox.title = "افزودن انبار مادر جدید";
      addBox.innerHTML = `<b>+</b><span>انبار مادر جدید</span>`;
      addBox.onclick = async () => {
        const name = prompt("نام انبار مادر جدید:");
        if (!name || !name.trim()) return;
        const list = getMotherWarehouses();
        if (list.includes(name.trim())) { alert("این نام از قبل هست"); return; }
        list.push(name.trim());
        await saveMotherWarehouses(list);
        window.__whFilter = name.trim();
        render();
      };
      boxes.appendChild(addBox);
    }
    root.appendChild(boxes);

    // عنوان بخش فعال
    const filterTitle = document.createElement("div");
    filterTitle.className = "card";
    if (current && current !== "__low_stock__") {
      filterTitle.innerHTML = `<h2>کالاهای انبار: ${current}</h2><p class="hint">فقط کالاهای این انبار مادر نمایش داده می‌شوند. برای افزودن کالا از دکمه + استفاده کنید.</p>`;
    } else if (current === "__low_stock__") {
      filterTitle.innerHTML = `<h2>کالاهای زیر حداقل موجودی</h2>`;
    } else {
      filterTitle.innerHTML = `<h2>همه کالاهای انبار</h2><p class="hint">روی نام هر انبار مادر در بالا کلیک کنید تا فقط کالاهای همان بخش را ببینید.</p>`;
    }
    root.appendChild(filterTitle);

    // جستجو
    const searchCard = document.createElement("div");
    searchCard.className = "card";
    const titleText = current === "__low_stock__"
      ? "کالاهای مورد نیاز برای تهیه (حداقل موجودی)"
      : ("انبار " + (current || "— همه"));
    searchCard.innerHTML = `<h2>${titleText}</h2>
      <p class="hint">در افزودن کالا، «حداقل موجودی» را وارد کنید. وقتی موجودی به آن عدد یا کمتر برسد، در باکس بالا نمایش داده می‌شود.</p>`;
    const search = document.createElement("input");
    search.type = "search";
    search.placeholder = "جستجو در نام کالا / دسته...";
    search.style.cssText = "width:100%;margin-bottom:10px;padding:8px";
    search.value = window.__whSearch || "";
    searchCard.appendChild(search);
    root.appendChild(searchCard);

    function draw() {
      const q = (search.value || "").trim();
      window.__whSearch = q;
      const old = root.querySelector("[data-wh-table]");
      if (old) old.remove();
      const wrap = document.createElement("div");
      wrap.setAttribute("data-wh-table", "1");
      const isLow = current === "__low_stock__";
      wrap.appendChild(crudTable("stock_items", isLow ? "کالاهای زیر حداقل موجودی" : (current ? ("موجودی — " + current) : "موجودی همه انبارها"), {
        filterFn: (i) => {
          if (isLow) {
            const qty = parseFloat(i.qty) || 0;
            const min = parseFloat(i.min_qty) || 0;
            if (!(min > 0 && qty <= min)) return false;
          } else {
            const w = i.category || i.warehouse || "";
            if (current && w !== current) return false;
          }
          if (!q) return true;
          const hay = [i.item, i.category, i.unit, i.warehouse].join(" ");
          return hay.includes(q);
        },
      }));
      root.appendChild(wrap);
    }
    search.oninput = () => draw();
    draw();

    // ── حواله بین انبارها ──
    const trCard = document.createElement("div");
    trCard.className = "card";
    trCard.innerHTML = `<h2>حواله بین انبارها</h2>
      <p class="hint">انتقال کالا از یک انبار مادر به انبار دیگر — موجودی مبدأ کم و مقصد زیاد می‌شود.</p>`;
    root.appendChild(trCard);
    root.appendChild(crudTable("stock_transfers", "حواله‌های ثبت‌شده", {}));

    // ── کاردکس ساده ──
    const cardex = document.createElement("div");
    cardex.className = "card";
    cardex.innerHTML = `<h2>کاردکس ساده کالا</h2>
      <p class="hint">ورود (خرید)، خروج (مصرف/فروش)، حواله — بر اساس نام کالا فیلتر کنید.</p>`;
    const cf = document.createElement("div");
    cf.className = "field";
    cf.innerHTML = `<label>نام کالا</label><input id="cardex-item" list="cardex-list" placeholder="جستجوی کالا..."><datalist id="cardex-list"></datalist>`;
    cardex.appendChild(cf);
    (S.stock_items || []).forEach((i) => {
      const o = document.createElement("option"); o.value = i.item || "";
      cf.querySelector("#cardex-list").appendChild(o);
    });
    const btnC = document.createElement("button");
    btnC.type = "button"; btnC.className = "btn btn-sm"; btnC.textContent = "نمایش کاردکس";
    const out = document.createElement("div");
    out.style.marginTop = "12px";
    btnC.onclick = () => {
      const name = (cf.querySelector("#cardex-item").value || "").trim();
      if (!name) { alert("نام کالا را وارد کنید"); return; }
      const rows = [];
      (S.purchases || []).forEach((r) => {
        if ((r.item || "") !== name) return;
        rows.push({ date: r.invoice_date || "", kind: "خرید (ورود)", qty: "+" + (r.qty || ""), wh: r.warehouse || "", note: r.supplier || "" });
      });
      (S.stock_usage || []).forEach((r) => {
        if ((r.item_name || "") !== name) return;
        const sign = (r.kind || "برداشت") === "بازگشت" ? "+" : "-";
        rows.push({ date: r.used_at || "", kind: "مصرف: " + (r.kind || "برداشت"), qty: sign + (r.qty || ""), wh: "", note: r.project || "" });
      });
      (S.stock_transfers || []).forEach((r) => {
        if ((r.item_name || "") !== name) return;
        rows.push({ date: r.transfer_date || "", kind: "حواله", qty: (r.qty || ""), wh: (r.from_warehouse || "") + " → " + (r.to_warehouse || ""), note: r.notes || "" });
      });
      (S.sales_invoices || []).forEach((inv) => {
        let items = [];
        try { items = typeof inv.items_json === "string" ? JSON.parse(inv.items_json || "[]") : (inv.items_json || []); } catch (e) {}
        items.forEach((it) => {
          if ((it.item || it.name || "") !== name) return;
          rows.push({ date: inv.invoice_date || "", kind: "فروش", qty: "-" + (it.qty || ""), wh: inv.warehouse || "", note: inv.customer_name || "" });
        });
      });
      rows.sort((a, b) => String(a.date).localeCompare(String(b.date)));
      const item = (S.stock_items || []).find((i) => i.item === name);
      let html = `<p><strong>موجودی فعلی:</strong> ${item ? (item.qty + " " + (item.unit || "")) : "—"} — انبار: ${item ? (item.category || "—") : "—"}</p>`;
      if (!rows.length) html += `<p class="empty-hint">گردشی یافت نشد.</p>`;
      else {
        html += `<div class="table-wrap"><table><thead><tr><th>تاریخ</th><th>نوع</th><th>مقدار</th><th>انبار</th><th>توضیح</th></tr></thead><tbody>`;
        rows.forEach((r) => {
          html += `<tr><td>${r.date || "—"}</td><td>${r.kind}</td><td>${r.qty}</td><td>${r.wh || "—"}</td><td>${r.note || "—"}</td></tr>`;
        });
        html += `</tbody></table></div>`;
      }
      out.innerHTML = html;
    };
    cardex.appendChild(btnC);
    cardex.appendChild(out);
    root.appendChild(cardex);
  }

  function renderProjectMessages(root) {
    const name = (USER.name || "").trim();
    // پروژه‌هایی که این پرسنل نصاب آن‌هاست
    const projects = (S.customers || []).filter((c) => {
      const inst = c.installer || "";
      return inst === name || String(inst).includes(name);
    });
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = "<h2>مکاتبات پروژه‌ها</h2><p class=\"hint\">پروژه‌هایی که مدیر شما را به‌عنوان نصاب معرفی کرده.</p>";
    if (!projects.length) {
      card.innerHTML += '<div class="empty">پروژه‌ای به شما اختصاص داده نشده.</div>';
      root.appendChild(card);
      return;
    }
    root.appendChild(card);
    // لیست پیام‌ها
    const msgs = (S.messages || []).filter((m) => {
      const proj = m.project || "";
      return projects.some((c) => c.name === proj) || m.sender_name === name || m.recipient_name === name;
    });
    const hist = document.createElement("div");
    hist.className = "card";
    hist.innerHTML = "<h2>تاریخچه مکاتبات</h2>";
    if (!msgs.length) hist.innerHTML += '<div class="empty">پیامی نیست</div>';
    else {
      const list = document.createElement("div");
      list.style.cssText = "display:flex;flex-direction:column;gap:8px";
      msgs.slice().reverse().forEach((m) => {
        const row = document.createElement("div");
        row.style.cssText = "padding:10px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc";
        const audio = m.file_path && /\.(webm|ogg|mp3|wav|m4a)(\?|$)/i.test(m.file_path);
        row.innerHTML = `<strong>${m.sender_name || "—"}</strong> → ${m.recipient_name || "—"} (${m.project || "—"})
          <div>${m.body || ""}</div>
          ${audio ? '<audio class="chat-audio" controls src="'+m.file_path+'"></audio>' : (m.file_path ? ' — <a href="'+m.file_path+'" target="_blank">پیوست</a>' : "")}
          <div class="hint">${(window.J && J.formatChatDate) ? J.formatChatDate(m.created_at) : (m.created_at || "")}</div>`;
        list.appendChild(row);
      });
      hist.appendChild(list);
    }
    root.appendChild(hist);

    // فرم ارسال
    const formCard = document.createElement("div");
    formCard.className = "card";
    formCard.innerHTML = "<h2>ارسال مکاتبه</h2>";
    const opts = projects.map((c) => `<option value="${c.name}">${c.name}</option>`).join("");
    formCard.innerHTML += `
      <div class="field"><label>پروژه / مشتری</label><select id="pm-proj">${opts}</select></div>
      <div class="field"><label>گیرنده</label>
        <select id="pm-to"><option value="مشتری">مشتری</option><option value="مدیر">مدیر</option></select>
      </div>
      <div class="field"><label>متن</label><textarea id="pm-body" style="min-height:70px;width:100%"></textarea></div>
      <div class="field"><label>فایل</label><input type="file" id="pm-file"></div>
      <div style="display:flex;gap:8px;align-items:center;margin-bottom:10px">
        <button type="button" class="chat-voice-btn" id="pm-voice" title="ضبط ویس">🎤</button>
        <span class="hint" id="pm-voice-hint">ویس برای مکاتبه</span>
      </div>
      <button type="button" class="btn" id="pm-send">ارسال</button>`;
    root.appendChild(formCard);

    // ویس مکاتبات
    let pmRec = null, pmChunks = [], pmRecording = false;
    const pmVoice = formCard.querySelector("#pm-voice");
    if (pmVoice) {
      pmVoice.onclick = async () => {
        if (pmRecording && pmRec) {
          pmRec.stop();
          return;
        }
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          pmChunks = [];
          const mime = MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "";
          pmRec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
          pmRec.ondataavailable = (e) => { if (e.data && e.data.size) pmChunks.push(e.data); };
          pmRec.onstop = async () => {
            stream.getTracks().forEach((t) => t.stop());
            const blob = new Blob(pmChunks, { type: pmRec.mimeType || "audio/webm" });
            const file = new File([blob], "voice-pm-" + Date.now() + ".webm", { type: blob.type });
            const dt = new DataTransfer();
            dt.items.add(file);
            const fi = document.getElementById("pm-file");
            if (fi) fi.files = dt.files;
            const body = document.getElementById("pm-body");
            if (body && !body.value) body.value = "🎤 پیام صوتی";
            pmVoice.classList.remove("recording");
            pmVoice.textContent = "🎤";
            pmRecording = false;
            const hint = document.getElementById("pm-voice-hint");
            if (hint) hint.textContent = "ویس آماده — ارسال را بزن";
            showToast("ویس آماده", "دکمه ارسال را بزن", "ok");
          };
          pmRec.start();
          pmRecording = true;
          pmVoice.classList.add("recording");
          pmVoice.textContent = "⏹";
          const hint = document.getElementById("pm-voice-hint");
          if (hint) hint.textContent = "در حال ضبط… دوباره بزن";
        } catch (e) {
          alert("دسترسی میکروفون لازم است");
        }
      };
    }

    formCard.querySelector("#pm-send").onclick = async () => {
      const body = (document.getElementById("pm-body").value || "").trim();
      if (!body) { alert("متن را بنویسید"); return; }
      const project = document.getElementById("pm-proj").value;
      const to = document.getElementById("pm-to").value;
      let file_path = "";
      const fi = document.getElementById("pm-file");
      if (fi.files && fi.files[0]) {
        const fd = new FormData();
        fd.append("action", "upload"); fd.append("_wpnonce", CSRF);
        fd.append("instance", String(INSTANCE_ID)); fd.append("file", fi.files[0]);
        fd.append("table", "photos");
        fd.append("payload", JSON.stringify({ project, stage: "message", caption: "مکاتبه" }));
        const up = await fetch(API + (API.includes("?") ? "&" : "?") + "action=upload", { method: "POST", body: fd, credentials: "same-origin" }).then((r) => r.json());
        if (up.ok && up.data) file_path = up.data.url || (window.UPLOADS + (up.data.filename || ""));
      }
      const payload = {
        sender_role: POLICY.role || "employee",
        sender_name: name,
        recipient_name: to === "مدیر" ? "مدیر" : project,
        recipient_role: to === "مدیر" ? "management" : "customer",
        body, msg_type: "project", file_path, project,
      };
      const res = await api("save", { table: "messages", payload });
      if (!res.ok) { alert(res.error || "خطا"); return; }
      alert("ارسال شد"); await reload(); render();
    };
  }

  function parseDesignFiles(raw) {
    if (!raw) return [];
    try {
      const arr = typeof raw === "string" ? JSON.parse(raw) : raw;
      return Array.isArray(arr) ? arr.filter(Boolean) : [];
    } catch (e) {
      return String(raw).split(/[\n,]+/).map((s) => s.trim()).filter(Boolean);
    }
  }

  function normalizeCustomerStatus(st) {
    st = st || "مشتریان جدید";
    if (CUSTOMER_STATUS_MAP[st]) st = CUSTOMER_STATUS_MAP[st];
    return st;
  }

  function renderCustomersPage(root) {
    if (window.__selectedCustomerId) {
      renderCustomerDetail(root, window.__selectedCustomerId);
      return;
    }
    // از داشبورد: فیلتر مراحل عقب‌مانده
    if (window.__dashFilter === "new_stages") {
      window.__customerStatusFilter = "مشتریان جدید";
      window.__dashFilter = null;
    }
    const filterCard = document.createElement("div");
    filterCard.className = "card";
    filterCard.innerHTML = "<h2>مشتریان و پروژه‌ها</h2><p class=\"hint\">چهار مرحله اصلی + کنسل‌شده. روی نام مشتری کلیک کنید تا پرونده و چت پروژه را ببینید. افزودن مشتری جدید از دکمه + افزودن.</p>";
    const bar = document.createElement("div");
    bar.style.cssText = "display:flex;flex-wrap:wrap;gap:8px;margin-bottom:4px";
    let currentFilter = window.__customerStatusFilter || "";
    const counts = {};
    CUSTOMER_STATUSES.forEach((s) => { counts[s.v] = 0; });
    (S.customers || []).forEach((c) => {
      const st = normalizeCustomerStatus(c.status);
      counts[st] = (counts[st] || 0) + 1;
    });
    function drawTable() {
      const old = root.querySelector("[data-customers-table]");
      if (old) old.remove();
      const wrap = document.createElement("div");
      wrap.setAttribute("data-customers-table", "1");
      const tableCard = crudTable("customers", currentFilter ? ("مشتریان — " + currentFilter) : "همه مشتریان", {
        filterFn: currentFilter
          ? (c) => normalizeCustomerStatus(c.status) === currentFilter
          : null,
      });
      wrap.appendChild(tableCard);
      // کلیک روی ردیف برای تاریخچه
      wrap.querySelectorAll("tbody tr").forEach((tr) => {
        const idCell = tr.querySelector(".row-check");
        if (!idCell) return;
        const id = Number(idCell.value);
        tr.style.cursor = "pointer";
        tr.addEventListener("click", (e) => {
          if (e.target.closest("button, input, a")) return;
          window.__selectedCustomerId = id;
          render();
        });
      });
      root.appendChild(wrap);
    }
    const allBtn = document.createElement("button");
    allBtn.type = "button";
    allBtn.className = "btn btn-sm" + (!currentFilter ? "" : " btn-outline");
    allBtn.textContent = "همه (" + (S.customers || []).length + ")";
    allBtn.onclick = () => {
      currentFilter = "";
      window.__customerStatusFilter = "";
      bar.querySelectorAll("button").forEach((b) => { b.className = "btn btn-sm btn-outline"; });
      allBtn.className = "btn btn-sm";
      drawTable();
    };
    bar.appendChild(allBtn);
    CUSTOMER_STATUSES.forEach((s) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "btn btn-sm" + (currentFilter === s.v ? "" : " btn-outline");
      btn.textContent = s.l + " (" + (counts[s.v] || 0) + ")";
      btn.onclick = () => {
        currentFilter = s.v;
        window.__customerStatusFilter = s.v;
        bar.querySelectorAll("button").forEach((b) => { b.className = "btn btn-sm btn-outline"; });
        btn.className = "btn btn-sm";
        drawTable();
      };
      bar.appendChild(btn);
    });
    filterCard.appendChild(bar);
    root.appendChild(filterCard);
    drawTable();
  }

  function renderCustomerDetail(root, id) {
    const c = (S.customers || []).find((x) => String(x.id) === String(id));
    const back = document.createElement("button");
    back.type = "button";
    back.className = "btn btn-outline btn-sm";
    back.textContent = "← بازگشت به لیست مشتریان";
    back.onclick = () => { window.__selectedCustomerId = null; render(); };
    root.appendChild(back);
    if (!c) {
      root.appendChild(Object.assign(document.createElement("div"), { className: "empty", textContent: "مشتری یافت نشد" }));
      return;
    }
    let st = normalizeCustomerStatus(c.status);
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `<h2>پرونده مشتری: ${c.name || "—"}</h2>
      <p>وضعیت: <strong>${st}</strong> — تلفن: ${fmt(c.phone)} — آدرس: ${fmt(c.address)}</p>
      <p>مبلغ پروژه: <strong>${fmt(c.project_amount, "project_amount")}</strong> — مانده: <strong>${fmt(c.balance, "balance")}</strong></p>`;
    root.appendChild(card);

    // ─── ماشین حالت مشتریان جدید ───
    if (st === "مشتریان جدید" || st === "مشتریان کنسل شده") {
      const stageCard = document.createElement("div");
      stageCard.className = "card";
      stageCard.innerHTML = "<h2>مراحل مشتریان جدید</h2><p class=\"hint\">هر مرحله باید تأیید شود. برای اندازه‌گیری آپلود عکس الزامی است.</p>";
      const currentSub = c.sub_stage || "اندازه‌گیری";
      const stagesWrap = document.createElement("div");
      stagesWrap.style.cssText = "display:flex;flex-direction:column;gap:10px;margin-top:10px";
      NEW_CUSTOMER_STAGES.forEach((sg, i) => {
        const row = document.createElement("div");
        row.style.cssText = "padding:12px;border:1px solid var(--b,#e2e8f0);border-radius:10px;background:" + (sg.key === currentSub ? "var(--p-soft,rgba(10,124,255,.08))" : "var(--card,#fff)");
        const done = (c.stage_done_at && sg.key !== currentSub && NEW_CUSTOMER_STAGES.findIndex(x => x.key === currentSub) > i);
        row.innerHTML = `<strong>${i + 1}. ${sg.label}</strong> ${done ? " ✅" : (sg.key === currentSub ? " ← جاری" : "")}`;
        if (sg.key === currentSub && st !== "مشتریان کنسل شده" && (POLICY.is_manager || POLICY.role === "supervisor")) {
          const acts = document.createElement("div");
          acts.style.cssText = "display:flex;flex-wrap:wrap;gap:8px;margin-top:8px";
          // انجام شد
          const btnDone = document.createElement("button");
          btnDone.type = "button";
          btnDone.className = "btn btn-sm";
          btnDone.textContent = "انجام شد";
          btnDone.onclick = async () => {
            if (sg.needPhoto) {
              const fileInp = document.createElement("input");
              fileInp.type = "file";
              fileInp.accept = "image/*";
              fileInp.multiple = true;
              fileInp.onchange = async () => {
                let photos = [];
                for (const f of fileInp.files || []) {
                  const fd = new FormData();
                  fd.append("action", "upload");
                  fd.append("_wpnonce", CSRF);
                  fd.append("instance", String(INSTANCE_ID));
                  fd.append("file", f);
                  fd.append("table", "photos");
                  fd.append("payload", JSON.stringify({ project: c.name, stage: sg.key, caption: "اندازه‌گیری" }));
                  try {
                    const up = await fetch(API + (API.includes("?") ? "&" : "?") + "action=upload", { method: "POST", body: fd, credentials: "same-origin" }).then(r => r.json());
                    if (up.ok && up.data) photos.push(up.data.url || up.data.filename || "");
                  } catch (e) {}
                }
                if (!photos.length) { alert("حداقل یک عکس اندازه‌گیری آپلود کنید"); return; }
                await advanceStage(c, sg, i, photos);
              };
              fileInp.click();
            } else {
              await advanceStage(c, sg, i, []);
            }
          };
          // انجام می‌دم
          const btnLater = document.createElement("button");
          btnLater.type = "button";
          btnLater.className = "btn btn-sm btn-outline";
          btnLater.textContent = "انجام می‌دم";
          btnLater.onclick = async () => {
            const when = prompt("تاریخ و ساعت انجام (مثال: ۱۴۰۵/۰۷/۱۵ ۱۴:۳۰):", (window.J && J.todayStr ? J.todayStr() + " " + (J.nowTime24 ? J.nowTime24() : "") : ""));
            if (!when) return;
            const res = await api("save", { table: "customers", payload: { id: c.id, stage_action: "later", stage_remind_at: when } });
            if (res && res.ok) { alert("یادآوری ثبت شد"); await reload(); render(); }
            else alert((res && res.error) || "خطا");
          };
          // کنسل
          const btnCancel = document.createElement("button");
          btnCancel.type = "button";
          btnCancel.className = "btn btn-sm btn-danger";
          btnCancel.textContent = "مشتری کنسل شده";
          btnCancel.onclick = async () => {
            if (!confirm("مشتری کنسل شود؟ اطلاعات در پرونده باقی می‌ماند.")) return;
            const res = await api("save", { table: "customers", payload: { id: c.id, status: "مشتریان کنسل شده", cancelled_at: (window.J && J.todayStr) ? J.todayStr() : "", stage_action: "cancelled" } });
            if (res && res.ok) { await reload(); render(); }
            else alert((res && res.error) || "خطا");
          };
          acts.appendChild(btnDone);
          acts.appendChild(btnLater);
          acts.appendChild(btnCancel);
          row.appendChild(acts);
        }
        stagesWrap.appendChild(row);
      });
      stageCard.appendChild(stagesWrap);
      root.appendChild(stageCard);
    }

    // ─── پیشرفت نصب ───
    if (st === "مشتریان در حال نصب") {
      const instCard = document.createElement("div");
      instCard.className = "card";
      let prog = {};
      try { prog = typeof c.install_progress === "string" ? JSON.parse(c.install_progress || "{}") : (c.install_progress || {}); } catch(e) { prog = {}; }
      const allSteps = INSTALL_STAGES_WALL.concat(INSTALL_STAGES_FLOOR);
      const doneCount = allSteps.filter(s => prog[s]).length;
      const pct = allSteps.length ? Math.round(doneCount / allSteps.length * 100) : 0;
      instCard.innerHTML = `<h2>پیشرفت نصب — ${pct}٪</h2><div style="height:10px;background:#e5e7eb;border-radius:6px;margin:8px 0"><div style="height:100%;width:${pct}%;background:var(--p,#0a7cff);border-radius:6px"></div></div>`;
      const list = document.createElement("div");
      list.style.cssText = "display:flex;flex-direction:column;gap:4px;max-height:320px;overflow:auto";
      allSteps.forEach(step => {
        const lab = document.createElement("label");
        lab.style.cssText = "display:flex;align-items:center;gap:8px;padding:4px 0;font-size:0.9rem";
        const cb = document.createElement("input");
        cb.type = "checkbox";
        cb.checked = !!prog[step];
        cb.disabled = !(POLICY.is_manager || POLICY.role === "supervisor" || POLICY.role === "employee");
        cb.onchange = async () => {
          prog[step] = cb.checked;
          const res = await api("save", { table: "customers", payload: { id: c.id, install_progress: JSON.stringify(prog) } });
          if (res && res.ok) { c.install_progress = JSON.stringify(prog); await reload(); window.__selectedCustomerId = id; render(); }
        };
        lab.appendChild(cb);
        lab.appendChild(document.createTextNode(step));
        list.appendChild(lab);
      });
      instCard.appendChild(list);
      // دکمه انتقال به تحویل
      if (POLICY.is_manager && pct >= 90) {
        const deliv = document.createElement("button");
        deliv.type = "button";
        deliv.className = "btn";
        deliv.style.marginTop = "12px";
        deliv.textContent = "انتقال به مشتریان تحویل داده شده";
        deliv.onclick = async () => {
          if (!confirm("پروژه تحویل شده ثبت شود؟")) return;
          const res = await api("save", { table: "customers", payload: { id: c.id, status: "مشتریان تحویل داده شده" } });
          if (res && res.ok) { await reload(); window.__selectedCustomerId = id; render(); }
        };
        instCard.appendChild(deliv);
      }
      root.appendChild(instCard);
    }

    async function advanceStage(cust, sg, idx, photos) {
      const next = NEW_CUSTOMER_STAGES[idx + 1];
      let payload = { id: cust.id, stage_action: "done", stage_done_at: (window.J && J.todayStr) ? J.todayStr() : "" };
      if (photos && photos.length) {
        let existing = [];
        try { existing = JSON.parse(cust.stage_photos || "[]"); } catch(e) {}
        payload.stage_photos = JSON.stringify(existing.concat(photos.map(p => ({ stage: sg.key, url: p }))));
      }
      if (next) {
        payload.sub_stage = next.key;
      } else {
        // اتمام قرارداد → ورود به تولید
        payload.status = "مشتریان در حال تولید";
        payload.sub_stage = "";
      }
      // اگر فاکتور قیمت: مشتری بدهکار می‌شود
      if (sg.key === "فاکتور قیمت") {
        const amt = parseFloat(cust.project_amount) || 0;
        if (amt > 0) payload.balance = String(amt);
      }
      const res = await api("save", { table: "customers", payload });
      if (res && res.ok) { await reload(); window.__selectedCustomerId = cust.id; render(); }
      else alert((res && res.error) || "خطا در ذخیره مرحله");
    }


    // ─── ثبت تولید و لیست یراق (مشتریان در حال تولید) ───
    if (st === "مشتریان در حال تولید" || st === "مشتریان در حال نصب") {
      const prodCard = document.createElement("div");
      prodCard.className = "card";
      prodCard.innerHTML = "<h2>ثبت مراحل تولید و مصرف مواد</h2><p class=\"hint\">داده‌ها خودکار در پرونده همین مشتری ذخیره می‌شوند. فقط مدیر و حسابداری جزئیات کامل را می‌بینند.</p>";
      const btnRow = document.createElement("div");
      btnRow.style.cssText = "display:flex;flex-wrap:wrap;gap:8px;margin:10px 0";
      PROD_STAGES.forEach((ps) => {
        const b = document.createElement("button");
        b.type = "button";
        b.className = "btn btn-sm btn-outline";
        b.textContent = ps.label;
        b.onclick = () => openProdForm(c, ps.key);
        btnRow.appendChild(b);
      });
      // دکمه انتقال به نصب
      if (st === "مشتریان در حال تولید" && POLICY.is_manager) {
        const toInst = document.createElement("button");
        toInst.type = "button";
        toInst.className = "btn btn-sm";
        toInst.textContent = "انتقال به مرحله نصب (بارگیری و حمل)";
        toInst.onclick = async () => {
          if (!confirm("مشتری به «در حال نصب» منتقل شود؟")) return;
          const res = await api("save", { table: "customers", payload: { id: c.id, status: "مشتریان در حال نصب", install_progress: "{}" } });
          if (res && res.ok) { await reload(); window.__selectedCustomerId = c.id; render(); }
        };
        btnRow.appendChild(toInst);
      }
      prodCard.appendChild(btnRow);

      // لیست مصرف‌های ثبت‌شده این مشتری — جدول با جمع کل (قابل مشاهده مدیر / حسابدار)
      const usages = (S.stock_usage || []).filter((u) => (u.project || "") === (c.name || ""));
      const hlists = (S.hardware_lists || []).filter((h) => (h.customer_name || "") === (c.name || ""));
      if (hlists.length || usages.length) {
        const hist = document.createElement("div");
        hist.style.cssText = "margin-top:12px";
        hist.innerHTML = "<h3>سابقه ثبت تولید و مصرف انبار</h3>";
        if (hlists.length) {
          hlists.forEach((h) => {
            const d = document.createElement("div");
            d.style.cssText = "padding:8px;border-bottom:1px solid #eee;font-size:0.9rem";
            let items = [];
            try { items = JSON.parse(h.items_json || "[]"); } catch(e) {}
            const filled = items.filter((x) => parseFloat(x.qty) > 0);
            d.innerHTML = `<strong>لیست یراق</strong> — ${h.list_date || ""} — ${h.personnel_name || ""} — ${filled.length} قلم`;
            hist.appendChild(d);
          });
        }
        if (usages.length) {
          // جدول مصرفی‌ها
          const tblWrap = document.createElement("div");
          tblWrap.style.cssText = "overflow-x:auto;margin-top:8px";
          let totalQty = 0;
          let totalCost = 0;
          let rowsHtml = "";
          usages.forEach((u) => {
            const q = parseFloat(u.qty) || 0;
            const kind = u.kind || "برداشت";
            const signed = (kind === "بازگشت") ? -q : q;
            totalQty += signed;
            // قیمت از کالا
            const stock = (S.stock_items || []).find((s) => s.item === u.item_name);
            const unitPrice = stock ? (parseFloat(stock.price) || 0) : 0;
            const lineCost = unitPrice * signed;
            totalCost += lineCost;
            rowsHtml += `<tr>
              <td>${u.used_at || "—"}</td>
              <td>${u.item_name || "—"}</td>
              <td>${kind}</td>
              <td>${u.qty || "0"} ${u.unit || (stock && stock.unit) || ""}</td>
              <td>${u.personnel_name || "—"}</td>
              <td>${u.prod_stage || "—"}</td>
              <td>${unitPrice ? unitPrice.toLocaleString("fa-IR") + " ریال" : "—"}</td>
              <td>${lineCost ? lineCost.toLocaleString("fa-IR") + " ریال" : "—"}</td>
            </tr>`;
          });
          tblWrap.innerHTML = `<table class="data-table" style="width:100%;border-collapse:collapse;font-size:0.9rem">
            <thead><tr style="background:#f1f5f9">
              <th style="padding:6px;border:1px solid #e2e8f0">تاریخ</th>
              <th style="padding:6px;border:1px solid #e2e8f0">نام کالا</th>
              <th style="padding:6px;border:1px solid #e2e8f0">نوع</th>
              <th style="padding:6px;border:1px solid #e2e8f0">تعداد</th>
              <th style="padding:6px;border:1px solid #e2e8f0">پرسنل</th>
              <th style="padding:6px;border:1px solid #e2e8f0">مرحله</th>
              <th style="padding:6px;border:1px solid #e2e8f0">قیمت واحد</th>
              <th style="padding:6px;border:1px solid #e2e8f0">مبلغ</th>
            </tr></thead>
            <tbody>${rowsHtml}</tbody>
            <tfoot><tr style="background:#fef3c7;font-weight:700">
              <td colspan="3" style="padding:8px;border:1px solid #e2e8f0">جمع کل مصرفی</td>
              <td style="padding:8px;border:1px solid #e2e8f0">${totalQty}</td>
              <td colspan="3" style="padding:8px;border:1px solid #e2e8f0"></td>
              <td style="padding:8px;border:1px solid #e2e8f0">${totalCost ? totalCost.toLocaleString("fa-IR") + " ریال" : "—"}</td>
            </tr></tfoot>
          </table>`;
          hist.appendChild(tblWrap);
        }
        prodCard.appendChild(hist);
      }
      root.appendChild(prodCard);
    }

        // مکاتبات مالی
    const msgs = (S.messages || []).filter((m) => (m.project || "") === (c.name || "") || (m.sender_name || "") === (c.name || ""));
    const msgCard = document.createElement("div");
    msgCard.className = "card";
    msgCard.innerHTML = "<h2>مکاتبات و تاریخچه مالی</h2>";
    if (!msgs.length) {
      msgCard.innerHTML += '<div class="empty">مکاتبه‌ای ثبت نشده.</div>';
    } else {
      const list = document.createElement("div");
      list.style.cssText = "display:flex;flex-direction:column;gap:8px";
      msgs.slice().reverse().forEach((m) => {
        const row = document.createElement("div");
        row.style.cssText = "padding:10px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc";
        row.innerHTML = `<strong>${m.sender_name || "—"}</strong>
          ${m.payment_type ? " — " + m.payment_type : ""}
          ${m.amount ? " — " + fmt(m.amount, "amount") : ""}
          <div>${m.body || ""}</div>
          <div class="hint">${(window.J && J.formatChatDate) ? J.formatChatDate(m.created_at) : (m.created_at || "")}${m.file_path ? ' — <a href="' + m.file_path + '" target="_blank">پیوست</a>' : ""}</div>`;
        list.appendChild(row);
      });
      msgCard.appendChild(list);
    }
    root.appendChild(msgCard);

    // فایل‌های طراحی
    const files = parseDesignFiles(c.design_files);
    const fc = document.createElement("div");
    fc.className = "card";
    fc.innerHTML = "<h2>فایل‌های طراحی</h2>";
    if (!files.length) fc.innerHTML += '<div class="empty">فایلی نیست</div>';
    else {
      files.forEach((u) => {
        const a = document.createElement("div");
        a.innerHTML = `<a href="${u}" target="_blank">${String(u).split("/").pop()}</a>`;
        fc.appendChild(a);
      });
    }
    root.appendChild(fc);
    root.appendChild(crudTable("customers", "ویرایش این مشتری", {
      filterFn: (r) => String(r.id) === String(id),
    }));
  }

  function renderSalaryPage(root) {
    const day = new Date().getDate();
    // لیست حقوق ماهانه
    const listCard = document.createElement("div");
    listCard.className = "card";
    listCard.innerHTML = "<h2>لیست حقوق پرسنل</h2><p class=\"hint\">مبلغ ماهانه و روز سررسید هر نفر. نزدیک سررسید با رنگ مشخص شده.</p>";
    const table = document.createElement("table");
    table.innerHTML = "<thead><tr><th>نام</th><th>نقش</th><th>حقوق ماهانه</th><th>روز سررسید</th><th>وضعیت این ماه</th></tr></thead>";
    const tb = document.createElement("tbody");
    const nowYm = new Date().getFullYear() + "-" + String(new Date().getMonth() + 1).padStart(2, "0");
    (S.personnel || []).forEach((p) => {
      const amt = parseFloat(p.salary_amount) || 0;
      if (amt <= 0 && !p.salary_day) return;
      const sd = parseInt(p.salary_day, 10) || 0;
      const paid = (S.salary_payments || []).some((s) =>
        s.personnel_name === p.name && String(s.pay_date || s.period || "").includes(String(new Date().getMonth() + 1))
      );
      const near = sd > 0 && Math.abs(sd - day) <= 3 && !paid;
      const tr = document.createElement("tr");
      if (near) tr.style.background = "#fff7ed";
      tr.innerHTML = `<td>${p.name || "—"}</td>
        <td>${fmt(p.role, "role")}</td>
        <td>${fmt(amt, "amount")}</td>
        <td>${sd || "—"}</td>
        <td>${paid ? "پرداخت‌شده" : (near ? "نزدیک سررسید" : "در انتظار")}</td>`;
      tb.appendChild(tr);
    });
    table.appendChild(tb);
    listCard.appendChild(table);
    root.appendChild(listCard);

    // ثبت پرداخت حقوق (فقط مدیر)
    if (POLICY.is_manager) {
      root.appendChild(crudTable("salary_payments", "ثبت / تاریخچه پرداخت حقوق", {
        // ویرایش غیرفعال — فقط افزودن و حذف
        noEdit: true,
      }));
    } else {
      root.appendChild(crudTable("salary_payments", "تاریخچه پرداخت حقوق", { noAdd: true, noEdit: true }));
    }
  }

  function personOnLeave(name) {
    const today = (window.J && J.todayJalali) ? J.todayJalali() : "";
    return (S.leave_requests || []).some((r) => {
      if ((r.personnel_name || "") !== name) return false;
      if (r.status !== "تأیید" && r.status !== "تأییدشده" && r.status !== "approved") return false;
      const from = r.from_date || "";
      const to = r.to_date || from;
      if (!today) return true;
      return today >= from && today <= to;
    });
  }

  function renderPersonnelPage(root) {
    if (window.__selectedPersonnelId) {
      renderPersonnelDetail(root, window.__selectedPersonnelId);
      return;
    }
    // خلاصه وضعیت مرخصی / حاضر
    const onLeaveList = (S.personnel || []).filter((p) => personOnLeave(p.name));
    const presentCnt = (S.personnel || []).length - onLeaveList.length;
    const statusCard = document.createElement("div");
    statusCard.className = "card";
    statusCard.innerHTML = `<h2>وضعیت حضور پرسنل</h2>
      <div class="stats" style="margin:0">
        <div class="stat"><b>${presentCnt}</b><span>حاضر</span></div>
        <div class="stat ${onLeaveList.length ? "stat-alert" : ""}"><b>${onLeaveList.length}</b><span>مرخصی</span></div>
      </div>
      <p class="hint" style="margin-top:8px">اگر پرسنل در مرخصی تأییدشده باشد، ردیف او در جدول زیر قرمز نمایش داده می‌شود. مدیریت مرخصی از منوی «مرخصی» انجام می‌شود.</p>`;
    root.appendChild(statusCard);

    const card = crudTable("personnel", "پرسنل");
    root.appendChild(card);
    // ستون وضعیت مرخصی/حاضر + پس‌زمینه قرمز
    card.querySelectorAll("tbody tr").forEach((tr) => {
      const idCell = tr.querySelector(".row-check");
      if (!idCell) return;
      const id = Number(idCell.value);
      const person = (S.personnel || []).find((x) => String(x.id) === String(id));
      const onLv = person && personOnLeave(person.name);
      if (onLv) {
        tr.classList.add("row-on-leave");
        tr.title = "در حال مرخصی";
        tr.style.background = "#fef2f2";
      }
      // افزودن نشان وضعیت در انتهای ردیف (قبل از عملیات)
      const actionsTd = tr.querySelector("td.actions");
      if (actionsTd) {
        const badge = document.createElement("span");
        badge.className = onLv ? "leave-badge leave-on" : "leave-badge leave-present";
        badge.textContent = onLv ? "مرخصی" : "حاضر";
        badge.style.cssText = onLv
          ? "display:inline-block;margin-left:6px;padding:2px 8px;border-radius:6px;background:#fee2e2;color:#b91c1c;font-size:.75rem;font-weight:600"
          : "display:inline-block;margin-left:6px;padding:2px 8px;border-radius:6px;background:#dcfce7;color:#166534;font-size:.75rem;font-weight:600";
        actionsTd.insertBefore(badge, actionsTd.firstChild);
      }
      tr.style.cursor = "pointer";
      tr.addEventListener("click", (e) => {
        if (e.target.closest("button, input, a")) return;
        window.__selectedPersonnelId = id;
        render();
      });
    });
  }

  function renderPersonnelDetail(root, id) {
    const p = (S.personnel || []).find((x) => String(x.id) === String(id));
    const back = document.createElement("button");
    back.type = "button";
    back.className = "btn btn-outline btn-sm";
    back.textContent = "← بازگشت به لیست پرسنل";
    back.onclick = () => { window.__selectedPersonnelId = null; render(); };
    root.appendChild(back);
    if (!p) {
      root.appendChild(Object.assign(document.createElement("div"), { className: "empty", textContent: "یافت نشد" }));
      return;
    }
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `<h2>${p.name || "—"}</h2>
      <p>نقش: ${fmt(p.role, "role")} — تلفن: ${fmt(p.phone)}</p>
      <p>حقوق ماهانه: <strong>${fmt(p.salary_amount, "amount")}</strong> — روز سررسید: <strong>${p.salary_day || "—"}</strong></p>
      <p>مانده مرخصی: ${fmt(p.leave_days)}</p>`;
    root.appendChild(card);

    // تاریخچه حقوق — فقط حذف، بدون ویرایش
    root.appendChild(crudTable("salary_payments", "تاریخچه پرداخت حقوق این فرد", {
      filterFn: (r) => r.personnel_name === p.name,
      noEdit: true,
      noAdd: !POLICY.is_manager,
    }));
    root.appendChild(crudTable("personnel", "ویرایش مشخصات", {
      filterFn: (r) => String(r.id) === String(id),
    }));
  }

  function renderCustomerView(root, which) {
    const me = (S.customers || [])[0];
    const card = document.createElement("div");
    card.className = "card";
    if (!me) {
      card.innerHTML = '<div class="empty">اطلاعات پروژه شما هنوز ثبت نشده است.</div>';
      root.appendChild(card);
      return;
    }
    let st = me.status || "مشتریان جدید";
    if (CUSTOMER_STATUS_MAP[st]) st = CUSTOMER_STATUS_MAP[st];
    if (which === "cust_finance") {
      card.innerHTML = `<h2>وضعیت مالی من</h2>
        <p>مبلغ پروژه: <strong>${fmt(me.project_amount, "project_amount")}</strong></p>
        <p>مانده حساب: <strong>${fmt(me.balance, "balance")}</strong></p>
        <p>وضعیت پروژه: <strong>${st}</strong></p>
        <p class="hint">فقط مشاهده — امکان ویرایش یا حذف ندارید. برای مکاتبه مالی از فرم زیر استفاده کنید.</p>`;
      root.appendChild(card);

      // تاریخچه مکاتبات مالی این مشتری
      const myMsgs = (S.messages || []).filter((m) => {
        const proj = (m.project || "").trim();
        const sn = (m.sender_name || "").trim();
        return proj === (me.name || "") || sn === (me.name || "") || sn === (USER.name || "");
      });
      const hist = document.createElement("div");
      hist.className = "card";
      hist.innerHTML = "<h2>تاریخچه مالی / مکاتبات</h2>";
      if (!myMsgs.length) {
        hist.innerHTML += '<div class="empty">هنوز مکاتبه‌ای ثبت نشده.</div>';
      } else {
        const list = document.createElement("div");
        list.style.cssText = "display:flex;flex-direction:column;gap:10px";
        myMsgs.slice().reverse().forEach((m) => {
          const row = document.createElement("div");
          row.style.cssText = "padding:12px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc";
          const pay = m.payment_type ? ` — پرداخت: ${m.payment_type}` : "";
          const amt = m.amount ? ` — مبلغ: ${fmt(m.amount, "amount")}` : "";
          const file = m.file_path ? ` <a href="${m.file_path}" target="_blank">پیوست</a>` : "";
          row.innerHTML = `<div><strong>${m.sender_name || "—"}</strong>${pay}${amt}</div>
            <div style="margin-top:6px">${m.body || "—"}</div>
            <div class="hint" style="margin-top:6px">${(window.J && J.formatChatDate) ? J.formatChatDate(m.created_at) : (m.created_at || "")}${file}</div>`;
          list.appendChild(row);
        });
        hist.appendChild(list);
      }
      root.appendChild(hist);

      // فرم مکاتبه — فقط ارسال
      const formCard = document.createElement("div");
      formCard.className = "card";
      formCard.innerHTML = "<h2>ارسال مکاتبه مالی</h2><p class=\"hint\">متن، فایل و نوع پرداخت را مشخص کنید؛ برای مدیر ارسال می‌شود.</p>";
      const f = document.createElement("div");
      f.innerHTML = `
        <div class="field"><label>نوع پرداخت</label>
          <select id="cm-pay"><option value="نقدی">نقدی</option><option value="چک">چک</option><option value="سایر">سایر</option></select>
        </div>
        <div class="field"><label>مبلغ (اختیاری)</label><input id="cm-amt" type="text" placeholder="مثلا 1500000"></div>
        <div class="field"><label>توضیحات</label><textarea id="cm-body" style="min-height:80px;width:100%" placeholder="شرح مکاتبه یا پرداخت..."></textarea></div>
        <div class="field"><label>فایل پیوست</label><input id="cm-file" type="file"></div>
        <button type="button" class="btn" id="cm-send">ارسال مکاتبه</button>`;
      formCard.appendChild(f);
      formCard.querySelector("#cm-send").onclick = async () => {
        const body = (document.getElementById("cm-body").value || "").trim();
        if (!body) { alert("توضیحات را بنویسید"); return; }
        let file_path = "";
        const fi = document.getElementById("cm-file");
        if (fi.files && fi.files[0]) {
          const fd = new FormData();
          fd.append("action", "upload");
          fd.append("_wpnonce", CSRF);
          fd.append("instance", String(INSTANCE_ID));
          fd.append("file", fi.files[0]);
          fd.append("table", "photos");
          fd.append("payload", JSON.stringify({ project: me.name || "", stage: "finance", caption: "مکاتبه مشتری" }));
          const up = await fetch(API + (API.includes("?") ? "&" : "?") + "action=upload", { method: "POST", body: fd, credentials: "same-origin" }).then((r) => r.json());
          if (up.ok && up.data) file_path = up.data.url || (window.UPLOADS + (up.data.filename || ""));
          else { alert(up.error || "خطا در آپلود"); return; }
        }
        const payload = {
          sender_role: "customer",
          sender_name: me.name || USER.name || "",
          recipient_role: "management",
          recipient_name: "مدیر",
          body,
          msg_type: "finance",
          payment_type: document.getElementById("cm-pay").value,
          amount: String(document.getElementById("cm-amt").value || "").replace(/[,،\s]/g, ""),
          file_path,
          project: me.name || "",
        };
        const res = await api("save", { table: "messages", payload });
        if (!res.ok) { alert(res.error || "خطا"); return; }
        alert("مکاتبه ارسال شد");
        await reload();
        render();
      };
      root.appendChild(formCard);

      // ثبت چک توسط مشتری → چک دریافتنی در انتظار
      const chkCard = document.createElement("div");
      chkCard.className = "card";
      chkCard.innerHTML = `<h2>ثبت چک / خرید دین</h2>
        <p class="hint">پس از ارسال، در بخش چک‌های دریافتنی مدیر با وضعیت «در انتظار» ثبت می‌شود تا تأیید یا رد شود.</p>
        <div class="field"><label>نوع</label>
          <select id="ck-kind"><option value="check">چک</option><option value="خرید دین">خرید دین</option></select>
        </div>
        <div class="field"><label>شماره صیادی</label><input id="ck-num" placeholder="شماره صیاد"></div>
        <div class="field"><label>مبلغ</label><input id="ck-amt" placeholder="مبلغ"></div>
        <div class="field"><label>تاریخ سررسید</label><input id="ck-date" placeholder="1403/01/01"></div>
        <div class="field"><label>توضیحات</label><textarea id="ck-note" style="min-height:60px;width:100%"></textarea></div>
        <div class="field"><label>تصویر / فایل چک</label><input type="file" id="ck-file" accept="image/*,.pdf"></div>
        <button type="button" class="btn" id="ck-send">ثبت چک</button>`;
      root.appendChild(chkCard);
      chkCard.querySelector("#ck-send").onclick = async () => {
        const num = (document.getElementById("ck-num").value || "").trim();
        const amount = String(document.getElementById("ck-amt").value || "").replace(/[,،\s]/g, "");
        if (!amount) { alert("مبلغ را وارد کنید"); return; }
        let photo = "";
        const fi = document.getElementById("ck-file");
        if (fi.files && fi.files[0]) {
          const fd = new FormData();
          fd.append("action", "upload"); fd.append("_wpnonce", CSRF);
          fd.append("instance", String(INSTANCE_ID)); fd.append("file", fi.files[0]);
          fd.append("table", "photos");
          fd.append("payload", JSON.stringify({ project: me.name || "", stage: "check", caption: "چک مشتری" }));
          const up = await fetch(API + (API.includes("?") ? "&" : "?") + "action=upload", { method: "POST", body: fd, credentials: "same-origin" }).then((r) => r.json());
          if (up.ok && up.data) photo = up.data.url || (window.UPLOADS + (up.data.filename || ""));
          else { alert(up.error || "خطا در آپلود"); return; }
        }
        const payload = {
          name: me.name || USER.name || "",
          num,
          amount,
          check_date: document.getElementById("ck-date").value || "",
          note: document.getElementById("ck-note").value || "",
          kind: document.getElementById("ck-kind").value || "check",
          photo,
          approval: "pending",
          for_what: "ثبت توسط مشتری",
        };
        const res = await api("save", { table: "checks_received", payload });
        if (!res.ok) { alert(res.error || "خطا"); return; }
        alert("چک با وضعیت در انتظار ثبت شد");
        await reload(); render();
      };
      return;
    }

    // خانه / پروژه
    card.innerHTML = `<h2>سلام ${me.name || USER.name || ""}</h2>
      <p>وضعیت پروژه: <strong>${st}</strong></p>
      <p>تلفن: ${fmt(me.phone)}</p>
      <p>آدرس: ${fmt(me.address)}</p>
      <p class="hint">امکان ویرایش یا حذف ندارید. فایل‌های طراحی و دستورات مربوط به شما در زیر آمده است.</p>`;
    root.appendChild(card);

    // مکاتبه با نصاب معرفی‌شده
    if (me.installer) {
      const msgC = document.createElement("div");
      msgC.className = "card";
      msgC.innerHTML = `<h2>مکاتبه با نصاب: ${me.installer}</h2>
        <div class="field"><label>متن</label><textarea id="ci-body" style="min-height:70px;width:100%"></textarea></div>
        <div class="field"><label>فایل</label><input type="file" id="ci-file"></div>
        <button type="button" class="btn" id="ci-send">ارسال به نصاب</button>`;
      root.appendChild(msgC);
      msgC.querySelector("#ci-send").onclick = async () => {
        const body = (document.getElementById("ci-body").value || "").trim();
        if (!body) { alert("متن را بنویسید"); return; }
        let file_path = "";
        const fi = document.getElementById("ci-file");
        if (fi.files && fi.files[0]) {
          const fd = new FormData();
          fd.append("action", "upload"); fd.append("_wpnonce", CSRF);
          fd.append("instance", String(INSTANCE_ID)); fd.append("file", fi.files[0]);
          fd.append("table", "photos");
          fd.append("payload", JSON.stringify({ project: me.name || "", stage: "message", caption: "مکاتبه مشتری-نصاب" }));
          const up = await fetch(API + (API.includes("?") ? "&" : "?") + "action=upload", { method: "POST", body: fd, credentials: "same-origin" }).then((r) => r.json());
          if (up.ok && up.data) file_path = up.data.url || (window.UPLOADS + (up.data.filename || ""));
        }
        const payload = {
          sender_role: "customer",
          sender_name: me.name || USER.name || "",
          recipient_name: me.installer,
          recipient_role: "employee",
          body, msg_type: "project", file_path, project: me.name || "",
        };
        const res = await api("save", { table: "messages", payload });
        if (!res.ok) { alert(res.error || "خطا"); return; }
        alert("ارسال شد"); await reload(); render();
      };
    }

    const files = parseDesignFiles(me.design_files);
    const fileCard = document.createElement("div");
    fileCard.className = "card";
    fileCard.innerHTML = "<h2>فایل‌های طراحی</h2>";
    if (!files.length) {
      fileCard.innerHTML += '<div class="empty">هنوز فایل طراحی ثبت نشده است.</div>';
    } else {
      const ul = document.createElement("div");
      ul.style.cssText = "display:flex;flex-direction:column;gap:10px";
      files.forEach((u, idx) => {
        const name = String(u).split("/").pop() || ("فایل " + (idx + 1));
        const row = document.createElement("div");
        row.style.cssText = "display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px;border:1px solid #e2e8f0;border-radius:10px;background:#f8fafc";
        row.innerHTML = `<span>📎 ${name}</span>
          <a class="btn btn-sm" href="${u}" target="_blank" rel="noopener" download>دانلود / مشاهده</a>`;
        ul.appendChild(row);
      });
      fileCard.appendChild(ul);
    }
    root.appendChild(fileCard);

    if ((S.directives || []).length) {
      root.appendChild(crudTable("directives", "پیام‌ها / دستورات مربوط به شما", { noAdd: true }));
    }
  }



  function openProdForm(customer, stageKey) {
    if (stageKey === "لیست یراق") {
      openHardwareListForm(customer);
      return;
    }
    // فرم عمومی مراحل تولید
    const modal = document.getElementById("modal");
    const form = document.getElementById("modal-form");
    const title = document.getElementById("modal-title");
    if (!modal || !form) { alert("مودال یافت نشد"); return; }
    title.textContent = "ثبت " + stageKey + " — " + (customer.name || "");
    form.innerHTML = "";
    editTable = "stock_usage";
    editId = 0;

    const fields = [
      { name: "item_name", label: "نام کالا / نوع", type: "combo" },
      { name: "qty", label: "تعداد / مقدار", type: "text" },
      { name: "unit", label: "واحد", type: "text" },
      { name: "notes", label: "توضیحات", type: "textarea" },
    ];
    if (stageKey === "سی‌ان‌سی") {
      fields.push({ name: "transfer_to", label: "انتقال بعد از اتمام به", type: "select", opts: ["برش", "رنگ", "روکش"] });
    }
    if (stageKey === "نوارکاری") {
      fields[0].label = "نوع نوار";
      fields[1].label = "متراژ نوار مصرفی";
      fields[2].label = "واحد (متر)";
    }

    fields.forEach((f) => {
      const wrap = document.createElement("div");
      wrap.className = "field";
      const lab = document.createElement("label");
      lab.textContent = f.label;
      wrap.appendChild(lab);
      if (f.type === "combo") {
        const stockNames = (S.stock_items || []).map((s) => s.item).filter(Boolean);
        const combo = createCombo("item_name", stockNames, "", false);
        wrap.appendChild(combo);
      } else if (f.type === "select") {
        const sel = document.createElement("select");
        sel.name = f.name;
        (f.opts || []).forEach((o) => {
          const opt = document.createElement("option");
          opt.value = o; opt.textContent = o;
          sel.appendChild(opt);
        });
        wrap.appendChild(sel);
      } else if (f.type === "textarea") {
        const ta = document.createElement("textarea");
        ta.name = f.name;
        wrap.appendChild(ta);
      } else {
        const inp = document.createElement("input");
        inp.name = f.name;
        inp.type = "text";
        if (f.name === "unit" && stageKey === "نوارکاری") inp.value = "متر";
        wrap.appendChild(inp);
      }
      form.appendChild(wrap);
    });

    // hidden fields
    const h1 = document.createElement("input");
    h1.type = "hidden"; h1.name = "project"; h1.value = customer.name || "";
    form.appendChild(h1);
    const h2 = document.createElement("input");
    h2.type = "hidden"; h2.name = "prod_stage"; h2.value = stageKey;
    form.appendChild(h2);
    const h3 = document.createElement("input");
    h3.type = "hidden"; h3.name = "kind"; h3.value = "برداشت";
    form.appendChild(h3);
    const h4 = document.createElement("input");
    h4.type = "hidden"; h4.name = "personnel_name"; h4.value = (USER && USER.name) || "";
    form.appendChild(h4);
    const h5 = document.createElement("input");
    h5.type = "hidden"; h5.name = "used_at"; h5.value = (window.J && J.todayStr) ? J.todayStr() : "";
    form.appendChild(h5);
    const h6 = document.createElement("input");
    h6.type = "hidden"; h6.name = "status"; h6.value = "تأییدشده";
    form.appendChild(h6);

    modal.classList.add("open");
    modal.style.display = "flex";
  }

  function openHardwareListForm(customer) {
    const modal = document.getElementById("modal");
    const form = document.getElementById("modal-form");
    const title = document.getElementById("modal-title");
    if (!modal || !form) return;
    title.textContent = "لیست یراق — " + (customer.name || "");
    form.innerHTML = "";
    editTable = "hardware_lists";
    editId = 0;

    const info = document.createElement("div");
    info.className = "hint";
    info.textContent = "جناب آقای / خانم: " + (customer.name || "") + " — تاریخ: " + ((window.J && J.todayStr) ? J.todayStr() : "");
    form.appendChild(info);

    const table = document.createElement("table");
    table.style.cssText = "width:100%;font-size:0.88rem;border-collapse:collapse";
    table.innerHTML = "<thead><tr><th style='text-align:right'>شرح</th><th style='width:90px'>تعداد</th></tr></thead>";
    const tb = document.createElement("tbody");
    let rowIdx = 0;
    HARDWARE_TEMPLATE.forEach((cat) => {
      const hr = document.createElement("tr");
      hr.innerHTML = `<td colspan="2" style="background:#f1f5f9;font-weight:700;padding:6px">${cat.cat}</td>`;
      tb.appendChild(hr);
      cat.items.forEach((itemName) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `<td style="padding:4px 6px;border-bottom:1px solid #eee">${itemName}</td>`;
        const td = document.createElement("td");
        const inp = document.createElement("input");
        inp.type = "number";
        inp.min = "0";
        inp.step = "1";
        inp.name = "hw_qty_" + rowIdx;
        inp.dataset.item = itemName;
        inp.style.cssText = "width:80px;padding:4px;border:1px solid #ddd;border-radius:6px";
        td.appendChild(inp);
        tr.appendChild(td);
        tb.appendChild(tr);
        rowIdx++;
      });
    });
    table.appendChild(tb);
    form.appendChild(table);

    const notesW = document.createElement("div");
    notesW.className = "field";
    notesW.innerHTML = "<label>توضیحات</label>";
    const notes = document.createElement("textarea");
    notes.name = "notes";
    notesW.appendChild(notes);
    form.appendChild(notesW);

    // دکمه ذخیره اختصاصی یراق داخل فرم
    const hwSave = document.createElement("button");
    hwSave.type = "button";
    hwSave.className = "btn";
    hwSave.textContent = "ذخیره لیست یراق";
    hwSave.style.marginTop = "12px";
    hwSave.onclick = async () => {
      const items = [];
      form.querySelectorAll("input[data-item]").forEach((inp) => {
        const q = parseFloat(inp.value) || 0;
        if (q > 0) items.push({ name: inp.dataset.item, qty: q });
      });
      if (!items.length) { alert("حداقل تعداد یک قلم را وارد کنید"); return; }
      const payload = {
        customer_name: customer.name || "",
        list_date: (window.J && J.todayStr) ? J.todayStr() : "",
        items_json: JSON.stringify(items),
        personnel_name: (USER && USER.name) || "",
        notes: (form.querySelector("[name=notes]") || {}).value || "",
        status: "ثبت‌شده",
      };
      const res = await api("save", { table: "hardware_lists", payload });
      if (res && res.ok) {
        for (const it of items) {
          await api("save", { table: "stock_usage", payload: {
            project: customer.name || "",
            item_name: it.name,
            qty: String(it.qty),
            kind: "برداشت",
            prod_stage: "لیست یراق",
            personnel_name: (USER && USER.name) || "",
            used_at: payload.list_date,
            status: "تأییدشده",
            notes: "از لیست یراق",
          }});
        }
        closeModal();
        await reload();
        window.__selectedCustomerId = customer.id;
        render();
      } else {
        alert((res && res.error) || "خطا در ذخیره لیست یراق");
      }
    };
    form.appendChild(hwSave);

    modal.classList.add("open");
    modal.style.display = "flex";
  }

  function renderInvoicesPage(root) {
    if (!(POLICY.is_manager || POLICY.role === "warehouse")) {
      root.appendChild(Object.assign(document.createElement("div"), { className: "empty", textContent: "فقط مدیر و حسابدار به نرخ‌نامه و صدور فاکتور دسترسی دارند." }));
      return;
    }
    // نرخ‌ها از settings یا پیش‌فرض
    let rates = DEFAULT_INVOICE_RATES;
    try {
      if (S.settings && S.settings.invoice_rates) {
        const saved = typeof S.settings.invoice_rates === "string" ? JSON.parse(S.settings.invoice_rates) : S.settings.invoice_rates;
        if (saved && typeof saved === "object") rates = Object.assign({}, DEFAULT_INVOICE_RATES, saved);
      }
    } catch (e) {}

    const head = document.createElement("div");
    head.className = "card";
    head.innerHTML = `<h2>صدور فاکتور و نرخ‌نامه</h2>
      <p class="hint">قیمت‌ها فقط برای مدیر و حسابدار قابل مشاهده و ویرایش است. صدور فاکتور از انبار کم نمی‌کند و فقط مبلغ ثبت می‌شود.</p>`;
    root.appendChild(head);

    function moneyFa(n) { return Number(n || 0).toLocaleString("fa-IR"); }

    function renderRateTable(title, desc, key, list, btnLabel) {
      const box = document.createElement("div");
      box.className = "card";
      box.innerHTML = `<h3>${title}</h3><p class="hint">${desc}</p>`;
      const tbl = document.createElement("table");
      tbl.style.cssText = "width:100%;font-size:0.88rem;border-collapse:collapse";
      tbl.innerHTML = "<thead><tr><th style='text-align:right'>شرح</th><th style='width:160px'>قیمت (ریال)</th></tr></thead>";
      const tb = document.createElement("tbody");
      (list || []).forEach((r, i) => {
        const tr = document.createElement("tr");
        const tdN = document.createElement("td");
        tdN.style.cssText = "padding:6px;border-bottom:1px solid #eee";
        tdN.textContent = r.name;
        const tdP = document.createElement("td");
        tdP.style.cssText = "padding:6px;border-bottom:1px solid #eee";
        const inp = document.createElement("input");
        inp.type = "text";
        inp.value = r.price;
        inp.dataset.rateKey = key;
        inp.dataset.rateIdx = String(i);
        inp.style.cssText = "width:140px;padding:4px 6px;border:1px solid #ddd;border-radius:6px;font-family:inherit;direction:ltr";
        tdP.appendChild(inp);
        tr.appendChild(tdN);
        tr.appendChild(tdP);
        tb.appendChild(tr);
      });
      tbl.appendChild(tb);
      box.appendChild(tbl);
      const actions = document.createElement("div");
      actions.style.cssText = "display:flex;flex-wrap:wrap;gap:8px;margin-top:12px";
      const saveBtn = document.createElement("button");
      saveBtn.type = "button";
      saveBtn.className = "btn btn-sm btn-outline";
      saveBtn.textContent = "ذخیره نرخ‌های این بخش";
      saveBtn.onclick = async () => {
        const inputs = box.querySelectorAll("input[data-rate-key]");
        const updated = (list || []).map((r, i) => {
          const inp = box.querySelector(`input[data-rate-idx="${i}"]`);
          const p = parseInt(String(inp ? inp.value : r.price).replace(/[^\d]/g, ""), 10) || 0;
          return { name: r.name, price: p };
        });
        rates[key] = updated;
        const allRates = {
          partner: rates.partner || DEFAULT_INVOICE_RATES.partner,
          customer_cabinet: rates.customer_cabinet || DEFAULT_INVOICE_RATES.customer_cabinet,
          customer_closet: rates.customer_closet || DEFAULT_INVOICE_RATES.customer_closet,
        };
        const res = await api("save", { table: "settings", payload: { invoice_rates: JSON.stringify(allRates) } });
        // settings may not be a normal table - try settings endpoint or save via full settings
        if (!res || !res.ok) {
          // fallback: save into S.settings via api settings if available
          try {
            const res2 = await api("settings", { payload: { invoice_rates: JSON.stringify(allRates) } });
            if (res2 && res2.ok) { alert("نرخ‌ها ذخیره شد"); if (!S.settings) S.settings = {}; S.settings.invoice_rates = JSON.stringify(allRates); return; }
          } catch (e) {}
          // store in local for session
          if (!S.settings) S.settings = {};
          S.settings.invoice_rates = JSON.stringify(allRates);
          alert("نرخ‌ها در این نشست ذخیره شد (برای ماندگاری از بکاپ JSON استفاده کنید).");
        } else {
          alert("نرخ‌ها ذخیره شد");
          if (!S.settings) S.settings = {};
          S.settings.invoice_rates = JSON.stringify(allRates);
        }
      };
      const issueBtn = document.createElement("button");
      issueBtn.type = "button";
      issueBtn.className = "btn btn-sm";
      issueBtn.textContent = btnLabel;
      issueBtn.onclick = () => {
        const cust = prompt("نام مشتری / طرف حساب:");
        if (!cust) return;
        const items = [];
        (list || []).forEach((r) => {
          if (confirm("افزودن «" + r.name + "» به فاکتور؟\nقیمت: " + moneyFa(r.price) + " ریال")) {
            items.push(r);
          }
        });
        if (!items.length) { alert("هیچ قلمی انتخاب نشد"); return; }
        const total = items.reduce((s, x) => s + (x.price || 0), 0);
        alert("فاکتور برای «" + cust + "»\n\n" + items.map(x => x.name + ": " + moneyFa(x.price)).join("\n") + "\n\nجمع: " + moneyFa(total) + " ریال\n\n(ثبت نهایی در نسخه بعدی به بدهکاران متصل می‌شود)");
      };
      actions.appendChild(saveBtn);
      actions.appendChild(issueBtn);
      box.appendChild(actions);
      root.appendChild(box);
    }

    renderRateTable("فاکتور مشتری — کابینت", "کابینت زمینی و دیواری. صدور فاکتور از انبار کم نمی‌کند.", "customer_cabinet", rates.customer_cabinet || DEFAULT_INVOICE_RATES.customer_cabinet, "صدور فاکتور مشتری");
    renderRateTable("فاکتور مشتری — کمد", "انواع کمد.", "customer_closet", rates.customer_closet || DEFAULT_INVOICE_RATES.customer_closet, "صدور فاکتور کمد");
    renderRateTable("فاکتور خدمات همکار", "برش، نوار، CNC، مونتاژ، نصب، روکش و رنگ.", "partner", rates.partner || DEFAULT_INVOICE_RATES.partner, "صدور فاکتور همکار");

    // پیش‌فاکتور
    const est = document.createElement("div");
    est.className = "card";
    est.innerHTML = `<h3>پیش‌فاکتور / برآورد</h3><p class="hint">اندازه‌ها و متراژها تا تأیید نهایی مدیریت.</p>`;
    const estBtn = document.createElement("button");
    estBtn.type = "button";
    estBtn.className = "btn";
    estBtn.textContent = "ایجاد پیش‌فاکتور";
    estBtn.onclick = () => {
      const name = prompt("نام مشتری:");
      if (!name) return;
      const note = prompt("توضیحات / متراژها:", "");
      alert("پیش‌فاکتور برای «" + name + "» ثبت پیش‌نویس شد.\n" + (note || ""));
    };
    est.appendChild(estBtn);
    root.appendChild(est);
  }


  function renderSettings(root) {
    const st = S.settings || {};

    // —— تنظیمات شخصی کاربر (تم، فونت، راهنما) ——
    const prefCard = document.createElement("div");
    prefCard.className = "card";
    const prefH = document.createElement("h2");
    prefH.innerHTML = "<span>تنظیمات شخصی من</span>";
    attachHelpQ(prefH, "settings", "این تنظیمات فقط برای شما ذخیره می‌شود و با پاک شدن کش مرورگر هم با کلید اختصاصی‌تان می‌ماند.");
    prefCard.appendChild(prefH);
    const hintP = document.createElement("p");
    hintP.className = "hint";
    hintP.textContent = "تم، فونت و حالت راهنما فقط مال شماست و در مرورگر ذخیره می‌ماند.";
    prefCard.appendChild(hintP);
    const grid = document.createElement("div");
    grid.className = "prefs-grid";

    // تم
    const themeBox = document.createElement("div");
    themeBox.className = "pref-card";
    themeBox.innerHTML = `<label>پوسته ظاهر</label>
      <select id="pref-theme">
        <option value="light">☀️ روشن (پیش‌فرض)</option>
        <option value="dark">🌙 تیره</option>
      </select>
      <p class="hint" style="margin-top:6px">ظاهر یکپارچه با پنل مدیریت فروشگاه — فقط روشن و تیره.</p>`;
    grid.appendChild(themeBox);

    // فونت
    const fontBox = document.createElement("div");
    fontBox.className = "pref-card";
    fontBox.innerHTML = `<label>فونت</label>
      <select id="pref-font">
        <option value="zar">بی‌زر (کلاسیک)</option>
        <option value="vazir">وزیرمتن</option>
        <option value="nazanin">نازنین</option>
        <option value="tahoma">تاهوما</option>
        <option value="system">سیستم</option>
      </select>`;
    grid.appendChild(fontBox);

    // اندازه
    const sizeBox = document.createElement("div");
    sizeBox.className = "pref-card";
    sizeBox.innerHTML = `<label>اندازه فونت: <span id="pref-size-val">${PREFS.fontSize || 15}</span>px</label>
      <input type="range" id="pref-size" min="12" max="20" step="1" value="${PREFS.fontSize || 15}">`;
    grid.appendChild(sizeBox);

    // راهنما
    const helpBox = document.createElement("div");
    helpBox.className = "pref-card";
    helpBox.innerHTML = `<label>حالت علامت‌سؤال کنار بخش‌ها</label>
      <button type="button" class="btn btn-sm ${PREFS.helpMode ? "" : "btn-outline"}" id="pref-help">${PREFS.helpMode ? "فعال — کلیک برای خاموش" : "خاموش — کلیک برای روشن"}</button>`;
    grid.appendChild(helpBox);

    // نوتیف
    const notifBox = document.createElement("div");
    notifBox.className = "pref-card";
    notifBox.innerHTML = `<label>نوتیفیکیشن سیستمی</label>
      <button type="button" class="btn btn-sm btn-outline" id="pref-notif">درخواست مجوز نوتیف گوشی / سیستم</button>`;
    grid.appendChild(notifBox);

    // ناوبری پایین موبایل (۵ آیتم — قابل تنظیم)
    if (POLICY.is_manager || POLICY.is_employee || POLICY.role === "employee") {
      const bnBox = document.createElement("div");
      bnBox.className = "pref-card";
      bnBox.style.gridColumn = "1 / -1";
      const opts = [
        ["dashboard", "داشبورد"],
        ["persons_group", "اشخاص"],
        ["directives", "دستورات"],
        ["accounting_group", "حسابداری"],
        ["attendance_group", "حضور و غیاب"],
        ["settings", "تنظیمات"],
        ["warehouse", "انبار"],
        ["finance", "حسابداری (پول)"],
        ["customers", "مشتریان"],
        ["personnel", "پرسنل"],
        ["emp_dashboard", "خانه من"],
        ["emp_tasks", "کارهای من"],
        ["emp_attendance", "ورود/خروج"],
        ["emp_messages", "مکاتبات"],
        ["emp_leave", "مرخصی"],
      ];
      const cur = getBottomNavItems();
      let html = "<label>ناوبری پایین موبایل (حداکثر ۵ مورد — سیاه و سفید)</label><div style=\"display:flex;flex-wrap:wrap;gap:8px;margin-top:8px\">";
      for (let i = 0; i < 5; i++) {
        html += `<select data-bn-slot="${i}" class="bn-slot" style="min-width:120px">`;
        html += `<option value="">— خالی —</option>`;
        opts.forEach(([v, l]) => {
          html += `<option value="${v}" ${cur[i] === v ? "selected" : ""}>${l}</option>`;
        });
        html += "</select>";
      }
      html += "</div><p class=\"hint\" style=\"margin-top:6px\">روی گوشی فقط همین ۵ میانبر پایین صفحه دیده می‌شود.</p>";
      bnBox.innerHTML = html;
      grid.appendChild(bnBox);
    }

    prefCard.appendChild(grid);
    root.appendChild(prefCard);

    // bind prefs
    setTimeout(() => {
      document.querySelectorAll(".bn-slot").forEach((sel) => {
        sel.onchange = () => {
          const slots = Array.from(document.querySelectorAll(".bn-slot")).map((s) => s.value).filter(Boolean);
          PREFS.bottomNav = slots.slice(0, 5);
          savePrefs(PREFS);
          renderBottomNav();
        };
      });
      const th = document.getElementById("pref-theme");
      if (th) { th.value = PREFS.theme === "dark" ? "dark" : "light"; th.onchange = () => { applyTheme(th.value); }; }
      const ff = document.getElementById("pref-font");
      if (ff) { ff.value = PREFS.fontFamily || "zar"; ff.onchange = () => { PREFS.fontFamily = ff.value; savePrefs(PREFS); applyPrefs(); }; }
      const sz = document.getElementById("pref-size");
      const szv = document.getElementById("pref-size-val");
      if (sz) {
        sz.oninput = () => {
          PREFS.fontSize = Number(sz.value);
          if (szv) szv.textContent = sz.value;
          savePrefs(PREFS);
          applyPrefs();
        };
      }
      const hb = document.getElementById("pref-help");
      if (hb) hb.onclick = () => { toggleHelpMode(); render(); };
      const nb = document.getElementById("pref-notif");
      if (nb) nb.onclick = async () => {
        const ok = await requestNotifPermission();
        showToast(ok ? "مجوز داده شد" : "مجوز رد شد یا پشتیبانی نمی‌شود", ok ? "نوتیف‌های سررسید چک در گوشی/سیستم نمایش داده می‌شود" : "می‌توانید از تنظیمات مرورگر مجوز بدهید", ok ? "ok" : "warn");
      };
    }, 0);

    const card = document.createElement("div");
    card.className = "card";
    const h2s = document.createElement("h2");
    h2s.innerHTML = "<span>تنظیمات این پنل</span>";
    attachHelpQ(h2s, "settings");
    card.appendChild(h2s);
    const form = document.createElement("form");
    [
      ["company_name", "نام کارگاه / پروژه"],
      ["panel_slug", "آدرس پنل (اسلاگ انگلیسی)"],
      ["currency", "واحد پول"],
      ["report_fine", "مبلغ جریمه پیش‌فرض"],
      ["warning_count", "تعداد هشدار قبل از جریمه"],
      ["min_stock_alert", "حداقل موجودی هشدار"],
      ["max_monthly_leave", "شارژ ماهانه مرخصی (روز — پیش‌فرض ۲.۵)"],
      ["standard_hours", "ساعت کار استاندارد روز"],
      ["allow_peer_chat", "اجازه چت بین پرسنل بدون مدیر (1=بله / 0=خیر)"],
    ].forEach(([k, label]) => {
      const div = document.createElement("div");
      div.className = "field";
      div.style.marginBottom = "10px";
      div.innerHTML = `<label>${label}</label><input name="${k}" value="${st[k] != null ? st[k] : ""}">`;
      form.appendChild(div);
    });
    const logoDiv = document.createElement("div");
    logoDiv.className = "field";
    logoDiv.innerHTML = `<label>لوگو</label>`;
    if (st.logo) {
      const img = document.createElement("img");
      img.src = st.logo;
      img.className = "logo-preview";
      logoDiv.appendChild(img);
    }
    const file = document.createElement("input");
    file.type = "file";
    file.accept = "image/*";
    logoDiv.appendChild(file);
    form.appendChild(logoDiv);

    // تلفن مدیر / کارگاه
    const phoneTitle = document.createElement("h3");
    phoneTitle.style.cssText = "margin:18px 0 8px;font-size:1rem";
    phoneTitle.textContent = "تماس کارگاه";
    form.appendChild(phoneTitle);
    const phoneDiv = document.createElement("div");
    phoneDiv.className = "field";
    phoneDiv.innerHTML = `<label>شماره تماس مدیر / کارگاه (صفحه ورود)</label><input name="company_phone" value="${st.company_phone != null ? st.company_phone : ""}" placeholder="0912...">`;
    form.appendChild(phoneDiv);

    // شبکه‌های اجتماعی
    const socialTitle = document.createElement("h3");
    socialTitle.style.cssText = "margin:18px 0 8px;font-size:1rem";
    socialTitle.textContent = "اطلاعات شبکه اجتماعی مجموعه";
    form.appendChild(socialTitle);
    const socialHint = document.createElement("p");
    socialHint.className = "hint";
    socialHint.textContent = "این لینک‌ها در فوتر پنل و صفحه ورود نمایش داده می‌شوند.";
    form.appendChild(socialHint);
    [
      ["social_instagram", "اینستاگرام (لینک کامل)"],
      ["social_telegram", "تلگرام (لینک کامل)"],
      ["social_whatsapp", "واتساپ (لینک یا شماره)"],
      ["social_linkedin", "لینکدین"],
      ["social_aparat", "آپارات"],
      ["social_website", "وب‌سایت"],
      ["cameras_url", "لینک پخش زنده دوربین‌ها"],
      ["neshan_api_key", "کلید API نقشه نشان (وب)"],
    ].forEach(([k, label]) => {
      const div = document.createElement("div");
      div.className = "field";
      div.style.marginBottom = "10px";
      div.innerHTML = `<label>${label}</label><input name="${k}" value="${st[k] != null ? st[k] : ""}" placeholder="https://...">`;
      form.appendChild(div);
    });

    const hint = document.createElement("div");
    hint.className = "hint";
    hint.textContent = "اگر آدرس پنل را عوض کردید، بعد از ذخیره یک‌بار از پیشخوان وردپرس به «تنظیمات ← پیوندهای یکتا» بروید و فقط دکمه «ذخیره تغییرات» را بزنید.";
    form.appendChild(hint);

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "btn";
    btn.textContent = "ذخیره تنظیمات";
    btn.onclick = async () => {
      const payload = {};
      form.querySelectorAll("input[name]").forEach((i) => { if (i.type !== "file") payload[i.name] = i.value; });
      if (file.files && file.files[0]) {
        const fd = new FormData();
        fd.append("action", "upload_logo");
        fd.append("_wpnonce", CSRF);
        fd.append("instance", String(INSTANCE_ID));
        fd.append("file", file.files[0]);
        const up = await fetch(API + (API.includes("?") ? "&" : "?") + "action=upload_logo", { method: "POST", body: fd, credentials: "same-origin" }).then((r) => r.json());
        if (up.ok && up.data && (up.data.logo || up.data.url)) payload.logo = up.data.logo || up.data.url;
        else { alert(up.error || "خطا در آپلود لوگو"); return; }
      }
      const res = await api("settings", { payload });
      if (!res.ok) { alert(res.error || "خطا"); return; }
      alert((res.data && res.data.hint) || "ذخیره شد.");
      await reload();
      const bn = document.getElementById("brand-name");
      if (bn && S.settings) bn.textContent = S.settings.company_name || "سامانه";
      renderSocialFooter();
      render();
    };
    form.appendChild(btn);
    card.appendChild(form);
    root.appendChild(card);

    // —— بکاپ و بازیابی ——
    const bakCard = document.createElement("div");
    bakCard.className = "card";
    bakCard.innerHTML = `<h2>بکاپ و بازیابی</h2>
      <p class="hint">بکاپ <strong>دستی</strong> (دانلود یا ذخیره روی سرور) و بکاپ <strong>خودکار هر ۱۲ ساعت</strong> — هر کارگاه جداگانه با تمام داده‌ها.</p>
      <div id="auto-bak-status" style="margin:10px 0;padding:12px;background:#f8fafc;border-radius:10px;border:1px solid #e2e8f0;font-size:0.9rem">در حال دریافت وضعیت…</div>`;

    const bakActs = document.createElement("div");
    bakActs.style.cssText = "display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px";

    // دانلود دستی JSON
    const fullBtn = document.createElement("button");
    fullBtn.type = "button";
    fullBtn.className = "btn";
    fullBtn.textContent = "دانلود بکاپ دستی (JSON)";
    fullBtn.title = "فایل را روی دستگاه خود ذخیره می‌کند";
    fullBtn.onclick = () => {
      const url = API + (API.includes("?") ? "&" : "?") + "action=export&table=full&format=json&instance=" + INSTANCE_ID;
      const f = document.createElement("form");
      f.method = "POST"; f.action = url; f.target = "_blank";
      const n = document.createElement("input"); n.type = "hidden"; n.name = "_wpnonce"; n.value = CSRF; f.appendChild(n);
      document.body.appendChild(f); f.submit(); f.remove();
    };
    bakActs.appendChild(fullBtn);

    // ذخیره دستی روی سرور (همان پوشه بکاپ‌های کارگاه)
    const manualServerBtn = document.createElement("button");
    manualServerBtn.type = "button";
    manualServerBtn.className = "btn btn-outline";
    manualServerBtn.textContent = "ذخیره بکاپ دستی روی سرور";
    manualServerBtn.title = "در پوشه بکاپ این کارگاه روی هاست ذخیره می‌شود";
    manualServerBtn.onclick = async () => {
      manualServerBtn.disabled = true;
      manualServerBtn.textContent = "در حال ذخیره…";
      try {
        const res = await api("manual_backup_now", {});
        if (!res || !res.ok) {
          alert((res && res.error) || "بکاپ دستی ناموفق");
        } else {
          const d = res.data || {};
          alert("بکاپ دستی روی سرور ذخیره شد." + (d.file ? ("\nفایل: " + d.file) : "") + (d.bytes ? ("\nحجم: " + Math.round(d.bytes / 1024) + " کیلوبایت") : ""));
          if (typeof refreshBakStatus === "function") refreshBakStatus();
        }
      } catch (e) {
        alert("خطا در ارتباط با سرور");
      }
      manualServerBtn.disabled = false;
      manualServerBtn.textContent = "ذخیره بکاپ دستی روی سرور";
    };
    bakActs.appendChild(manualServerBtn);

    // بکاپ خودکار همین حالا
    const autoBtn = document.createElement("button");
    autoBtn.type = "button";
    autoBtn.className = "btn btn-outline";
    autoBtn.textContent = "اجرای بکاپ خودکار همین حالا";
    autoBtn.onclick = async () => {
      autoBtn.disabled = true;
      autoBtn.textContent = "در حال ذخیره…";
      try {
        const res = await api("auto_backup_now", {});
        if (!res || !res.ok) alert((res && res.error) || "بکاپ ناموفق");
        else {
          alert("بکاپ خودکار این کارگاه ذخیره شد.");
          if (typeof refreshBakStatus === "function") refreshBakStatus();
        }
      } catch (e) { alert("خطا در ارتباط"); }
      autoBtn.disabled = false;
      autoBtn.textContent = "اجرای بکاپ خودکار همین حالا";
    };
    bakActs.appendChild(autoBtn);

    // اکسل
    const excelDataBtn = document.createElement("button");
    excelDataBtn.type = "button";
    excelDataBtn.className = "btn btn-outline";
    excelDataBtn.textContent = "دانلود اکسل (همه بخش‌ها + داده)";
    excelDataBtn.onclick = () => {
      const url = API + (API.includes("?") ? "&" : "?") + "action=export&table=excel_template&format=excel&instance=" + INSTANCE_ID;
      const f = document.createElement("form");
      f.method = "POST"; f.action = url; f.target = "_blank";
      const n = document.createElement("input"); n.type = "hidden"; n.name = "_wpnonce"; n.value = CSRF; f.appendChild(n);
      document.body.appendChild(f); f.submit(); f.remove();
    };
    bakActs.appendChild(excelDataBtn);

    bakCard.appendChild(bakActs);

    // بازیابی از فایل
    const restoreRow = document.createElement("div");
    restoreRow.style.cssText = "display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:8px";
    const restoreLabel = document.createElement("span");
    restoreLabel.textContent = "بازیابی از فایل:";
    restoreLabel.style.fontWeight = "600";
    restoreRow.appendChild(restoreLabel);
    const fileInp = document.createElement("input");
    fileInp.type = "file";
    fileInp.accept = ".json,.json.gz,.csv,.xls,.xlsx,application/json";
    restoreRow.appendChild(fileInp);
    const impBtn = document.createElement("button");
    impBtn.type = "button";
    impBtn.className = "btn btn-sm";
    impBtn.textContent = "درون‌ریزی بکاپ";
    impBtn.onclick = async () => {
      if (!fileInp.files || !fileInp.files[0]) { alert("فایل را انتخاب کنید"); return; }
      if (!confirm("درون‌ریزی بکاپ روی داده‌های فعلی این کارگاه انجام شود؟\nپیشنهاد: قبلش یک بکاپ دستی بگیرید.")) return;
      const fd = new FormData();
      fd.append("action", "import");
      fd.append("_wpnonce", CSRF);
      fd.append("instance", String(INSTANCE_ID));
      fd.append("table", "full");
      fd.append("file", fileInp.files[0]);
      try {
        const res = await fetch(API + (API.includes("?") ? "&" : "?") + "action=import", { method: "POST", body: fd, credentials: "same-origin" }).then((r) => r.json());
        if (!res.ok) { alert(res.error || "خطا در درون‌ریزی"); return; }
        alert("بازیابی انجام شد. صفحه تازه می‌شود.");
        location.reload();
      } catch (e) {
        alert("خطا در آپلود");
      }
    };
    restoreRow.appendChild(impBtn);
    bakCard.appendChild(restoreRow);

    async function refreshBakStatus() {
      const box = bakCard.querySelector("#auto-bak-status");
      if (!box) return;
      try {
        const st = await api("auto_backup_status", {});
        if (!st || !st.ok) {
          box.textContent = "وضعیت بکاپ در دسترس نیست.";
          return;
        }
        const d = st.data || {};
        const last = d.last;
        const files = d.files || [];
        let html = `<div style="margin-bottom:6px"><strong>بازه خودکار:</strong> هر ${d.interval_hours || 12} ساعت — فقط همین کارگاه</div>`;
        if (last && (last.at || last.time)) {
          html += `<div><strong>آخرین ذخیره سرور:</strong> ${last.at || "—"} ${last.bytes ? "(" + Math.round(last.bytes / 1024) + " KB)" : ""} ${last.kind === "manual" ? "— دستی" : (last.kind === "auto" || last.auto ? "— خودکار" : "")}</div>`;
        } else {
          html += `<div><strong>آخرین ذخیره سرور:</strong> هنوز نیست — از دکمه‌های بالا بسازید</div>`;
        }
        if (d.next) html += `<div><strong>اجرای بعدی خودکار:</strong> ${d.next}</div>`;
        if (files.length) {
          html += `<div style="margin-top:8px"><strong>فایل‌های ذخیره‌شده روی سرور:</strong><ul style="margin:6px 0 0;padding-right:18px">`;
          files.slice(0, 8).forEach((f) => {
            const kind = (f.file || "").indexOf("manual_") === 0 ? "دستی" : "خودکار";
            html += `<li style="margin:2px 0"><code>${f.file}</code> — ${kind} — ${f.at || ""} — ${Math.round((f.bytes || 0) / 1024)} KB</li>`;
          });
          html += `</ul></div>`;
        }
        box.innerHTML = html;
      } catch (e) {
        box.textContent = "خطا در دریافت وضعیت بکاپ.";
      }
    }
    refreshBakStatus();

    root.appendChild(bakCard);

    // —— درون‌ریزی / برون‌ریزی اکسل همه بخش‌ها ——
    if (POLICY.is_manager || POLICY.can_settings) {
      const ioCard = document.createElement("div");
      ioCard.className = "card";
      ioCard.innerHTML = `<h2>درون‌ریزی و برون‌ریزی اکسل (همه بخش‌ها)</h2>
        <p class="hint">برای هر بخش قالب خام Excel (CSV) را دانلود کنید، پر کنید و آپلود کنید. ستون‌ها باید دقیقاً مطابق قالب باشند.</p>`;
      const tables = [
        ["personnel", "پرسنل"], ["customers", "مشتریان"], ["stock_items", "انبار"],
        ["suppliers", "تأمین‌کنندگان"], ["purchases", "خریدها"], ["directives", "دستورات"],
        ["fines", "جریمه و پاداش"], ["daily_reports", "گزارش روزانه"],
        ["leave_requests", "مرخصی"], ["overtime", "اضافه‌کاری"],
        ["stock_usage", "اعلام مصرفی"], ["checks_received", "چک دریافتنی"], ["checks_paid", "چک پرداختنی"],
      ];
      const grid = document.createElement("div");
      grid.style.cssText = "display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px";
      tables.forEach(([tbl, label]) => {
        const box = document.createElement("div");
        box.style.cssText = "border:1px solid #e2e8f0;border-radius:10px;padding:12px;background:#f8fafc";
        box.innerHTML = `<strong style="display:block;margin-bottom:8px">${label}</strong>`;
        const row = document.createElement("div");
        row.style.cssText = "display:flex;flex-wrap:wrap;gap:6px";
        const tpl = document.createElement("button");
        tpl.type = "button";
        tpl.className = "btn btn-sm btn-outline";
        tpl.textContent = "قالب Excel";
        tpl.onclick = () => downloadTemplate(tbl);
        const exp = document.createElement("button");
        exp.type = "button";
        exp.className = "btn btn-sm btn-outline";
        exp.textContent = "خروجی";
        exp.onclick = () => {
          const url = API + (API.includes("?") ? "&" : "?") + "action=export&table=" + encodeURIComponent(tbl) + "&format=csv&instance=" + INSTANCE_ID;
          const f = document.createElement("form");
          f.method = "POST"; f.action = url; f.target = "_blank";
          const n = document.createElement("input"); n.name = "_wpnonce"; n.value = CSRF; f.appendChild(n);
          document.body.appendChild(f); f.submit(); f.remove();
        };
        const imp = document.createElement("button");
        imp.type = "button";
        imp.className = "btn btn-sm";
        imp.textContent = "درون‌ریزی";
        imp.onclick = () => {
          const inp = document.createElement("input");
          inp.type = "file";
          inp.accept = ".csv,.txt,.xlsx,text/csv";
          inp.onchange = async () => {
            if (!inp.files || !inp.files[0]) return;
            if (!confirm("درون‌ریزی «" + label + "» انجام شود؟")) return;
            const fd = new FormData();
            fd.append("action", "import");
            fd.append("_wpnonce", CSRF);
            fd.append("instance", String(INSTANCE_ID));
            fd.append("table", tbl);
            fd.append("file", inp.files[0]);
            const res = await fetch(API + (API.includes("?") ? "&" : "?") + "action=import", { method: "POST", body: fd, credentials: "same-origin" }).then((r) => r.json());
            if (!res.ok) { alert(res.error || "خطا"); return; }
            alert((res.data && res.data.rows != null) ? ("وارد شد: " + res.data.rows + " ردیف") : "انجام شد");
            await reload();
            render();
          };
          inp.click();
        };
        row.appendChild(tpl);
        row.appendChild(exp);
        row.appendChild(imp);
        box.appendChild(row);
        // نمایش ستون‌های قالب
        const cols = (FIELDS[tbl] || COLS[tbl] || []).filter((f) => f !== "password" && f !== "photo");
        const colHint = document.createElement("div");
        colHint.style.cssText = "font-size:.75rem;color:#64748b;margin-top:8px;line-height:1.4";
        colHint.textContent = "ستون‌ها: " + cols.map((c) => LABELS[c] || c).join("، ");
        box.appendChild(colHint);
        grid.appendChild(box);
      });
      ioCard.appendChild(grid);
      root.appendChild(ioCard);
    }

    // استودیو ظاهر حذف شد — مدیریت منو در صفحه جداگانه «مدیریت منو» برای همه کاربران

    if (st.wp_datetime) {
      const clock = document.createElement("div");
      clock.className = "card";
      clock.innerHTML = `<p class="hint" style="margin:0">تاریخ و ساعت وردپرس: ${(st.wp_datetime.date || "")} — ${(st.wp_datetime.time || "")} (منطقه: ${(st.wp_datetime.tz || "")})</p>`;
      root.appendChild(clock);
    }
  }


  function renderMenuOrder(root) {
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = `<h2>مدیریت منو</h2>
      <p class="hint">ترتیب منوی کناری را فقط برای خودتان عوض کنید. با دکمه‌های بالا/پایین جابه‌جا کنید. ذخیره فقط در مرورگر شماست و روی دیگران اثر ندارد.</p>`;
    const list = document.createElement("div");
    list.id = "menu-order-list";
    list.style.cssText = "display:flex;flex-direction:column;gap:8px;margin-top:12px";

    let items = menus().filter((m) => m.id !== "menu_order").map((m) => m.id);
    // include menu_order at end optional - keep it reorderable too
    items = menus().map((m) => m.id);

    const colorMap = { blue:"#2563eb", green:"#16a34a", orange:"#ea580c", purple:"#7c3aed", pink:"#db2777", teal:"#0d9488", red:"#dc2626", indigo:"#4f46e5", amber:"#d97706", cyan:"#0891b2", slate:"#475569", lime:"#65a30d" };

    function paint() {
      list.innerHTML = "";
      items.forEach((id, idx) => {
        const row = document.createElement("div");
        row.style.cssText = "display:flex;align-items:center;gap:10px;padding:12px 14px;border:1px solid var(--b);border-radius:12px;background:var(--card)";
        const icon = MENU_ICONS[id] || "◆";
        const label = MENU_LABELS[id] || id;
        const c = MENU_COLORS[id] || "blue";
        const bg = colorMap[c] || "#2563eb";
        row.innerHTML = `<span style="width:40px;height:40px;border-radius:10px;background:${bg};color:#fff;display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0">${icon}</span>
          <span style="flex:1;font-weight:600">${label}</span>
          <button type="button" class="btn btn-sm btn-outline mo-up" data-i="${idx}" title="بالا">▲</button>
          <button type="button" class="btn btn-sm btn-outline mo-down" data-i="${idx}" title="پایین">▼</button>`;
        list.appendChild(row);
      });
      list.querySelectorAll(".mo-up").forEach((b) => {
        b.onclick = () => {
          const i = Number(b.dataset.i);
          if (i <= 0) return;
          const t = items[i - 1]; items[i - 1] = items[i]; items[i] = t;
          paint();
        };
      });
      list.querySelectorAll(".mo-down").forEach((b) => {
        b.onclick = () => {
          const i = Number(b.dataset.i);
          if (i >= items.length - 1) return;
          const t = items[i + 1]; items[i + 1] = items[i]; items[i] = t;
          paint();
        };
      });
    }
    paint();
    card.appendChild(list);
    const actions = document.createElement("div");
    actions.style.cssText = "display:flex;flex-wrap:wrap;gap:8px;margin-top:16px";
    const save = document.createElement("button");
    save.type = "button";
    save.className = "btn";
    save.textContent = "ذخیره ترتیب منو";
    save.onclick = () => {
      PREFS.menuOrder = items.slice();
      savePrefs(PREFS);
      renderNav();
      renderBottomNav();
      showToast("ترتیب منو", "ذخیره شد — فقط برای شما", "ok");
    };
    const reset = document.createElement("button");
    reset.type = "button";
    reset.className = "btn btn-outline";
    reset.textContent = "بازگشت به ترتیب پیش‌فرض";
    reset.onclick = () => {
      PREFS.menuOrder = [];
      savePrefs(PREFS);
      items = menus().map((m) => m.id);
      paint();
      renderNav();
      renderBottomNav();
      showToast("ترتیب منو", "به پیش‌فرض برگشت", "info");
    };
    actions.appendChild(save);
    actions.appendChild(reset);
    card.appendChild(actions);
    root.appendChild(card);
  }

  function renderRoles(root) {
    const roles = S.panel_roles || {};
    const allMenus = POLICY.all_menus || MENU_LABELS;
    const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = "<h2>مدیریت نقش‌ها و دسترسی‌ها</h2><p class=\"hint\">برچسب نقش‌ها فارسی است. حذف داده غیرفعال است — فقط بایگانی. تیک منوهای مجاز را بزنید.</p>";
    const box = document.createElement("div");
    box.id = "roles-editor";

    function draw() {
      box.innerHTML = "";
      Object.keys(roles).forEach((key) => {
        const r = roles[key];
        const row = document.createElement("div");
        row.className = "role-row";
        row.dataset.key = key;
        let checks = "";
        Object.keys(allMenus).forEach((mid) => {
          const on = (r.menus || []).includes(mid);
          checks += `<label><input type="checkbox" data-menu="${mid}" ${on ? "checked" : ""}> ${allMenus[mid]}</label>`;
        });
        row.innerHTML = `
          <h3><input name="label" value="${r.label || key}" style="width:180px"> 
          <code>${key}</code>
          ${key !== "management" ? `<button type="button" class="btn btn-sm btn-danger" data-rm="${key}">حذف نقش</button>` : ""}</h3>
          <div class="field"><label>نقش وردپرس</label>
            <select name="wp_role">
              <option value="administrator" ${r.wp_role==="administrator"?"selected":""}>Administrator</option>
              <option value="author" ${r.wp_role==="author"?"selected":""}>Author</option>
              <option value="editor" ${r.wp_role==="editor"?"selected":""}>Editor</option>
              <option value="contributor" ${r.wp_role==="contributor"?"selected":""}>Contributor</option>
            </select>
          </div>
          <label style="margin-right:12px;opacity:.65" title="تنظیمات فقط برای مدیر مجموعه"><input type="checkbox" name="can_settings" disabled ${key==="management"?"checked":""}> تنظیمات فقط مدیر</label>
          <div class="checks" style="margin-top:8px">${checks}</div>`;
        box.appendChild(row);
        const rm = row.querySelector("[data-rm]");
        if (rm) rm.onclick = () => {
          delete roles[key];
          draw();
        };
      });
    }
    draw();

    const add = document.createElement("div");
    add.style.margin = "12px 0";
    add.innerHTML = `<input id="new-role-key" placeholder="کلید انگلیسی مثلا installer" style="width:140px"> 
      <input id="new-role-label" placeholder="برچسب فارسی"> 
      <button type="button" class="btn btn-sm" id="add-role">+ نقش جدید</button>`;
    card.appendChild(box);
    card.appendChild(add);
    add.querySelector("#add-role").onclick = () => {
      const k = (document.getElementById("new-role-key").value || "").trim().replace(/\s+/g, "_");
      const l = document.getElementById("new-role-label").value || k;
      if (!k) return;
      roles[k] = { key: k, label: l, wp_role: "editor", menus: ["emp_dashboard"], can_delete: false, can_settings: false };
      draw();
    };

    const save = document.createElement("button");
    save.className = "btn";
    save.textContent = "ذخیره نقش‌ها";
    save.onclick = async () => {
      const payload = {};
      box.querySelectorAll(".role-row").forEach((row) => {
        const key = row.dataset.key;
        const menus = [];
        row.querySelectorAll("[data-menu]").forEach((c) => { if (c.checked) menus.push(c.dataset.menu); });
        payload[key] = {
          key, label: row.querySelector("[name=label]").value,
          wp_role: row.querySelector("[name=wp_role]").value,
          can_delete: false,
          can_settings: (key === "management"),
          menus,
        };
      });
      const res = await api("roles", { payload });
      if (!res.ok) { alert(res.error || "خطا"); return; }
      alert("نقش‌ها ذخیره شد");
      await reload();
      renderNav();
      renderBottomNav();
      render();
    };
    card.appendChild(save);
    root.appendChild(card);

    // —— دسترسی خاص هر کاربر (منو + پیام + انبار) ——
    const upCard = document.createElement("div");
    upCard.className = "card";
    upCard.innerHTML = `<h2>دسترسی ریز برای هر کاربر</h2>
      <p class="hint">برای هر پرسنل/حسابدار/انباردار مشخص کنید به کدام منوها، کدام انبارها و با چه عملیاتی دسترسی دارد.</p>`;
    const upForm = document.createElement("div");
    const personnelNames = (S.personnel || []).map((p) => p.name).filter(Boolean);
    let opts = personnelNames.map((n) => `<option value="${n}">${n}</option>`).join("");
    // لیست انبارها از category کالاها یا warehouse خریدها
    const whSet = new Set(getMotherWarehouses());
    (S.stock_items || []).forEach((i) => { if (i.category) whSet.add(i.category); if (i.warehouse) whSet.add(i.warehouse); });
    (S.purchases || []).forEach((p) => { if (p.warehouse) whSet.add(p.warehouse); });
    const warehouses = [...whSet];
    const whChecks = warehouses.map((w) =>
      `<label style="display:inline-flex;align-items:center;gap:4px;margin:4px 8px 4px 0"><input type="checkbox" class="up-wh" value="${w}"> ${w}</label>`
    ).join("");
    const actLabels = {
      view: "مشاهده",
      withdraw: "برداشت",
      return: "بازگشت",
      purchase: "ثبت خرید",
      edit_stock: "ویرایش موجودی و حداقل موجودی",
    };
    const actChecks = Object.entries(actLabels).map(([k, l]) =>
      `<label style="display:inline-flex;align-items:center;gap:4px;margin:4px 8px 4px 0"><input type="checkbox" class="up-wa" value="${k}"> ${l}</label>`
    ).join("");
    // منوهای قابل تیک
    const menuChecks = Object.entries(allMenus).map(([mid, ml]) =>
      `<label style="display:inline-flex;align-items:center;gap:4px;margin:4px 8px 4px 0"><input type="checkbox" class="up-menu" value="${mid}"> ${ml}</label>`
    ).join("");

    upForm.innerHTML = `
      <div class="field"><label>انتخاب کاربر</label>
        <select id="up-user"><option value="">— انتخاب —</option>${opts}</select>
      </div>
      <div class="field"><label>منوهای اضافه</label>
        <div class="checks" id="up-menus-box">${menuChecks}</div>
      </div>
      <div class="field"><label>انبارهای مجاز</label>
        <div class="checks" id="up-wh-box">${whChecks || '<span class="hint">هنوز انبار مادری تعریف نشده — ابتدا در بخش انبار نام‌ها را وارد کنید</span>'}</div>
        <input id="up-wh-new" placeholder="نام انبار جدید برای اضافه به لیست" style="margin-top:6px;width:100%">
      </div>
      <div class="field"><label>عملیات مجاز روی انبار</label>
        <div class="checks">${actChecks}</div>
      </div>
      <div class="field"><label>اجازه پیام به این افراد (نام‌ها با کاما)</label>
        <input id="up-msg" placeholder="علی حیدری,رضا محمدی">
      </div>
      <button type="button" class="btn" id="up-save">ذخیره دسترسی کاربر</button>
      <div id="up-list" style="margin-top:14px"></div>`;
    upCard.appendChild(upForm);

    // پر کردن فرم هنگام انتخاب کاربر
    upForm.querySelector("#up-user").onchange = () => {
      const uname = upForm.querySelector("#up-user").value;
      const p = (POLICY.user_perms || {})[uname] || {};
      upForm.querySelectorAll(".up-menu").forEach((c) => { c.checked = (p.menus || []).includes(c.value); });
      upForm.querySelectorAll(".up-wh").forEach((c) => { c.checked = (p.warehouses || []).includes(c.value); });
      upForm.querySelectorAll(".up-wa").forEach((c) => { c.checked = (p.warehouse_actions || []).includes(c.value); });
      upForm.querySelector("#up-msg").value = (p.can_message || []).join("، ");
    };

    function drawUpList() {
      const list = document.getElementById("up-list");
      if (!list) return;
      const perms = POLICY.user_perms || {};
      const keys = Object.keys(perms);
      if (!keys.length) {
        list.innerHTML = '<p class="hint">هنوز دسترسی خاصی تعریف نشده.</p>';
        return;
      }
      const actMap = { view: "مشاهده", withdraw: "برداشت", return: "بازگشت", purchase: "خرید", edit_stock: "ویرایش" };
      list.innerHTML = keys.map((k) => {
        const p = perms[k];
        const menuNames = (p.menus || []).map((m) => allMenus[m] || m).join("، ") || "—";
        const wh = (p.warehouses || []).join("، ") || "—";
        const acts = (p.warehouse_actions || []).map((a) => actMap[a] || a).join("، ") || "—";
        return `<div class="role-row"><strong>${k}</strong>
          <div>منوها: ${menuNames}</div>
          <div>انبارها: ${wh}</div>
          <div>عملیات انبار: ${acts}</div>
          <div>پیام به: ${(p.can_message || []).join("، ") || "—"}</div>
          <button type="button" class="btn btn-sm btn-danger" data-rm-up="${k}">حذف</button></div>`;
      }).join("");
      list.querySelectorAll("[data-rm-up]").forEach((btn) => {
        btn.onclick = async () => {
          const perms2 = Object.assign({}, POLICY.user_perms || {});
          delete perms2[btn.dataset.rmUp];
          const res = await api("user_perms", { payload: perms2 });
          if (!res.ok) { alert(res.error || "خطا"); return; }
          POLICY.user_perms = perms2;
          drawUpList();
        };
      });
    }
    drawUpList();

    upForm.querySelector("#up-save").onclick = async () => {
      const uname = document.getElementById("up-user").value;
      if (!uname) { alert("کاربر را انتخاب کنید"); return; }
      const menus = Array.from(upForm.querySelectorAll(".up-menu:checked")).map((c) => c.value);
      let warehouses = Array.from(upForm.querySelectorAll(".up-wh:checked")).map((c) => c.value);
      const newWh = (document.getElementById("up-wh-new").value || "").trim();
      if (newWh && !warehouses.includes(newWh)) warehouses.push(newWh);
      const warehouse_actions = Array.from(upForm.querySelectorAll(".up-wa:checked")).map((c) => c.value);
      const can_message = (document.getElementById("up-msg").value || "").split(/[,،]/).map((s) => s.trim()).filter(Boolean);
      const perms = Object.assign({}, POLICY.user_perms || {});
      perms[uname] = { menus, can_message, warehouses, warehouse_actions };
      const res = await api("user_perms", { payload: perms });
      if (!res.ok) { alert(res.error || "خطا"); return; }
      POLICY.user_perms = perms;
      alert("دسترسی ذخیره شد");
      drawUpList();
    };
    root.appendChild(upCard);
  }

  function myOpenDirectives() {
    const name = (USER.name || "").trim();
    const login = (USER.login || "").trim();
    return (S.directives || []).filter((d) => {
      const st = d.status || "باز";
      if (st !== "باز" && st !== "pending" && st !== "") return false;
      // مهلت: اگر due_date گذشته و status باز است هنوز نشان بده تا کاربر نرود
      const tn = (d.target_name || "").trim();
      const tr = (d.target_role || "").trim();
      if (tn && (tn === name || tn === login || tn === "*")) return true;
      if (!tn && tr && (tr === USER.role || tr === "all" || tr === "همه" || (POLICY.role_labels || {})[USER.role] === tr)) return true;
      if (!tn && !tr && USER.role !== "management") return true;
      if (USER.role === "management" && !tn) return false;
      return tn === name;
    });
  }

  function renderDirectiveBanners(root) {
    const list = myOpenDirectives();
    if (!list.length) return;
    const wrap = document.createElement("div");
    wrap.id = "dir-banners";
    list.forEach((d) => {
      let pri = d.priority || "critical";
      if (pri === "فوری") pri = "critical";
      if (pri === "مهم") pri = "important";
      if (pri === "عادی") pri = "normal";
      const box = document.createElement("div");
      box.className = "dir-banner dir-" + pri;
      const title = d.title || "دستور";
      const body = d.body || "";
      const due = d.due_date ? ` <small style="opacity:.85">(مهلت: ${d.due_date})</small>` : "";
      const target = d.target_name || d.target_role || "عمومی";
      box.innerHTML = `<div class="dir-banner-text"><strong>${pri === "critical" ? "دستور بحرانی" : pri === "important" ? "دستور مهم" : "دستور"}: ${title}${due}</strong><div>${body}</div><div style="margin-top:4px;font-size:.8rem;opacity:.9">مخاطب: ${target}</div></div>`;
      const actions = document.createElement("div");
      actions.className = "dir-banner-actions";
      const done = document.createElement("button");
      done.className = "btn btn-sm";
      done.textContent = "انجام شد";
      done.onclick = async () => {
        const res = await api("save", { table: "directives", payload: { id: d.id, status: "انجام شد" } });
        if (!res.ok) { alert(res.error || "خطا"); return; }
        await reload();
        renderNav();
        renderBottomNav();
        render();
      };
      const rej = document.createElement("button");
      rej.className = "btn btn-sm btn-danger";
      rej.textContent = "رد شد";
      rej.onclick = async () => {
        const reason = prompt("دلیل رد (اختیاری):") || "";
        const res = await api("save", { table: "directives", payload: { id: d.id, status: "رد شد", body: (d.body || "") + (reason ? "\n[رد: " + reason + "]" : "") } });
        if (!res.ok) { alert(res.error || "خطا"); return; }
        await reload();
        renderNav();
        renderBottomNav();
        render();
      };
      actions.appendChild(done);
      actions.appendChild(rej);
      box.appendChild(actions);
      wrap.appendChild(box);
    });
    root.insertBefore(wrap, root.firstChild);
  }



  // ═══════════ چت زنده (دکمه شناور + تمام‌صفحه) ═══════════
  let chatRoom = null;
  let chatOpen = false;
  let voiceRecorder = null;
  let voiceChunks = [];
  let voiceRecording = false;

  function myName() {
    return (USER.name || USER.login || "").trim();
  }

  function chatReadKey() {
    return "samaneh_chat_read_" + (USER.id || USER.wp_user_id || USER.login || myName() || "g") + "_" + (INSTANCE_ID || 1);
  }
  function loadChatRead() {
    try { return JSON.parse(localStorage.getItem(chatReadKey()) || "{}"); } catch (e) { return {}; }
  }
  function saveChatRead(map) {
    try { localStorage.setItem(chatReadKey(), JSON.stringify(map)); } catch (e) {}
  }
  function markRoomRead(room) {
    if (!room) return;
    const key = room.type + ":" + room.id;
    const map = loadChatRead();
    map[key] = new Date().toISOString();
    saveChatRead(map);
    updateChatBadge();
  }
  function countUnread() {
    const name = myName();
    const map = loadChatRead();
    let n = 0;
    (S.messages || []).forEach((m) => {
      if ((m.sender_name || "") === name) return;
      // only messages visible to me
      const mt = m.msg_type || "";
      const rn = m.recipient_name || "";
      const sn = m.sender_name || "";
      const proj = m.project || "";
      let roomKey = null;
      if (mt === "staff" || rn === "__staff__") roomKey = "staff:__staff__";
      else if (mt === "project" || mt === "group_project") roomKey = "project:" + proj;
      else if (rn === name) roomKey = "dm:" + sn;
      else if (sn === name) roomKey = "dm:" + rn;
      else return;
      const last = map[roomKey] || "1970-01-01";
      const ca = m.created_at || m.updated_at || "";
      if (ca && ca > last) n++;
    });
    return n;
  }
  function updateChatBadge() {
    const badge = document.getElementById("chat-fab-badge");
    const fab = document.getElementById("chat-fab");
    if (!fab) return;
    const n = countUnread();
    if (badge) {
      if (n > 0) {
        badge.textContent = n > 99 ? "99+" : String(n);
        badge.style.display = "flex";
      } else {
        badge.style.display = "none";
      }
    }
  }

  function initStatsScroll() {
    document.querySelectorAll(".stats").forEach((el) => {
      if (el.classList.contains("stats-kpis")) return;
      if (el.dataset.scrollInit) return;
      el.dataset.scrollInit = "1";
      let down = false, startX = 0, startScroll = 0;
      el.addEventListener("mousedown", (e) => {
        down = true;
        startX = e.pageX;
        startScroll = el.scrollLeft;
        el.style.cursor = "grabbing";
      });
      window.addEventListener("mouseup", () => { down = false; el.style.cursor = ""; });
      el.addEventListener("mouseleave", () => { down = false; el.style.cursor = ""; });
      el.addEventListener("mousemove", (e) => {
        if (!down) return;
        e.preventDefault();
        el.scrollLeft = startScroll - (e.pageX - startX);
      });
      // padding so first/last half-peek: ensure content wider
      el.style.scrollPaddingInline = "24px";
    });
  }

  function ensureChatFab() {
    let fab = document.getElementById("chat-fab");
    if (!fab) {
      fab = document.createElement("button");
      fab.type = "button";
      fab.id = "chat-fab";
      fab.className = "chat-fab";
      fab.title = "چت";
      fab.innerHTML = '<svg class="tg-icon" viewBox="0 0 24 24" width="28" height="28" aria-hidden="true"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 00-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z"/></svg><span id="chat-fab-badge" class="chat-fab-badge" style="display:none">0</span>';
      document.body.appendChild(fab);
      fab.onclick = () => openChatOverlay();
    }
    // hide when overlay open
    fab.classList.toggle("hidden-fab", chatOpen);
    updateChatBadge();
  }

  function allChatPeople() {
    const set = new Map();
    (S.personnel || []).forEach((p) => {
      if (p.name) set.set(p.name, { name: p.name, role: p.role || "employee", kind: "personnel" });
    });
    (S.customers || []).forEach((c) => {
      if (c.name) set.set(c.name, { name: c.name, role: "customer", kind: "customer" });
    });
    set.set("مدیر", { name: "مدیر", role: "management", kind: "manager" });
    return [...set.values()];
  }

  function peerChatAllowed() {
    const st = S.settings || {};
    return st.allow_peer_chat !== "0" && st.allow_peer_chat !== 0 && st.allow_peer_chat !== false;
  }

  function chatAccessMap() {
    const st = S.settings || {};
    const m = st.chat_access;
    return (m && typeof m === "object") ? m : {};
  }
  function chatAvatarsMap() {
    const st = S.settings || {};
    const m = st.chat_avatars;
    return (m && typeof m === "object") ? m : {};
  }
  function getChatAvatar(personName) {
    const av = chatAvatarsMap()[personName];
    if (av) return av;
    const p = (S.personnel || []).find((x) => x.name === personName);
    if (p && p.photo) return p.photo;
    const c = (S.customers || []).find((x) => x.name === personName);
    if (c && (c.photo || c.avatar)) return c.photo || c.avatar;
    return "";
  }
  function isChatDisabled(personName, kind, targetId) {
    const acc = chatAccessMap()[personName] || {};
    if (kind === "project") {
      const dis = acc.disabled_projects || [];
      return dis.includes(targetId);
    }
    if (kind === "dm") {
      const dis = acc.disabled_dms || [];
      return dis.includes(targetId);
    }
    if (kind === "staff") return !!acc.disable_staff;
    return false;
  }
  function roleLabelForChat(role) {
    const map = (POLICY.role_labels || {});
    if (map[role]) return map[role];
    const labels = { management: "مدیر", employee: "پرسنل", warehouse: "حسابدار", customer: "مشتری", supervisor: "سرپرست" };
    return labels[role] || role || "—";
  }

  function myProjectsForChat() {
    const name = myName();
    const role = POLICY.role || "";
    if (POLICY.is_manager || role === "management" || role === "warehouse") {
      return (S.customers || []).filter((c) => c.name);
    }
    // هوشمند: نصاب روی مشتری + گزارش کار روی پروژه + نام خود مشتری
    const set = new Set();
    (S.customers || []).forEach((c) => {
      if (!c.name) return;
      if (c.name === name) { set.add(c.name); return; }
      const inst = String(c.installer || "");
      if (inst === name || inst.split(/[,،]/).map((s) => s.trim()).includes(name)) set.add(c.name);
    });
    (S.daily_reports || []).forEach((r) => {
      if ((r.personnel_name || "") === name && r.project) set.add(r.project);
    });
    // اگر مدیر در مدیریت چت پروژه را برای این کاربر غیرفعال کرده باشد
    return [...set].filter((proj) => !isChatDisabled(name, "project", proj)).map((n) => {
      return (S.customers || []).find((c) => c.name === n) || { name: n };
    });
  }

  function isMsgHidden(m) {
    const st = (m.payment_type || m.status || "").toString();
    return st === "pending_delete" || st === "deleted";
  }
  function filterMsgsForRoom(room) {
    const msgs = S.messages || [];
    const name = myName();
    if (!room) return [];
    let list = [];
    if (room.type === "staff") {
      list = msgs.filter((m) => m.msg_type === "staff" || m.recipient_name === "__staff__");
    } else if (room.type === "project") {
      list = msgs.filter((m) => (m.msg_type === "project" || m.msg_type === "group_project") && (m.project || "") === room.id);
    } else if (room.type === "dm") {
      list = msgs.filter((m) => {
        const a = m.sender_name || "";
        const b = m.recipient_name || "";
        return (a === name && b === room.id) || (a === room.id && b === name);
      });
    }
    // پیام‌های در انتظار حذف / حذف‌شده از چت عادی پنهان
    return list.filter((m) => !isMsgHidden(m));
  }

  function isProjectClosed(projectName) {
    const c = (S.customers || []).find((x) => x.name === projectName);
    if (!c) return false;
    const st = normalizeCustomerStatus(c.status || "");
    return st === "تحویل شده" || st === "بسته" || st === "تمام شده" || st === "closed" || st === "done";
  }

  async function uploadChatFile(file) {
    if (!file) return "";
    const fd = new FormData();
    fd.append("action", "upload");
    fd.append("_wpnonce", CSRF);
    fd.append("instance", String(INSTANCE_ID));
    fd.append("file", file);
    fd.append("table", "photos");
    fd.append("payload", JSON.stringify({ project: "chat", stage: "file", caption: file.name || "فایل چت" }));
    const up = await fetch(API + (API.includes("?") ? "&" : "?") + "action=upload", { method: "POST", body: fd, credentials: "same-origin" }).then((r) => r.json());
    if (up.ok && up.data) return up.data.url || (window.UPLOADS + (up.data.filename || ""));
    throw new Error(up.error || "آپلود ناموفق");
  }

  async function sendChatMessage(room, body, filePath, msgTypeExtra) {
    const name = myName();
    const payload = {
      sender_role: POLICY.role || "",
      sender_name: name,
      body: body || "",
      file_path: filePath || "",
      msg_type: msgTypeExtra || (room.type === "staff" ? "staff" : room.type === "project" ? "project" : "dm"),
      recipient_name: room.type === "staff" ? "__staff__" : room.id,
      recipient_role: "",
      project: room.type === "project" ? room.id : "",
    };
    const res = await api("save", { table: "messages", payload });
    if (!res.ok) throw new Error(res.error || "خطا در ارسال");
    return res;
  }

  function isAudioPath(p) {
    if (!p) return false;
    return /\.(webm|ogg|mp3|wav|m4a|aac)(\?|$)/i.test(p) || String(p).includes("audio");
  }

  function renderChatInto(container) {
    const name = myName();
    container.innerHTML = "";
    const layout = document.createElement("div");
    const isMobileChat2 = window.matchMedia && window.matchMedia("(max-width: 700px)").matches;
    layout.className = "chat-layout tg-layout" + (isMobileChat2 && chatRoom ? " tg-show-chat" : "") + (isMobileChat2 && !chatRoom ? " tg-show-list" : "");

    // —— لیست گفتگوها (شبیه تلگرام) ——
    const roomsWrap = document.createElement("div");
    roomsWrap.className = "chat-rooms tg-sidebar";
    const searchBox = document.createElement("div");
    searchBox.className = "tg-search-wrap";
    searchBox.innerHTML = `<input type="search" id="tg-room-search" class="tg-search" placeholder="جستجوی گفتگو و افراد...">`;
    roomsWrap.appendChild(searchBox);

    const roomsList = document.createElement("div");
    roomsList.className = "tg-rooms-list";
    roomsWrap.appendChild(roomsList);

    const rooms = [];
    // گروه کارکنان
    if (POLICY.is_manager || POLICY.role === "warehouse" || POLICY.role === "employee" || POLICY.role === "supervisor") {
      if (!isChatDisabled(name, "staff")) {
        rooms.push({ type: "staff", id: "__staff__", title: "گروه کارکنان", role: "گروه", avatar: "" });
      }
    }
    // پروژه‌ها
    myProjectsForChat().forEach((c) => {
      const closed = isProjectClosed(c.name);
      rooms.push({
        type: "project", id: c.name,
        title: c.name,
        role: closed ? "پروژه (بسته)" : "پروژه",
        avatar: getChatAvatar(c.name),
        closed,
      });
    });
    // افراد
    const people = allChatPeople();
    people.forEach((p) => {
      if (p.name === name) return;
      if (p.name === "مدیر" && POLICY.is_manager) return;
      // دسترسی DM
      if (!POLICY.is_manager && p.kind !== "manager" && !peerChatAllowed()) {
        // غیرمدیر بدون اجازه peer فقط با مدیر و افراد پروژه
        if (p.kind === "manager") {
          /* ok */
        } else {
          // اگر در پروژه‌های مشترک هستند اجازه بده
          const myP = myProjectsForChat().map((x) => x.name);
          const theirProjects = [];
          (S.customers || []).forEach((c) => {
            const inst = String(c.installer || "");
            if (inst === p.name || inst.split(/[,،]/).map((s) => s.trim()).includes(p.name)) theirProjects.push(c.name);
          });
          (S.daily_reports || []).forEach((r) => {
            if ((r.personnel_name || "") === p.name && r.project) theirProjects.push(r.project);
          });
          const shared = theirProjects.some((t) => myP.includes(t));
          if (!shared && p.kind !== "customer") return;
          // مشتری پروژه مشترک
          if (p.kind === "customer" && !myP.includes(p.name)) return;
        }
      }
      if (isChatDisabled(name, "dm", p.name)) return;
      rooms.push({
        type: "dm", id: p.name,
        title: p.name,
        role: roleLabelForChat(p.role || p.kind),
        avatar: getChatAvatar(p.name),
        kind: p.kind,
      });
    });

    const isMobileChat = window.matchMedia && window.matchMedia("(max-width: 700px)").matches;
    // موبایل: اول لیست مخاطبین — بدون انتخاب خودکار
    if (!chatRoom && rooms.length && !isMobileChat) chatRoom = rooms[0];

    function paintRooms(filterQ) {
      const q = normFa(filterQ || "");
      roomsList.innerHTML = "";
      const filtered = rooms.filter((r) => {
        if (!q) return true;
        return normFa(r.title).includes(q) || normFa(r.role).includes(q);
      });
      if (!filtered.length) {
        roomsList.innerHTML = '<div class="tg-empty">گفتگویی یافت نشد</div>';
        return;
      }
      filtered.forEach((r) => {
        const btn = document.createElement("button");
        btn.type = "button";
        const active = chatRoom && chatRoom.type === r.type && chatRoom.id === r.id;
        btn.className = "tg-room-item" + (active ? " active" : "");
        const initial = (r.title || "?").charAt(0);
        const avHtml = r.avatar
          ? `<img class="tg-avatar" src="${r.avatar}" alt="">`
          : `<span class="tg-avatar tg-avatar-letter" data-type="${r.type}">${initial}</span>`;
        btn.innerHTML = `${avHtml}<span class="tg-room-meta"><span class="tg-room-title">${r.title}</span><span class="tg-room-role">${r.role || ""}</span></span>`;
        btn.onclick = (e) => {
          e.preventDefault();
          e.stopPropagation();
          chatRoom = r;
          markRoomRead(r);
          renderChatInto(container);
        };
        roomsList.appendChild(btn);
      });
    }
    paintRooms("");
    const sInput = searchBox.querySelector("#tg-room-search");
    if (sInput) sInput.oninput = () => paintRooms(sInput.value);

    layout.appendChild(roomsWrap);

    // —— پنل گفتگو ——
    const main = document.createElement("div");
    main.className = "tg-main";

    const head = document.createElement("div");
    head.className = "tg-chat-head";
    if (chatRoom) {
      const initial = (chatRoom.title || "?").charAt(0);
      const av = chatRoom.avatar
        ? `<img class="tg-avatar sm" src="${chatRoom.avatar}" alt="">`
        : `<span class="tg-avatar tg-avatar-letter sm">${initial}</span>`;
      const backBtn = (window.matchMedia && window.matchMedia("(max-width: 700px)").matches)
        ? `<button type="button" class="tg-back-btn" id="tg-back-list" aria-label="بازگشت">→ لیست</button>`
        : "";
      head.innerHTML = `${backBtn}${av}<div class="tg-head-text"><div class="tg-head-title">${chatRoom.title || ""}</div><div class="tg-head-sub">${chatRoom.role || ""}</div></div>`;
    } else {
      head.innerHTML = `<div class="tg-head-title">یک گفتگو انتخاب کنید</div>`;
    }
    main.appendChild(head);
    const backEl = head.querySelector("#tg-back-list");
    if (backEl) {
      backEl.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        chatRoom = null;
        renderChatInto(container);
      };
    }

    const body = document.createElement("div");
    body.className = "chat-body tg-body";
    const list = filterMsgsForRoom(chatRoom).slice().sort((a, b) => String(a.created_at || "").localeCompare(String(b.created_at || "")));
    if (!chatRoom) {
      body.innerHTML = '<div class="tg-empty">از لیست راست یک نفر یا گروه را انتخاب کنید</div>';
    } else if (!list.length) {
      body.innerHTML = '<div class="tg-empty">هنوز پیامی نیست — بنویسید یا ویس بفرستید</div>';
    } else {
      list.forEach((m) => {
        const me = (m.sender_name || "") === name;
        const bub = document.createElement("div");
        bub.className = "chat-bubble tg-bubble " + (me ? "me" : "them");
        bub.dataset.msgId = m.id || "";
        let html = "";
        if (!me) html += `<div class="tg-sender">${m.sender_name || "—"}</div>`;
        if (m.body) html += `<div class="tg-text">${m.body}</div>`;
        if (m.file_path) {
          if (isAudioPath(m.file_path) || (m.body || "").startsWith("🎤")) {
            html += `<audio class="chat-audio" controls src="${m.file_path}"></audio>`;
          } else {
            html += `<div class="chat-file"><a href="${m.file_path}" target="_blank" rel="noopener">📎 فایل</a></div>`;
          }
        }
        html += `<div class="chat-meta">${(window.J && J.formatChatDate) ? J.formatChatDate(m.created_at) : (m.created_at || "")}`;
        if (me && m.id) {
          html += ` <button type="button" class="tg-del-btn" data-del-id="${m.id}" title="درخواست حذف پیام">حذف</button>`;
        }
        html += `</div>`;
        bub.innerHTML = html;
        body.appendChild(bub);
      });
      body.querySelectorAll("[data-del-id]").forEach((btn) => {
        btn.onclick = async (e) => {
          e.stopPropagation();
          if (!confirm("درخواست حذف این پیام ثبت شود؟ مدیر تصمیم نهایی را می‌گیرد.")) return;
          const id = btn.dataset.delId;
          const res = await api("save", { table: "messages", payload: { id: Number(id), payment_type: "pending_delete" } });
          if (!res.ok) { alert(res.error || "خطا"); return; }
          showToast("درخواست حذف", "برای تأیید مدیر ارسال شد", "info");
          await reload();
          const box = document.getElementById("chat-overlay-body");
          if (box) renderChatInto(box);
        };
      });
    }
    main.appendChild(body);
    setTimeout(() => { body.scrollTop = body.scrollHeight; }, 40);

    const closed = chatRoom && chatRoom.type === "project" && isProjectClosed(chatRoom.id);
    const compose = document.createElement("div");
    compose.className = "chat-compose tg-compose";
    if (closed) {
      compose.innerHTML = '<div class="hint" style="padding:8px;text-align:center">این گروه پروژه بسته شده است.</div>';
    } else if (!chatRoom) {
      compose.innerHTML = '<div class="hint" style="padding:8px;text-align:center">یک گفتگو انتخاب کنید</div>';
    } else {
      compose.innerHTML = `
        <label class="tg-file-btn" title="فایل"><input type="file" id="chat-file" hidden>📎</label>
        <div class="tg-input-wrap">
          <button type="button" class="chat-voice-btn" id="chat-voice" title="ضبط ویس">🎤</button>
          <textarea id="chat-text" placeholder="پیام بنویسید... (Enter برای ارسال)" rows="1"></textarea>
        </div>`;
    }
    main.appendChild(compose);
    layout.appendChild(main);
    container.appendChild(layout);

    if (chatRoom) markRoomRead(chatRoom);

    async function doSendChat() {
      const ta = document.getElementById("chat-text");
      const text = (ta && ta.value || "").trim();
      const fi = document.getElementById("chat-file");
      if (!text && !(fi && fi.files && fi.files[0])) return;
      try {
        let fp = "";
        if (fi && fi.files && fi.files[0]) fp = await uploadChatFile(fi.files[0]);
        await sendChatMessage(chatRoom, text, fp);
        if (ta) ta.value = "";
        if (fi) fi.value = "";
        await reload();
        const box = document.getElementById("chat-overlay-body");
        if (box) renderChatInto(box);
        else render();
        updateChatBadge();
      } catch (err) {
        alert(err.message || "خطا");
      }
    }
    const taEl = document.getElementById("chat-text");
    if (taEl) {
      taEl.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();
          doSendChat();
        }
      });
      // auto-grow
      taEl.addEventListener("input", () => {
        taEl.style.height = "auto";
        taEl.style.height = Math.min(120, taEl.scrollHeight) + "px";
      });
    }
    // فایل: با انتخاب خودکار ارسال نشود — فقط آماده باشد؛ Enter متن را می‌فرستد
    const fiEl = document.getElementById("chat-file");
    if (fiEl) {
      fiEl.onchange = () => {
        if (fiEl.files && fiEl.files[0]) {
          // ارسال فایل به‌محض انتخاب
          doSendChat();
        }
      };
    }

    const voiceBtn = document.getElementById("chat-voice");
    if (voiceBtn) {
      voiceBtn.onclick = async () => {
        if (voiceRecording) {
          stopVoiceRecord(voiceBtn);
          return;
        }
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          voiceChunks = [];
          const mime = MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "";
          voiceRecorder = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
          voiceRecorder.ondataavailable = (e) => { if (e.data && e.data.size) voiceChunks.push(e.data); };
          voiceRecorder.onstop = async () => {
            stream.getTracks().forEach((t) => t.stop());
            const blob = new Blob(voiceChunks, { type: voiceRecorder.mimeType || "audio/webm" });
            const file = new File([blob], "voice-" + Date.now() + ".webm", { type: blob.type });
            try {
              voiceBtn.textContent = "…";
              const fp = await uploadChatFile(file);
              await sendChatMessage(chatRoom, "🎤 پیام صوتی", fp);
              await reload();
              const box = document.getElementById("chat-overlay-body");
              if (box) renderChatInto(box);
              updateChatBadge();
              showToast("ویس ارسال شد", "", "ok");
            } catch (err) {
              alert(err.message || "خطا در ارسال ویس");
            }
            voiceBtn.textContent = "🎤";
            voiceBtn.classList.remove("recording");
            voiceRecording = false;
          };
          voiceRecorder.start();
          voiceRecording = true;
          voiceBtn.classList.add("recording");
          voiceBtn.textContent = "⏹";
          showToast("در حال ضبط", "دوباره بزنید تا ارسال شود", "info");
        } catch (err) {
          alert("دسترسی میکروفون لازم است");
        }
      };
    }
  }

  function stopVoiceRecord(btn) {
    if (voiceRecorder && voiceRecording) {
      voiceRecorder.stop();
      voiceRecording = false;
      if (btn) { btn.classList.remove("recording"); btn.textContent = "🎤"; }
    }
  }

  function openChatOverlay() {
    chatOpen = true;
    ensureChatFab();
    let ov = document.getElementById("chat-overlay");
    if (ov) ov.remove();
    ov = document.createElement("div");
    ov.id = "chat-overlay";
    ov.className = "chat-overlay";
    const company = ((S.settings && (S.settings.company_name || S.settings.name)) || (window.BOOT && BOOT.company_name) || (document.querySelector(".drawer-title") && document.querySelector(".drawer-title").textContent) || "کارگاه").toString().trim();
    ov.innerHTML = `
      <div class="chat-overlay-head tg-overlay-head">
        <button type="button" class="chat-close-btn" id="chat-close" aria-label="بستن">×</button>
        <h2 class="tg-app-title">پیام‌رسان · ${company}</h2>
      </div>
      <div id="chat-overlay-body" style="flex:1;min-height:0;display:flex;flex-direction:column"></div>`;
    document.body.appendChild(ov);
    document.getElementById("chat-close").onclick = closeChatOverlay;
    renderChatInto(document.getElementById("chat-overlay-body"));
  }

  function closeChatOverlay() {
    chatOpen = false;
    stopVoiceRecord();
    const ov = document.getElementById("chat-overlay");
    if (ov) ov.remove();
    ensureChatFab();
  }

  function renderChatPage(root) {
    // سازگاری — به overlay هدایت
    openChatOverlay();
    root.innerHTML = '<div class="empty">چت از دکمه پایین صفحه باز می‌شود</div>';
  }

  function renderChatHistory(root) {
    if (!POLICY.is_manager && POLICY.role !== "management") {
      root.innerHTML = '<div class="card empty">فقط مدیر به مدیریت چت دسترسی دارد.</div>';
      return;
    }

    // —— تصاویر کاربری چت ——
    const avCard = document.createElement("div");
    avCard.className = "card";
    avCard.innerHTML = "<h2>تصویر کاربری چت</h2><p class=\"hint\">برای هر شخص یا پروژه تصویر پیام‌رسان را تنظیم کنید.</p>";
    const avList = document.createElement("div");
    avList.style.cssText = "display:flex;flex-direction:column;gap:8px;max-height:280px;overflow:auto";
    const avatars = Object.assign({}, chatAvatarsMap());
    const peopleAv = allChatPeople();
    (S.customers || []).forEach((c) => {
      if (c.name && !peopleAv.some((p) => p.name === c.name)) peopleAv.push({ name: c.name, role: "customer", kind: "customer" });
    });
    peopleAv.forEach((p) => {
      const row = document.createElement("div");
      row.style.cssText = "display:flex;align-items:center;gap:8px;flex-wrap:wrap";
      const cur = avatars[p.name] || getChatAvatar(p.name) || "";
      row.innerHTML = `<span style="min-width:100px;font-weight:600">${p.name}</span>
        <span class="hint">${roleLabelForChat(p.role)}</span>
        <input type="url" data-av-name="${p.name}" placeholder="آدرس تصویر" value="${cur}" style="flex:1;min-width:140px;padding:6px 8px;border-radius:8px;border:1px solid var(--b)">
        <input type="file" accept="image/*" data-av-file="${p.name}" style="max-width:140px;font-size:.75rem">`;
      avList.appendChild(row);
    });
    avCard.appendChild(avList);
    const avSave = document.createElement("button");
    avSave.type = "button"; avSave.className = "btn"; avSave.style.marginTop = "10px";
    avSave.textContent = "ذخیره تصاویر چت";
    avSave.onclick = async () => {
      const map = {};
      avList.querySelectorAll("input[data-av-name]").forEach((inp) => { if (inp.value.trim()) map[inp.dataset.avName] = inp.value.trim(); });
      for (const fi of avList.querySelectorAll("input[data-av-file]")) {
        if (!fi.files || !fi.files[0]) continue;
        try { map[fi.dataset.avFile] = await uploadChatFile(fi.files[0]); } catch (e) { alert(e.message || "خطا"); return; }
      }
      const res = await api("settings", { payload: { chat_avatars: map } });
      if (!res.ok) { alert(res.error || "خطا"); return; }
      if (S.settings) S.settings.chat_avatars = map;
      showToast("تصاویر چت", "ذخیره شد", "ok");
      render();
    };
    avCard.appendChild(avSave);
    root.appendChild(avCard);

    // —— دسترسی چت ——
    const accCard = document.createElement("div");
    accCard.className = "card";
    accCard.innerHTML = "<h2>دسترسی چت</h2><p class=\"hint\">اگر پرسنل نصاب پروژه باشد یا برای آن پروژه گزارش کار ثبت کند، به‌صورت هوشمند می‌تواند با افراد مرتبط و مشتری چت کند مگر اینکه اینجا قطع کنید.</p>";
    const accMap = Object.assign({}, chatAccessMap());
    const accList = document.createElement("div");
    accList.style.cssText = "display:flex;flex-direction:column;gap:10px";
    (S.personnel || []).forEach((p) => {
      if (!p.name) return;
      const cur = accMap[p.name] || { disabled_projects: [], disable_staff: false };
      const row = document.createElement("div");
      row.style.cssText = "border:1px solid var(--b);border-radius:12px;padding:12px";
      const projs = (S.customers || []).map((c) => c.name).filter(Boolean);
      const projChecks = projs.map((pr) => {
        const on = (cur.disabled_projects || []).includes(pr);
        return `<label style="display:inline-flex;gap:4px;margin:2px 6px;font-size:.8rem"><input type="checkbox" data-dis-proj="${p.name}" value="${pr}" ${on ? "checked" : ""}> قطع ${pr}</label>`;
      }).join("");
      row.innerHTML = `<strong>${p.name}</strong> <span class="hint">${roleLabelForChat(p.role)}</span>
        <div style="margin-top:6px"><label style="font-size:.85rem"><input type="checkbox" data-dis-staff="${p.name}" ${cur.disable_staff ? "checked" : ""}> قطع از گروه کارکنان</label></div>
        <div style="margin-top:6px" class="hint">قطع از پروژه‌ها:</div><div>${projChecks || '<span class="hint">—</span>'}</div>`;
      accList.appendChild(row);
    });
    accCard.appendChild(accList);
    const peerRow = document.createElement("div");
    peerRow.style.marginTop = "12px";
    peerRow.innerHTML = `<label><input type="checkbox" id="chat-allow-peer" ${peerChatAllowed() ? "checked" : ""}> اجازه چت آزاد بین پرسنل (بدون محدودیت پروژه)</label>`;
    accCard.appendChild(peerRow);
    const accSave = document.createElement("button");
    accSave.type = "button"; accSave.className = "btn"; accSave.style.marginTop = "10px";
    accSave.textContent = "ذخیره دسترسی‌ها";
    accSave.onclick = async () => {
      const map = {};
      (S.personnel || []).forEach((p) => {
        if (!p.name) return;
        map[p.name] = {
          disabled_projects: [...accList.querySelectorAll('input[data-dis-proj="'+p.name+'"]:checked')].map((c) => c.value),
          disabled_dms: [],
          disable_staff: !!(accList.querySelector('input[data-dis-staff="'+p.name+'"]') || {}).checked,
        };
      });
      const allowPeer = document.getElementById("chat-allow-peer").checked ? "1" : "0";
      const res = await api("settings", { payload: { chat_access: map, allow_peer_chat: allowPeer } });
      if (!res.ok) { alert(res.error || "خطا"); return; }
      if (S.settings) { S.settings.chat_access = map; S.settings.allow_peer_chat = allowPeer; }
      showToast("دسترسی چت", "ذخیره شد", "ok");
    };
    accCard.appendChild(accSave);
    root.appendChild(accCard);


    // درخواست‌های حذف پیام
    const pend = (S.messages || []).filter((m) => (m.payment_type || "") === "pending_delete");
    if (pend.length) {
      const pdCard = document.createElement("div");
      pdCard.className = "card";
      pdCard.innerHTML = "<h2>درخواست حذف پیام (" + pend.length + ")</h2><p class=\"hint\">کاربر درخواست حذف داده — تأیید = حذف قطعی، رد = برگشت به چت</p>";
      const pdList = document.createElement("div");
      pdList.style.cssText = "display:flex;flex-direction:column;gap:8px";
      pend.forEach((m) => {
        const row = document.createElement("div");
        row.style.cssText = "border:1px solid #fde68a;background:#fffbeb;border-radius:10px;padding:10px";
        row.innerHTML = `<div><strong>${m.sender_name || "—"}</strong> <span class="hint">${(window.J && J.formatChatDate) ? J.formatChatDate(m.created_at) : (m.created_at || "")}</span></div>
          <div style="margin:6px 0">${m.body || (m.file_path ? "[فایل/ویس]" : "—")}</div>`;
        const acts = document.createElement("div");
        acts.style.cssText = "display:flex;gap:8px";
        const ok = document.createElement("button");
        ok.type = "button"; ok.className = "btn btn-sm btn-danger"; ok.textContent = "حذف قطعی";
        ok.onclick = async () => {
          const res = await api("delete", { table: "messages", id: m.id });
          if (!res.ok) {
            // fallback soft
            const r2 = await api("save", { table: "messages", payload: { id: m.id, payment_type: "deleted", body: "[حذف‌شده توسط مدیر]" } });
            if (!r2.ok) { alert(res.error || r2.error || "خطا"); return; }
          }
          await reload(); render();
        };
        const no = document.createElement("button");
        no.type = "button"; no.className = "btn btn-sm btn-outline"; no.textContent = "رد حذف (برگرداندن)";
        no.onclick = async () => {
          const res = await api("save", { table: "messages", payload: { id: m.id, payment_type: "" } });
          if (!res.ok) { alert(res.error || "خطا"); return; }
          await reload(); render();
        };
        acts.appendChild(ok); acts.appendChild(no);
        row.appendChild(acts);
        pdList.appendChild(row);
      });
      pdCard.appendChild(pdList);
      root.appendChild(pdCard);
    }

        const card = document.createElement("div");
    card.className = "card";
    card.innerHTML = "<h2>تاریخچه پیام‌ها</h2><p class=\"hint\">جستجو و فیلتر روی تمام پیام‌های ذخیره‌شده</p>";

    const bar = document.createElement("div");
    bar.className = "chat-filter-bar";
    const people = allChatPeople();
    const opts = people.map((p) => `<option value="${p.name}">${p.name}</option>`).join("");
    const projects = (S.customers || []).map((c) => c.name).filter(Boolean);
    const projOpts = projects.map((p) => `<option value="${p}">${p}</option>`).join("");
    bar.innerHTML = `
      <div class="field"><label>نفر اول</label><select id="ch-p1"><option value="">همه</option>${opts}</select></div>
      <div class="field"><label>نفر دوم</label><select id="ch-p2"><option value="">همه</option>${opts}</select></div>
      <div class="field"><label>فرستنده</label><select id="ch-sender"><option value="">همه</option>${opts}</select></div>
      <div class="field"><label>گروه / پروژه</label><select id="ch-group"><option value="">همه</option><option value="__staff__">گروه کارکنان</option>${projOpts}</select></div>
      <div class="field"><label>از تاریخ</label><input id="ch-from" class="date-field" placeholder="1403/01/01"></div>
      <div class="field"><label>تا تاریخ</label><input id="ch-to" class="date-field" placeholder="1403/12/29"></div>
      <div class="field"><label>جستجوی متن</label><input id="ch-q" type="search" placeholder="کلمه در پیام..."></div>
      <div class="field" style="display:flex;align-items:end"><button type="button" class="btn btn-sm" id="ch-go">اعمال فیلتر</button></div>`;
    card.appendChild(bar);

    const out = document.createElement("div");
    out.id = "ch-out";
    out.style.cssText = "margin-top:12px;display:flex;flex-direction:column;gap:8px;max-height:480px;overflow-y:auto";
    card.appendChild(out);
    root.appendChild(card);

    const apply = () => {
      const p1 = (document.getElementById("ch-p1").value || "").trim();
      const p2 = (document.getElementById("ch-p2").value || "").trim();
      const sender = (document.getElementById("ch-sender").value || "").trim();
      const group = (document.getElementById("ch-group").value || "").trim();
      const from = (document.getElementById("ch-from").value || "").trim();
      const to = (document.getElementById("ch-to").value || "").trim();
      const q = (document.getElementById("ch-q").value || "").trim().toLowerCase();
      let rows = (S.messages || []).slice();
      if (sender) rows = rows.filter((m) => (m.sender_name || "") === sender);
      if (group === "__staff__") rows = rows.filter((m) => m.msg_type === "staff" || m.recipient_name === "__staff__");
      else if (group) rows = rows.filter((m) => (m.project || "") === group);
      if (p1 && p2) {
        rows = rows.filter((m) => {
          const a = m.sender_name || "";
          const b = m.recipient_name || "";
          return (a === p1 && b === p2) || (a === p2 && b === p1);
        });
      } else if (p1) {
        rows = rows.filter((m) => (m.sender_name || "") === p1 || (m.recipient_name || "") === p1);
      } else if (p2) {
        rows = rows.filter((m) => (m.sender_name || "") === p2 || (m.recipient_name || "") === p2);
      }
      if (from) rows = rows.filter((m) => String(m.created_at || "") >= from || String(m.created_at || "").includes(from.replace(/\\//g, "-")));
      if (to) rows = rows.filter((m) => {
        const ca = String(m.created_at || "");
        return ca <= to + " 23:59:59" || ca.includes(to.replace(/\\//g, "-"));
      });
      if (q) rows = rows.filter((m) => String(m.body || "").toLowerCase().includes(q) || String(m.sender_name || "").toLowerCase().includes(q));
      rows.sort((a, b) => String(b.created_at || "").localeCompare(String(a.created_at || "")));
      out.innerHTML = "";
      if (!rows.length) {
        out.innerHTML = '<div class="empty">نتیجه‌ای نیست</div>';
        return;
      }
      rows.forEach((m) => {
        const row = document.createElement("div");
        row.style.cssText = "padding:10px 12px;border:1px solid var(--b);border-radius:10px;background:var(--card)";
        const mt = m.msg_type === "staff" ? "گروه کارکنان" : (m.project ? "پروژه " + m.project : "خصوصی");
        let bodyHtml = m.body || "";
        if (m.file_path && isAudioPath(m.file_path)) {
          bodyHtml += `<div><audio class="chat-audio" controls src="${m.file_path}"></audio></div>`;
        } else if (m.file_path) {
          bodyHtml += `<div class="chat-file"><a href="${m.file_path}" target="_blank">📎 فایل</a></div>`;
        }
        row.innerHTML = `<div style="font-size:.8rem;color:var(--m)">${mt} · ${(window.J && J.formatChatDate) ? J.formatChatDate(m.created_at) : (m.created_at || "")}</div>
          <strong>${m.sender_name || "—"}</strong> → ${m.recipient_name || "—"}
          <div style="margin-top:4px">${bodyHtml}</div>`;
        out.appendChild(row);
      });
    };
    document.getElementById("ch-go").onclick = apply;
    apply();
  }


  const CAT_COLORS = ["#e11d48","#2563eb","#16a34a","#ca8a04","#9333ea","#0891b2","#ea580c","#4f46e5","#db2777","#0d9488","#dc2626","#7c3aed"];

  function renderCategoryPage(root, groupId) {
    const g = MENU_GROUPS[groupId];
    if (!g) {
      root.innerHTML = "<div class=\"card\"><p>دسته یافت نشد.</p></div>";
      return;
    }
    const wrap = document.createElement("div");
    wrap.className = "cat-page";
    const head = document.createElement("div");
    head.className = "cat-page-head";
    const back = document.createElement("button");
    back.type = "button";
    back.className = "btn btn-sm btn-outline";
    back.textContent = "→ بازگشت";
    back.onclick = () => {
      const prev = menuHistory.pop();
      menu = prev && !String(prev).startsWith("cat:") ? prev : "dashboard";
      renderNav();
      renderBottomNav();
      render();
    };
    const title = document.createElement("h2");
    title.textContent = g.label || MENU_LABELS[groupId] || "دسته";
    head.appendChild(back);
    head.appendChild(title);
    wrap.appendChild(head);

    const grid = document.createElement("div");
    grid.className = "cat-grid";
    let items = [];
    if (g.keepSelf) {
      items.push({ id: groupId, label: g.label || MENU_LABELS[groupId], icon: g.icon || MENU_ICONS[groupId] });
    }
    groupChildren(groupId).forEach((cid) => {
      items.push({ id: cid, label: MENU_LABELS[cid], icon: MENU_ICONS[cid] || "◆" });
    });
    if (groupId === "persons_group" && POLICY.is_manager) {
      items.push({ id: "__add_person_folder", label: "افزودن پوشه", icon: "➕" });
    }
    items.forEach((it, i) => {
      const tile = document.createElement("button");
      tile.type = "button";
      tile.className = "cat-tile";
      const color = CAT_COLORS[i % CAT_COLORS.length];
      tile.innerHTML = `<span class="cat-tile-icon" style="background:${color}">${it.icon}</span><span class="cat-tile-label">${it.label}</span>`;
      tile.onclick = () => {
        if (it.id === "__add_person_folder") {
          const name = prompt("نام پوشه / دسته اشخاص:");
          if (name && name.trim()) {
            const folders = Array.isArray(PREFS.personFolders) ? PREFS.personFolders : [];
            folders.push(name.trim());
            PREFS.personFolders = folders;
            if (typeof savePrefs === "function") savePrefs(PREFS);
            alert("پوشه «" + name.trim() + "» اضافه شد.");
            renderCategoryPage(root, groupId);
          }
          return;
        }
        goMenu(it.id);
      };
      grid.appendChild(tile);
    });
    wrap.appendChild(grid);
    // فضای خالی پایین عمدی — مثل الگوی آچاره
    const spacer = document.createElement("div");
    spacer.className = "cat-page-spacer";
    wrap.appendChild(spacer);
    root.innerHTML = "";
    root.appendChild(wrap);
  }

  function render() {

    const root = document.getElementById("content");
    const titleEl = document.getElementById("page-title");
    // صفحه دسته‌بندی گروه (اشخاص، حسابداری، …) — قبل از پاک کردن محتوا
    if (String(menu).startsWith("cat:")) {
      const gid = menu.slice(4);
      const g = MENU_GROUPS[gid];
      if (titleEl) titleEl.textContent = (g && g.label) || MENU_LABELS[gid] || "دسته";
      root.innerHTML = "";
      closeHelpPopover();
      renderCategoryPage(root, gid);
      setTimeout(() => { try { injectHelpIcons(); ensureChatFab(); } catch (e) {} }, 40);
      return;
    }
    if (titleEl) titleEl.textContent = MENU_LABELS[menu] || menu;
    root.innerHTML = "";
    closeHelpPopover();
    // دکمه بازگشت به صفحه قبل
    if (menuHistory.length > 0 && menu !== "dashboard" && menu !== "emp_dashboard" && menu !== "cust_home") {
      const backBar = document.createElement("div");
      backBar.className = "back-bar";
      backBar.style.cssText = "margin-bottom:12px;display:flex;align-items:center;gap:8px";
      const backBtn = document.createElement("button");
      backBtn.type = "button";
      backBtn.className = "btn btn-sm btn-outline";
      backBtn.innerHTML = "← بازگشت";
      backBtn.onclick = () => {
        const prev = menuHistory.pop();
        if (prev) {
          menu = prev;
          renderNav();
          renderBottomNav();
          render();
        }
      };
      backBar.appendChild(backBtn);
      root.appendChild(backBar);
    }
    renderDirectiveBanners(root);
    const _finish = () => { setTimeout(() => { injectHelpIcons(); ensureChatFab(); }, 40); };
    if (window.SamanehModules && window.SamanehModules.render && window.SamanehModules.render(menu, root, S, USER, { api, reload, openModal })) { _finish(); return; }
if (menu === "dashboard" || menu === "emp_dashboard") { renderDashboard(root); _finish(); return; }
    if (menu === "emp_tasks") { renderEmpTasks(root); _finish(); return; }
    if (menu === "emp_projects") { renderEmpProjects(root); _finish(); return; }
    if (menu === "installments") { renderInstallments(root); _finish(); return; }
    if (menu === "work_sites") { renderWorkSites(root); _finish(); return; }
    if (menu === "att_map") { renderAttendanceMap(root); _finish(); return; }
    if (menu === "emp_attendance" || menu === "attendance") { renderSmartAttendance(root); _finish(); return; }
    if (menu === "finance") {
      renderFinancePage(root);
      _finish(); return;
    }
    if (menu === "warehouse") {
      renderWarehousePage(root);
      _finish(); return;
    }
    if (menu === "emp_messages") {
      renderProjectMessages(root);
      _finish(); return;
    }
    if (menu === "customers") {
      renderCustomersPage(root);
      _finish(); return;
    }
    if (menu === "salary") {
      renderSalaryPage(root);
      _finish(); return;
    }
    if (menu === "personnel") {
      renderPersonnelPage(root);
      _finish(); return;
    }
    if (menu === "invoices") {
      if (!(POLICY.is_manager || POLICY.role === "warehouse")) { menu = "dashboard"; renderNav(); render(); return; }
      renderInvoicesPage(root); _finish(); return;
    }
    if (menu === "settings") {
      if (!POLICY.is_manager) { menu = "dashboard"; renderNav(); render(); return; }
      renderSettings(root); _finish(); return;
    }
    if (menu === "menu_order") { renderMenuOrder(root); _finish(); return; }
    if (menu === "cust_home" || menu === "cust_project" || menu === "cust_finance") {
      renderCustomerView(root, menu);
      _finish(); return;
    }
    if (menu === "roles") { renderRoles(root); _finish(); return; }
    if (menu === "chat") { renderChatPage(root); _finish(); return; }
    if (menu === "chat_history") { renderChatHistory(root); _finish(); return; }
    const table = TABLE_FOR[menu];
    if (table === "daily_reports" && (POLICY.is_manager || POLICY.role === "warehouse")) {
      const filt = document.createElement("div");
      filt.className = "card";
      filt.innerHTML = `<h2>گزارش روزانه</h2>
        <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:end">
          <div class="field" style="margin:0"><label>از تاریخ</label><input id="dr-from" class="date-field" placeholder="1403/01/01"></div>
          <div class="field" style="margin:0"><label>تا تاریخ</label><input id="dr-to" class="date-field" placeholder="1403/01/31"></div>
          <button type="button" class="btn btn-sm" id="dr-go">اعمال</button>
        </div>`;
      root.appendChild(filt);
      const draw = () => {
        const old = root.querySelector("[data-dr-table]");
        if (old) old.remove();
        const from = (document.getElementById("dr-from").value || "").trim();
        const to = (document.getElementById("dr-to").value || "").trim();
        const wrap = document.createElement("div");
        wrap.setAttribute("data-dr-table", "1");
        wrap.appendChild(crudTable("daily_reports", "گزارش‌ها", {
          filterFn: (r) => {
            const d = r.report_date || "";
            if (from && d < from) return false;
            if (to && d > to) return false;
            return true;
          },
        }));
        root.appendChild(wrap);
      };
      filt.querySelector("#dr-go").onclick = draw;
      draw();
      _finish(); return;
    }
    if (table) {
      const opts = {};
      if (POLICY.is_employee && table === "directives") opts.noAdd = true;
      // فیلترهای آماری داشبورد (مثلاً فقط در انتظار)
      if (window.__dashFilter === "pending_leave" && table === "leave_requests") {
        opts.filterFn = (r) => r.status === "در انتظار" || !r.status;
        window.__dashFilter = null;
      }
      if (window.__dashFilter === "pending_ot" && table === "overtime") {
        opts.filterFn = (r) => r.status === "در انتظار" || !r.status;
        window.__dashFilter = null;
      }
      if (window.__dashFilter === "pending_return" && table === "stock_usage") {
        opts.filterFn = (r) => r.kind === "بازگشت" && (r.status === "در انتظار تأیید" || r.status === "در انتظار");
        window.__dashFilter = null;
      }
      if (window.__dashFilter === "open_dirs" && table === "directives") {
        opts.filterFn = (d) => d.status === "باز" || !d.status;
        window.__dashFilter = null;
      }
      if (window.__dashFilter === "low_stock" && table === "stock_items") {
        opts.filterFn = (i) => {
          const qty = parseFloat(i.qty) || 0;
          const min = parseFloat(i.min_qty) || 0;
          return min > 0 && qty <= min;
        };
        window.__dashFilter = null;
      }
      root.appendChild(crudTable(table, MENU_LABELS[menu] || menu, opts));
      _finish(); return;
    }
    root.innerHTML = '<div class="empty">این بخش یافت نشد.</div>';
    _finish();
  }

  document.getElementById("modal-close").onclick = closeModal;
  document.getElementById("modal-cancel").onclick = closeModal;
  document.getElementById("modal-save").onclick = saveModal;
  document.getElementById("modal").addEventListener("click", (e) => { if (e.target.id === "modal") closeModal(); });

  function renderSocialFooter() {
    const foot = document.querySelector(".drawer-foot");
    if (!foot) return;
    let box = foot.querySelector(".social-footer");
    if (!box) {
      box = document.createElement("div");
      box.className = "social-footer";
      box.style.cssText = "display:flex;flex-wrap:wrap;gap:8px;margin-bottom:8px;font-size:.8rem";
      foot.insertBefore(box, foot.firstChild);
    }
    const st = (S && S.settings) || {};
    const items = [
      { k: "social_instagram", l: "اینستاگرام" },
      { k: "social_telegram", l: "تلگرام" },
      { k: "social_whatsapp", l: "واتساپ" },
      { k: "social_linkedin", l: "لینکدین" },
      { k: "social_aparat", l: "آپارات" },
      { k: "social_website", l: "وب‌سایت" },
    ];
    const links = items.map(({ k, l }) => {
      let href = (st[k] || "").trim();
      if (!href) return "";
      if (k === "social_whatsapp" && !/^https?:\/\//i.test(href)) {
        href = "https://wa.me/" + href.replace(/[^\d+]/g, "").replace(/^\+/, "");
      }
      return `<a href="${href}" target="_blank" rel="noopener" title="${l}" style="color:#94a3b8;text-decoration:none">${l}</a>`;
    }).filter(Boolean);
    box.innerHTML = links.join("") || "";
    box.style.display = links.length ? "flex" : "none";
  }

  window.SamanehCore = { api, reload, openModal, getState: () => S };

  function init() {
    initTheme();
    bindAutoEnglishDigits(document);
    // تبلت و دسکتاپ: منو باز؛ گوشی: بسته
    try {
      if (window.matchMedia && window.matchMedia("(min-width: 801px)").matches) {
        openDrawer();
      }
    } catch (e) {}
    const menuBtn = document.getElementById("menu-btn");
    const closeBtn = document.getElementById("drawer-close");
    const overlay = document.getElementById("drawer-overlay");
    function isDesk() {
      return window.matchMedia && window.matchMedia("(min-width: 801px)").matches;
    }
    function toggleDrawer() {
      const d = document.getElementById("drawer");
      if (d && d.classList.contains("open")) closeDrawer();
      else openDrawer();
    }
    if (menuBtn) menuBtn.onclick = () => { if (isDesk()) toggleDrawer(); else openDrawer(); };
    if (closeBtn) closeBtn.onclick = closeDrawer;
    if (overlay) overlay.onclick = closeDrawer;
    const ms = document.getElementById("menu-search");
    if (ms) {
      ms.oninput = filterMenuSearch;
      ms.onkeyup = filterMenuSearch;
      ms.onchange = filterMenuSearch;
    }
    const th1 = document.getElementById("btn-theme-toggle");
    const th2 = document.getElementById("btn-theme-toggle-header");
    if (th1) th1.onclick = toggleTheme;
    if (th2) th2.onclick = toggleTheme;
    const helpTour = document.getElementById("btn-help-tour");
    if (helpTour) helpTour.onclick = () => { closeDrawer(); startTour(); };
    const helpModeBtn = document.getElementById("btn-help-mode");
    if (helpModeBtn) helpModeBtn.onclick = () => { toggleHelpMode(); closeDrawer(); };
    // اندازه متن — delegation تا همیشه کار کند
    function bumpFont(delta) {
      const cur = Number(PREFS.fontSize) || 15;
      const next = Math.max(12, Math.min(22, cur + delta));
      PREFS.fontSize = next;
      savePrefs(PREFS);
      applyPrefs();
      // اعمال فوری روی html برای همه rem/em
      document.documentElement.style.fontSize = next + "px";
      document.documentElement.style.setProperty("--font-size-base", next + "px");
      document.body.style.fontSize = "";
      const fsd = document.getElementById("font-size-display");
      if (fsd) fsd.textContent = String(next);
      if (typeof showToast === "function") {
        showToast("اندازه متن", next + " پیکسل", delta > 0 ? "ok" : "info");
      }
    }
    document.addEventListener("click", (e) => {
      const t = e.target && e.target.closest ? e.target.closest("#btn-font-plus, #btn-font-minus") : null;
      if (!t) return;
      e.preventDefault();
      e.stopPropagation();
      if (t.id === "btn-font-plus") bumpFont(1);
      else bumpFont(-1);
    }, true);
    const fontPlus = document.getElementById("btn-font-plus");
    const fontMinus = document.getElementById("btn-font-minus");
    if (fontPlus) fontPlus.onclick = (e) => { e.preventDefault(); bumpFont(1); };
    if (fontMinus) fontMinus.onclick = (e) => { e.preventDefault(); bumpFont(-1); };
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeDrawer(); });
    // مشتری: اولین ورود منو باز باشد
    try {
      if (POLICY.is_customer || POLICY.role === "customer") {
        const k = "samaneh_drawer_seen_" + (INSTANCE_ID || 1);
        if (!localStorage.getItem(k)) {
          localStorage.setItem(k, "1");
          setTimeout(openDrawer, 300);
        }
      }
    } catch (e) {}
    renderSocialFooter();
    const m = menus();
    menu = (m[0] && m[0].id) || "dashboard";
    renderNav();
    renderBottomNav();
    render();
    ensureChatFab();
    // تور اولین ورود
    try {
      if (!PREFS.tourDone && (POLICY.is_manager || POLICY.role === "warehouse")) {
        setTimeout(() => startTour(), 600);
      }
    } catch (e) {}
    // نوتیف چک‌های نزدیک سررسید
    setTimeout(() => {
      requestNotifPermission().then(() => checkDueSoonNotifs());
    }, 1500);
    // به‌روزرسانی چت زنده
    setInterval(async () => {
      try {
        await reload();
        updateChatBadge();
        if (chatOpen) {
          const box = document.getElementById("chat-overlay-body");
          if (box) renderChatInto(box);
        }
        if (menu === "chat_history") render();
      } catch (e) {}
    }, 12000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
