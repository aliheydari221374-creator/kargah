<?php
/**
 * Plugin Name: کارگاه آماده (Samaneh Core)
 * Description: کارگاه آماده زاگرس — پنل مدیریت کارگاه، متصل به زاگرس کنترل، سفارش از /panel، اقساط و پشتیبانی.
 * Version: 3.5.5
 * نویسنده: Zagroos
 * Text Domain: samaneh-core
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit;
}

define('SAMANEH_CORE_VERSION', '3.5.5');
define('SAMANEH_CORE_FILE', __FILE__);
define('SAMANEH_CORE_DIR', plugin_dir_path(__FILE__));
define('SAMANEH_CORE_URL', plugin_dir_url(__FILE__));

require_once SAMANEH_CORE_DIR . 'includes/helpers.php';
require_once SAMANEH_CORE_DIR . 'includes/class-jalali.php';
require_once SAMANEH_CORE_DIR . 'includes/class-grants.php';
require_once SAMANEH_CORE_DIR . 'includes/class-reserved-slugs.php';
require_once SAMANEH_CORE_DIR . 'includes/class-instances.php';
require_once SAMANEH_CORE_DIR . 'includes/class-workshop-bridge.php';
require_once SAMANEH_CORE_DIR . 'includes/class-roles.php';
require_once SAMANEH_CORE_DIR . 'includes/class-db.php';
require_once SAMANEH_CORE_DIR . 'includes/class-stock.php';
require_once SAMANEH_CORE_DIR . 'includes/class-backup.php';
require_once SAMANEH_CORE_DIR . 'includes/class-auth.php';
require_once SAMANEH_CORE_DIR . 'includes/class-rbac.php';
require_once SAMANEH_CORE_DIR . 'includes/class-modules.php';
require_once SAMANEH_CORE_DIR . 'includes/class-login.php';
require_once SAMANEH_CORE_DIR . 'includes/class-api.php';
require_once SAMANEH_CORE_DIR . 'includes/class-router.php';

final class Samaneh_Core {

    private static $instance = null;

    public static function instance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        register_activation_hook(SAMANEH_CORE_FILE, [$this, 'activate']);
        register_deactivation_hook(SAMANEH_CORE_FILE, [$this, 'deactivate']);

        add_action('init', [$this, 'init']);
        if (class_exists('Samaneh_Backup')) {
            Samaneh_Backup::schedule_hooks();
        }
        add_action('admin_menu', [$this, 'admin_menu']);
        add_filter('query_vars', [$this, 'query_vars']);
        add_action('template_redirect', ['Samaneh_Login', 'maybe_serve'], 5);
        add_action('template_redirect', ['Samaneh_Router', 'maybe_serve'], 10);
        add_filter('login_redirect', [$this, 'login_redirect'], 20, 3);
        add_action('plugins_loaded', ['Samaneh_Modules', 'load'], 20);
        Samaneh_Instances::hook_woocommerce();
        if (class_exists('Samaneh_Workshop_Bridge')) { Samaneh_Workshop_Bridge::init(); }
        if (class_exists('Samaneh_Reserved_Slugs')) { Samaneh_Reserved_Slugs::init(); }

        if (is_multisite()) {
            add_action('wp_initialize_site', [$this, 'on_new_site'], 20, 1);
            add_action('network_admin_menu', [$this, 'network_admin_menu']);
            add_action('network_admin_notices', [$this, 'network_grants_notice']);
        }
    }

    /** سازگاری — اسلاگ پنل اول */
    public static function panel_slug(): string {
        $inst = Samaneh_Instances::get(1);
        return $inst['slug'] ?? 'panel';
    }

    public static function panel_url(int $id = 1): string {
        $inst = Samaneh_Instances::get($id);
        $slug = $inst['slug'] ?? 'panel';
        return home_url('/' . $slug . '/');
    }

    public function activate($network_wide = false): void {
        if (is_multisite() && $network_wide) {
            foreach (get_sites(['fields' => 'ids', 'number' => 0]) as $blog_id) {
                switch_to_blog((int) $blog_id);
                $this->activate_site();
                restore_current_blog();
            }
        } else {
            $this->activate_site();
        }
    }

    private function activate_site(): void {
        if (get_option(Samaneh_Instances::OPT_SLOTS) === false) {
            add_option(Samaneh_Instances::OPT_SLOTS, 1, '', false);
        }
        Samaneh_Instances::all(); // اطمینان از وجود پنل ۱
        Samaneh_Roles::all();
        Samaneh_DB::create_tables();
        $dirs = [SAMANEH_CORE_DIR . 'data', SAMANEH_CORE_DIR . 'uploads'];
        foreach ($dirs as $dir) {
            if (!is_dir($dir)) {
                wp_mkdir_p($dir);
            }
        }
        $up = SAMANEH_CORE_DIR . 'uploads/.htaccess';
        if (!file_exists($up)) {
            file_put_contents($up, "Options -Indexes\n<FilesMatch \"\\.(jpg|jpeg|png|gif|webp|mp3|ogg|wav|webm|pdf)$\">\n  Allow from all\n</FilesMatch>\n");
        }
        Samaneh_Instances::register_rewrites();
        Samaneh_Reserved_Slugs::persist();
        if (class_exists('Samaneh_Backup')) {
            Samaneh_Backup::schedule_hooks();
            // یک بکاپ اولیه در پس‌زمینه (غیربلاک‌کننده با cron)
            if (!wp_next_scheduled('samaneh_auto_backup_event')) {
                wp_schedule_single_event(time() + 60, 'samaneh_auto_backup_event');
            }
        }
        flush_rewrite_rules();
    }

    public function on_new_site($site): void {
        $blog_id = is_object($site) ? (int) $site->blog_id : (int) $site;
        if ($blog_id < 1) {
            return;
        }
        switch_to_blog($blog_id);
        $this->activate_site();
        restore_current_blog();
    }

    public function deactivate(): void {
        if (class_exists('Samaneh_Backup')) {
            Samaneh_Backup::unschedule_hooks();
        }
        flush_rewrite_rules();
    }

    public function init(): void {
        Samaneh_Instances::register_rewrites();
        if (function_exists('is_admin') && is_admin() && Samaneh_Auth::is_network_admin()) {
            Samaneh_Reserved_Slugs::persist();
        }
    }

    public function query_vars(array $vars): array {
        $vars[] = 'samaneh_panel';
        $vars[] = 'samaneh_panel_api';
        $vars[] = 'samaneh_login';
        $vars[] = 'samaneh_instance';
        return $vars;
    }

    public function login_redirect($redirect_to, $requested, $user) {
        if (is_wp_error($user) || !($user instanceof WP_User)) {
            return $redirect_to;
        }
        if (Samaneh_Auth::can_access()) {
            return self::panel_url(1);
        }
        return $redirect_to;
    }

    public function admin_menu(): void {
        add_menu_page(
            'سامانه هسته',
            'سامانه هسته',
            'manage_options',
            'samaneh-core',
            [$this, 'admin_page'],
            'dashicons-admin-generic',
            58
        );
        add_submenu_page(
            'samaneh-core',
            'پنل‌های کارگاه',
            'پنل‌های کارگاه',
            'manage_options',
            'samaneh-core',
            [$this, 'admin_page']
        );
        add_submenu_page(
            'samaneh-core',
            'افزودن ماژول',
            'افزودن ماژول',
            'manage_options',
            'samaneh-modules',
            [$this, 'admin_modules_page']
        );
        add_submenu_page(
            'samaneh-core',
            'بکاپ و بازیابی',
            'بکاپ و بازیابی',
            'manage_options',
            'samaneh-backup',
            [$this, 'admin_backup_page']
        );
        // بایگانی حذف‌شده‌ها و کاربر تستر فقط برای ادمین شبکه (سوپرادمین)
        if (is_super_admin()) {
            add_submenu_page(
                'samaneh-core',
                'بایگانی حذف‌شده‌ها',
                'بایگانی حذف‌شده‌ها',
                'manage_options',
                'samaneh-archives',
                [$this, 'admin_archives_page']
            );
            add_submenu_page(
                'samaneh-core',
                'کاربر تستر کارگاه',
                'کاربر تستر کارگاه',
                'manage_options',
                'samaneh-testers',
                [$this, 'admin_testers_page']
            );
        }
    }

    public function admin_page(): void {
        if (isset($_POST['samaneh_admin_save']) && check_admin_referer('samaneh_admin')) {
            try {
                if (!empty($_POST['create_instance'])) {
                    $inst = Samaneh_Instances::create(
                        sanitize_title($_POST['new_slug'] ?? ''),
                        sanitize_text_field(wp_unslash($_POST['new_name'] ?? ''))
                    );
                    echo '<div class="updated"><p>پنل جدید ساخته شد: <a href="' . esc_url(home_url('/' . $inst['slug'] . '/')) . '">' . esc_html($inst['slug']) . '</a></p></div>';
                }
                if (isset($_POST['inst_id'])) {
                    $id = (int) $_POST['inst_id'];
                    $data = [
                        'name' => sanitize_text_field(wp_unslash($_POST['inst_name'] ?? '')),
                    ];
                    // اسلاگ فقط توسط ادمین شبکه و واقعاً ذخیره + بازنویسی قوانین آدرس
                    if (Samaneh_Auth::is_network_admin() && isset($_POST['inst_slug'])) {
                        $data['slug'] = sanitize_title(wp_unslash($_POST['inst_slug']));
                    }
                    if (!empty($_POST['inst_logo_url'])) {
                        $data['logo'] = esc_url_raw(wp_unslash($_POST['inst_logo_url']));
                    }
                    $saved_inst = Samaneh_Instances::save($id, $data);
                    // مدیر کل = ردیف پرسنل با is_main (نه کاربر وردپرس)
                    if (Samaneh_Auth::is_network_admin()) {
                        $m_name = sanitize_text_field(wp_unslash($_POST['main_mgr_name'] ?? ''));
                        $m_phone = sanitize_text_field(wp_unslash($_POST['main_mgr_phone'] ?? ''));
                        $m_pass = (string) ($_POST['main_mgr_pass'] ?? '');
                        if ($m_name !== '' || $m_phone !== '') {
                            if ($m_name === '') {
                                throw new RuntimeException('نام مدیر کل را وارد کنید.');
                            }
                            Samaneh_DB::set_instance($id);
                            Samaneh_DB::create_tables_for($id);
                            Samaneh_DB::ensure_password_column_public('personnel');
                            global $wpdb;
                            $pt = Samaneh_DB::table('personnel');
                            // phpcs:ignore
                            $existing_main = $wpdb->get_row("SELECT * FROM `{$pt}` WHERE is_main = 1 LIMIT 1", ARRAY_A);
                            // اگر ستون is_main تازه ساخته شده و ردیفی نیست، با نام/موبایل هم جستجو کن
                            if (!$existing_main && $m_phone !== '') {
                                // phpcs:ignore
                                $existing_main = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$pt}` WHERE phone = %s LIMIT 1", $m_phone), ARRAY_A);
                            }
                            if (!$existing_main && $m_name !== '') {
                                // phpcs:ignore
                                $existing_main = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$pt}` WHERE name = %s LIMIT 1", $m_name), ARRAY_A);
                            }
                            $payload = [
                                'name'    => $m_name,
                                'phone'   => $m_phone,
                                'role'    => 'management',
                                'is_main' => 1,
                            ];
                            if ($m_pass !== '') {
                                $payload['password'] = $m_pass;
                            } elseif (empty($existing_main['password'])) {
                                throw new RuntimeException('برای مدیر کل حتماً یک رمز عبور وارد کنید.');
                            }
                            if ($existing_main) {
                                $payload['id'] = (int) $existing_main['id'];
                            }
                            $saved_p = Samaneh_DB::save('personnel', $payload);
                            $pid = (int) ($saved_p['id'] ?? 0);
                            if ($pid < 1) {
                                throw new RuntimeException('ذخیره مدیر کل در دیتابیس ناموفق بود.');
                            }
                            // فقط یک مدیر کل + نقش management
                            // phpcs:ignore
                            $wpdb->query($wpdb->prepare("UPDATE `{$pt}` SET is_main = 0 WHERE id != %d", $pid));
                            // phpcs:ignore
                            $wpdb->update($pt, ['is_main' => 1, 'role' => 'management'], ['id' => $pid]);
                            // تأیید نهایی که رمز ذخیره شده
                            // phpcs:ignore
                            $check = $wpdb->get_row($wpdb->prepare("SELECT id, name, phone, password, role, is_main FROM `{$pt}` WHERE id = %d", $pid), ARRAY_A);
                            if (!$check || empty($check['password'])) {
                                throw new RuntimeException('رمز مدیر کل در دیتابیس ذخیره نشد. دوباره با رمز جدید ذخیره کنید.');
                            }
                            $login_hint = $check['phone'] !== '' ? $check['phone'] : $check['name'];
                            echo '<div class="updated"><p>مدیر کل ذخیره شد. ورود با تب «پرسنل / مدیر»: <strong>' . esc_html($login_hint) . '</strong> و رمزی که وارد کردید.</p></div>';
                        }
                    }
                    if (!empty($data['slug'])) {
                        flush_rewrite_rules(true);
                    }
                    echo '<div class="updated"><p>ذخیره شد.';
                    if (!empty($saved_inst['slug'])) {
                        echo ' آدرس پنل: <a href="' . esc_url(home_url('/' . $saved_inst['slug'] . '/')) . '" target="_blank">' . esc_html(home_url('/' . $saved_inst['slug'] . '/')) . '</a>';
                    }
                    echo '</p></div>';
                }
            } catch (Throwable $e) {
                echo '<div class="error"><p>' . esc_html($e->getMessage()) . '</p></div>';
            }
        }

        $instances = Samaneh_Instances::all();
        $slots = Samaneh_Instances::max_slots();
        $used = count($instances);
        $prefix = Samaneh_DB::prefix();

        $buy_url = Samaneh_Instances::product_url();
        echo '<div class="wrap"><h1>سامانه هسته — پنل‌های کارگاه</h1>';
        echo '<p>اسلات پنل فعال: <strong>' . (int) $used . ' / ' . (int) $slots . '</strong>';
        if ($used >= $slots) {
            echo '</p><div class="notice notice-warning"><p>سقف پنل پر است. برای افزودن کارگاه بعدی باید محصول <strong>پنل کارگاه بعدی</strong> را از فروشگاه شبکه خریداری کنید:</p>';
            echo '<p><a class="button button-primary" href="' . esc_url($buy_url) . '" target="_blank" rel="noopener">خرید پنل کارگاه بعدی از zagroos.com</a></p>';
            echo '<p class="description">هر خرید موفق = یک اسلات اضافه. برای دو کارگاه اضافی باید دو بار خرید کنید (یا تعداد ۲ در سبد).</p></div><p>';
        }
        echo '</p>';

        foreach ($instances as $inst) {
            $url = home_url('/' . $inst['slug'] . '/');
            $login = home_url('/' . $inst['slug'] . '/login/');
            echo '<div style="background:#fff;border:1px solid #ccd0d4;padding:16px;margin:12px 0;max-width:560px;">';
            echo '<h2>پنل #' . (int) $inst['id'] . '</h2>';
            echo '<p><a class="button button-primary" href="' . esc_url($url) . '" target="_blank">باز کردن پنل</a> ';
            echo '<a class="button" href="' . esc_url($login) . '" target="_blank">صفحه ورود</a></p>';
            echo '<form method="post">';
            wp_nonce_field('samaneh_admin');
            echo '<input type="hidden" name="inst_id" value="' . (int) $inst['id'] . '">';
            echo '<table class="form-table">';
            echo '<tr><th>نام کارگاه</th><td><input name="inst_name" class="regular-text" value="' . esc_attr($inst['name'] ?? '') . '"></td></tr>';
            if (Samaneh_Auth::is_network_admin()) {
                echo '<tr><th>آدرس (اسلاگ)</th><td><code>' . esc_html(home_url('/')) . '</code><input name="inst_slug" value="' . esc_attr($inst['slug'] ?? '') . '" style="width:140px" pattern="[a-z0-9\\-]+" title="فقط حروف انگلیسی کوچک، عدد و خط تیره">';
                echo '<p class="description">بعد از تغییر اسلاگ، آدرس جدید فعال می‌شود. یک‌بار ذخیره کافی است.</p></td></tr>';
            } else {
                echo '<tr><th>آدرس (اسلاگ)</th><td><code>' . esc_html(home_url('/' . ($inst['slug'] ?? '') . '/')) . '</code>';
                echo '<p class="description">فقط مدیر شبکه می‌تواند آدرس را تغییر دهد.</p></td></tr>';
            }
            echo '<tr><th>آدرس لوگو</th><td><input name="inst_logo_url" class="large-text" value="' . esc_attr($inst['logo'] ?? '') . '" placeholder="https://...">';
            echo '<p class="description">از رسانه وردپرس آپلود کنید و URL را اینجا بگذارید.</p></td></tr>';
            // مدیر کل از جدول پرسنل همان کارگاه — بدون کاربر وردپرس
            Samaneh_DB::set_instance((int) $inst['id']);
            $main_row = null;
            try {
                Samaneh_DB::create_tables_for((int) $inst['id']);
                global $wpdb;
                $pt = Samaneh_DB::table('personnel');
                // phpcs:ignore
                $main_row = $wpdb->get_row("SELECT * FROM `{$pt}` WHERE is_main = 1 LIMIT 1", ARRAY_A);
            } catch (Throwable $e) {
                $main_row = null;
            }
            echo '<tr><th>مدیر کل کارگاه</th><td>';
            if (Samaneh_Auth::is_network_admin()) {
                echo '<p style="margin:0 0 8px"><strong>بدون کاربر وردپرس</strong> — فقط در جدول پرسنل همین کارگاه ذخیره می‌شود.</p>';
                echo '<p>نام: <input name="main_mgr_name" class="regular-text" value="' . esc_attr($main_row['name'] ?? '') . '" placeholder="نام مدیر کل"></p>';
                echo '<p>موبایل: <input name="main_mgr_phone" class="regular-text" value="' . esc_attr($main_row['phone'] ?? '') . '" placeholder="09..." dir="ltr"></p>';
                echo '<p>رمز ورود: <input type="password" name="main_mgr_pass" class="regular-text" value="" placeholder="' . ($main_row ? 'خالی = بدون تغییر رمز' : 'رمزی برای ورود به پنل') . '" autocomplete="new-password"></p>';
                echo '<p class="description">مدیر کل با تب «پرسنل / مدیر» در صفحه ورود پنل، با موبایل یا نام + رمز وارد می‌شود. می‌تواند مدیران عادی اضافه کند؛ فقط شما می‌توانید مدیر کل را عوض کنید.</p>';
            } else {
                if ($main_row) {
                    echo '<strong>' . esc_html(($main_row['name'] ?? '') . ' — ' . ($main_row['phone'] ?? '')) . '</strong>';
                } else {
                    echo '— هنوز تعیین نشده —';
                }
                echo '<p class="description">فقط مدیر شبکه می‌تواند مدیر کل را تعیین کند.</p>';
            }
            echo '</td></tr>';
            echo '</table>';
            echo '<p><button class="button button-primary" name="samaneh_admin_save" value="1">ذخیره این پنل</button></p>';
            echo '</form></div>';
        }

        if ($used < $slots) {
            echo '<div style="background:#f0fdf4;border:1px solid #86efac;padding:16px;margin:12px 0;max-width:560px;">';
            echo '<h2>افزودن کارگاه بعدی</h2>';
            echo '<p class="description">اسلات آزاد دارید. کارگاه جدید بسازید (دیتای جدا از پنل‌های قبلی).</p>';
            echo '<form method="post">';
            wp_nonce_field('samaneh_admin');
            echo '<input type="hidden" name="create_instance" value="1">';
            echo '<input type="hidden" name="samaneh_admin_save" value="1">';
            echo '<p>نام کارگاه: <input name="new_name" class="regular-text" required> ';
            echo 'آدرس (اسلاگ): <input name="new_slug" placeholder="panel2" style="width:120px"></p>';
            echo '<p><button type="submit" class="button button-primary">ساخت پنل کارگاه جدید</button></p>';
            echo '</form></div>';
        } else {
            echo '<div style="background:#fff7ed;border:1px solid #fed7aa;padding:16px;margin:12px 0;max-width:560px;">';
            echo '<h2>افزودن کارگاه بعدی</h2>';
            echo '<p>برای داشتن پنل دوم/سوم باید محصول را از سایت اصلی شبکه بخرید:</p>';
            echo '<p><a class="button button-primary" href="' . esc_url($buy_url) . '" target="_blank" rel="noopener">خرید از zagroos.com</a></p>';
            echo '</div>';
        }

        echo '<h2>فنی</h2><ul>';
        echo '<li>پیشوند جدول پنل فعلی: <code>' . esc_html($prefix) . '</code></li>';
        echo '<li>Multisite: ' . (is_multisite() ? 'بله' : 'خیر') . '</li>';
        echo '<li>داده اولیه: هیچ</li>';
        echo '</ul>';
        echo '<p><strong>نکته پیوندهای یکتا:</strong> بعد از تغییر اسلاگ، یک‌بار به تنظیمات ← پیوندهای یکتا بروید و Save را بزنید تا آدرس جدید کار کند.</p>';
        echo '</div>';
    }

    public function admin_modules_page(): void {
        $modules_catalog = apply_filters('samaneh_modules_catalog', [
            [
                'slug'  => 'customers-pro',
                'name'  => 'مشتریان پیشرفته',
                'desc'  => 'چهار دسته مشتری، مراحل قفل‌شونده، کارپوشه و چت پروژه',
                'url'   => 'https://zagroos.com/',
                'price' => 'به‌زودی',
            ],
            [
                'slug'  => 'warehouse-pro',
                'name'  => 'انبار و تولید',
                'desc'  => 'جداول یراق، برش، CNC، نوار، وکیوم، رنگ، مونتاژ',
                'url'   => 'https://zagroos.com/',
                'price' => 'به‌زودی',
            ],
            [
                'slug'  => 'finance-pro',
                'name'  => 'حسابداری و فاکتور',
                'desc'  => 'فاکتورهای ثابت قیمت، بدهکار/بستانکار، چک چهار دسته',
                'url'   => 'https://zagroos.com/',
                'price' => 'به‌زودی',
            ],
            [
                'slug'  => 'install-pro',
                'name'  => 'نصب و تحویل',
                'desc'  => 'چک‌لیست نصب، درصد پیشرفت، نظرسنجی تحویل',
                'url'   => 'https://zagroos.com/',
                'price' => 'به‌زودی',
            ],
            [
                'slug'  => 'hr-pro',
                'name'  => 'حضور و حقوق',
                'desc'  => 'ورود/خروج پیشرفته، جریمه خودکار، درخواست حقوق',
                'url'   => 'https://zagroos.com/',
                'price' => 'به‌زودی',
            ],
            [
                'slug'  => 'panel-slot',
                'name'  => 'پنل کارگاه بعدی',
                'desc'  => 'یک اسلات اضافه برای راه‌اندازی کارگاه مجزا روی همین سایت',
                'url'   => Samaneh_Instances::product_url(),
                'price' => 'خرید از فروشگاه',
            ],
        ]);

        $active = Samaneh_Modules::all();
        echo '<div class="wrap"><h1>افزودن ماژول به هسته کارگاه</h1>';
        echo '<p>هسته به‌تنهایی کار می‌کند. برای توسعه، ماژول‌ها را جداگانه تهیه و نصب کنید.</p>';
        echo '<h2>ماژول‌های فعال روی این سایت</h2>';
        if (empty($active)) {
            echo '<p>فعلاً فقط هسته نصب است.</p>';
        } else {
            echo '<ul>';
            foreach ($active as $slug => $info) {
                echo '<li><strong>' . esc_html($info['name'] ?? $slug) . '</strong> — v' . esc_html($info['version'] ?? '') . '</li>';
            }
            echo '</ul>';
        }
        echo '<h2>کاتالوگ ماژول‌ها</h2>';
        echo '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;">';
        foreach ($modules_catalog as $m) {
            $installed = isset($active[$m['slug']]);
            echo '<div style="background:#fff;border:1px solid #c3c4c7;border-radius:8px;padding:16px;">';
            echo '<h3 style="margin:0 0 8px">' . esc_html($m['name']) . '</h3>';
            echo '<p style="color:#646970;min-height:48px">' . esc_html($m['desc']) . '</p>';
            echo '<p><strong>' . esc_html($m['price']) . '</strong></p>';
            if ($installed) {
                echo '<span class="button disabled">نصب‌شده</span>';
            } else {
                echo '<a class="button button-primary" href="' . esc_url($m['url']) . '" target="_blank" rel="noopener">مشاهده / خرید</a>';
            }
            echo '</div>';
        }
        echo '</div>';
        echo '<p style="margin-top:24px;color:#646970">پس از خرید، فایل افزونه ماژول را مثل افزونه‌های عادی وردپرس نصب و فعال کنید.</p>';
        echo '</div>';
    }

    public function admin_backup_page(): void {
        $instances = Samaneh_Instances::all();
        echo '<div class="wrap"><h1>بکاپ و بازیابی</h1>';
        echo '<p>خروجی Excel (CSV)، JSON قابل بازیابی، و چاپ/PDF از داخل هر پنل روی هر جدول در دسترس است.</p>';
        echo '<h2>پنل‌های این سایت</h2><ul>';
        foreach ($instances as $inst) {
            $slug = $inst['slug'] ?? 'panel';
            echo '<li><strong>#' . (int) $inst['id'] . '</strong> ' . esc_html($inst['name'] ?: $slug);
            echo ' — <a href="' . esc_url(home_url('/' . $slug . '/')) . '" target="_blank">باز کردن پنل</a></li>';
        }
        echo '</ul>';
        echo '<p>در پنل: روی هر جدول دکمه‌های <strong>Excel</strong>، <strong>JSON</strong>، <strong>PDF</strong> و در تنظیمات <strong>بکاپ کامل</strong> و <strong>بازیابی</strong> را بزنید.</p>';
        echo '<hr><h2>حذف و بایگانی</h2>';
        echo '<p>مدیر مجموعه از داخل پنل می‌تواند رکوردها را انتخاب و <strong>حذف</strong> کند. هر حذف ابتدا در بایگانی ذخیره می‌شود.</p>';
        echo '<p>مشاهده و پاکسازی نهایی بایگانی فقط برای <strong>ادمین شبکه zagroos.com</strong> است';
        if (is_multisite() ? is_super_admin() : is_super_admin()) {
            echo ' — <a href="' . esc_url(admin_url('admin.php?page=samaneh-archives')) . '">رفتن به بایگانی حذف‌شده‌ها</a>';
        } else {
            echo ' و برای مدیر سایت قابل مشاهده نیست.';
        }
        echo '</p>';
        echo '</div>';
    }

    /** فقط سوپرادمین شبکه — لیست و پاکسازی نهایی بایگانی */
    public function admin_archives_page(): void {
        if (!(is_multisite() ? is_super_admin() : is_super_admin())) {
            wp_die('فقط ادمین شبکه به این بخش دسترسی دارد.');
        }
        // انتخاب instance
        $instances = Samaneh_Instances::all();
        $iid = max(1, (int) ($_GET['instance'] ?? 1));
        if (!isset($instances[$iid])) {
            $iid = (int) array_key_first($instances);
        }
        Samaneh_DB::set_instance($iid);

        if (isset($_POST['purge_archive']) && check_admin_referer('samaneh_purge_archive')) {
            $aid = (int) ($_POST['archive_id'] ?? 0);
            if ($aid > 0) {
                Samaneh_DB::purge_archive($aid);
                echo '<div class="updated"><p>رکورد بایگانی #' . $aid . ' برای همیشه پاک شد.</p></div>';
            }
        }

        $rows = Samaneh_DB::list_archives(300);
        echo '<div class="wrap"><h1>بایگانی حذف‌شده‌ها (فقط ادمین شبکه)</h1>';
        echo '<p class="description">این داده‌ها از پنل مدیر مجموعه حذف شده‌اند و فقط شما می‌بینید. مدیر سایت و دیگران به این بخش دسترسی ندارند.</p>';
        echo '<p>پنل: ';
        foreach ($instances as $inst) {
            $id = (int) $inst['id'];
            $url = admin_url('admin.php?page=samaneh-archives&instance=' . $id);
            echo ($id === $iid)
                ? '<strong>#' . $id . '</strong> '
                : '<a href="' . esc_url($url) . '">#' . $id . '</a> ';
        }
        echo '</p>';
        if (empty($rows)) {
            echo '<p>بایگانی خالی است.</p></div>';
            return;
        }
        echo '<table class="widefat striped"><thead><tr>';
        echo '<th>ID</th><th>جدول</th><th>شناسه مبدأ</th><th>حذف‌کننده</th><th>زمان</th><th>پیش‌نمایش</th><th>پاکسازی نهایی</th>';
        echo '</tr></thead><tbody>';
        foreach ($rows as $r) {
            echo '<tr>';
            echo '<td>' . (int) $r['id'] . '</td>';
            echo '<td>' . esc_html($r['source_table'] ?? '') . '</td>';
            echo '<td>' . (int) ($r['source_id'] ?? 0) . '</td>';
            echo '<td>' . esc_html($r['archived_by'] ?? '') . '</td>';
            echo '<td>' . esc_html($r['created_at'] ?? '') . '</td>';
            echo '<td><code style="font-size:11px">' . esc_html(mb_substr((string) ($r['preview'] ?? ''), 0, 120)) . '</code></td>';
            echo '<td><form method="post" style="display:inline" onsubmit="return confirm(\'برای همیشه از بایگانی پاک شود؟\');">';
            wp_nonce_field('samaneh_purge_archive');
            echo '<input type="hidden" name="archive_id" value="' . (int) $r['id'] . '">';
            echo '<button type="submit" name="purge_archive" value="1" class="button button-small">پاکسازی نهایی</button>';
            echo '</form></td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    }

    /**
     * کاربر تستر کارگاه — فقط سوپرادمین شبکه
     * به یک کاربر وردپرس دسترسی انتخابی به چند کارگاه با نقش دلخواه می‌دهد.
     */
    public function admin_testers_page(): void {
        if (!is_super_admin()) {
            wp_die('فقط ادمین شبکه به این بخش دسترسی دارد.');
        }

        $blog_id = get_current_blog_id();
        $map = Samaneh_Auth::tester_access_all();

        // ذخیره
        if (isset($_POST['samaneh_tester_save']) && check_admin_referer('samaneh_testers')) {
            $user_id = (int) ($_POST['tester_user_id'] ?? 0);
            $roles_post = isset($_POST['tester_roles']) && is_array($_POST['tester_roles']) ? $_POST['tester_roles'] : [];
            if ($user_id > 0) {
                $uid = (string) $user_id;
                if (!isset($map[$uid]) || !is_array($map[$uid])) {
                    $map[$uid] = [];
                }
                // فقط کلیدهای همین سایت را بازنویسی کن
                foreach (array_keys($map[$uid]) as $k) {
                    if (strpos((string) $k, $blog_id . '_') === 0) {
                        unset($map[$uid][$k]);
                    }
                }
                foreach ($roles_post as $iid => $role) {
                    $iid = (int) $iid;
                    $role = sanitize_key($role);
                    if ($iid < 1 || $role === '' || $role === '0') {
                        continue;
                    }
                    if (!Samaneh_Roles::get($role) && $role !== 'management') {
                        continue;
                    }
                    $map[$uid][$blog_id . '_' . $iid] = $role;
                }
                if (empty($map[$uid])) {
                    unset($map[$uid]);
                }
                Samaneh_Auth::tester_access_save($map);
                echo '<div class="updated"><p>دسترسی کاربر تستر ذخیره شد.</p></div>';
            } else {
                echo '<div class="error"><p>کاربر را انتخاب کنید.</p></div>';
            }
        }

        // حذف کامل یک کاربر از تسترها
        if (isset($_POST['samaneh_tester_remove']) && check_admin_referer('samaneh_testers')) {
            $user_id = (int) ($_POST['remove_user_id'] ?? 0);
            if ($user_id > 0) {
                unset($map[(string) $user_id]);
                Samaneh_Auth::tester_access_save($map);
                echo '<div class="updated"><p>دسترسی تستر حذف شد.</p></div>';
            }
        }

        $instances = Samaneh_Instances::all();
        $role_labels = Samaneh_Roles::labels();
        $users = get_users(['orderby' => 'display_name', 'number' => 300]);

        echo '<div class="wrap"><h1>کاربر تستر کارگاه</h1>';
        echo '<p class="description">از اینجا به یک کاربر وردپرس دسترسی انتخابی به یک یا چند کارگاه این سایت می‌دهید. او با یوزر و رمز وردپرس وارد پنل می‌شود و در لیست پرسنل ظاهر نمی‌شود. نقش را خودتان انتخاب کنید (مثلاً مدیر، حسابدار، پرسنل).</p>';

        // فرم افزودن/ویرایش
        echo '<div style="background:#fff;border:1px solid #ccd0d4;padding:16px;margin:16px 0;max-width:720px;">';
        echo '<h2>افزودن / ویرایش دسترسی</h2>';
        echo '<form method="post">';
        wp_nonce_field('samaneh_testers');
        echo '<p><label>کاربر وردپرس: <select name="tester_user_id" required><option value="">— انتخاب —</option>';
        foreach ($users as $u) {
            if (is_super_admin($u->ID)) {
                continue;
            }
            echo '<option value="' . (int) $u->ID . '">' . esc_html($u->display_name . ' (' . $u->user_login . ')') . '</option>';
        }
        echo '</select></label></p>';
        echo '<table class="widefat striped" style="max-width:560px"><thead><tr><th>کارگاه</th><th>نقش در پنل</th></tr></thead><tbody>';
        foreach ($instances as $inst) {
            $iid = (int) $inst['id'];
            $label = ($inst['name'] ?? '') !== '' ? $inst['name'] : ('پنل #' . $iid . ' / ' . ($inst['slug'] ?? ''));
            echo '<tr><td>' . esc_html($label) . ' <code>#' . $iid . '</code></td><td>';
            echo '<select name="tester_roles[' . $iid . ']"><option value="0">— بدون دسترسی —</option>';
            foreach ($role_labels as $rk => $rl) {
                if ($rk === 'customer') {
                    continue;
                }
                echo '<option value="' . esc_attr($rk) . '">' . esc_html($rl) . '</option>';
            }
            echo '</select></td></tr>';
        }
        echo '</tbody></table>';
        echo '<p><button type="submit" name="samaneh_tester_save" value="1" class="button button-primary">ذخیره دسترسی تستر</button></p>';
        echo '</form></div>';

        // لیست فعلی
        echo '<h2>تسترهای فعلی (این سایت و شبکه)</h2>';
        if (empty($map)) {
            echo '<p>هنوز کاربری به‌عنوان تستر تعریف نشده.</p>';
        } else {
            echo '<table class="widefat striped"><thead><tr><th>کاربر</th><th>دسترسی‌ها</th><th>حذف</th></tr></thead><tbody>';
            foreach ($map as $uid => $access) {
                if (!is_array($access) || empty($access)) {
                    continue;
                }
                $u = get_user_by('id', (int) $uid);
                $uname = $u ? ($u->display_name . ' (' . $u->user_login . ')') : ('#' . $uid);
                $parts = [];
                foreach ($access as $key => $role) {
                    $parts[] = esc_html($key) . ' → ' . esc_html($role_labels[$role] ?? $role);
                }
                echo '<tr><td>' . esc_html($uname) . '</td><td>' . implode('<br>', $parts) . '</td><td>';
                echo '<form method="post" style="display:inline" onsubmit="return confirm(\'همه دسترسی‌های این تستر حذف شود؟\');">';
                wp_nonce_field('samaneh_testers');
                echo '<input type="hidden" name="remove_user_id" value="' . (int) $uid . '">';
                echo '<button type="submit" name="samaneh_tester_remove" value="1" class="button button-small">حذف</button>';
                echo '</form></td></tr>';
            }
            echo '</tbody></table>';
        }
        echo '<p class="description">کلید دسترسی به صورت <code>شناسه‌سایت_شناسه‌پنل</code> است. برای دادن دسترسی روی سایت‌های دیگر شبکه، به همان سایت بروید و دوباره این صفحه را باز کنید.</p>';
        echo '</div>';
    }

    public function network_admin_menu(): void {
        add_menu_page(
            'کارگاه آماده',
            'کارگاه آماده',
            'manage_network',
            'samaneh-network',
            [$this, 'network_grants_page'],
            'dashicons-shield',
            3
        );
        add_submenu_page(
            'samaneh-network',
            'دسترسی ماژول‌ها',
            'دسترسی ماژول‌ها',
            'manage_network',
            'samaneh-network',
            [$this, 'network_grants_page']
        );
        add_submenu_page(
            'samaneh-network',
            'اسلاگ‌های رزرو شده',
            'اسلاگ‌های رزرو شده',
            'manage_network',
            'samaneh-reserved-slugs',
            [$this, 'network_slugs_page']
        );
        add_submenu_page(
            'samaneh-network',
            'بایگانی حذف‌شده‌ها',
            'بایگانی حذف‌شده‌ها',
            'manage_network',
            'samaneh-network-archives',
            [$this, 'network_archives_page']
        );
    }

    public function network_grants_notice(): void {
        if (!is_super_admin()) {
            return;
        }
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if ($screen && strpos((string) $screen->id, 'samaneh') !== false) {
            return;
        }
        $sites = get_sites(['fields' => 'ids', 'number' => 50]);
        $ungranted = 0;
        foreach ($sites as $bid) {
            if (!Samaneh_Grants::site_is_enabled((int) $bid)) {
                $ungranted++;
            }
        }
        if ($ungranted < 1) {
            return;
        }
        $url = network_admin_url('admin.php?page=samaneh-network');
        echo '<div class="notice notice-warning"><p>کارگاه آماده: <strong>' . (int) $ungranted . '</strong> سایت هنوز هیچ ماژولی نگرفته‌اند و افزونه روی آن‌ها قفل است. ';
        echo '<a href="' . esc_url($url) . '">اعطای دسترسی ماژول‌ها</a></p></div>';
    }

    /** مدیر شبکه: اعطای بخش‌های افزونه به هر سایت */
    public function network_grants_page(): void {
        if (!is_super_admin() && !current_user_can('manage_network')) {
            wp_die('فقط مدیر شبکه به این بخش دسترسی دارد.');
        }
        $catalog = Samaneh_Grants::catalog();

        if (isset($_POST['samaneh_grants_save']) && check_admin_referer('samaneh_network_grants')) {
            $blog_id = (int) ($_POST['blog_id'] ?? 0);
            $enabled = !empty($_POST['grant_enabled']);
            $mods = isset($_POST['modules']) && is_array($_POST['modules']) ? $_POST['modules'] : [];
            if ($blog_id > 0) {
                Samaneh_Grants::save_for_site($blog_id, $enabled, $mods);
                echo '<div class="updated"><p>دسترسی سایت #' . $blog_id . ' ذخیره شد. بدون تیک فعال‌سازی، هیچ بخشی از افزونه روی آن سایت کار نمی‌کند.</p></div>';
            }
        }

        $sites = get_sites(['number' => 200, 'orderby' => 'id']);
        echo '<div class="wrap"><h1>اعطای ماژول‌های کارگاه آماده به سایت‌ها</h1>';
        echo '<p class="description">به‌صورت پیش‌فرض هیچ سایتی به این افزونه دسترسی ندارد. برای هر سایت مشخص کنید کدام بخش‌ها باز باشد — مثلاً فقط مشتریان، فقط دستورات، یا دستورات و جریمه‌ها با هم.</p>';

        foreach ($sites as $site) {
            $bid = (int) $site->blog_id;
            $details = get_blog_details($bid);
            $path = $details ? ($details->path ?: '/') : '/';
            $name = $details ? $details->blogname : ('سایت #' . $bid);
            $grant = Samaneh_Grants::get_for_site($bid);
            echo '<div style="background:#fff;border:1px solid #ccd0d4;padding:16px;margin:12px 0;max-width:820px;">';
            echo '<h2>' . esc_html($name) . ' <code>#' . $bid . '</code> <span style="font-weight:400;color:#646970">' . esc_html($path) . '</span></h2>';
            echo '<form method="post">';
            wp_nonce_field('samaneh_network_grants');
            echo '<input type="hidden" name="blog_id" value="' . $bid . '">';
            echo '<p><label><input type="checkbox" name="grant_enabled" value="1"' . checked(!empty($grant['enabled']), true, false) . '> فعال‌سازی افزونه روی این سایت</label></p>';
            echo '<p><strong>بخش‌ها:</strong></p><p>';
            foreach ($catalog as $slug => $info) {
                $on = in_array($slug, $grant['modules'], true);
                echo '<label style="display:inline-block;min-width:210px;margin:4px 12px 4px 0">';
                echo '<input type="checkbox" name="modules[]" value="' . esc_attr($slug) . '"' . checked($on, true, false) . '> ';
                echo esc_html($info['label']);
                echo '</label>';
            }
            echo '</p>';
            echo '<p><button class="button button-primary" name="samaneh_grants_save" value="1">ذخیره این سایت</button></p>';
            echo '</form></div>';
        }
        echo '</div>';
    }

    public function network_slugs_page(): void {
        if (!is_super_admin() && !current_user_can('manage_network')) {
            wp_die('فقط مدیر شبکه به این بخش دسترسی دارد.');
        }
        if (isset($_POST['samaneh_slug_add']) && check_admin_referer('samaneh_reserved_slugs')) {
            $slug = sanitize_title(wp_unslash($_POST['new_reserved'] ?? ''));
            if ($slug !== '') {
                Samaneh_Reserved_Slugs::add($slug);
                echo '<div class="updated"><p>اسلاگ <code>' . esc_html($slug) . '</code> رزرو شد. وردپرس شبکه نمی‌تواند سایتی با این مسیر بسازد.</p></div>';
            }
        }
        Samaneh_Reserved_Slugs::persist();
        $slugs = Samaneh_Reserved_Slugs::all();
        echo '<div class="wrap"><h1>اسلاگ‌های رزرو شده</h1>';
        echo '<p class="description">هر آدرس پنل کارگاه (مثل <code>kargah</code> در zagroos.com/kargah) اینجا قفل می‌شود تا وردپرس مولتی‌سایت نتواند همان مسیر را به‌عنوان سایت به کسی بدهد.</p>';
        echo '<form method="post" style="margin:16px 0">';
        wp_nonce_field('samaneh_reserved_slugs');
        echo '<input name="new_reserved" placeholder="example" pattern="[a-z0-9\\-]+" required> ';
        echo '<button class="button button-primary" name="samaneh_slug_add" value="1">رزرو اسلاگ</button>';
        echo '</form>';
        if (empty($slugs)) {
            echo '<p>هنوز اسلاگی رزرو نشده.</p>';
        } else {
            echo '<ul>';
            foreach ($slugs as $s) {
                $taken = Samaneh_Reserved_Slugs::slug_taken_by_site($s);
                echo '<li><code>/' . esc_html($s) . '/</code>';
                if ($taken) {
                    echo ' — <span style="color:#b32d2e">تداخل با سایت شبکه موجود</span>';
                } else {
                    echo ' — مسدود برای ساخت سایت';
                }
                echo '</li>';
            }
            echo '</ul>';
        }
        echo '</div>';
    }

    /** بایگانی شبکه — حذف نهایی فقط از اینجا */
    public function network_archives_page(): void {
        if (!is_super_admin()) {
            wp_die('فقط ادمین شبکه به این بخش دسترسی دارد.');
        }
        $blog_id = (int) ($_GET['blog'] ?? get_current_blog_id());
        $sites = get_sites(['number' => 200, 'fields' => 'ids']);
        if (!in_array($blog_id, array_map('intval', $sites), true)) {
            $blog_id = (int) $sites[0];
        }

        if (isset($_POST['purge_forever']) && check_admin_referer('samaneh_purge_forever')) {
            $table = sanitize_key($_POST['table'] ?? '');
            $id = (int) ($_POST['row_id'] ?? 0);
            switch_to_blog($blog_id);
            $iid = max(1, (int) ($_POST['instance'] ?? 1));
            Samaneh_DB::set_instance($iid);
            try {
                Samaneh_DB::purge_forever($table, $id);
                echo '<div class="updated"><p>رکورد برای همیشه از دیتابیس پاک شد.</p></div>';
            } catch (Throwable $e) {
                echo '<div class="error"><p>' . esc_html($e->getMessage()) . '</p></div>';
            }
            restore_current_blog();
        }

        if (isset($_POST['restore_row']) && check_admin_referer('samaneh_purge_forever')) {
            $table = sanitize_key($_POST['table'] ?? '');
            $id = (int) ($_POST['row_id'] ?? 0);
            switch_to_blog($blog_id);
            $iid = max(1, (int) ($_POST['instance'] ?? 1));
            Samaneh_DB::set_instance($iid);
            try {
                Samaneh_DB::restore($table, $id);
                echo '<div class="updated"><p>رکورد به نمایش پنل برگشت.</p></div>';
            } catch (Throwable $e) {
                echo '<div class="error"><p>' . esc_html($e->getMessage()) . '</p></div>';
            }
            restore_current_blog();
        }

        echo '<div class="wrap"><h1>بایگانی حذف‌شده‌ها (فقط مدیر شبکه)</h1>';
        echo '<p class="description">این ردیف‌ها از پنل کارگاه مخفی شده‌اند. هیچ کاربر دیگری از هیچ مسیری آن‌ها را نمی‌بیند. حذف برای همیشه فقط از همین صفحه وردپرس ممکن است.</p>';
        echo '<p>سایت: ';
        foreach ($sites as $bid) {
            $bid = (int) $bid;
            $d = get_blog_details($bid);
            $label = $d ? ($d->blogname . ' ' . $d->path) : ('#' . $bid);
            $url = network_admin_url('admin.php?page=samaneh-network-archives&blog=' . $bid);
            echo $bid === $blog_id
                ? '<strong>' . esc_html($label) . '</strong> '
                : '<a href="' . esc_url($url) . '">' . esc_html($label) . '</a> ';
        }
        echo '</p>';

        switch_to_blog($blog_id);
        $instances = class_exists('Samaneh_Instances') ? Samaneh_Instances::all() : [1 => ['id' => 1, 'slug' => 'panel']];
        $iid = max(1, (int) ($_GET['instance'] ?? 1));
        if (!isset($instances[$iid])) {
            $iid = (int) array_key_first($instances);
        }
        echo '<p>پنل: ';
        foreach ($instances as $inst) {
            $id = (int) $inst['id'];
            $url = network_admin_url('admin.php?page=samaneh-network-archives&blog=' . $blog_id . '&instance=' . $id);
            echo ($id === $iid)
                ? '<strong>#' . $id . '</strong> '
                : '<a href="' . esc_url($url) . '">#' . $id . '</a> ';
        }
        echo '</p>';

        Samaneh_DB::set_instance($iid);
        $rows = Samaneh_DB::list_soft_deleted(400);
        restore_current_blog();

        if (empty($rows)) {
            echo '<p>مورد مخفی‌شده‌ای نیست.</p></div>';
            return;
        }
        echo '<table class="widefat striped"><thead><tr>';
        echo '<th>جدول</th><th>شناسه</th><th>پیش‌نمایش</th><th>حذف‌کننده</th><th>زمان</th><th>بازگردانی</th><th>حذف برای همیشه</th>';
        echo '</tr></thead><tbody>';
        foreach ($rows as $r) {
            echo '<tr style="opacity:.7">';
            echo '<td>' . esc_html($r['source_table'] ?? '') . '</td>';
            echo '<td>' . (int) ($r['source_id'] ?? 0) . '</td>';
            echo '<td><code style="font-size:11px">' . esc_html(mb_substr((string) ($r['preview'] ?? ''), 0, 140)) . '</code></td>';
            echo '<td>' . esc_html($r['deleted_by'] ?? '') . '</td>';
            echo '<td>' . esc_html($r['deleted_at'] ?? '') . '</td>';
            echo '<td><form method="post" style="display:inline">';
            wp_nonce_field('samaneh_purge_forever');
            echo '<input type="hidden" name="table" value="' . esc_attr($r['source_table'] ?? '') . '">';
            echo '<input type="hidden" name="row_id" value="' . (int) ($r['source_id'] ?? 0) . '">';
            echo '<input type="hidden" name="instance" value="' . (int) $iid . '">';
            echo '<button class="button button-small" name="restore_row" value="1">بازگردانی</button></form></td>';
            echo '<td><form method="post" style="display:inline" onsubmit="return confirm(\'برای همیشه از دیتابیس پاک شود؟ این کار برگشت‌ناپذیر است.\');">';
            wp_nonce_field('samaneh_purge_forever');
            echo '<input type="hidden" name="table" value="' . esc_attr($r['source_table'] ?? '') . '">';
            echo '<input type="hidden" name="row_id" value="' . (int) ($r['source_id'] ?? 0) . '">';
            echo '<input type="hidden" name="instance" value="' . (int) $iid . '">';
            echo '<button class="button button-small button-link-delete" name="purge_forever" value="1">حذف برای همیشه</button></form></td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    }

}

Samaneh_Core::instance();
