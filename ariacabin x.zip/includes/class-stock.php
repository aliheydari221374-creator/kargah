<?php
/**
 * Samaneh Stock Service
 * منطق یکپارچه انبار با پشتیبانی کامل دو واحدی + اعتبارسنجی قوی + محاسبه دقیق مانده
 */
if (!defined('ABSPATH')) {
    exit;
}

class Samaneh_Stock {

    /** تبدیل مقدار به واحد اصلی (unit1) */
    public static function to_primary(float $qty, string $used_unit, array $item): float {
        if ($qty <= 0) {
            return 0.0;
        }
        $unit1 = trim((string) ($item['unit'] ?? ''));
        $unit2 = trim((string) ($item['unit2'] ?? ''));
        $ratio = self::parse_ratio($item['unit_ratio'] ?? '');

        // اگر واحد استفاده‌شده همان واحد اصلی است یا واحد دوم تعریف نشده
        if ($used_unit === '' || $used_unit === $unit1 || $unit2 === '' || $ratio <= 0) {
            return $qty;
        }

        // اگر با واحد دوم مصرف شده → تبدیل به واحد ۱
        if ($used_unit === $unit2) {
            return $qty / $ratio; // هر unit1 = ratio * unit2  ⇒  qty_unit2 / ratio = qty_unit1
        }

        // واحد ناشناخته → فرض می‌کنیم واحد اصلی است
        return $qty;
    }

    /** تبدیل از واحد اصلی به واحد نمایشی دلخواه */
    public static function from_primary(float $primary_qty, string $target_unit, array $item): float {
        if ($primary_qty <= 0) {
            return 0.0;
        }
        $unit1 = trim((string) ($item['unit'] ?? ''));
        $unit2 = trim((string) ($item['unit2'] ?? ''));
        $ratio = self::parse_ratio($item['unit_ratio'] ?? '');

        if ($target_unit === '' || $target_unit === $unit1 || $unit2 === '' || $ratio <= 0) {
            return $primary_qty;
        }
        if ($target_unit === $unit2) {
            return $primary_qty * $ratio;
        }
        return $primary_qty;
    }

    /** پارس امن نسبت واحد */
    public static function parse_ratio($raw): float {
        if ($raw === null || $raw === '') {
            return 0.0;
        }
        // پشتیبانی از اعداد فارسی و جداکننده اعشار
        $s = samaneh_normalize_digits((string) $raw);
        $s = str_replace([',', '،', ' '], ['.', '.', ''], $s);
        $n = (float) $s;
        return $n > 0 ? $n : 0.0;
    }

    /** پارس امن مقدار عددی */
    public static function parse_qty($raw): float {
        if ($raw === null || $raw === '') {
            return 0.0;
        }
        $s = samaneh_normalize_digits((string) $raw);
        $s = str_replace([',', '،', ' '], ['.', '.', ''], $s);
        return (float) $s;
    }

    /**
     * اعتبارسنجی قوی هنگام ذخیره کالا
     * @throws RuntimeException
     */
    public static function validate_item(array &$data, ?array $existing = null): void {
        $item_name = trim((string) ($data['item'] ?? ''));
        if ($item_name === '') {
            throw new RuntimeException('نام کالا الزامی است');
        }

        $unit1 = trim((string) ($data['unit'] ?? ($existing['unit'] ?? '')));
        $unit2 = trim((string) ($data['unit2'] ?? ($existing['unit2'] ?? '')));
        $ratio_raw = $data['unit_ratio'] ?? ($existing['unit_ratio'] ?? '');

        // واحد ۱ همیشه باید وجود داشته باشد
        if ($unit1 === '') {
            $data['unit'] = 'عدد';
            $unit1 = 'عدد';
        }

        // اگر واحد ۲ تعریف شده، نسبت باید مثبت و معتبر باشد
        if ($unit2 !== '') {
            $ratio = self::parse_ratio($ratio_raw);
            if ($ratio <= 0) {
                throw new RuntimeException('وقتی واحد ۲ تعریف می‌شود، نسبت (هر واحد۱ = چند واحد۲) باید عددی بزرگ‌تر از صفر باشد');
            }
            // نرمال‌سازی ذخیره
            $data['unit_ratio'] = (string) $ratio;
        } else {
            // بدون واحد ۲، نسبت خالی می‌ماند
            $data['unit_ratio'] = '';
            $data['unit2'] = '';
        }

        // جلوگیری از واحدهای یکسان
        if ($unit2 !== '' && mb_strtolower($unit1) === mb_strtolower($unit2)) {
            throw new RuntimeException('واحد ۱ و واحد ۲ نباید یکسان باشند');
        }

        // موجودی و حداقل باید عدد غیرمنفی باشند
        if (array_key_exists('qty', $data)) {
            $q = self::parse_qty($data['qty']);
            if ($q < 0) {
                throw new RuntimeException('موجودی نمی‌تواند منفی باشد');
            }
            $data['qty'] = self::format_qty($q);
        }
        if (array_key_exists('min_qty', $data)) {
            $m = self::parse_qty($data['min_qty']);
            if ($m < 0) {
                throw new RuntimeException('حداقل موجودی نمی‌تواند منفی باشد');
            }
            $data['min_qty'] = self::format_qty($m);
        }
    }

    /** فرمت یکنواخت برای ذخیره qty */
    public static function format_qty(float $n): string {
        // تا ۴ رقم اعشار، بدون صفرهای اضافی
        $s = number_format($n, 4, '.', '');
        $s = rtrim(rtrim($s, '0'), '.');
        return $s === '' ? '0' : $s;
    }

    /**
     * بررسی موجودی کافی با در نظر گرفتن واحد مصرف
     * @throws RuntimeException
     */
    public static function assert_available(string $item_name, float $need_qty, string $used_unit = ''): void {
        if ($item_name === '' || $need_qty <= 0) {
            return;
        }
        $item = self::find_item($item_name);
        if (!$item) {
            throw new RuntimeException('کالای «' . $item_name . '» در انبار یافت نشد');
        }

        $need_primary = self::to_primary($need_qty, $used_unit, $item);
        $have_primary = self::parse_qty($item['qty'] ?? 0);

        if ($need_primary > $have_primary + 0.0001) { // تحمل خطای شناور
            $unit1 = $item['unit'] ?: 'واحد';
            $have_display = self::format_qty($have_primary);
            $need_display = self::format_qty($need_primary);
            throw new RuntimeException(
                "موجودی کافی نیست. موجودی فعلی «{$item_name}»: {$have_display} {$unit1} — مورد نیاز: {$need_display} {$unit1}"
            );
        }
    }

    /** پیدا کردن ردیف کالا */
    public static function find_item(string $item_name): ?array {
        global $wpdb;
        $t = Samaneh_DB::table('stock_items');
        // phpcs:ignore
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM `{$t}` WHERE item = %s AND (deleted_at IS NULL OR deleted_at = '' OR deleted_at = '0000-00-00 00:00:00') LIMIT 1",
            $item_name
        ), ARRAY_A);
        return is_array($row) ? $row : null;
    }

    // ═════════════════════════════════════════════════════════════
    //  تراکنش، قفل و تغییر اتمیک موجودی
    // ═════════════════════════════════════════════════════════════

    /** وضعیت‌هایی که برای «بازگشت» یعنی موجودی افزوده شده */
    const RETURN_APPROVED = ['تأییدشده', 'approved', 'تأیید'];
    /** وضعیت‌هایی که «برداشت» را بی‌اثر می‌کنند */
    const WITHDRAW_VOID = ['رد', 'رد شده', 'rejected', 'لغو', 'لغوشده', 'cancelled'];

    /** عمق تراکنش (برای فراخوانی‌های تودرتو) */
    private static $tx_depth = 0;
    private static $tx_failed = false;
    /** دفتر تغییرات برای جبران دستی روی موتورهای غیرتراکنشی (مثل MyISAM) */
    private static $journal = [];
    private static $engine_cache = [];

    public static function begin(): void {
        global $wpdb;
        if (self::$tx_depth === 0) {
            self::$journal = [];
            self::$tx_failed = false;
            $wpdb->query('START TRANSACTION');
        }
        self::$tx_depth++;
    }

    public static function commit(): void {
        global $wpdb;
        if (self::$tx_depth <= 0) {
            return;
        }
        self::$tx_depth--;
        if (self::$tx_depth === 0) {
            if (self::$tx_failed) {
                self::do_rollback();
            } else {
                $wpdb->query('COMMIT');
                self::$journal = [];
            }
        }
    }

    public static function rollback(): void {
        if (self::$tx_depth <= 0) {
            return;
        }
        self::$tx_depth--;
        self::$tx_failed = true;
        if (self::$tx_depth === 0) {
            self::do_rollback();
        }
    }

    private static function do_rollback(): void {
        global $wpdb;
        $wpdb->query('ROLLBACK');
        if (!self::is_transactional()) {
            // موتور غیرتراکنشی: تغییرات ثبت‌شده را دستی برگردان
            $items_t = Samaneh_DB::table('stock_items');
            foreach (array_reverse(self::$journal) as $j) {
                if ($j[0] === 'adj') {
                    // phpcs:ignore
                    $wpdb->query($wpdb->prepare(
                        "UPDATE `{$items_t}` SET qty = CAST(qty AS DECIMAL(14,4)) - %F WHERE id = %d",
                        (float) $j[2], (int) $j[1]
                    ));
                } elseif ($j[0] === 'new') {
                    $wpdb->delete($items_t, ['id' => (int) $j[1]], ['%d']);
                }
            }
        }
        self::$journal = [];
        self::$tx_failed = false;
    }

    /** آیا جدول‌های انبار InnoDB (تراکنشی) هستند؟ */
    public static function is_transactional(): bool {
        global $wpdb;
        $key = Samaneh_DB::prefix();
        if (isset(self::$engine_cache[$key])) {
            return self::$engine_cache[$key];
        }
        $names = [
            Samaneh_DB::table('stock_items'),
            Samaneh_DB::table('stock_usage'),
            Samaneh_DB::table('purchases'),
        ];
        // phpcs:ignore
        $engines = $wpdb->get_col($wpdb->prepare(
            'SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME IN (%s,%s,%s)',
            $names[0], $names[1], $names[2]
        ));
        $ok = is_array($engines) && count($engines) === 3;
        if ($ok) {
            foreach ($engines as $e) {
                if (strcasecmp((string) $e, 'InnoDB') !== 0) {
                    $ok = false;
                    break;
                }
            }
        }
        self::$engine_cache[$key] = $ok;
        return $ok;
    }

    /**
     * یک‌بار برای هر پنل: جدول‌های انبار را InnoDB می‌کند تا تراکنش واقعی کار کند.
     * (ALTER باعث commit ضمنی می‌شود، پس هرگز داخل تراکنش صدا زده نشود.)
     */
    public static function ensure_innodb(string $prefix, int $instance_id): void {
        global $wpdb;
        $flag = 'samaneh_stock_innodb_v1_' . $instance_id;
        if (get_option($flag)) {
            return;
        }
        foreach (['stock_items', 'stock_usage', 'purchases'] as $n) {
            $t = $prefix . $n;
            // phpcs:ignore
            $engine = $wpdb->get_var($wpdb->prepare(
                'SELECT ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s',
                $t
            ));
            if ($engine && strcasecmp((string) $engine, 'InnoDB') !== 0) {
                // phpcs:ignore
                $wpdb->query("ALTER TABLE `{$t}` ENGINE=InnoDB");
            }
        }
        self::$engine_cache = [];
        update_option($flag, 1, false);
    }

    /** خواندن یک ردیف با قفل (داخل تراکنش) — شامل ردیف‌های حذف‌شده */
    public static function lock_row(string $table, int $id): ?array {
        global $wpdb;
        $t = Samaneh_DB::table($table);
        // phpcs:ignore
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id = %d FOR UPDATE", $id), ARRAY_A);
        if (!is_array($row)) {
            return null;
        }
        $row['_deleted'] = Samaneh_DB::row_is_deleted($row);
        return $row;
    }

    /** ردیف کالا با شناسه (شامل حذف‌شده) */
    public static function get_item(int $id): ?array {
        global $wpdb;
        if ($id < 1) {
            return null;
        }
        $t = Samaneh_DB::table('stock_items');
        // phpcs:ignore
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id = %d", $id), ARRAY_A);
        return is_array($row) ? $row : null;
    }

    /**
     * کم‌کردن اتمیک از موجودی: بررسی و کسر در یک دستور UPDATE.
     * اگر موجودی کافی نباشد هیچ تغییری نمی‌دهد و false برمی‌گرداند.
     */
    public static function withdraw(int $item_id, float $delta_primary): bool {
        global $wpdb;
        if ($delta_primary <= 0) {
            return true;
        }
        $t = Samaneh_DB::table('stock_items');
        // phpcs:ignore
        $n = $wpdb->query($wpdb->prepare(
            "UPDATE `{$t}`
             SET qty = GREATEST(0, CAST(qty AS DECIMAL(14,4)) - %F)
             WHERE id = %d AND CAST(qty AS DECIMAL(14,4)) >= %F",
            $delta_primary, $item_id, $delta_primary - 0.0001
        ));
        if ($n === false) {
            throw new RuntimeException('خطای دیتابیس انبار: ' . $wpdb->last_error);
        }
        if ($n >= 1) {
            self::$journal[] = ['adj', $item_id, -$delta_primary];
            return true;
        }
        return false;
    }

    /** اضافه‌کردن به موجودی */
    public static function deposit(int $item_id, float $delta_primary): bool {
        global $wpdb;
        if ($delta_primary <= 0) {
            return true;
        }
        $t = Samaneh_DB::table('stock_items');
        // phpcs:ignore
        $n = $wpdb->query($wpdb->prepare(
            "UPDATE `{$t}` SET qty = CAST(qty AS DECIMAL(14,4)) + %F WHERE id = %d",
            $delta_primary, $item_id
        ));
        if ($n === false) {
            throw new RuntimeException('خطای دیتابیس انبار: ' . $wpdb->last_error);
        }
        if ($n >= 1) {
            self::$journal[] = ['adj', $item_id, $delta_primary];
            return true;
        }
        return false;
    }

    /** اعمال یک تغییر علامت‌دار روی یک کالا؛ در کمبود موجودی خطا می‌دهد */
    public static function adjust(int $item_id, float $delta): void {
        if ($item_id < 1 || abs($delta) < 0.00005) {
            return;
        }
        if ($delta < 0) {
            $need = -$delta;
            if (self::withdraw($item_id, $need)) {
                return;
            }
            $item = self::get_item($item_id);
            if (!$item) {
                return; // کالا برای همیشه پاک شده؛ چیزی برای کم‌کردن نیست
            }
            $unit1 = ($item['unit'] ?? '') !== '' ? $item['unit'] : 'واحد';
            $have = self::format_qty(self::parse_qty($item['qty'] ?? 0));
            throw new RuntimeException(
                'موجودی کافی نیست. موجودی فعلی «' . ($item['item'] ?? '') . '»: ' . $have . ' ' . $unit1
                . ' — مورد نیاز: ' . self::format_qty($need) . ' ' . $unit1
            );
        }
        self::deposit($item_id, $delta);
    }

    // ═════════════════════════════════════════════════════════════
    //  مدل «اثر موجودی»: هر ردیف مصرف/خرید یک اثر مشخص روی انبار دارد.
    //  هنگام ثبت/ویرایش/حذف/بازگردانی فقط «اختلاف» اثر قدیم و جدید اعمال می‌شود،
    //  پس ویرایش، تأیید تکراری و حذف، موجودی را خراب نمی‌کنند.
    // ═════════════════════════════════════════════════════════════

    private static function name_field(string $table): string {
        return $table === 'purchases' ? 'item' : 'item_name';
    }

    /** اثر علامت‌دار (به واحد اصلی) یک ردیف روی موجودی کالا */
    public static function effect_for(string $table, array $row, ?array $item): float {
        if ($item === null || Samaneh_DB::row_is_deleted($row)) {
            return 0.0;
        }
        $qty = self::parse_qty($row['qty'] ?? 0);
        if ($qty <= 0) {
            return 0.0;
        }
        if ($table === 'purchases') {
            return round($qty, 4);
        }
        $kind = trim((string) ($row['kind'] ?? ''));
        if ($kind === '') {
            $kind = 'برداشت';
        }
        $status = trim((string) ($row['status'] ?? ''));
        $delta = self::to_primary($qty, trim((string) ($row['unit'] ?? '')), $item);
        if ($delta <= 0) {
            return 0.0;
        }
        $delta = round($delta, 4);
        if ($kind === 'برداشت') {
            return in_array($status, self::WITHDRAW_VOID, true) ? 0.0 : -$delta;
        }
        if ($kind === 'بازگشت') {
            return in_array($status, self::RETURN_APPROVED, true) ? $delta : 0.0;
        }
        return 0.0;
    }

    /** کالای مربوط به ردیف: اول با شناسه ذخیره‌شده، وگرنه با نام */
    private static function resolve_item(string $table, array $eff, ?array $old): ?array {
        $nf = self::name_field($table);
        $name = trim((string) ($eff[$nf] ?? ''));
        $old_name = $old ? trim((string) ($old[$nf] ?? '')) : '';
        $old_id = $old ? (int) ($old['item_id'] ?? 0) : 0;
        if ($old && $old_id > 0 && $name === $old_name) {
            $it = self::get_item($old_id);
            if ($it && !Samaneh_DB::row_is_deleted($it)) {
                return $it;
            }
        }
        if ($name === '') {
            return null;
        }
        return self::find_item($name);
    }

    /** اثری که قبلاً روی انبار اعمال شده: [item_id, effect] */
    private static function old_applied(string $table, ?array $old): array {
        if (!$old) {
            return [0, 0.0];
        }
        if ((int) ($old['stock_applied'] ?? 0) === 1) {
            return [(int) ($old['item_id'] ?? 0), (float) ($old['stock_effect'] ?? 0)];
        }
        // ردیف قدیمی (قبل از این نسخه): اثر را بازسازی کن؛ حذف‌شدگی نادیده گرفته می‌شود
        // چون در نسخه قبل حذف، موجودی را برنمی‌گرداند.
        $nf = self::name_field($table);
        $name = trim((string) ($old[$nf] ?? ''));
        $item = $name !== '' ? self::find_item($name) : null;
        if (!$item) {
            return [0, 0.0];
        }
        $copy = $old;
        $copy['deleted_at'] = null;
        return [(int) $item['id'], self::effect_for($table, $copy, $item)];
    }

    /** اختلاف اثر قدیم و جدید به‌صورت [item_id => delta]، مرتب برای جلوگیری از deadlock */
    private static function diff(int $old_id, float $old_eff, int $new_id, float $new_eff): array {
        $ch = [];
        if ($old_id > 0 && abs($old_eff) > 0) {
            $ch[$old_id] = ($ch[$old_id] ?? 0.0) - $old_eff;
        }
        if ($new_id > 0 && abs($new_eff) > 0) {
            $ch[$new_id] = ($ch[$new_id] ?? 0.0) + $new_eff;
        }
        ksort($ch);
        foreach ($ch as $id => $d) {
            $d = round($d, 4);
            if (abs($d) < 0.00005) {
                unset($ch[$id]);
            } else {
                $ch[$id] = $d;
            }
        }
        return $ch;
    }

    private static function create_item_from_purchase(array $eff): ?array {
        global $wpdb;
        $t = Samaneh_DB::table('stock_items');
        $ok = $wpdb->insert($t, [
            'category' => sanitize_text_field((string) ($eff['warehouse'] ?? '')),
            'item'     => trim((string) ($eff['item'] ?? '')),
            'qty'      => '0', // موجودی را همان اثر خرید اضافه می‌کند
            'unit'     => 'عدد',
            'min_qty'  => '0',
            'price'    => (int) ($eff['price'] ?? 0),
        ]);
        if (!$ok) {
            throw new RuntimeException('خطای دیتابیس انبار: ' . ($wpdb->last_error ?: 'ساخت کالا ناموفق بود'));
        }
        $id = (int) $wpdb->insert_id;
        self::$journal[] = ['new', $id];
        return self::get_item($id);
    }

    /**
     * برنامه تغییر موجودی برای ذخیره یک ردیف stock_usage / purchases.
     * $data فیلدهای در حال ذخیره، $old ردیف قبلی (یا null).
     * خروجی: ['changes' => [item_id => delta], 'row' => ستون‌هایی که باید روی ردیف ذخیره شوند]
     */
    public static function plan(string $table, array $data, ?array $old): array {
        $eff = $old ? array_merge($old, $data) : $data;
        list($old_item_id, $old_effect) = self::old_applied($table, $old);

        $item = self::resolve_item($table, $eff, $old);
        $nf = self::name_field($table);
        $name = trim((string) ($eff[$nf] ?? ''));
        $qty = self::parse_qty($eff['qty'] ?? 0);
        $is_deleted = Samaneh_DB::row_is_deleted($eff);

        if (!$item && $table === 'purchases' && $name !== '' && $qty > 0 && !$is_deleted) {
            $item = self::create_item_from_purchase($eff);
        }
        if (!$item && $table === 'stock_usage' && !$old && $name !== '' && $qty > 0) {
            $kind = trim((string) ($eff['kind'] ?? '')) ?: 'برداشت';
            if ($kind === 'برداشت') {
                throw new RuntimeException('کالای «' . $name . '» در انبار یافت نشد');
            }
        }

        $new_effect = self::effect_for($table, $eff, $item);
        $new_item_id = $item ? (int) $item['id'] : 0;

        return [
            'changes' => self::diff($old_item_id, $old_effect, $new_item_id, $new_effect),
            'row'     => [
                'item_id'       => $new_item_id,
                'stock_effect'  => number_format($new_effect, 4, '.', ''),
                'stock_applied' => 1,
            ],
        ];
    }

    /** اعمال برنامه روی انبار (داخل تراکنش) */
    public static function execute(array $plan): void {
        foreach (($plan['changes'] ?? []) as $item_id => $delta) {
            self::adjust((int) $item_id, (float) $delta);
        }
    }

    /** هنگام حذف نرم یک ردیف: اثرش را از انبار بردار و علامت بزن */
    public static function release_row(string $table, array $row): void {
        global $wpdb;
        list($oid, $oeff) = self::old_applied($table, $row);
        self::execute(['changes' => self::diff($oid, $oeff, 0, 0.0)]);
        $res = $wpdb->update(
            Samaneh_DB::table($table),
            ['item_id' => $oid, 'stock_effect' => '0.0000', 'stock_applied' => 1],
            ['id' => (int) ($row['id'] ?? 0)]
        );
        if ($res === false) {
            throw new RuntimeException('خطای دیتابیس انبار: ' . $wpdb->last_error);
        }
    }

    /** هنگام بازگردانی ردیف حذف‌شده: اثرش را دوباره روی انبار اعمال کن */
    public static function reapply_row(string $table, array $row): void {
        global $wpdb;
        $plan = self::plan($table, [], $row);
        self::execute($plan);
        $res = $wpdb->update(Samaneh_DB::table($table), $plan['row'], ['id' => (int) ($row['id'] ?? 0)]);
        if ($res === false) {
            throw new RuntimeException('خطای دیتابیس انبار: ' . $wpdb->last_error);
        }
    }

    /**
     * نمایش مانده با هر دو واحد (برای UI)
     * مثال: "۱۲ عدد (۲۴۰ کیلو)"
     */
    public static function format_remaining(array $item): string {
        $primary = self::parse_qty($item['qty'] ?? 0);
        $unit1 = trim((string) ($item['unit'] ?? 'عدد'));
        $unit2 = trim((string) ($item['unit2'] ?? ''));
        $ratio = self::parse_ratio($item['unit_ratio'] ?? '');

        $s = self::format_qty($primary) . ' ' . $unit1;
        if ($unit2 !== '' && $ratio > 0) {
            $secondary = $primary * $ratio;
            $s .= ' (' . self::format_qty($secondary) . ' ' . $unit2 . ')';
        }
        return $s;
    }

    /**
     * آیا کالا در وضعیت اخطار کمبود است؟
     */
    public static function is_low(array $item): bool {
        $qty = self::parse_qty($item['qty'] ?? 0);
        $min = self::parse_qty($item['min_qty'] ?? 0);
        return $min > 0 && $qty <= $min;
    }

    /**
     * لیست کالاهای کمبود موجودی
     */
    public static function low_stock_items(): array {
        global $wpdb;
        $t = Samaneh_DB::table('stock_items');
        // phpcs:ignore
        $rows = $wpdb->get_results(
            "SELECT * FROM `{$t}` WHERE (deleted_at IS NULL OR deleted_at = '' OR deleted_at = '0000-00-00 00:00:00')",
            ARRAY_A
        );
        if (!is_array($rows)) {
            return [];
        }
        return array_values(array_filter($rows, [self::class, 'is_low']));
    }
}
