<?php
/**
 * نقش‌های داخلی پنل — قابل تعریف توسط مدیر — برچسب‌ها همیشه فارسی
 */
if (!defined('ABSPATH')) {
    exit;
}

class Samaneh_Roles {

    const OPT = 'samaneh_panel_roles';

    /** نقش‌های پیش‌فرض — برچسب فارسی */
    public static function defaults(): array {
        return [
            'management' => [
                'key'         => 'management',
                'label'       => 'مدیر',
                'wp_role'     => 'administrator',
                'menus'       => ['dashboard', 'customers', 'personnel', 'finance', 'warehouse', 'suppliers', 'purchases', 'directives', 'fines', 'salary', 'chat_history', 'settings', 'roles'],
                'can_delete'  => false,
                'can_settings'=> true,
            ],
            'warehouse' => [
                'key'         => 'warehouse',
                'label'       => 'حسابدار / انباردار',
                'wp_role'     => 'author',
                'menus'       => ['dashboard', 'warehouse', 'finance', 'suppliers', 'purchases', 'salary', 'emp_leave', 'emp_overtime', 'emp_attendance'],
                'can_delete'  => false,
                'can_settings'=> false,
            ],
            'employee' => [
                'key'         => 'employee',
                'label'       => 'پرسنل / نصاب',
                'wp_role'     => 'editor',
                'menus'       => ['emp_dashboard', 'directives', 'emp_report', 'emp_attendance', 'emp_leave', 'emp_overtime', 'emp_stock', 'emp_messages'],
                'can_delete'  => false,
                'can_settings'=> false,
            ],
            'customer' => [
                'key'         => 'customer',
                'label'       => 'مشتری',
                'wp_role'     => '',
                'menus'       => ['cust_home', 'cust_project', 'cust_finance'],
                'can_delete'  => false,
                'can_settings'=> false,
            ],
            'supervisor' => [
                'key'         => 'supervisor',
                'label'       => 'سرپرست کارگاه',
                'wp_role'     => 'editor',
                'menus'       => ['dashboard', 'customers', 'warehouse', 'directives', 'emp_report', 'emp_stock', 'emp_leave', 'emp_overtime'],
                'can_delete'  => false,
                'can_settings'=> false,
            ],
        ];
    }

    public static function all(): array {
        $saved = get_option(self::OPT, null);
        if (!is_array($saved) || empty($saved)) {
            $saved = self::defaults();
            update_option(self::OPT, $saved, false);
        } else {
            // نقش‌های جدید هسته را اضافه کن اگر نبودند؛ منوهای انباردار را هم همگام کن
            foreach (self::defaults() as $k => $def) {
                if (!isset($saved[$k])) {
                    $saved[$k] = $def;
                } elseif ($k === 'warehouse') {
                    $need = ['emp_leave', 'emp_overtime', 'emp_attendance', 'salary'];
                    $menus = (array) ($saved[$k]['menus'] ?? []);
                    foreach ($need as $m) {
                        if (!in_array($m, $menus, true)) {
                            $menus[] = $m;
                        }
                    }
                    $saved[$k]['menus'] = $menus;
                    $saved[$k]['can_delete'] = false;
                } elseif ($k === 'management') {
                    $menus = (array) ($saved[$k]['menus'] ?? []);
                    foreach (['salary', 'chat_history'] as $m) {
                        if (!in_array($m, $menus, true)) {
                            $menus[] = $m;
                        }
                    }
                    // چت از منو حذف — فقط FAB
                    $menus = array_values(array_filter($menus, function ($m) { return $m !== 'chat'; }));
                    $saved[$k]['menus'] = $menus;
                } else {
                    $menus = (array) ($saved[$k]['menus'] ?? []);
                    $menus = array_values(array_filter($menus, function ($m) { return $m !== 'chat'; }));
                    $saved[$k]['menus'] = $menus;
                }
            }
            update_option(self::OPT, $saved, false);
        }
        // force settings only management
        foreach ($saved as $k => &$role) {
            if ($k === 'management') {
                $role['can_settings'] = true;
                $menus = (array) ($role['menus'] ?? []);
                if (!in_array('settings', $menus, true)) {
                    $menus[] = 'settings';
                }
                if (!in_array('roles', $menus, true)) {
                    $menus[] = 'roles';
                }
                $role['menus'] = $menus;
            } else {
                $role['can_settings'] = false;
                $menus = (array) ($role['menus'] ?? []);
                $menus = array_values(array_filter($menus, function ($m) {
                    return $m !== 'settings' && $m !== 'roles';
                }));
                $role['menus'] = $menus;
            }
        }
        unset($role);

        return $saved;
    }

    public static function get(string $key): ?array {
        $all = self::all();
        return $all[$key] ?? null;
    }

    public static function labels(): array {
        $out = [];
        foreach (self::all() as $k => $r) {
            $out[$k] = $r['label'] ?? $k;
        }
        return $out;
    }

    public static function save_all(array $roles): void {
        $clean = [];
        foreach ($roles as $key => $r) {
            $key = sanitize_key($key);
            if ($key === '') {
                continue;
            }
            $clean[$key] = [
                'key'          => $key,
                'label'        => sanitize_text_field($r['label'] ?? $key),
                'wp_role'      => sanitize_key($r['wp_role'] ?? 'editor'),
                'menus'        => array_values(array_map('sanitize_key', (array) ($r['menus'] ?? []))),
                'can_delete'   => false, // هیچ‌کس نمی‌تواند داده را پاک کند — فقط بایگانی
                'can_settings' => !empty($r['can_settings']),
            ];
        }
        if (empty($clean)) {
            throw new RuntimeException('حداقل یک نقش لازم است');
        }
        update_option(self::OPT, $clean, false);
    }

    public static function available_menus(): array {
        return [
            'dashboard'      => 'داشبورد',
            'customers'      => 'مشتریان',
            'personnel'      => 'پرسنل',
            'finance'        => 'مالی و چک‌ها',
            'warehouse'      => 'انبار',
            'suppliers'      => 'تأمین‌کنندگان',
            'purchases'      => 'خریدها',
            'directives'     => 'دستورات',
            'fines'          => 'جریمه و پاداش',
            'salary'         => 'حقوق',
            'settings'       => 'تنظیمات',
            'roles'          => 'مدیریت نقش‌ها',
            'emp_dashboard'  => 'داشبورد من',
            'emp_report'     => 'گزارش روزانه',
            'emp_attendance' => 'ورود / خروج',
            'emp_leave'      => 'مرخصی',
            'emp_overtime'   => 'اضافه‌کاری',
            'emp_stock'      => 'اعلام مصرفی',
            'emp_messages'   => 'مکاتبات پروژه',
            'chat_history'   => 'تاریخچه چت',
            'cust_home'      => 'خانه مشتری',
            'cust_project'   => 'پروژه من',
            'cust_finance'   => 'مالی من',
        ];
    }
}
