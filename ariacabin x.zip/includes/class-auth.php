<?php
/**
 * احراز هویت پنل:
 * - مدیر اصلی هر کارگاه = کاربر وردپرس که در پیشخوان به آن پنل وصل شده
 * - بقیه = پرسنل همان کارگاه (موبایل/نام + رمز داخل جدول personnel)
 */
if (!defined('ABSPATH')) {
    exit;
}

class Samaneh_Auth {

    const SESSION_KEY = 'samaneh_panel_auth';

    public static function start_session(): void {
        if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
            $life = 10 * YEAR_IN_SECONDS; // حدود ۱۰ سال
            if (PHP_VERSION_ID >= 70300) {
                session_set_cookie_params([
                    'lifetime' => $life,
                    'path' => '/',
                    'secure' => is_ssl(),
                    'httponly' => true,
                    'samesite' => 'Lax',
                ]);
            } else {
                session_set_cookie_params($life, '/; samesite=Lax', '', is_ssl(), true);
            }
            ini_set('session.gc_maxlifetime', (string) $life);
            session_start();
        }
    }

    /** ماندگاری ورود تا وقتی کاربر خروج نزند */
    public static function persist_login(bool $remember = true): void {
        self::start_session();
        $auth = $_SESSION[self::SESSION_KEY] ?? null;
        if (!is_array($auth) || !$remember) {
            return;
        }
        $token = wp_hash(wp_json_encode($auth) . wp_salt('auth'));
        $payload = [
            'auth' => $auth,
            'token' => $token,
            'exp' => time() + (10 * YEAR_IN_SECONDS),
        ];
        $val = base64_encode(wp_json_encode($payload));
        setcookie('samaneh_panel_persist', $val, [
            'expires' => time() + (10 * YEAR_IN_SECONDS),
            'path' => '/',
            'secure' => is_ssl(),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        $_COOKIE['samaneh_panel_persist'] = $val;
    }

    public static function restore_from_cookie(): void {
        self::start_session();
        if (!empty($_SESSION[self::SESSION_KEY])) {
            return;
        }
        $raw = $_COOKIE['samaneh_panel_persist'] ?? '';
        if ($raw === '') {
            return;
        }
        $data = json_decode(base64_decode($raw), true);
        if (!is_array($data) || empty($data['auth']) || empty($data['token'])) {
            return;
        }
        if (!empty($data['exp']) && (int) $data['exp'] < time()) {
            return;
        }
        $auth = $data['auth'];
        $token = wp_hash(wp_json_encode($auth) . wp_salt('auth'));
        if (!hash_equals($token, (string) $data['token'])) {
            return;
        }
        $_SESSION[self::SESSION_KEY] = $auth;
    }

    /** نشست کاربر پنل برای یک instance */
    public static function get_panel_user(?int $instance_id = null): ?array {
        self::start_session();
        self::restore_from_cookie();
        $auth = $_SESSION[self::SESSION_KEY] ?? null;
        if (!is_array($auth)) {
            return null;
        }
        if ($instance_id !== null && (int) ($auth['instance_id'] ?? 0) !== (int) $instance_id) {
            return null;
        }
        return $auth;
    }

    public static function set_panel_user(array $user): void {
        self::start_session();
        $_SESSION[self::SESSION_KEY] = $user;
    }

    public static function clear_panel_user(): void {
        self::start_session();
        unset($_SESSION[self::SESSION_KEY]);
        if (!headers_sent()) {
            setcookie('samaneh_panel_persist', '', [
                'expires' => time() - 3600,
                'path' => '/',
                'secure' => is_ssl(),
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        }
        unset($_COOKIE['samaneh_panel_persist']);
    }

    /**
     * ورود پنل — کاربران پنل (مدیر/پرسنل/مشتری) فقط از جداول همان کارگاه هستند، نه وردپرس.
     * فقط مدیر شبکه / تستر کارگاه با یوزر وردپرس وارد می‌شوند.
     */
    public static function attempt_login(int $instance_id, string $login, string $password, bool $remember = false, string $expect = ''): array {
        $login = trim(samaneh_normalize_digits($login));
        $password = samaneh_normalize_digits((string) $password);
        if ($login === '' || $password === '') {
            throw new RuntimeException('نام کاربری و رمز را وارد کنید');
        }

        Samaneh_DB::set_instance($instance_id);
        $inst = Samaneh_Instances::get($instance_id);
        if (!$inst) {
            throw new RuntimeException('پنل یافت نشد');
        }
        try {
            Samaneh_DB::create_tables_for($instance_id);
        } catch (Throwable $e) {
            // ادامه
        }

        // --- اول: پرسنل / مدیر همان کارگاه (جدول personnel) ---
        if ($expect !== 'customer') {
        Samaneh_DB::ensure_password_column_public('personnel');
        $row = Samaneh_DB::find_personnel_for_login($login);
        if ($row) {
            $hash = (string) ($row['password'] ?? '');
            if ($hash === '') {
                throw new RuntimeException('برای این کاربر هنوز رمز تنظیم نشده. پرسنل را ویرایش کنید و رمز جدید بگذارید.');
            }
            $ok = wp_check_password($password, $hash);
            if (!$ok && !preg_match('/^\$[P2w]/', $hash) && hash_equals(samaneh_normalize_digits($hash), $password)) {
                Samaneh_DB::set_personnel_password((int) $row['id'], $password);
                $ok = true;
            }
            if (!$ok) {
                throw new RuntimeException('رمز عبور اشتباه است.');
            }
            $name = trim((string) ($row['name'] ?? ''));
            $phone = trim((string) ($row['phone'] ?? ''));
            $role_key = sanitize_key($row['role'] ?? 'employee');
            if ($role_key === '') {
                $role_key = 'employee';
            }
            if (!Samaneh_Roles::get($role_key) && $role_key !== 'management') {
                $role_key = 'employee';
            }
            $auth = [
                'type'         => 'personnel',
                'instance_id'  => $instance_id,
                'role'         => $role_key,
                'name'         => $name !== '' ? $name : $login,
                'login'        => $phone !== '' ? $phone : $name,
                'wp_user_id'   => 0,
                'personnel_id' => (int) ($row['id'] ?? 0),
                'is_main'      => !empty($row['is_main']) ? 1 : 0,
            ];
            self::set_panel_user($auth);
            return $auth;
        }
        } // expect !== customer

        // --- مدیر شبکه / تستر کارگاه با یوزر وردپرس (فقط این‌ها از WP وارد می‌شوند) ---
        if ($expect !== 'customer') {
        $by_login = get_user_by('login', $login);
        if (!$by_login) {
            $by_login = get_user_by('email', $login);
        }
        if ($by_login && wp_check_password($password, $by_login->user_pass, $by_login->ID)) {
            $is_net = (function_exists('is_super_admin') && is_super_admin($by_login->ID))
                || user_can($by_login, 'manage_network')
                || (is_multisite() && user_can($by_login, 'manage_sites'));
            if ($is_net) {
                $auth = [
                    'type'         => 'network_admin',
                    'instance_id'  => $instance_id,
                    'role'         => 'management',
                    'name'         => $by_login->display_name ?: $by_login->user_login,
                    'login'        => $by_login->user_login,
                    'wp_user_id'   => (int) $by_login->ID,
                    'personnel_id' => 0,
                    'is_main'      => 0,
                ];
                self::set_panel_user($auth);
                wp_set_current_user($by_login->ID);
                wp_set_auth_cookie($by_login->ID, $remember);
                return $auth;
            }
            $tester_role = self::tester_role_for((int) $by_login->ID, $instance_id);
            if ($tester_role) {
                $auth = [
                    'type'         => 'workshop_tester',
                    'instance_id'  => $instance_id,
                    'role'         => $tester_role,
                    'name'         => $by_login->display_name ?: $by_login->user_login,
                    'login'        => $by_login->user_login,
                    'wp_user_id'   => (int) $by_login->ID,
                    'personnel_id' => 0,
                    'is_main'      => 0,
                ];
                self::set_panel_user($auth);
                wp_set_current_user($by_login->ID);
                wp_set_auth_cookie($by_login->ID, $remember);
                return $auth;
            }
        }
        } // expect !== customer

        // --- مشتری پنل (موبایل + رمز) ---
        if ($expect === 'staff') {
            throw new RuntimeException('نام کاربری یا رمز اشتباه است');
        }
        $crow = Samaneh_DB::find_customer_for_login($login);
        if ($crow) {
            $hash = (string) ($crow['password'] ?? '');
            if ($hash === '') {
                throw new RuntimeException('برای این مشتری هنوز رمز تنظیم نشده. مشتری را ویرایش کنید و رمز بگذارید.');
            }
            $ok = wp_check_password($password, $hash);
            if (!$ok && !preg_match('/^\$[P2w]/', $hash) && hash_equals(samaneh_normalize_digits($hash), $password)) {
                Samaneh_DB::set_customer_password((int) $crow['id'], $password);
                $ok = true;
            }
            if (!$ok) {
                throw new RuntimeException('رمز عبور اشتباه است.');
            }
            $auth = [
                'type'         => 'customer',
                'instance_id'  => $instance_id,
                'role'         => 'customer',
                'name'         => $crow['name'] ?? $login,
                'login'        => $crow['phone'] ?: ($crow['name'] ?? ''),
                'wp_user_id'   => 0,
                'personnel_id' => 0,
                'customer_id'  => (int) ($crow['id'] ?? 0),
            ];
            self::set_panel_user($auth);
            return $auth;
        }

        throw new RuntimeException('نام کاربری یا رمز اشتباه است');
    }

    /** ورود مشتری فقط با موبایل (بدون رمز) */
    public static function login_as_customer(int $instance_id, array $row): array {
        Samaneh_DB::set_instance($instance_id);
        $auth = [
            'type'         => 'customer',
            'instance_id'  => $instance_id,
            'role'         => 'customer',
            'name'         => $row['name'] ?? ($row['phone'] ?? ''),
            'login'        => $row['phone'] ?: ($row['name'] ?? ''),
            'wp_user_id'   => 0,
            'personnel_id' => 0,
            'customer_id'  => (int) ($row['id'] ?? 0),
        ];
        self::set_panel_user($auth);
        return $auth;
    }

    public static function panel_role(): string {
        $auth = self::get_panel_user();
        if ($auth && !empty($auth['role'])) {
            return (string) $auth['role'];
        }
        // سازگاری: اگر فقط لاگین وردپرس است و مدیر این پنل است
        if (is_user_logged_in()) {
            $uid = get_current_user_id();
            if (user_can($uid, 'manage_options') || self::is_network_admin()) {
                return 'management';
            }
        }
        return 'none';
    }

    /** ادمین شبکه (زاگروس) — دسترسی کامل به همه کارگاه‌ها بدون حضور در لیست پرسنل */
    public static function is_network_admin(): bool {
        if (!is_user_logged_in()) {
            $auth = self::get_panel_user();
            return is_array($auth) && ($auth['type'] ?? '') === 'network_admin';
        }
        if (function_exists('is_super_admin') && is_super_admin()) {
            return true;
        }
        // در غیرمولتی‌سایت هم کاربر با manage_network یا manage_options سطح بالا
        return current_user_can('manage_network') || (is_multisite() && current_user_can('manage_sites'));
    }

    /** فقط مدیر شبکه رکوردهای حذف‌شده را (کمرنگ) می‌بیند */
    public static function can_see_deleted(): bool {
        return self::is_network_admin();
    }

    /** حذف نهایی فقط از پیشخوان وردپرس توسط مدیر شبکه — نه از پنل */
    public static function can_purge(): bool {
        if (!is_admin() || wp_doing_ajax()) {
            // درخواست پنل از template_redirect است نه wp-admin
            if (!is_admin()) {
                return false;
            }
        }
        $uri = (string) ($_SERVER['REQUEST_URI'] ?? '');
        if (preg_match('#/(panel[^/]*)/(api|login)/?#', $uri)) {
            return false;
        }
        return function_exists('is_super_admin') && is_super_admin();
    }

    /**
     * کاربر تستر کارگاه — نگاشت از گزینه شبکه:
     * [ user_id => [ "blogId_instanceId" => "role", ... ] ]
     * فقط مدیر شبکه می‌تواند از پیشخوان شبکه تنظیم کند.
     */
    public static function tester_access_all(): array {
        $raw = is_multisite() ? get_site_option('samaneh_workshop_testers', []) : get_option('samaneh_workshop_testers', []);
        return is_array($raw) ? $raw : [];
    }

    public static function tester_access_save(array $map): void {
        if (is_multisite()) {
            update_site_option('samaneh_workshop_testers', $map);
        } else {
            update_option('samaneh_workshop_testers', $map, false);
        }
    }

    /** نقش تستر برای این instance روی سایت فعلی؛ null اگر دسترسی ندارد */
    public static function tester_role_for(int $user_id, int $instance_id): ?string {
        if ($user_id < 1 || $instance_id < 1) {
            return null;
        }
        $all = self::tester_access_all();
        $uid = (string) $user_id;
        if (empty($all[$uid]) || !is_array($all[$uid])) {
            return null;
        }
        $blog_id = get_current_blog_id();
        $key = $blog_id . '_' . $instance_id;
        $role = $all[$uid][$key] ?? null;
        if (!$role || !is_string($role)) {
            return null;
        }
        $role = sanitize_key($role);
        if (!Samaneh_Roles::get($role) && $role !== 'management') {
            return null;
        }
        return $role;
    }

    /** مدیر کل این کارگاه = پرسنل با is_main=1 (نه کاربر وردپرس) */
    public static function is_main_manager(?int $instance_id = null): bool {
        $auth = self::get_panel_user($instance_id);
        if (!$auth) {
            return false;
        }
        // مدیر شبکه همه جا قدرت مدیر کل را دارد
        if (($auth['type'] ?? '') === 'network_admin' || self::is_network_admin()) {
            return true;
        }
        if (!empty($auth['is_main'])) {
            return true;
        }
        // سازگاری: اگر پرسنل management است و در کل کارگاه فقط یک مدیر با is_main داریم و این همان است
        $pid = (int) ($auth['personnel_id'] ?? 0);
        if ($pid > 0 && ($auth['role'] ?? '') === 'management') {
            $iid = $instance_id ?? (int) ($auth['instance_id'] ?? 0);
            if ($iid > 0) {
                Samaneh_DB::set_instance($iid);
                $row = Samaneh_DB::get_row('personnel', $pid);
                if ($row && !empty($row['is_main'])) {
                    return true;
                }
            }
        }
        return false;
    }

    public static function can_access(?int $instance_id = null): bool {
        if ($instance_id && class_exists('Samaneh_Grants') && !Samaneh_Grants::is_single_site_open()) {
            $blog = get_current_blog_id();
            if (!self::is_network_admin() && !Samaneh_Grants::site_is_enabled($blog)) {
                $auth = self::get_panel_user($instance_id);
                if (!$auth || ($auth['type'] ?? '') !== 'network_admin') {
                    return false;
                }
            }
        }
        $auth = self::get_panel_user($instance_id);
        if ($auth && ($auth['role'] ?? 'none') !== 'none') {
            return true;
        }
        // مدیر شبکه زاگروس — دسترسی به همه کارگاه‌ها بدون حضور در لیست پرسنل
        if (self::is_network_admin()) {
            if ($instance_id) {
                $u = wp_get_current_user();
                self::set_panel_user([
                    'type'         => 'network_admin',
                    'instance_id'  => $instance_id,
                    'role'         => 'management',
                    'name'         => $u->display_name ?: $u->user_login,
                    'login'        => $u->user_login,
                    'wp_user_id'   => (int) $u->ID,
                    'personnel_id' => 0,
                ]);
            }
            return true;
        }
        // مدیر وردپرس سایت در پیشخوان
        if (is_user_logged_in() && current_user_can('manage_options')) {
            return true;
        }
        // کاربر تستر کارگاه (از شبکه)
        if ($instance_id && is_user_logged_in()) {
            $tester_role = self::tester_role_for(get_current_user_id(), $instance_id);
            if ($tester_role) {
                $u = wp_get_current_user();
                self::set_panel_user([
                    'type'         => 'workshop_tester',
                    'instance_id'  => $instance_id,
                    'role'         => $tester_role,
                    'name'         => $u->display_name ?: $u->user_login,
                    'login'        => $u->user_login,
                    'wp_user_id'   => (int) $u->ID,
                    'personnel_id' => 0,
                ]);
                return true;
            }
        }
        return false;
    }

    public static function require_login(int $instance_id = 1): void {
        if (self::can_access($instance_id)) {
            return;
        }
        $inst = Samaneh_Instances::get($instance_id);
        $slug = $inst['slug'] ?? 'panel';
        wp_safe_redirect(home_url('/' . $slug . '/login/'));
        exit;
    }

    public static function current_user_payload(): array {
        $auth = self::get_panel_user();
        if ($auth) {
            $iid = (int) ($auth['instance_id'] ?? 1);
            return [
                'id'               => (int) ($auth['personnel_id'] ?: $auth['wp_user_id'] ?: 0),
                'name'             => $auth['name'] ?? '',
                'login'            => $auth['login'] ?? '',
                'role'             => $auth['role'] ?? 'employee',
                'type'             => $auth['type'] ?? 'personnel',
                'instance_id'      => $iid,
                'is_network_admin' => self::is_network_admin(),
                'is_main_manager'  => self::is_main_manager($iid),
                'can_see_deleted'  => self::can_see_deleted(),
                'can_purge'        => false,
            ];
        }
        if (is_user_logged_in()) {
            $u = wp_get_current_user();
            $is_net = self::is_network_admin();
            return [
                'id'               => (int) $u->ID,
                'name'             => $u->display_name ?: $u->user_login,
                'login'            => $u->user_login,
                'role'             => ($is_net || user_can($u, 'manage_options')) ? 'management' : 'none',
                'is_network_admin' => $is_net,
                'is_main_manager'  => false,
                'type'  => 'wp',
            ];
        }
        return ['id' => 0, 'name' => '', 'login' => '', 'role' => 'none', 'type' => 'guest'];
    }

    public static function personnel_name(): string {
        $auth = self::get_panel_user();
        if ($auth) {
            return $auth['name'] ?? '';
        }
        $u = wp_get_current_user();
        return $u->display_name ?: $u->user_login;
    }

    public static function logout(int $instance_id = 1): void {
        self::clear_panel_user();
        // فقط اگر مدیر WP بود کوکی WP را نگه می‌داریم برای پیشخوان؛ پرسنل را کامل خارج نکن از WP اگر نبوده
        $inst = Samaneh_Instances::get($instance_id);
        $slug = $inst['slug'] ?? 'panel';
        wp_safe_redirect(home_url('/' . $slug . '/login/'));
        exit;
    }

    public static function list_admins(): array {
        $out = [];
        foreach (get_users(['role' => 'administrator', 'number' => 100]) as $u) {
            $out[] = ['id' => (int) $u->ID, 'name' => $u->display_name ?: $u->user_login];
        }
        return $out;
    }

    public static function list_staff(): array {
        $out = [];
        // پرسنل از جدول پنل
        try {
            $rows = Samaneh_DB::fetch_all()['personnel'] ?? [];
            foreach ($rows as $r) {
                $out[] = ['id' => (int) ($r['id'] ?? 0), 'name' => $r['name'] ?? '', 'role' => $r['role'] ?? ''];
            }
        } catch (Throwable $e) {
        }
        return $out;
    }

    /** تاریخ/ساعت فعلی طبق تنظیمات وردپرس */
    /**
     * تاریخ/ساعت طبق وردپرس + سازگاری با پارسی‌دیت و افزونه‌های مشابه
     */
    public static function wp_datetime(): array {
        $ts = current_time('timestamp');
        $date_fmt = get_option('date_format') ?: 'Y/m/d';
        $time_fmt = get_option('time_format') ?: 'H:i';

        // پارسی‌دیت / توابع رایج شمسی
        $date = self::format_wp_date($date_fmt, $ts);
        $time = self::format_wp_date($time_fmt, $ts);
        $iso_shamsi = self::format_wp_date('Y/m/d', $ts);
        $iso_dt_shamsi = self::format_wp_date('Y/m/d H:i', $ts);

        return [
            'mysql'       => current_time('mysql'),
            'date'        => $date,
            'time'        => $time,
            'iso'         => $iso_shamsi, // نمایش شمسی برای فرم‌ها
            'iso_dt'      => $iso_dt_shamsi,
            'iso_gregorian'=> date('Y-m-d', $ts), // ذخیره استاندارد در صورت نیاز
            'tz'          => wp_timezone_string(),
            'calendar'    => self::is_jalali_active() ? 'jalali' : 'gregorian',
        ];
    }

    public static function is_jalali_active(): bool {
        return true; // همیشه شمسی — مبدل داخلی
    }

    public static function format_wp_date(string $format, ?int $ts = null): string {
        if ($ts === null) {
            $ts = current_time('timestamp');
        }
        // ترجیح: مبدل داخلی شمسی
        if (class_exists('Samaneh_Jalali')) {
            // فقط بخش تاریخ را شمسی کن؛ اگر فرمت فقط ساعت است همان میلادی
            if (preg_match('/[Yymd]/', $format)) {
                return Samaneh_Jalali::format_from_timestamp($ts, $format);
            }
        }
        if (function_exists('parsidate')) {
            return (string) parsidate($format, $ts, 'per');
        }
        if (function_exists('wp_date')) {
            return (string) wp_date($format, $ts);
        }
        return (string) date_i18n($format, $ts);
    }
}

