<?php
if (!defined('ABSPATH')) {
    exit;
}

class Samaneh_Login {

    public static function maybe_serve(): void {
        $instance_id = 0;
        $matched = null;

        if ((int) get_query_var('samaneh_login') === 1) {
            $instance_id = max(1, (int) get_query_var('samaneh_instance'));
            $matched = Samaneh_Instances::get($instance_id);
        } else {
            $uri = $_SERVER['REQUEST_URI'] ?? '';
            $path = wp_parse_url($uri, PHP_URL_PATH);
            $home = wp_parse_url(home_url('/'), PHP_URL_PATH) ?: '/';
            $rel = '/' . ltrim(substr((string) $path, strlen(rtrim($home, '/'))), '/');
            foreach (Samaneh_Instances::all() as $inst) {
                $slug = $inst['slug'] ?? '';
                if ($slug && preg_match('#^/' . preg_quote($slug, '#') . '/login/?$#', $rel)) {
                    $matched = $inst;
                    $instance_id = (int) $inst['id'];
                    break;
                }
            }
        }

        if (!$matched) {
            return;
        }

        if (class_exists('Samaneh_Grants') && !Samaneh_Grants::site_is_enabled() && !Samaneh_Auth::is_network_admin()) {
            header('Content-Type: text/html; charset=utf-8');
            echo '<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><title>قفل</title></head><body style="font-family:Tahoma;background:#0f172a;color:#e2e8f0;display:flex;align-items:center;justify-content:center;min-height:100vh">';
            echo '<div style="max-width:420px;text-align:center"><h1>افزونه روی این سایت فعال نیست</h1><p>دسترسی این کارگاه هنوز توسط مدیر شبکه زاگرس داده نشده است.</p></div></body></html>';
            exit;
        }

        if (isset($_GET['samaneh_logout'])) {
            Samaneh_Auth::clear_panel_user();
            wp_safe_redirect(home_url('/' . ($matched['slug'] ?? 'panel') . '/login/'));
            exit;
        }

        if (Samaneh_Auth::can_access($instance_id)) {
            wp_safe_redirect(home_url('/' . $matched['slug'] . '/'));
            exit;
        }

        $error = '';
        $info = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['samaneh_login'])) {
            check_admin_referer('samaneh_login');
            try {
                if (!session_id()) {
                    @session_start();
                }
                $a = (int) samaneh_normalize_digits((string) ($_POST['cap_a'] ?? 0));
                $b = (int) samaneh_normalize_digits((string) ($_POST['cap_b'] ?? 0));
                $op = (string) ($_POST['cap_op'] ?? '+');
                $ans = (int) samaneh_normalize_digits((string) ($_POST['cap_ans'] ?? -99999));
                $expected = self::calc($a, $b, $op);
                $sess = (int) ($_SESSION['samaneh_cap_' . $instance_id] ?? -1);
                if ($ans !== $expected || $ans !== $sess) {
                    throw new RuntimeException('پاسخ کپچا نادرست است');
                }

                $login_type = sanitize_text_field($_POST['login_type'] ?? 'customer');
                $log = samaneh_normalize_digits(sanitize_text_field(wp_unslash($_POST['log'] ?? '')));
                $pwd = samaneh_normalize_digits((string) ($_POST['pwd'] ?? ''));

                if (trim($pwd) === '') {
                    throw new RuntimeException('رمز عبور را وارد کنید');
                }
                if ($login_type === 'customer') {
                    Samaneh_DB::set_instance($instance_id);
                    $found = Samaneh_DB::find_customer_for_login($log);
                    if (!$found) {
                        // مشتری ناشناس: سرنخ ذخیره شود، ورود نشود
                        self::save_lead($instance_id, $log);
                        $info = 'این شماره در مشتریان این کارگاه نیست. به‌زودی با شما تماس می‌گیریم.';
                    } else {
                        Samaneh_Auth::attempt_login($instance_id, $log, $pwd, true, 'customer');
                        Samaneh_Auth::persist_login(true);
                        wp_safe_redirect(home_url('/' . $matched['slug'] . '/'));
                        exit;
                    }
                } else {
                    Samaneh_Auth::attempt_login($instance_id, $log, $pwd, true, 'staff');
                    Samaneh_Auth::persist_login(true);
                    wp_safe_redirect(home_url('/' . $matched['slug'] . '/'));
                    exit;
                }
            } catch (Throwable $e) {
                $error = $e->getMessage();
            }
        }

        self::render($matched, $error, $info);
        exit;
    }

    private static function calc(int $a, int $b, string $op): int {
        if ($op === '-') {
            return $a - $b;
        }
        if ($op === '×' || $op === '*') {
            return $a * $b;
        }
        return $a + $b;
    }

    private static function find_customer_by_phone(int $instance_id, string $phone): ?array {
        global $wpdb;
        Samaneh_DB::set_instance($instance_id);
        $t = Samaneh_DB::table('customers');
        $phone = preg_replace('/\D+/', '', $phone);
        // phpcs:ignore
        $rows = $wpdb->get_results("SELECT * FROM `{$t}`", ARRAY_A);
        if (!is_array($rows)) {
            return null;
        }
        foreach ($rows as $r) {
            $p = preg_replace('/\D+/', '', (string) ($r['phone'] ?? ''));
            if ($p !== '' && $p === $phone) {
                return $r;
            }
        }
        return null;
    }

    private static function save_lead(int $instance_id, string $phone): void {
        Samaneh_DB::set_instance($instance_id);
        try {
            Samaneh_DB::create_tables_for($instance_id);
        } catch (Throwable $e) {
        }
        global $wpdb;
        $t = Samaneh_DB::table('leads');
        // phpcs:ignore
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t));
        if (!$exists) {
            return;
        }
        $phone = sanitize_text_field($phone);
        $wpdb->insert($t, [
            'phone'  => $phone,
            'note'   => 'درخواست ورود از صفحه لاگین',
            'status' => 'new',
            'source' => 'login',
        ]);
        $lead = [
            'phone' => $phone,
            'time'  => current_time('mysql'),
            'id'    => (int) $wpdb->insert_id,
        ];
        // صف چندتایی درخواست‌ها (نه فقط یکی)
        $leads = get_option('samaneh_new_leads_' . $instance_id, []);
        if (!is_array($leads)) {
            $leads = [];
        }
        // سازگاری با تک‌لید قدیمی
        $old_one = get_option('samaneh_new_lead_' . $instance_id, null);
        if (is_array($old_one) && !empty($old_one['phone'])) {
            $leads[] = $old_one;
            delete_option('samaneh_new_lead_' . $instance_id);
        }
        $leads[] = $lead;
        // حداکثر ۵۰ مورد اخیر
        if (count($leads) > 50) {
            $leads = array_slice($leads, -50);
        }
        update_option('samaneh_new_leads_' . $instance_id, array_values($leads), false);
        update_option('samaneh_new_lead_' . $instance_id, $lead, false); // آخرین برای سازگاری
    }

    private static function render(array $inst, string $error, string $info = ''): void {
        if (!session_id()) {
            @session_start();
        }
        $name  = ($inst['name'] ?? '') !== '' ? $inst['name'] : 'سامانه';
        $logo  = $inst['logo'] ?? '';
        $theme = is_array($inst['theme'] ?? null) ? $inst['theme'] : [];
        $slug  = $inst['slug'] ?? 'panel';
        $iid   = (int) ($inst['id'] ?? 1);
        $login_logo = $theme['login_logo'] ?? $logo;
        $login_bg   = $theme['login_bg'] ?? '#0f172a';
        $login_card = $theme['login_card_bg'] ?? '#ffffff';
        $primary    = $theme['login_btn'] ?? ($theme['primary'] ?? '#1d4ed8');
        $bg_img     = $theme['login_bg_image'] ?? '';
        $css = SAMANEH_CORE_URL . 'assets/app.css?v=' . SAMANEH_CORE_VERSION;

        $phone = (string) get_option('samaneh_company_phone_' . $iid, get_option('samaneh_company_phone', ''));
        $socials = [
            'instagram' => (string) get_option('samaneh_social_instagram_' . $iid, get_option('samaneh_social_instagram', '')),
            'telegram'  => (string) get_option('samaneh_social_telegram_' . $iid, get_option('samaneh_social_telegram', '')),
            'whatsapp'  => (string) get_option('samaneh_social_whatsapp_' . $iid, get_option('samaneh_social_whatsapp', '')),
            'linkedin'  => (string) get_option('samaneh_social_linkedin_' . $iid, get_option('samaneh_social_linkedin', '')),
            'website'   => (string) get_option('samaneh_social_website_' . $iid, get_option('samaneh_social_website', '')),
            'aparat'    => (string) get_option('samaneh_social_aparat_' . $iid, get_option('samaneh_social_aparat', '')),
        ];

        $ops = ['+', '-', '×'];
        $op = $ops[array_rand($ops)];
        if ($op === '-') {
            $a = random_int(5, 20);
            $b = random_int(1, $a);
        } elseif ($op === '×') {
            $a = random_int(2, 9);
            $b = random_int(2, 9);
        } else {
            $a = random_int(1, 15);
            $b = random_int(1, 15);
        }
        $expected = self::calc($a, $b, $op);
        $_SESSION['samaneh_cap_' . $iid] = $expected;

        $dt = Samaneh_Auth::wp_datetime();

        header('Content-Type: text/html; charset=utf-8');
        ?><!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ورود — <?php echo esc_html($name); ?></title>
<link rel="stylesheet" href="<?php echo esc_url($css); ?>">
<style>
.login-page {
  min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 24px;
  background: <?php echo esc_attr($login_bg); ?>;
  <?php if ($bg_img): ?>background-image: url('<?php echo esc_url($bg_img); ?>'); background-size: cover; background-position: center;<?php endif; ?>
}
.login-card {
  background: <?php echo esc_attr($login_card); ?>; border-radius: 16px; padding: 36px 32px; width: 100%; max-width: 420px;
  box-shadow: 0 25px 60px rgba(0,0,0,.35);
}
.login-logo { text-align: center; margin-bottom: 20px; }
.login-logo img { max-height: 72px; max-width: 200px; object-fit: contain; }
.login-logo h1 { font-size: 1.25rem; margin-top: 10px; color: #0f172a; }
.login-card .field { margin-bottom: 14px; }
.login-card label { display: block; font-size: .8rem; color: #64748b; margin-bottom: 4px; }
.login-card input[type=text], .login-card input[type=password] {
  width: 100%; padding: 10px 12px; border: 1px solid #e2e8f0; border-radius: 8px; font-size: .95rem; font-family: inherit;
}
.login-card .btn {
  width: 100%; padding: 12px; font-size: 1rem; margin-top: 8px; border-radius: 8px;
  background: <?php echo esc_attr($primary); ?>; color: #fff; border: none; cursor: pointer; font-family: inherit;
}
.login-error { background: #fef2f2; color: #b91c1c; padding: 10px 12px; border-radius: 8px; font-size: .85rem; margin-bottom: 14px; }
.login-info { background: #ecfdf5; color: #047857; padding: 10px 12px; border-radius: 8px; font-size: .9rem; margin-bottom: 14px; }
.login-tabs { display:flex; gap:8px; margin-bottom:16px; }
.login-tabs button { flex:1; padding:10px; border:1px solid #e2e8f0; background:#f8fafc; border-radius:8px; cursor:pointer; font-family:inherit; }
.login-tabs button.active { background: <?php echo esc_attr($primary); ?>; color:#fff; border-color:transparent; }
.cap-row { display:flex; align-items:center; gap:10px; flex-wrap:nowrap; direction:ltr; justify-content:flex-start; }
.cap-row .cap-eq { font-weight:700; color:#0f172a; white-space:nowrap; direction:ltr; }
.cap-row input { max-width: 120px; direction:ltr; text-align:left; }
.login-foot { text-align: center; margin-top: 18px; font-size: .8rem; color: #64748b; line-height: 1.7; }
.login-foot a { color: <?php echo esc_attr($primary); ?>; text-decoration: none; margin: 0 6px; }
.login-foot .phone { font-weight: 700; font-size: .95rem; color: #0f172a; display: block; margin: 6px 0; }
.login-time { text-align: center; font-size: .75rem; color: #94a3b8; margin-bottom: 12px; }
.cap-box { background:#f8fafc; border:1px solid #e2e8f0; border-radius:10px; padding:12px; margin-bottom:14px; }
</style>
</head>
<body>
<div class="login-page">
  <div class="login-card">
    <div class="login-logo">
      <?php if ($login_logo): ?><img src="<?php echo esc_url($login_logo); ?>" alt=""><?php endif; ?>
      <h1><?php echo esc_html($name); ?></h1>
    </div>
    <div class="login-time"><?php echo esc_html(is_array($dt) ? (($dt['iso_dt'] ?? $dt['date'] ?? '') . ' ' . ($dt['time'] ?? '')) : (string) $dt); ?></div>
    <?php if ($error): ?><div class="login-error"><?php echo esc_html($error); ?></div><?php endif; ?>
    <?php if ($info): ?><div class="login-info"><?php echo esc_html($info); ?></div><?php endif; ?>

    <div class="login-tabs">
      <button type="button" class="active" data-tab="staff">پرسنل / مدیر</button>
      <button type="button" data-tab="customer">مشتری</button>
    </div>

    <form method="post" id="login-form">
      <?php wp_nonce_field('samaneh_login'); ?>
      <input type="hidden" name="samaneh_login" value="1">
      <input type="hidden" name="login_type" id="login_type" value="staff">
      <input type="hidden" name="cap_a" value="<?php echo (int) $a; ?>">
      <input type="hidden" name="cap_b" value="<?php echo (int) $b; ?>">
      <input type="hidden" name="cap_op" value="<?php echo esc_attr($op); ?>">

      <div class="field">
        <label id="log-label">موبایل یا نام</label>
        <input type="text" name="log" required autocomplete="username" placeholder="09... یا نام">
      </div>
      <div class="field" id="pwd-field">
        <label>رمز عبور</label>
        <input type="password" name="pwd" id="pwd-input" autocomplete="current-password" required>
      </div>

      <!-- کپچا: عبارت سمت چپ، جواب سمت راست -->
      <div class="cap-box">
        <div class="field" style="margin:0">
          <label>کپچا — ابتدا پاسخ را وارد کنید</label>
          <div class="cap-row">
            <span class="cap-eq"><?php echo (int) $a; ?> <?php echo esc_html($op); ?> <?php echo (int) $b; ?> =</span>
            <input type="text" name="cap_ans" required inputmode="numeric" placeholder="?" autocomplete="off">
          </div>
        </div>
      </div>
      <button type="submit" class="btn">ورود</button>
    </form>

    <div class="login-foot">
      <div>در صورت مشکل با کارگاه تماس بگیرید</div>
      <?php if ($phone): ?>
        <a class="phone" href="tel:<?php echo esc_attr(preg_replace('/\s+/', '', $phone)); ?>">📞 <?php echo esc_html($phone); ?></a>
      <?php endif; ?>
      <div style="margin-top:8px">
        <?php
        $labels = ['instagram' => 'اینستاگرام', 'telegram' => 'تلگرام', 'whatsapp' => 'واتساپ', 'linkedin' => 'لینکدین', 'website' => 'وب‌سایت', 'aparat' => 'آپارات'];
        foreach ($socials as $k => $url) {
            if (!$url) {
                continue;
            }
            $href = $url;
            if ($k === 'whatsapp' && preg_match('/^\+?\d+$/', preg_replace('/\s+/', '', $url))) {
                $href = 'https://wa.me/' . preg_replace('/\D+/', '', $url);
            }
            echo '<a href="' . esc_url($href) . '" target="_blank" rel="noopener">' . esc_html($labels[$k] ?? $k) . '</a>';
        }
        ?>
      </div>
    </div>
  </div>
</div>
<script>
(function(){
  var tabs = document.querySelectorAll('.login-tabs button');
  var type = document.getElementById('login_type');
  var pwdField = document.getElementById('pwd-field');
  var pwdInput = document.getElementById('pwd-input');
  var logLabel = document.getElementById('log-label');
  tabs.forEach(function(btn){
    btn.onclick = function(){
      tabs.forEach(function(b){ b.classList.remove('active'); });
      btn.classList.add('active');
      type.value = btn.dataset.tab;
      pwdField.style.display = '';
      pwdInput.setAttribute('required', 'required');
      if (btn.dataset.tab === 'customer') {
        logLabel.textContent = 'شماره موبایل';
      } else {
        logLabel.textContent = 'موبایل یا نام';
      }
    };
  });
  // تبدیل خودکار ارقام فارسی/عربی به انگلیسی در همه فیلدهای ورود
  function faToEn(s) {
    return String(s || '').replace(/[۰-۹]/g, function(d){ return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); }).replace(/[٠-٩]/g, function(d){ return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); });
  }
  function convertDigits(e) {
    var t = e.target;
    if (!t || (t.tagName !== 'INPUT' && t.tagName !== 'TEXTAREA')) return;
    var v = t.value;
    if (!v) return;
    var n = faToEn(v);
    if (n !== v) {
      var start = t.selectionStart, end = t.selectionEnd;
      t.value = n;
      try { if (typeof start === 'number') t.setSelectionRange(start, end); } catch (err) {}
    }
  }
  document.addEventListener('input', convertDigits, true);
  document.addEventListener('blur', convertDigits, true);
  var form = document.getElementById('login-form');
  if (form) {
    form.addEventListener('submit', function() {
      form.querySelectorAll('input').forEach(function(inp) {
        if (inp.value) inp.value = faToEn(inp.value);
      });
    });
  }
})();
</script>
</body>
</html><?php
    }
}
