<?php
/**
 * پل کارگاه آماده ↔ زاگرس کنترل
 */
if (!defined('ABSPATH')) {
    exit;
}

class Samaneh_Workshop_Bridge {

    public static function init(): void {
        add_filter('samaneh_boot_extra', [__CLASS__, 'boot_extra'], 10, 2);
        add_action('wp_ajax_samaneh_set_domain', [__CLASS__, 'ajax_set_domain']);
        // مسدود کردن ساخت سایت از داخل کارگاه
        add_action('admin_init', [__CLASS__, 'maybe_hide_site_create']);
    }

    public static function boot_extra(array $extra, int $instance_id): array {
        $support = class_exists('ZC_Workshop') ? (int) ZC_Workshop::get('support') : 45000000;
        $grace   = class_exists('ZC_Workshop') ? (int) ZC_Workshop::get('grace') : 3;
        $disk    = class_exists('ZC_Workshop') ? (int) ZC_Workshop::get('infra_disk') : 10000;
        $db      = class_exists('ZC_Workshop') ? (int) ZC_Workshop::get('infra_db') : 15000;
        $inst    = Samaneh_Instances::get($instance_id);
        $extra['workshop_billing'] = [
            'support_monthly' => $support,
            'grace_days'      => $grace,
            'infra_disk_kb'   => $disk,
            'infra_db_kb'     => $db,
            'domain'          => is_array($inst) ? ($inst['domain'] ?? '') : '',
            'slug_locked'     => true,
            'panel_url'       => is_array($inst) ? home_url('/' . ($inst['slug'] ?? 'panel') . '/') : '',
        ];
        return $extra;
    }

    public static function ajax_set_domain(): void {
        if (!is_user_logged_in()) {
            wp_send_json_error(['message' => 'ورود لازم است'], 401);
        }
        $domain = isset($_POST['domain']) ? sanitize_text_field(wp_unslash($_POST['domain'])) : '';
        $iid    = isset($_POST['instance_id']) ? absint($_POST['instance_id']) : 1;
        $domain = strtolower(trim($domain));
        $domain = preg_replace('#^https?://#i', '', $domain);
        $domain = preg_replace('#^www\.#i', '', $domain);
        $domain = preg_replace('#/.*$#', '', $domain);
        if ($domain === '' || !preg_match('/^[a-z0-9.\-]+\.[a-z]{2,}$/i', $domain)) {
            wp_send_json_error(['message' => 'دامنه نامعتبر']);
        }
        try {
            Samaneh_Instances::save($iid, ['domain' => $domain]);
        } catch (Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()]);
        }
        // تلاش برای domain mapping وردپرس اگر موجود باشد
        if (is_multisite() && function_exists('domain_exists')) {
            // ذخیره در site option برای reverse proxy / mapping دستی
            $map = get_site_option('zc_workshop_domains', []);
            if (!is_array($map)) {
                $map = [];
            }
            $map[$iid] = $domain;
            update_site_option('zc_workshop_domains', $map);
        }
        wp_send_json_success(['domain' => $domain, 'message' => 'دامنه ذخیره و به‌صورت خودکار اعمال شد']);
    }

    public static function maybe_hide_site_create(): void {
        if (!is_admin()) {
            return;
        }
        // اگر کاربر فقط مدیر کارگاه است و در سایت کارگاهی است
        if (get_option('zc_is_workshop')) {
            remove_submenu_page('sites.php', 'site-new.php');
        }
    }
}
