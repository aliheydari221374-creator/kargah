<?php
if (!defined('ABSPATH')) {
    exit;
}

class Samaneh_Router {

    public static function maybe_serve(): void {
        $is_panel = (int) get_query_var('samaneh_panel') === 1;
        $is_api   = (int) get_query_var('samaneh_panel_api') === 1;
        $instance_id = max(1, (int) get_query_var('samaneh_instance'));

        $uri  = $_SERVER['REQUEST_URI'] ?? '';
        $path = wp_parse_url($uri, PHP_URL_PATH);
        $home = wp_parse_url(home_url('/'), PHP_URL_PATH) ?: '/';
        $rel  = '/' . ltrim(substr((string) $path, strlen(rtrim($home, '/'))), '/');

        if (!$is_panel && !$is_api) {
            foreach (Samaneh_Instances::all() as $inst) {
                $slug = $inst['slug'] ?? '';
                if (!$slug) {
                    continue;
                }
                if (preg_match('#^/' . preg_quote($slug, '#') . '/?$#', $rel)) {
                    $is_panel = true;
                    $instance_id = (int) $inst['id'];
                    break;
                }
                if (preg_match('#^/' . preg_quote($slug, '#') . '/api/?$#', $rel)) {
                    $is_api = true;
                    $instance_id = (int) $inst['id'];
                    break;
                }
                // PWA manifest
                if (preg_match('#^/' . preg_quote($slug, '#') . '/manifest\.webmanifest/?$#', $rel)) {
                    Samaneh_DB::set_instance((int) $inst['id']);
                    self::serve_manifest((int) $inst['id']);
                    exit;
                }
                // Service worker
                if (preg_match('#^/' . preg_quote($slug, '#') . '/sw\.js/?$#', $rel)) {
                    self::serve_sw($slug);
                    exit;
                }
            }
        }

        Samaneh_DB::set_instance($instance_id);

        if ($is_api) {
            Samaneh_API::handle();
            exit;
        }
        if (!$is_panel) {
            return;
        }

        if (class_exists('Samaneh_Grants') && !Samaneh_Grants::site_is_enabled() && !Samaneh_Auth::is_network_admin()) {
            self::render_locked($instance_id);
            exit;
        }

        if (!Samaneh_Auth::can_access()) {
            $inst = Samaneh_Instances::get($instance_id);
            $slug = $inst['slug'] ?? 'panel';
            wp_safe_redirect(home_url('/' . $slug . '/login/'));
            exit;
        }

        self::render($instance_id);
        exit;
    }

    private static function render_locked(int $instance_id): void {
        $inst = Samaneh_Instances::get($instance_id) ?: [];
        $name = ($inst['name'] ?? '') !== '' ? $inst['name'] : 'کارگاه آماده';
        header('Content-Type: text/html; charset=utf-8');
        echo '<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
        echo '<title>' . esc_html($name) . '</title>';
        echo '<style>body{font-family:Tahoma,sans-serif;background:#0f172a;color:#e2e8f0;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}';
        echo '.box{background:#1e293b;padding:32px;border-radius:16px;max-width:420px;text-align:center}h1{font-size:1.2rem}p{color:#94a3b8;line-height:1.8}</style></head><body>';
        echo '<div class="box"><h1>افزونه روی این سایت فعال نیست</h1>';
        echo '<p>دسترسی این کارگاه به بخش‌های کارگاه آماده هنوز توسط مدیر شبکه زاگرس داده نشده است. با پشتیبانی تماس بگیرید.</p></div></body></html>';
    }

    private static function render(int $instance_id): void {
        Samaneh_DB::create_tables_for($instance_id);
        $boot = Samaneh_DB::fetch_all();
        if (!is_array($boot)) {
            $boot = [];
        }
        if (!isset($boot['extra']) || !is_array($boot['extra'])) {
            $boot['extra'] = [];
        }
        $boot['extra'] = apply_filters('samaneh_boot_extra', $boot['extra'], $instance_id);
        $user = Samaneh_Auth::current_user_payload();
        $role = $user['role'];
        $boot = Samaneh_RBAC::filter_boot($boot, $role);
        $policy = Samaneh_RBAC::policy($role);
        $inst = Samaneh_Instances::get($instance_id) ?: [];
        $company = ($inst['name'] ?? '') !== '' ? $inst['name'] : 'سامانه';
        $logo = $inst['logo'] ?? '';
        $slug = $inst['slug'] ?? 'panel';
        $theme = is_array($inst['theme'] ?? null) ? $inst['theme'] : [];
        $g = function ($k, $d) use ($theme) {
            $v = $theme[$k] ?? $d;
            return preg_match('/^#[0-9a-fA-F]{3,8}$/', (string) $v) || preg_match('/^rgba?\(/', (string) $v) ? $v : $d;
        };
        $primary = $g('primary', '#0a7cff');
        $primary_h = $g('primary_hover', $primary);
        $sidebar_bg = $g('sidebar_bg', '#ffffff');
        $sidebar_text = $g('sidebar_text', '#1a1d21');
        $sidebar_active = $g('sidebar_active', '#0a7cff');
        $content_bg = $g('content_bg', '#f0f2f5');
        $card_bg = $g('card_bg', '#ffffff');
        $card_border = $g('card_border', '#e2e8f0');
        $text_c = $g('text', '#1a1d21');
        $muted = $g('muted', '#6b7280');
        $header_bg = $g('header_bg', '#ffffff');
        $header_text = $g('header_text', '#0f172a');
        $table_h = $g('table_header', '#f8fafc');
        $danger = $g('danger', '#dc2626');
        $success = $g('success', '#16a34a');
        $bc = $g('banner_critical', '#7f1d1d');
        $bi = $g('banner_important', '#9a3412');
        $bg_image = esc_url($theme['bg_image'] ?? '');
        $font_base = sanitize_text_field($theme['font_family'] ?? 'Tahoma');
        $font_side = sanitize_text_field($theme['font_sidebar'] ?? $font_base);
        $font_head = sanitize_text_field($theme['font_heading'] ?? 'Tahoma');
        $fs_base = max(11, min(28, (int) ($theme['font_size'] ?? 16)));
        $fs_side = max(11, min(28, (int) ($theme['font_size_sidebar'] ?? 16)));
        $fs_head = max(11, min(32, (int) ($theme['font_size_heading'] ?? 18)));
        $font_face_css = '';
        if (!empty($theme['custom_fonts']) && is_array($theme['custom_fonts'])) {
            foreach ($theme['custom_fonts'] as $fn => $furl) {
                $fn = sanitize_text_field($fn);
                $furl = esc_url($furl);
                $ext = strtolower(pathinfo(parse_url($furl, PHP_URL_PATH) ?: '', PATHINFO_EXTENSION));
                $fmt = $ext === 'woff2' ? 'woff2' : ($ext === 'woff' ? 'woff' : ($ext === 'otf' ? 'opentype' : 'truetype'));
                $font_face_css .= "@font-face{font-family:'{$fn}';src:url('{$furl}') format('{$fmt}');font-weight:normal;font-style:normal;font-display:swap;}";
            }
        }
        $use_grad = !empty($theme['use_gradient']);
        $grad_from = sanitize_hex_color($theme['grad_from'] ?? '#0f172a') ?: '#0f172a';
        $grad_to = sanitize_hex_color($theme['grad_to'] ?? '#1e3a5f') ?: '#1e3a5f';
        $grad_dir = in_array($theme['grad_dir'] ?? '', ['to bottom', 'to left', 'to bottom left'], true) ? $theme['grad_dir'] : 'to bottom';
        $sidebar_bg_css = $use_grad
            ? "linear-gradient({$grad_dir}, {$grad_from}, {$grad_to})"
            : $sidebar_bg;
        $theme_css = $font_face_css . ":root{--p:{$primary};--p-h:{$primary_h};--p-hover:{$primary_h};--bg:{$content_bg};--card:{$card_bg};--t:{$text_c};--m:{$muted};--b:{$card_border};--d:{$danger};--ok:{$success};--font-size-base:{$fs_base}px;--drawer-bg:{$sidebar_bg};--drawer-t:{$sidebar_text};--drawer-item-hover:{$sidebar_active};}
body{color:{$text_c};background:{$content_bg};font-family:\"{$font_base}\",\"B Nazanin\",Vazirmatn,Tahoma,sans-serif!important;font-size:{$fs_base}px}
.sidebar{background:{$sidebar_bg_css}!important;color:{$sidebar_text}!important;font-family:\"{$font_side}\",\"B Nazanin\",sans-serif!important;font-size:{$fs_side}px}
.sidebar .brand{color:{$sidebar_text}!important;font-family:\"{$font_head}\",\"B Zar\",sans-serif!important;font-size:{$fs_head}px}
.sidebar a{color:{$sidebar_text}!important;opacity:.85}
.sidebar a:hover,.sidebar a.active{opacity:1;background:{$sidebar_active}!important}
body:not(.theme-dark) .drawer{background:{$sidebar_bg_css}!important;color:{$sidebar_text}!important}body:not(.theme-dark) .drawer-nav a,body:not(.theme-dark) #nav a{color:{$sidebar_text}!important}body:not(.theme-dark) .drawer-nav a:hover,body:not(.theme-dark) #nav a:hover{background:var(--drawer-item-hover,#f3f4f6)!important}body:not(.theme-dark) .drawer-nav a.active,body:not(.theme-dark) #nav a.active{background:{$sidebar_active}!important;color:#fff!important;box-shadow:0 4px 14px rgba(10,124,255,.35)}body.theme-dark .drawer,body.theme-dark #drawer{background:#1a1a1e!important;color:#fff!important}body.theme-dark .drawer-nav a,body.theme-dark #nav a,body.theme-dark .drawer-nav a .nav-label,body.theme-dark #nav a .nav-label{color:#ffffff!important}body.theme-dark .drawer-nav a:not(.active),body.theme-dark #nav a:not(.active){color:#ffffff!important;background:transparent!important}body.theme-dark .drawer-nav a.active,body.theme-dark #nav a.active{background:{$sidebar_active}!important;color:#fff!important}
.topbar{background:{$header_bg}!important;color:{$header_text}!important}
.topbar strong,.user-meta{color:{$header_text}!important}
.card h2,.modal-head strong{font-family:\"{$font_head}\",\"B Zar\",sans-serif!important}
.content{background:{$content_bg}}
.card{background:{$card_bg}!important;border-color:{$card_border}!important}
.btn{background:{$primary}!important}.btn:hover{background:{$primary_h}!important}
.btn-danger{background:{$danger}!important}
.btn-outline{border-color:{$card_border}!important;color:{$text_c}!important;background:transparent!important}
table th{background:{$table_h}!important}
.empty,.hint{color:{$muted}!important}
.dir-banner.dir-critical{background:{$bc}!important}
.dir-banner.dir-important{background:{$bi}!important}"
            . ($bg_image ? ".layout .content{background-image:url('{$bg_image}');background-size:cover;background-attachment:fixed}" : '');

        $boot_json   = wp_json_encode($boot, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS);
        $user_json   = wp_json_encode($user, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS);
        $policy_json = wp_json_encode($policy, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS);
        $api_url     = esc_url(home_url('/' . $slug . '/api/'));
        $assets      = SAMANEH_CORE_URL . 'assets/';
        $nonce       = samaneh_panel_nonce();
        $logout      = home_url('/' . $slug . '/login/?samaneh_logout=1');
        $fields      = wp_json_encode(Samaneh_DB::fields(), JSON_UNESCAPED_UNICODE);
        $mod_assets  = apply_filters('samaneh_module_assets', ['css' => [], 'js' => []]);

        header('Content-Type: text/html; charset=utf-8');
        ?><!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,viewport-fit=cover">
<title><?php echo esc_html($company); ?> — پنل</title>
<meta name="theme-color" content="<?php echo esc_attr($primary); ?>">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="<?php echo esc_attr($company); ?>">
<link rel="manifest" href="<?php echo esc_url(home_url('/' . $slug . '/manifest.webmanifest')); ?>">
<?php if ($logo): ?><link rel="apple-touch-icon" href="<?php echo esc_url($logo); ?>"><?php endif; ?>
<link rel="preconnect" href="https://cdn.jsdelivr.net" crossorigin>
<link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo esc_url($assets . 'app.css?v=' . SAMANEH_CORE_VERSION); ?>">
<style id="samaneh-theme"><?php echo $theme_css; // phpcs:ignore ?></style>
<style>
  body, input, select, textarea, button, .btn, table, .card, .sidebar {
    font-family: Tahoma, "Vazirmatn", "B Nazanin", "BNazanin", system-ui, sans-serif !important;
  }
  .sidebar-foot { display: flex; flex-direction: column; gap: 8px; }
  .sidebar-foot a, .sidebar-foot button {
    color: #94a3b8; text-decoration: none; font-size: .85rem; background: none; border: none;
    cursor: pointer; text-align: right; padding: 0; font-family: inherit;
  }
  .sidebar-foot a:hover, .sidebar-foot button:hover { color: #fff; }
  .sidebar-foot .foot-logout { color: #f87171 !important; }
</style>
<?php foreach ($mod_assets['css'] as $c): ?>
<link rel="stylesheet" href="<?php echo esc_url($c); ?>">
<?php endforeach; ?>
</head>
<body class="layout-modir-desk" data-theme="light" data-role="<?php echo esc_attr($role); ?>">
<div class="layout layout-drawer">
  <!-- منوی تمام‌صفحه (سبک اندروید) -->
  <div id="drawer-overlay" class="drawer-overlay" aria-hidden="true"></div>
  <aside id="drawer" class="drawer" aria-hidden="true">
    <div class="drawer-head">
      <div class="drawer-title-wrap">
        <?php if ($logo): ?><img src="<?php echo esc_url($logo); ?>" alt="" class="brand-logo"><?php endif; ?>
        <span class="drawer-title" id="brand-name"><?php echo esc_html($company); ?></span>
      </div>
      <button type="button" id="drawer-close" class="drawer-close" aria-label="بستن">×</button>
    </div>
    <div class="drawer-search-wrap">
      <input type="search" id="menu-search" class="drawer-search" placeholder="جستجو..." autocomplete="off">
    </div>
    <div class="drawer-scroll">
      <nav id="nav" class="drawer-nav"></nav>
      <div class="drawer-scroll-tools">
        <div class="foot-row foot-row-tools">
          <button type="button" id="btn-theme-toggle" class="drawer-action foot-icon-btn" title="حالت روشن / تاریک" aria-label="تم">☀️</button>
          <div class="font-size-box" title="اندازه متن">
            <button type="button" id="btn-font-minus" class="font-size-btn" title="کوچک‌تر">−</button>
            <span id="font-size-display" class="font-size-val">16</span>
            <button type="button" id="btn-font-plus" class="font-size-btn" title="بزرگ‌تر">+</button>
          </div>
          <a href="<?php echo esc_url($logout); ?>" class="drawer-action foot-logout foot-logout-sm">خروج</a>
        </div>
      </div>
    </div>
    <div class="drawer-foot drawer-foot-help-only">
      <div class="foot-col">
        <button type="button" id="btn-help-tour" class="drawer-action foot-full" title="راهنمای استفاده از پنل">📖 آموزش</button>
        <button type="button" id="btn-help-mode" class="drawer-action foot-full" title="علامت سؤال کنار هر بخش"><span class="help-q-mark">؟</span> راهنمای زنده</button>
      </div>
    </div>
  </aside>

  <div class="main">
    <header class="topbar">
      <div class="topbar-right">
        <button type="button" id="menu-btn" class="menu-btn" aria-label="باز کردن منو">
          <span class="menu-btn-icon">☰</span>
        </button>
        <strong id="page-title">داشبورد</strong>
      </div>
      <div class="topbar-left">
        <span class="user-meta">سلام <?php echo esc_html($user['name'] ?: 'کاربر'); ?> · <span class="badge"><?php echo esc_html($policy['role_labels'][$role] ?? $role); ?></span></span>
      </div>
    </header>
    <div class="content" id="content"><div class="empty">بارگذاری...</div></div>
  </div>
</div>
<div id="modal" class="modal hidden">
  <div class="modal-box">
    <div class="modal-head"><strong id="modal-title">فرم</strong><button type="button" id="modal-close" class="btn-icon">×</button></div>
    <form id="modal-form"></form>
    <div class="modal-foot">
      <button type="button" class="btn" id="modal-save">ذخیره</button>
      <button type="button" class="btn btn-outline" id="modal-cancel">انصراف</button>
    </div>
  </div>
</div>
<script>
window.BOOT = <?php echo $boot_json; ?>;
window.USER = <?php echo $user_json; ?>;
window.POLICY = <?php echo $policy_json; ?>;
window.CSRF = <?php echo wp_json_encode($nonce); ?>;
window.API_URL = <?php echo wp_json_encode($api_url); ?>;
window.FIELDS = <?php echo $fields; ?>;
window.INSTANCE_ID = <?php echo (int) $instance_id; ?>;
window.UPLOADS = <?php echo wp_json_encode(SAMANEH_CORE_URL . 'uploads/'); ?>;
</script>
<script src="<?php echo esc_url($assets . 'app.js?v=' . SAMANEH_CORE_VERSION); ?>"></script>
<?php foreach ($mod_assets['js'] as $j): ?>
<script src="<?php echo esc_url($j); ?>"></script>
<?php endforeach; ?>
<?php do_action('samaneh_panel_footer'); ?>
<script>
// PWA: ثبت سرویس‌ورکر و دکمه نصب
(function(){
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register(<?php echo wp_json_encode(home_url('/' . $slug . '/sw.js')); ?>).catch(function(){});
  }
})();
</script>
</body>
</html><?php
    }

    /** Web App Manifest */
    private static function serve_manifest(int $instance_id): void {
        $inst = Samaneh_Instances::get($instance_id) ?: [];
        $name = ($inst['name'] ?? '') !== '' ? $inst['name'] : 'سامانه';
        $slug = $inst['slug'] ?? 'panel';
        $logo = $inst['logo'] ?? (SAMANEH_CORE_URL . 'assets/app.css');
        $start = home_url('/' . $slug . '/');
        $theme = is_array($inst['theme'] ?? null) ? $inst['theme'] : [];
        $color = preg_match('/^#[0-9a-fA-F]{3,8}$/', (string) ($theme['primary'] ?? '')) ? $theme['primary'] : '#1d4ed8';
        $manifest = [
            'name'             => $name,
            'short_name'       => mb_substr($name, 0, 12),
            'description'      => 'پنل کارگاه ' . $name,
            'start_url'        => $start,
            'scope'            => home_url('/' . $slug . '/'),
            'display'          => 'standalone',
            'orientation'      => 'any',
            'background_color' => '#0f172a',
            'theme_color'      => $color,
            'lang'             => 'fa',
            'dir'              => 'rtl',
            'icons'            => [
                [
                    'src'   => $logo ?: SAMANEH_CORE_URL . 'assets/icon-192.png',
                    'sizes' => '192x192',
                    'type'  => 'image/png',
                    'purpose' => 'any maskable',
                ],
                [
                    'src'   => $logo ?: SAMANEH_CORE_URL . 'assets/icon-512.png',
                    'sizes' => '512x512',
                    'type'  => 'image/png',
                    'purpose' => 'any maskable',
                ],
            ],
        ];
        header('Content-Type: application/manifest+json; charset=utf-8');
        header('Cache-Control: public, max-age=3600');
        echo wp_json_encode($manifest, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    /** Service Worker ساده برای حالت آفلاین سبک */
    private static function serve_sw(string $slug): void {
        $scope = home_url('/' . $slug . '/');
        header('Content-Type: application/javascript; charset=utf-8');
        header('Service-Worker-Allowed: ' . wp_parse_url($scope, PHP_URL_PATH));
        header('Cache-Control: no-cache');
        echo "const CACHE='samaneh-v1';\n";
        echo "self.addEventListener('install',e=>{self.skipWaiting();});\n";
        echo "self.addEventListener('activate',e=>{e.waitUntil(clients.claim());});\n";
        echo "self.addEventListener('fetch',e=>{/* network-first */});\n";
    }
}
