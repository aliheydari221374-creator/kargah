<?php
/**
 * چند پنل روی یک سایت — فقط از پیشخوان وردپرس مدیریت می‌شود
 * خرید محصول ووکامرس (شناسه 12789 یا SKU) → اسلات جدید
 */
if (!defined('ABSPATH')) {
    exit;
}

class Samaneh_Instances {

    const OPT_INSTANCES = 'samaneh_instances';
    const OPT_SLOTS     = 'samaneh_panel_slots';
    const WC_META       = '_samaneh_panel_slot';
    /** محصول رسمی «پنل کارگاه بعدی» روی zagroos.com */
    const WC_PRODUCT_IDS = [12789];

    public static function max_slots(): int {
        return max(1, (int) get_option(self::OPT_SLOTS, 1));
    }

    public static function all(): array {
        $list = get_option(self::OPT_INSTANCES, null);
        if (!is_array($list) || empty($list)) {
            $list = [
                1 => [
                    'id'                 => 1,
                    'slug'               => 'panel',
                    'name'               => (string) get_option('samaneh_company_name', ''),
                    'logo'               => (string) get_option('samaneh_logo', ''),
                    'manager_wp_user_id' => 0,
                    'theme'              => [],
                    'active'             => true,
                ],
            ];
            update_option(self::OPT_INSTANCES, $list, false);
        }
        return $list;
    }

    public static function get(int $id): ?array {
        $all = self::all();
        return $all[$id] ?? null;
    }

    public static function by_slug(string $slug): ?array {
        $slug = sanitize_title($slug);
        foreach (self::all() as $inst) {
            if (($inst['slug'] ?? '') === $slug && !empty($inst['active'])) {
                return $inst;
            }
        }
        return null;
    }

    public static function save(int $id, array $data): array {
        $all = self::all();
        if (!isset($all[$id])) {
            throw new RuntimeException('پنل یافت نشد');
        }
        if (isset($data['slug'])) {
            // فقط مدیر شبکه می‌تواند اسلاگ را عوض کند
            $can_slug = (function_exists('is_super_admin') && is_super_admin())
                || (class_exists('Samaneh_Auth') && Samaneh_Auth::is_network_admin());
            if (!$can_slug) {
                unset($data['slug']);
            } else {
                $slug = sanitize_title($data['slug']);
                if ($slug === '') {
                    $slug = 'panel' . ($id > 1 ? $id : '');
                }
                foreach ($all as $oid => $o) {
                    if ((int) $oid !== $id && ($o['slug'] ?? '') === $slug) {
                        throw new RuntimeException('این آدرس قبلاً استفاده شده');
                    }
                }
                if (class_exists('Samaneh_Reserved_Slugs') && Samaneh_Reserved_Slugs::slug_taken_by_site($slug)) {
                    throw new RuntimeException('این آدرس به‌عنوان سایت شبکه وجود دارد و قابل استفاده برای پنل نیست.');
                }
                $old_slug = $all[$id]['slug'] ?? '';
                $data['slug'] = $slug;
                    if ($old_slug !== $slug) {
                    // بازنویسی فوری قوانین آدرس تا اسلاگ جدید کار کند
                    $all[$id] = array_merge($all[$id], $data, ['id' => $id]);
                    update_option(self::OPT_INSTANCES, $all, false);
                    if ($id === 1) {
                        update_option('samaneh_panel_slug', $slug, false);
                    }
                    self::register_rewrites();
                    flush_rewrite_rules(true);
                    if (class_exists('Samaneh_Reserved_Slugs')) {
                        Samaneh_Reserved_Slugs::add($slug);
                    }
                }
            }
        }
        if (isset($data['name'])) {
            $data['name'] = sanitize_text_field($data['name']);
        }
        if (isset($data['logo'])) {
            $data['logo'] = esc_url_raw($data['logo']);
        }
        if (isset($data['domain'])) {
            $d = strtolower(trim((string) $data['domain']));
            $d = preg_replace('#^https?://#i', '', $d);
            $d = preg_replace('#^www\.#i', '', $d);
            $d = preg_replace('#/.*$#', '', $d);
            $data['domain'] = $d;
            // ست خودکار دامنه بدون تأیید شبکه
            if ($d !== '' && function_exists('update_site_option')) {
                $map = get_site_option('zc_workshop_domains', []);
                if (!is_array($map)) { $map = []; }
                $map[$id] = $d;
                update_site_option('zc_workshop_domains', $map);
            }
        }
        if (isset($data['manager_wp_user_id'])) {
            $data['manager_wp_user_id'] = (int) $data['manager_wp_user_id'];
        }
        if (isset($data['theme']) && is_array($data['theme'])) {
            $theme = [];
            $allowed = [
                'primary', 'primary_hover', 'sidebar_bg', 'sidebar_text', 'sidebar_active',
                'content_bg', 'card_bg', 'card_border', 'text', 'muted',
                'login_bg', 'login_card_bg', 'login_logo', 'login_btn', 'bg_image', 'login_bg_image',
                'header_bg', 'header_text', 'table_header', 'danger', 'success',
                'banner_critical', 'banner_important',
            ];
            foreach ($allowed as $k) {
                if (isset($data['theme'][$k])) {
                    $theme[$k] = sanitize_text_field((string) $data['theme'][$k]);
                }
            }
            $data['theme'] = $theme;
        }
        if (isset($data['chat_enabled'])) {
            $data['chat_enabled'] = !empty($data['chat_enabled']) ? 1 : 0;
        }
        $all[$id] = array_merge($all[$id], $data, ['id' => $id]);
        update_option(self::OPT_INSTANCES, $all, false);
        if ($id === 1) {
            if (isset($data['name'])) {
                update_option('samaneh_company_name', $data['name'], false);
            }
            if (isset($data['slug'])) {
                update_option('samaneh_panel_slug', $data['slug'], false);
            }
            if (isset($data['logo'])) {
                update_option('samaneh_logo', $data['logo'], false);
            }
        }
        flush_rewrite_rules(false);
        return $all[$id];
    }

    public static function create(string $slug = '', string $name = ''): array {
        $all = self::all();
        if (count($all) >= self::max_slots()) {
            throw new RuntimeException('سقف پنل پر است. محصول «پنل کارگاه بعدی» را بخرید.');
        }
        $id = 1;
        foreach (array_keys($all) as $k) {
            $id = max($id, (int) $k + 1);
        }
        $slug = sanitize_title($slug);
        if ($slug === '') {
            $slug = 'panel' . $id;
        }
        if (class_exists('Samaneh_Reserved_Slugs') && Samaneh_Reserved_Slugs::slug_taken_by_site($slug)) {
            throw new RuntimeException('این آدرس به‌عنوان سایت شبکه رزرو/موجود است.');
        }
        foreach ($all as $o) {
            if (($o['slug'] ?? '') === $slug) {
                $slug = 'panel' . $id . '-' . wp_generate_password(3, false, false);
            }
        }
        $all[$id] = [
            'id'     => $id,
            'slug'   => $slug,
            'name'   => sanitize_text_field($name),
            'logo'   => '',
            'active' => true,
        ];
        update_option(self::OPT_INSTANCES, $all, false);
        Samaneh_DB::create_tables_for($id);
        if (class_exists('Samaneh_Reserved_Slugs')) {
            Samaneh_Reserved_Slugs::add($slug);
        }
        flush_rewrite_rules(false);
        return $all[$id];
    }

    public static function table_prefix(int $instance_id): string {
        global $wpdb;
        if ($instance_id <= 1) {
            return $wpdb->prefix . 'sc_';
        }
        return $wpdb->prefix . 'sc' . $instance_id . '_';
    }

    public static function add_slot(int $count = 1): int {
        $n = self::max_slots() + max(1, $count);
        update_option(self::OPT_SLOTS, $n, false);
        return $n;
    }

    public static function register_rewrites(): void {
        foreach (self::all() as $inst) {
            if (empty($inst['active'])) {
                continue;
            }
            $slug = $inst['slug'] ?? '';
            if ($slug === '') {
                continue;
            }
            add_rewrite_rule('^' . preg_quote($slug, '/') . '/?$', 'index.php?samaneh_panel=1&samaneh_instance=' . (int) $inst['id'], 'top');
            add_rewrite_rule('^' . preg_quote($slug, '/') . '/api/?$', 'index.php?samaneh_panel_api=1&samaneh_instance=' . (int) $inst['id'], 'top');
            add_rewrite_rule('^' . preg_quote($slug, '/') . '/login/?$', 'index.php?samaneh_login=1&samaneh_instance=' . (int) $inst['id'], 'top');
        }
    }

    public static function is_slot_product($product): bool {
        if (!$product) {
            return false;
        }
        $id = (int) $product->get_id();
        if (in_array($id, self::WC_PRODUCT_IDS, true)) {
            return true;
        }
        // parent variable
        $parent = (int) $product->get_parent_id();
        if ($parent && in_array($parent, self::WC_PRODUCT_IDS, true)) {
            return true;
        }
        $flag = $product->get_meta(self::WC_META);
        if ($flag !== '' && $flag !== false && $flag !== '0') {
            return true;
        }
        $sku = (string) $product->get_sku();
        return in_array($sku, ['samaneh-panel-slot', 'samaneh_panel_next', 'panel-next'], true);
    }

    public static function hook_woocommerce(): void {
        add_action('woocommerce_order_status_completed', [__CLASS__, 'on_order_completed'], 20, 1);
        add_action('woocommerce_order_status_processing', [__CLASS__, 'on_order_completed'], 20, 1);
    }

    public static function on_order_completed($order_id): void {
        if (!function_exists('wc_get_order')) {
            return;
        }
        $order = wc_get_order($order_id);
        if (!$order || $order->get_meta('_samaneh_slots_granted')) {
            return;
        }
        $added = 0;
        foreach ($order->get_items() as $item) {
            $product = $item->get_product();
            if (!self::is_slot_product($product)) {
                continue;
            }
            // هر عدد خرید = همان تعداد اسلات (برای ۲ پنل باید ۲ بار بخرد یا تعداد ۲ در سبد)
            $added += max(1, (int) $item->get_quantity());
        }
        if ($added < 1) {
            return;
        }
        // روی همین سایت (یا در شبکه روی سایت مشتری)
        $target_blog = get_current_blog_id();
        if (is_multisite()) {
            $user_id = (int) $order->get_user_id();
            if ($user_id > 0) {
                $blogs = get_blogs_of_user($user_id);
                if (is_array($blogs) && !empty($blogs)) {
                    // اولین سایت غیر اصلی کاربر، یا همان سایت فعلی
                    foreach ($blogs as $b) {
                        $bid = (int) ($b->userblog_id ?? 0);
                        if ($bid > 1) {
                            $target_blog = $bid;
                            break;
                        }
                    }
                }
            }
        }
        if (is_multisite() && $target_blog !== get_current_blog_id()) {
            switch_to_blog($target_blog);
            self::add_slot($added);
            restore_current_blog();
        } else {
            self::add_slot($added);
        }
        $order->update_meta_data('_samaneh_slots_granted', $added);
        $order->add_order_note(sprintf('سامانه هسته: %d اسلات پنل کارگاه اضافه شد (سایت #%d).', $added, $target_blog));
        $order->save();
    }

    /** لینک خرید محصول اسلات روی فروشگاه شبکه */
    public static function product_url(): string {
        $custom = get_option('samaneh_slot_product_url', '');
        if ($custom) {
            return $custom;
        }
        return 'https://zagroos.com/product/%d9%be%d9%86%d9%84-%da%a9%d8%a7%d8%b1%da%af%d8%a7%d9%87-%d8%a8%d8%b9%d8%af%db%8c/';
    }
}
