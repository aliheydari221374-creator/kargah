<?php
if (!defined('ABSPATH')) {
    exit;
}

/** تبدیل ارقام فارسی/عربی به انگلیسی و یکدست‌سازی موبایل */
function samaneh_normalize_digits(string $s): string {
    $s = str_replace(
        ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹', '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'],
        ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'],
        $s
    );
    return $s;
}

/** فقط رقم‌های انگلیسی موبایل (بدون + و فاصله) */
function samaneh_phone_digits(string $phone): string {
    $phone = samaneh_normalize_digits(trim($phone));
    return preg_replace('/\D+/', '', $phone) ?: '';
}

function samaneh_json_ok(array $data = [], array $extra = []): void {
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
    }
    echo wp_json_encode(array_merge(['ok' => true, 'data' => $data], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}

function samaneh_json_err(string $msg, int $code = 400): void {
    if (!headers_sent()) {
        status_header($code);
        header('Content-Type: application/json; charset=utf-8');
    }
    echo wp_json_encode(['ok' => false, 'error' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}


function samaneh_panel_nonce(): string {
    Samaneh_Auth::start_session();
    if (empty($_SESSION['samaneh_csrf'])) {
        $_SESSION['samaneh_csrf'] = bin2hex(random_bytes(16));
    }
    // اگر کاربر WP لاگین است از nonce وردپرس هم پشتیبانی می‌شود
    if (is_user_logged_in()) {
        return wp_create_nonce('samaneh_panel');
    }
    return $_SESSION['samaneh_csrf'];
}

function samaneh_verify_panel_nonce($sent): bool {
    $sent = (string) $sent;
    if (is_user_logged_in() && wp_verify_nonce($sent, 'samaneh_panel')) {
        return true;
    }
    Samaneh_Auth::start_session();
    return hash_equals((string) ($_SESSION['samaneh_csrf'] ?? ''), $sent);
}
