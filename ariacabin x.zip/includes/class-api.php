<?php
if (!defined('ABSPATH')) {
    exit;
}

class Samaneh_API {

    public static function handle(): void {
        $instance_id = max(1, (int) get_query_var('samaneh_instance'));
        if (isset($_REQUEST['instance'])) {
            $instance_id = max(1, (int) $_REQUEST['instance']);
        }
        Samaneh_DB::set_instance($instance_id);

        if (!Samaneh_Auth::can_access($instance_id)) {
            samaneh_json_err('ورود لازم است', 401);
        }

        if (class_exists('Samaneh_Grants') && !Samaneh_Grants::site_is_enabled() && !Samaneh_Auth::is_network_admin()) {
            samaneh_json_err('افزونه روی این سایت فعال نیست', 403);
        }

        Samaneh_DB::create_tables_for($instance_id);

        $action = isset($_REQUEST['action']) ? sanitize_key($_REQUEST['action']) : '';
        $role   = Samaneh_Auth::panel_role();

        if ($action !== '' && !Samaneh_RBAC::can_action($role, $action)) {
            $handled = apply_filters('samaneh_api_action', null, $action, $role);
            if ($handled !== null) {
                exit;
            }
            samaneh_json_err('این عملیات مجاز نیست', 403);
        }

        try {
            if ($action === 'all') {
                $data = Samaneh_DB::fetch_all();
                $data = Samaneh_RBAC::filter_boot($data, $role);
                samaneh_json_ok($data, [
                    'csrf'   => samaneh_panel_nonce(),
                    'user'   => Samaneh_Auth::current_user_payload(),
                    'policy' => Samaneh_RBAC::policy($role),
                    'table_prefix' => Samaneh_DB::prefix(),
                    'instance_id'  => $instance_id,
                ]);
            }

            // بارگذاری انتخابی جدول‌ها (برای بهبود سرعت)
            if ($action === 'tables') {
                $tables_param = isset($_REQUEST['tables']) ? sanitize_text_field(wp_unslash((string) $_REQUEST['tables'])) : '';
                $wanted = array_filter(array_map('sanitize_key', explode(',', $tables_param)));
                if (empty($wanted)) {
                    samaneh_json_err('لیست جداول مشخص نشده');
                }
                $all = Samaneh_DB::fetch_all();
                $all = Samaneh_RBAC::filter_boot($all, $role);
                $subset = [];
                foreach ($wanted as $tn) {
                    if (isset($all[$tn])) {
                        $subset[$tn] = $all[$tn];
                    }
                }
                // همیشه settings را هم برمی‌گردانیم
                if (isset($all['settings'])) {
                    $subset['settings'] = $all['settings'];
                }
                samaneh_json_ok($subset, [
                    'csrf'   => samaneh_panel_nonce(),
                    'user'   => Samaneh_Auth::current_user_payload(),
                    'policy' => Samaneh_RBAC::policy($role),
                    'instance_id'  => $instance_id,
                    'partial' => true,
                ]);
            }

            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                samaneh_json_err('متد نامعتبر', 405);
            }

            $nonce = $_POST['_wpnonce'] ?? $_POST['csrf'] ?? '';
            if (!samaneh_verify_panel_nonce($nonce)) {
                samaneh_json_err('توکن نامعتبر — صفحه را تازه کنید', 403);
            }

            if ($action === 'save') {
                $table = sanitize_key($_POST['table'] ?? '');
                $payload = json_decode(wp_unslash((string) ($_POST['payload'] ?? '{}')), true);
                if (!is_array($payload) || $table === '') {
                    samaneh_json_err('داده نامعتبر');
                }
                // دستورات: ایجاد/ویرایش کامل فقط مدیر؛ گیرنده فقط وضعیت را عوض می‌کند
                if ($table === 'directives' && $role !== 'management') {
                    if (empty($payload['id'])) {
                        samaneh_json_err('فقط مدیر می‌تواند دستور بدهد', 403);
                    }
                    // فقط status مجاز
                    $allowed_keys = ['id', 'status'];
                    foreach (array_keys($payload) as $k) {
                        if (!in_array($k, $allowed_keys, true)) {
                            unset($payload[$k]);
                        }
                    }
                    if (empty($payload['status'])) {
                        samaneh_json_err('وضعیت نامعتبر', 400);
                    }
                }
                // چک ثبت‌شده توسط مشتری همیشه در انتظار
                if ($table === 'checks_received' && empty($payload['id']) && $role === 'customer') {
                    $payload['approval'] = 'pending';
                    $payload['name'] = $payload['name'] ?? (Samaneh_Auth::personnel_name() ?: '');
                }
                // فقط مدیر/حسابدار می‌تواند وضعیت چک را عوض کند
                if (in_array($table, ['checks_received', 'checks_paid'], true) && !empty($payload['id'])) {
                    if (array_key_exists('approval', $payload) || array_key_exists('check_status', $payload)) {
                        if (!in_array($role, ['management', 'warehouse'], true)) {
                            samaneh_json_err('فقط مدیر یا حسابدار می‌تواند وضعیت چک را تغییر دهد', 403);
                        }
                    }
                }
                // پیش‌فرض وضعیت چک جدید
                if (in_array($table, ['checks_received', 'checks_paid'], true) && empty($payload['id'])) {
                    if (empty($payload['check_status']) && empty($payload['approval'])) {
                        $payload['check_status'] = 'pending';
                        $payload['approval'] = 'pending';
                    } elseif (!empty($payload['check_status']) && empty($payload['approval'])) {
                        $payload['approval'] = $payload['check_status'];
                    } elseif (!empty($payload['approval']) && empty($payload['check_status'])) {
                        $payload['check_status'] = $payload['approval'];
                    }
                }
                // همگام‌سازی approval و check_status
                if (in_array($table, ['checks_received', 'checks_paid'], true)) {
                    if (!empty($payload['check_status']) && empty($payload['approval'])) {
                        $payload['approval'] = $payload['check_status'];
                    }
                    if (!empty($payload['approval']) && empty($payload['check_status'])) {
                        $payload['check_status'] = $payload['approval'];
                    }
                }
                // اعلام مصرفی: وضعیت فقط توسط مدیر / حسابدار / دارای دسترسی
                if ($table === 'stock_usage') {
                    if (empty($payload['id'])) {
                        unset($payload['status']); // ایجاد — سیستم status را ست می‌کند
                    } elseif (array_key_exists('status', $payload)) {
                        $ok_status = in_array($role, ['management', 'warehouse'], true);
                        if (!$ok_status) {
                            $pchk = Samaneh_RBAC::policy($role);
                            $ok_status = in_array('return', $pchk['warehouse_actions'] ?? [], true)
                                || in_array('edit_stock', $pchk['warehouse_actions'] ?? [], true);
                        }
                        if (!$ok_status) {
                            samaneh_json_err('شما اجازه تغییر وضعیت انبار را ندارید', 403);
                        }
                    }
                    if (empty($payload['id'])) {
                        $policy = Samaneh_RBAC::policy($role);
                        $kind = $payload['kind'] ?? 'برداشت';
                        $acts = $policy['warehouse_actions'] ?? [];
                        if ($kind === 'برداشت' && !in_array('withdraw', $acts, true) && $role !== 'management' && $role !== 'warehouse' && $role !== 'employee') {
                            // employee و warehouse به‌طور پیش‌فرض می‌توانند برداشت کنند مگر محدود شده باشند
                        }
                        if ($kind === 'برداشت' && !empty($acts) && !in_array('withdraw', $acts, true) && $role !== 'management') {
                            samaneh_json_err('شما اجازه برداشت از انبار ندارید', 403);
                        }
                        if ($kind === 'بازگشت' && !empty($acts) && !in_array('return', $acts, true) && $role !== 'management' && $role !== 'warehouse') {
                            samaneh_json_err('شما اجازه ثبت بازگشت به انبار ندارید', 403);
                        }
                    }
                }
                if ($table === 'purchases' && empty($payload['id'])) {
                    $policy = Samaneh_RBAC::policy($role);
                    $acts = $policy['warehouse_actions'] ?? [];
                    if (!in_array('purchase', $acts, true) && $role !== 'management' && $role !== 'warehouse') {
                        // warehouse role by default can purchase unless restricted
                        if (!empty($policy['my_warehouses']) && !in_array('*', $policy['my_warehouses'], true) && empty($acts)) {
                            // ok
                        }
                    }
                }
                if ($table === 'leave_requests' && isset($payload['status']) && in_array($payload['status'], ['تأیید', 'تأییدشده', 'approved', 'رد', 'rejected'], true)) {
                    if ($role !== 'management') {
                        samaneh_json_err('فقط مدیر می‌تواند مرخصی را تأیید یا رد کند', 403);
                    }
                }
                if ($table === 'overtime' && isset($payload['status']) && in_array($payload['status'], ['تأیید', 'تأییدشده', 'approved', 'رد', 'rejected', 'در انتظار'], true) && !empty($payload['id'])) {
                    if (!in_array($role, ['management', 'warehouse'], true)) {
                        samaneh_json_err('فقط مدیر یا حسابدار می‌تواند اضافه‌کاری را تأیید/رد کند', 403);
                    }
                }
                if ($table === 'leave_requests' && empty($payload['id'])) {
                    $payload['status'] = 'در انتظار';
                }
                // سلسله‌مراتب مدیران — همه مدیران در جدول personnel هستند (نه وردپرس)
                // مدیر کل = is_main=1 | مدیر عادی = role=management
                if ($table === 'personnel') {
                    $new_role = sanitize_key($payload['role'] ?? '');
                    $is_mgmt = ($new_role === 'management');
                    $existing = null;
                    if (!empty($payload['id'])) {
                        $existing = Samaneh_DB::get_row('personnel', (int) $payload['id']);
                        if ($existing && ($existing['role'] ?? '') === 'management') {
                            $is_mgmt = true;
                        }
                    }
                    if ($is_mgmt) {
                        $is_net  = Samaneh_Auth::is_network_admin();
                        $is_main = Samaneh_Auth::is_main_manager();
                        $my_name = Samaneh_Auth::personnel_name();
                        $my_pid  = (int) ((Samaneh_Auth::get_panel_user() ?? [])['personnel_id'] ?? 0);
                        $editing_self = false;
                        if (!empty($payload['id']) && $my_pid > 0 && (int) $payload['id'] === $my_pid) {
                            $editing_self = true;
                        } elseif (!empty($payload['name']) && $my_name !== '' && strcasecmp((string) $payload['name'], $my_name) === 0) {
                            $editing_self = true;
                        } elseif ($existing && $my_name !== '' && strcasecmp((string) ($existing['name'] ?? ''), $my_name) === 0) {
                            $editing_self = true;
                        }
                        // مدیر عادی فقط خودش؛ مدیرکل/شبکه همه را
                        // استثنا: اگر هنوز هیچ مدیرکلی نیست، هر مدیر می‌تواند مدیر اضافه کند
                        if (!$is_net && !$is_main && !$editing_self) {
                            global $wpdb;
                            $pt = Samaneh_DB::table('personnel');
                            // phpcs:ignore
                            $main_cnt = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$pt}` WHERE is_main = 1");
                            // phpcs:ignore  
                            $mgmt_cnt = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$pt}` WHERE role = 'management'");
                            if ($main_cnt > 0 || $mgmt_cnt > 1) {
                                samaneh_json_err('فقط مدیر شبکه یا مدیر کل مجموعه می‌تواند مدیران دیگر را اضافه یا ویرایش کند.', 403);
                            }
                        }
                    }
                    // فقط مدیر شبکه پرچم مدیر کل (is_main) را ست می‌کند
                    if (array_key_exists('is_main', $payload)) {
                        if (!Samaneh_Auth::is_network_admin()) {
                            unset($payload['is_main']);
                        } elseif (!empty($payload['is_main'])) {
                            $payload['is_main'] = 1;
                            $payload['role'] = 'management';
                        } else {
                            $payload['is_main'] = 0;
                        }
                    }
                }
                // پرسنل/مشتری جدید: رمز اجباری + اطمینان از ستون password
                if (in_array($table, ['personnel', 'customers'], true)) {
                    Samaneh_DB::ensure_password_column_public($table);
                    if (empty($payload['id'])) {
                        $pw = trim((string) ($payload['password'] ?? ''));
                        if ($pw === '' || $pw === '********' || preg_match('/^\*+$/', $pw)) {
                            samaneh_json_err('برای کاربر جدید حتماً رمز عبور وارد کنید تا بتواند با موبایل وارد پنل شود.', 400);
                        }
                        if (trim((string) ($payload['name'] ?? '')) === '') {
                            samaneh_json_err('نام الزامی است.', 400);
                        }
                        if ($table === 'personnel' && trim((string) ($payload['phone'] ?? '')) === '') {
                            samaneh_json_err('شماره موبایل برای ورود الزامی است.', 400);
                        }
                        if ($table === 'customers' && trim((string) ($payload['phone'] ?? '')) === '') {
                            samaneh_json_err('شماره موبایل مشتری برای ورود الزامی است.', 400);
                        }
                    }
                }
                if (class_exists('Samaneh_Grants') && !Samaneh_Grants::can_use_table($table) && !Samaneh_Auth::is_network_admin()) {
                    samaneh_json_err('این بخش برای این سایت فعال نشده است', 403);
                }
                if (!Samaneh_RBAC::can_write($role, $table)) {
                    samaneh_json_err('دسترسی نوشتن ندارید', 403);
                }
                // حضور هوشمند: IP سرور را همیشه ثبت کن
                if ($table === 'attendance' && empty($payload['ip_addr'])) {
                    $payload['ip_addr'] = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field((string) $_SERVER['REMOTE_ADDR']) : '';
                }
                $saved = Samaneh_DB::save($table, $payload);
                // اگر مدیر کل شد، بقیه is_main را صفر کن
                if ($table === 'personnel' && !empty($saved['is_main']) && !empty($saved['id'])) {
                    global $wpdb;
                    $pt = Samaneh_DB::table('personnel');
                    // phpcs:ignore
                    $wpdb->query($wpdb->prepare("UPDATE `{$pt}` SET is_main = 0 WHERE id != %d", (int) $saved['id']));
                }
                do_action('samaneh_after_save', $table, $saved);
                samaneh_json_ok($saved);
            }

            if ($action === 'delete') {
                // فقط مدیر مجموعه — از نمایش خارج می‌شود؛ دیتا در دیتابیس می‌ماند
                if ($role !== 'management') {
                    samaneh_json_err('فقط مدیر مجموعه می‌تواند حذف کند', 403);
                }
                if ($action === 'purge' || $action === 'purge_forever') {
                    samaneh_json_err('حذف برای همیشه از پنل مجاز نیست', 403);
                }
                $table = sanitize_key($_POST['table'] ?? '');
                $ids_raw = $_POST['ids'] ?? ($_POST['id'] ?? '');
                $ids = [];
                if (is_string($ids_raw) && strpos($ids_raw, '[') === 0) {
                    $decoded = json_decode(wp_unslash($ids_raw), true);
                    if (is_array($decoded)) {
                        $ids = array_map('intval', $decoded);
                    }
                } elseif (is_array($ids_raw)) {
                    $ids = array_map('intval', $ids_raw);
                } else {
                    $ids = [(int) $ids_raw];
                }
                $ids = array_filter($ids, function ($i) { return $i > 0; });
                if ($table === '' || empty($ids) || $table === 'archives') {
                    samaneh_json_err('شناسه یا جدول نامعتبر');
                }
                $by = Samaneh_Auth::personnel_name() ?: (wp_get_current_user()->user_login ?? 'manager');
                $done = [];
                foreach ($ids as $id) {
                    try {
                        $done[] = Samaneh_DB::delete($table, $id, $by);
                    } catch (Throwable $e) {
                        samaneh_json_err($e->getMessage());
                    }
                }
                samaneh_json_ok(['deleted' => $done, 'count' => count($done)]);
            }

            if ($action === 'archive') {
                // فقط کپی در بایگانی؛ رکورد اصلی می‌ماند (مگر حذف جداگانه)
                if (!in_array($role, ['management', 'warehouse'], true)) {
                    samaneh_json_err('دسترسی ندارید', 403);
                }
                $table = sanitize_key($_POST['table'] ?? '');
                $ids_raw = $_POST['ids'] ?? ($_POST['id'] ?? '');
                $ids = [];
                if (is_string($ids_raw) && strpos($ids_raw, '[') === 0) {
                    $decoded = json_decode(wp_unslash($ids_raw), true);
                    if (is_array($decoded)) {
                        $ids = array_map('intval', $decoded);
                    }
                } elseif (is_array($ids_raw)) {
                    $ids = array_map('intval', $ids_raw);
                } else {
                    $ids = [(int) $ids_raw];
                }
                $ids = array_filter($ids, function ($i) { return $i > 0; });
                if ($table === '' || empty($ids)) {
                    samaneh_json_err('شناسه نامعتبر');
                }
                $by = Samaneh_Auth::personnel_name() ?: 'system';
                $done = [];
                foreach ($ids as $id) {
                    $row = Samaneh_DB::get_row($table, $id);
                    if ($row) {
                        $done[] = Samaneh_DB::archive_row($table, $row, $by);
                    }
                }
                samaneh_json_ok(['archived' => $done, 'count' => count($done)]);
            }

            if ($action === 'user_perms') {
                if ($role !== 'management') {
                    samaneh_json_err('فقط مدیر', 403);
                }
                $payload = json_decode(wp_unslash((string) ($_POST['payload'] ?? '{}')), true);
                if (!is_array($payload)) {
                    samaneh_json_err('داده نامعتبر');
                }
                // payload: { "user_name": { menus, can_message, warehouses, warehouse_actions } }
                $clean = [];
                $allowed_wa = ['view', 'withdraw', 'return', 'purchase', 'edit_stock'];
                foreach ($payload as $uname => $perm) {
                    $uname = sanitize_text_field($uname);
                    if ($uname === '') {
                        continue;
                    }
                    $wa = array_values(array_intersect(
                        array_map('sanitize_key', (array) ($perm['warehouse_actions'] ?? [])),
                        $allowed_wa
                    ));
                    $clean[$uname] = [
                        'menus'             => array_values(array_map('sanitize_key', (array) ($perm['menus'] ?? []))),
                        'can_message'       => array_values(array_map('sanitize_text_field', (array) ($perm['can_message'] ?? []))),
                        'warehouses'        => array_values(array_map('sanitize_text_field', (array) ($perm['warehouses'] ?? []))),
                        'warehouse_actions' => $wa,
                    ];
                }
                update_option('samaneh_user_perms_' . $instance_id, $clean, false);
                samaneh_json_ok(['saved' => true]);
            }

            if ($action === 'dismiss_lead') {
                if (!in_array($role, ['management', 'warehouse'], true)) {
                    samaneh_json_err('دسترسی ندارید', 403);
                }
                $lead_id = isset($_POST['lead_id']) ? (int) $_POST['lead_id'] : 0;
                $leads = get_option('samaneh_new_leads_' . $instance_id, []);
                if (!is_array($leads)) {
                    $leads = [];
                }
                // مهاجرت از تک‌لید
                $old_one = get_option('samaneh_new_lead_' . $instance_id, null);
                if (is_array($old_one) && !empty($old_one['phone'])) {
                    $found = false;
                    foreach ($leads as $L) {
                        if (($L['phone'] ?? '') === ($old_one['phone'] ?? '') && ($L['time'] ?? '') === ($old_one['time'] ?? '')) {
                            $found = true;
                            break;
                        }
                    }
                    if (!$found) {
                        $leads[] = $old_one;
                    }
                }
                if ($lead_id > 0) {
                    $leads = array_values(array_filter($leads, function ($L) use ($lead_id) {
                        return (int) ($L['id'] ?? 0) !== $lead_id;
                    }));
                } elseif (!empty($_POST['phone'])) {
                    $ph = sanitize_text_field(wp_unslash((string) $_POST['phone']));
                    $leads = array_values(array_filter($leads, function ($L) use ($ph) {
                        return ($L['phone'] ?? '') !== $ph;
                    }));
                } else {
                    $leads = [];
                }
                update_option('samaneh_new_leads_' . $instance_id, $leads, false);
                if (!empty($leads)) {
                    update_option('samaneh_new_lead_' . $instance_id, $leads[count($leads) - 1], false);
                } else {
                    delete_option('samaneh_new_lead_' . $instance_id);
                }
                samaneh_json_ok(['dismissed' => true, 'remaining' => count($leads)]);
            }

            if ($action === 'settings') {
                if ($role !== 'management') {
                    samaneh_json_err('فقط مدیر مجموعه', 403);
                }
                $payload = json_decode(wp_unslash((string) ($_POST['payload'] ?? '{}')), true);
                if (!is_array($payload)) {
                    samaneh_json_err('داده نامعتبر');
                }
                $map = [
                    'currency' => 'samaneh_currency',
                    'allow_peer_chat' => 'samaneh_allow_peer_chat',
                    'chat_avatars' => 'samaneh_chat_avatars',
                    'chat_access' => 'samaneh_chat_access',
                    'report_fine' => 'samaneh_report_fine',
                    'warning_count' => 'samaneh_warning_count',
                    'min_stock_alert' => 'samaneh_min_stock_alert',
                    'max_monthly_leave' => 'samaneh_max_monthly_leave',
                    'standard_hours' => 'samaneh_standard_hours',
                ];
                foreach ($map as $key => $opt) {
                    if (!array_key_exists($key, $payload)) {
                        continue;
                    }
                    $val = $payload[$key];
                    if (in_array($key, ['chat_avatars', 'chat_access'], true) && is_array($val)) {
                        update_option($opt, $val, false);
                    } else {
                        update_option($opt, sanitize_text_field((string) $val), false);
                    }
                }
                // شبکه‌های اجتماعی (به‌ازای هر instance)
                $social_keys = ['social_instagram', 'social_telegram', 'social_whatsapp', 'social_linkedin', 'social_website', 'social_aparat', 'company_phone', 'cameras_url'];
                foreach ($social_keys as $sk) {
                    if (array_key_exists($sk, $payload)) {
                        $raw = trim((string) $payload[$sk]);
                        if ($sk === 'company_phone') {
                            $val = sanitize_text_field($raw);
                        } else {
                            $val = esc_url_raw($raw);
                            // واتساپ ممکن است فقط شماره باشد
                            if ($sk === 'social_whatsapp' && $val === '' && $raw !== '') {
                                $val = sanitize_text_field($raw);
                            } elseif ($sk === 'social_whatsapp' && !preg_match('#^https?://#', $raw) && preg_match('#^\+?[\d\s\-]+$#', $raw)) {
                                $val = sanitize_text_field($raw);
                            }
                        }
                        update_option('samaneh_' . $sk . '_' . $instance_id, $val, false);
                    }
                }
                $inst_data = [];
                if (isset($payload['company_name'])) {
                    $inst_data['name'] = sanitize_text_field((string) $payload['company_name']);
                }
                if (isset($payload['panel_slug'])) {
                    $inst_data['slug'] = sanitize_title((string) $payload['panel_slug']);
                }
                if (isset($payload['logo'])) {
                    $inst_data['logo'] = esc_url_raw((string) $payload['logo']);
                }
                if (isset($payload['theme']) && is_array($payload['theme'])) {
                    $inst_data['theme'] = $payload['theme'];
                }
                if (array_key_exists('warehouse_mothers', $payload)) {
                    $wm = $payload['warehouse_mothers'];
                    if (is_string($wm)) {
                        $decoded = json_decode($wm, true);
                        $wm = is_array($decoded) ? $decoded : array_filter(array_map('trim', explode(',', $wm)));
                    }
                    if (!is_array($wm)) {
                        $wm = [];
                    }
                    $wm = array_values(array_filter(array_map(function ($x) {
                        return sanitize_text_field((string) $x);
                    }, $wm)));
                    update_option('samaneh_warehouse_mothers_' . $instance_id, $wm, false);
                }
                if (array_key_exists('invoice_rates', $payload)) {
                    $ir = $payload['invoice_rates'];
                    if (is_array($ir)) {
                        $ir = wp_json_encode($ir, JSON_UNESCAPED_UNICODE);
                    }
                    update_option('samaneh_invoice_rates_' . $instance_id, (string) $ir, false);
                }
                if (array_key_exists('neshan_api_key', $payload)) {
                    update_option(
                        'samaneh_neshan_api_key_' . $instance_id,
                        sanitize_text_field((string) $payload['neshan_api_key']),
                        false
                    );
                }
                if (array_key_exists('work_sites', $payload)) {
                    $sites = $payload['work_sites'];
                    if (is_string($sites)) {
                        $decoded = json_decode(wp_unslash($sites), true);
                        $sites = is_array($decoded) ? $decoded : [];
                    }
                    if (!is_array($sites)) {
                        $sites = [];
                    }
                    $clean_sites = [];
                    foreach ($sites as $s) {
                        if (!is_array($s)) {
                            continue;
                        }
                        $clean_sites[] = [
                            'id'       => (int) ($s['id'] ?? 0),
                            'name'     => sanitize_text_field((string) ($s['name'] ?? '')),
                            'kind'     => sanitize_text_field((string) ($s['kind'] ?? 'کارگاه')),
                            'lat'      => sanitize_text_field((string) ($s['lat'] ?? '')),
                            'lng'      => sanitize_text_field((string) ($s['lng'] ?? '')),
                            'radius_m' => max(20, min(5000, (int) ($s['radius_m'] ?? 150))),
                            'address'  => sanitize_text_field((string) ($s['address'] ?? '')),
                            'active'   => !empty($s['active']) ? 1 : 0,
                        ];
                    }
                    update_option('samaneh_work_sites_' . $instance_id, $clean_sites, false);
                }
                if (array_key_exists('installments', $payload)) {
                    $inst = $payload['installments'];
                    if (is_string($inst)) {
                        $decoded = json_decode(wp_unslash($inst), true);
                        $inst = is_array($decoded) ? $decoded : [];
                    }
                    if (!is_array($inst)) {
                        $inst = [];
                    }
                    $clean = [];
                    foreach ($inst as $row) {
                        if (!is_array($row)) {
                            continue;
                        }
                        $clean[] = [
                            'id'          => (int) ($row['id'] ?? 0),
                            'kind'        => sanitize_text_field((string) ($row['kind'] ?? 'قسط')),
                            'title'       => sanitize_text_field((string) ($row['title'] ?? $row['name'] ?? '')),
                            'name'        => sanitize_text_field((string) ($row['name'] ?? $row['title'] ?? '')),
                            'amount'      => sanitize_text_field((string) ($row['amount'] ?? '0')),
                            'due_date'    => sanitize_text_field((string) ($row['due_date'] ?? '')),
                            'status'      => sanitize_text_field((string) ($row['status'] ?? 'فعال')),
                            'paid_at'     => sanitize_text_field((string) ($row['paid_at'] ?? '')),
                            'note'        => sanitize_textarea_field((string) ($row['note'] ?? '')),
                            'recurrence'  => sanitize_key((string) ($row['recurrence'] ?? 'none')), // none|monthly|quarterly|yearly
                            'remind_days' => max(0, min(90, (int) ($row['remind_days'] ?? 3))),
                            'history'     => (function ($h) {
                                if (!is_array($h)) {
                                    return [];
                                }
                                $out = [];
                                foreach (array_slice($h, -24) as $ev) {
                                    if (!is_array($ev)) {
                                        continue;
                                    }
                                    $out[] = [
                                        'paid_at'  => sanitize_text_field((string) ($ev['paid_at'] ?? '')),
                                        'amount'   => sanitize_text_field((string) ($ev['amount'] ?? '')),
                                        'due_date' => sanitize_text_field((string) ($ev['due_date'] ?? '')),
                                    ];
                                }
                                return $out;
                            })($row['history'] ?? null),
                        ];
                    }
                    update_option('samaneh_installments_' . $instance_id, $clean, false);
                }
                if ($inst_data) {
                    Samaneh_Instances::save($instance_id, $inst_data);
                }
                samaneh_json_ok([
                    'saved' => true,
                    'panel_slug' => (Samaneh_Instances::get($instance_id)['slug'] ?? 'panel'),
                    'hint' => 'اگر آدرس پنل را عوض کردید، از پیشخوان به «تنظیمات ← پیوندهای یکتا» بروید و «ذخیره تغییرات» را بزنید.',
                ]);
            }

            if ($action === 'upload_theme_image') {
                if ($role !== 'management') {
                    samaneh_json_err('فقط مدیر', 403);
                }
                if (empty($_FILES['file']['tmp_name'])) {
                    samaneh_json_err('فایل را انتخاب کنید');
                }
                $file = $_FILES['file'];
                $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true)) {
                    samaneh_json_err('فقط تصویر');
                }
                $dir = SAMANEH_CORE_DIR . 'uploads/';
                if (!is_dir($dir)) { wp_mkdir_p($dir); }
                $name = 'theme_' . $instance_id . '_' . time() . '.' . $ext;
                if (!move_uploaded_file($file['tmp_name'], $dir . $name) && !copy($file['tmp_name'], $dir . $name)) {
                    samaneh_json_err('ذخیره ناموفق');
                }
                $url = SAMANEH_CORE_URL . 'uploads/' . $name;
                $key = sanitize_key($_POST['theme_key'] ?? 'bg_image');
                $inst = Samaneh_Instances::get($instance_id) ?: [];
                $theme = is_array($inst['theme'] ?? null) ? $inst['theme'] : [];
                $theme[$key] = $url;
                Samaneh_Instances::save($instance_id, ['theme' => $theme]);
                samaneh_json_ok(['url' => $url, 'key' => $key, 'theme' => $theme]);
            }

            if ($action === 'upload_font') {
                if ($role !== 'management') {
                    samaneh_json_err('فقط مدیر', 403);
                }
                if (empty($_FILES['file']['tmp_name'])) {
                    samaneh_json_err('فایل فونت را انتخاب کنید');
                }
                $file = $_FILES['file'];
                $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                if (!in_array($ext, ['woff', 'woff2', 'ttf', 'otf'], true)) {
                    samaneh_json_err('فقط فونت woff/woff2/ttf/otf');
                }
                $dir = SAMANEH_CORE_DIR . 'uploads/fonts/';
                if (!is_dir($dir)) {
                    wp_mkdir_p($dir);
                }
                $safe = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', pathinfo($file['name'], PATHINFO_FILENAME));
                $name = 'font_' . $instance_id . '_' . $safe . '.' . $ext;
                if (!move_uploaded_file($file['tmp_name'], $dir . $name) && !copy($file['tmp_name'], $dir . $name)) {
                    samaneh_json_err('ذخیره فونت ناموفق');
                }
                $url = SAMANEH_CORE_URL . 'uploads/fonts/' . $name;
                $font_name = sanitize_text_field($_POST['font_name'] ?? $safe);
                $inst = Samaneh_Instances::get($instance_id) ?: [];
                $theme = is_array($inst['theme'] ?? null) ? $inst['theme'] : [];
                if (!isset($theme['custom_fonts']) || !is_array($theme['custom_fonts'])) {
                    $theme['custom_fonts'] = [];
                }
                $theme['custom_fonts'][$font_name] = $url;
                Samaneh_Instances::save($instance_id, ['theme' => $theme]);
                samaneh_json_ok(['url' => $url, 'font_name' => $font_name, 'theme' => $theme]);
            }

            if ($action === 'upload_logo') {
                if ($role !== 'management') {
                    samaneh_json_err('فقط مدیر', 403);
                }
                if (empty($_FILES['file']) || empty($_FILES['file']['tmp_name'])) {
                    samaneh_json_err('فایل لوگو را انتخاب کنید');
                }
                $file = $_FILES['file'];
                if ((int) $file['error'] !== UPLOAD_ERR_OK) {
                    samaneh_json_err('خطای آپلود لوگو: ' . (int) $file['error']);
                }
                $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true)) {
                    samaneh_json_err('فرمت تصویر باید jpg/png/gif/webp باشد');
                }
                if ((int) $file['size'] > 5 * 1024 * 1024) {
                    samaneh_json_err('حداکثر حجم لوگو ۵ مگابایت');
                }
                $dir = SAMANEH_CORE_DIR . 'uploads/';
                if (!is_dir($dir)) {
                    wp_mkdir_p($dir);
                }
                if (!is_writable($dir)) {
                    @chmod($dir, 0755);
                }
                $name = 'logo_' . $instance_id . '_' . time() . '.' . $ext;
                if (!@move_uploaded_file($file['tmp_name'], $dir . $name)) {
                    // fallback copy
                    if (!@copy($file['tmp_name'], $dir . $name)) {
                        samaneh_json_err('ذخیره لوگو روی سرور ناموفق بود (مجوز پوشه uploads)');
                    }
                }
                $url = SAMANEH_CORE_URL . 'uploads/' . $name;
                Samaneh_Instances::save($instance_id, ['logo' => $url]);
                samaneh_json_ok(['logo' => $url, 'url' => $url]);
            }

            if ($action === 'roles') {
                if ($role !== 'management') {
                    samaneh_json_err('فقط مدیر', 403);
                }
                $payload = json_decode(wp_unslash((string) ($_POST['payload'] ?? '{}')), true);
                if (!is_array($payload)) {
                    samaneh_json_err('داده نامعتبر');
                }
                Samaneh_Roles::save_all($payload);
                samaneh_json_ok(['saved' => true, 'roles' => Samaneh_Roles::all()]);
            }

            if ($action === 'create_instance') {
                if ($role !== 'management') {
                    samaneh_json_err('فقط مدیر', 403);
                }
                $payload = json_decode(wp_unslash((string) ($_POST['payload'] ?? '{}')), true) ?: [];
                $inst = Samaneh_Instances::create(
                    sanitize_title($payload['slug'] ?? ''),
                    sanitize_text_field($payload['name'] ?? '')
                );
                samaneh_json_ok($inst);
            }

            if ($action === 'upload') {
                self::upload();
            }

            if ($action === 'auto_backup_status') {
                if (!in_array($role, ['management'], true) && !Samaneh_Auth::is_network_admin()) {
                    samaneh_json_err('فقط مدیر', 403);
                }
                $iid = Samaneh_DB::instance_id();
                $last = get_option('samaneh_last_auto_backup_' . $iid, null);
                $next = wp_next_scheduled('samaneh_auto_backup_event');
                $list = Samaneh_Backup::list_auto_backups($iid, 10);
                samaneh_json_ok([
                    'last' => $last,
                    'next' => $next ? date('c', $next) : null,
                    'next_ts' => $next,
                    'files' => array_map(function ($f) {
                        return [
                            'file' => $f['file'],
                            'bytes' => $f['bytes'],
                            'at' => $f['at'],
                        ];
                    }, $list),
                    'interval_hours' => 12,
                ]);
            }
            if ($action === 'manual_backup_now') {
                if (!in_array($role, ['management'], true) && !Samaneh_Auth::is_network_admin()) {
                    samaneh_json_err('فقط مدیر', 403);
                }
                $iid = Samaneh_DB::instance_id();
                $res = Samaneh_Backup::save_manual_backup($iid);
                if (empty($res['ok'])) {
                    samaneh_json_err($res['error'] ?? 'بکاپ دستی ناموفق', 500);
                }
                samaneh_json_ok($res);
            }
            if ($action === 'auto_backup_now') {
                if (!in_array($role, ['management'], true) && !Samaneh_Auth::is_network_admin()) {
                    samaneh_json_err('فقط مدیر', 403);
                }
                $iid = Samaneh_DB::instance_id();
                $res = Samaneh_Backup::save_auto_backup($iid);
                if (empty($res['ok'])) {
                    samaneh_json_err($res['error'] ?? 'بکاپ ناموفق', 500);
                }
                samaneh_json_ok($res);
            }
            if ($action === 'export') {
                if ($role !== 'management' && empty(Samaneh_RBAC::role_def($role)['can_settings'])) {
                    // پرسنل فقط اگر can_delete نداره ولی مدیریت جداول خودش
                }
                $table = sanitize_key($_REQUEST['table'] ?? '');
                $fmt = sanitize_key($_REQUEST['format'] ?? 'csv');
                if ($table === 'full') {
                    $fmt_full = sanitize_key($_REQUEST['format'] ?? 'json');
                    if ($fmt_full === 'excel' || $fmt_full === 'xls' || $fmt_full === 'xlsx') {
                        Samaneh_Backup::export_full_excel_xml(true);
                    }
                    Samaneh_Backup::export_full_json();
                }
                if ($table === 'excel_template') {
                    Samaneh_Backup::export_full_excel_xml(true);
                }
                if ($table === 'excel_blank') {
                    Samaneh_Backup::export_full_excel_xml(false);
                }
                if ($table === '' || !isset(Samaneh_DB::fields()[$table])) {
                    samaneh_json_err('جدول نامعتبر');
                }
                if ($fmt === 'json') {
                    Samaneh_Backup::export_table_json($table);
                }
                if ($fmt === 'pdf' || $fmt === 'html') {
                    Samaneh_Backup::export_table_html_pdf($table);
                }
                Samaneh_Backup::export_table_csv($table);
            }

            if ($action === 'import') {
                if ($role !== 'management') {
                    samaneh_json_err('فقط مدیر', 403);
                }
                if (empty($_FILES['file']) || empty($_FILES['file']['tmp_name'])) {
                    samaneh_json_err('فایل بکاپ را انتخاب کنید');
                }
                if (!empty($_FILES['file']['error']) && (int) $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
                    samaneh_json_err('خطای آپلود فایل کد ' . (int) $_FILES['file']['error']);
                }
                $replace = !empty($_POST['replace']);
                $table_hint = sanitize_key($_POST['table'] ?? $_REQUEST['table'] ?? '');
                try {
                    $stats = Samaneh_Backup::import_file(
                        (string) $_FILES['file']['tmp_name'],
                        (string) ($_FILES['file']['name'] ?? 'upload.json'),
                        $table_hint,
                        $replace
                    );
                    samaneh_json_ok($stats, [
                        'message' => sprintf('%d ردیف در %d جدول وارد شد', (int) ($stats['rows'] ?? 0), (int) ($stats['tables'] ?? 0)),
                    ]);
                } catch (Throwable $e) {
                    samaneh_json_err('درون‌ریزی ناموفق: ' . $e->getMessage());
                }
            }

            // لیست حذف‌شده‌های یک جدول — مدیر کارگاه می‌تواند ببیند
            if ($action === 'trash_list') {
                if (!in_array($role, ['management', 'warehouse'], true) && !Samaneh_Auth::is_network_admin()) {
                    samaneh_json_err('دسترسی ندارید', 403);
                }
                $table = sanitize_key($_POST['table'] ?? ($_REQUEST['table'] ?? ''));
                if ($table === '') {
                    samaneh_json_err('جدول مشخص نشده');
                }
                $rows = Samaneh_DB::list_soft_deleted_table($table, 200);
                samaneh_json_ok(['table' => $table, 'rows' => $rows]);
            }

            // بازگردانی حذف نرم — مدیر کارگاه
            if ($action === 'restore') {
                if (!in_array($role, ['management'], true) && !Samaneh_Auth::is_network_admin()) {
                    samaneh_json_err('فقط مدیر مجموعه می‌تواند بازگردانی کند', 403);
                }
                $table = sanitize_key($_POST['table'] ?? '');
                $id = (int) ($_POST['id'] ?? 0);
                if ($table === '' || $id < 1) {
                    samaneh_json_err('شناسه نامعتبر');
                }
                try {
                    $row = Samaneh_DB::restore($table, $id);
                    samaneh_json_ok($row, ['message' => 'با موفقیت بازگردانی شد']);
                } catch (Throwable $e) {
                    samaneh_json_err($e->getMessage());
                }
            }

            if ($action === 'purge' || $action === 'purge_forever') {
                samaneh_json_err('حذف برای همیشه فقط از پیشخوان وردپرس توسط مدیر شبکه مجاز است', 403);
            }

            $handled = apply_filters('samaneh_api_action', null, $action, $role);
            if ($handled !== null) {
                exit;
            }
            samaneh_json_err('اکشن ناشناخته');
        } catch (Throwable $e) {
            samaneh_json_err($e->getMessage(), 500);
        }
    }

    private static function upload(): void {
        if (empty($_FILES['file'])) {
            samaneh_json_err('فایلی نیست');
        }
        $file = $_FILES['file'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            samaneh_json_err('خطای آپلود');
        }
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $ok = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'mp3', 'ogg', 'wav', 'webm', 'pdf'];
        if (!in_array($ext, $ok, true)) {
            samaneh_json_err('نوع فایل مجاز نیست');
        }
        $dir = SAMANEH_CORE_DIR . 'uploads/';
        if (!is_dir($dir)) {
            wp_mkdir_p($dir);
        }
        $name = date('Ymd_His') . '_' . wp_generate_password(8, false) . '.' . $ext;
        if (!move_uploaded_file($file['tmp_name'], $dir . $name)) {
            samaneh_json_err('ذخیره ناموفق');
        }
        $saved = Samaneh_DB::save('photos', [
            'project'  => sanitize_text_field($_POST['project'] ?? ''),
            'stage'    => sanitize_text_field($_POST['stage'] ?? ''),
            'filename' => $name,
            'caption'  => sanitize_text_field($_POST['caption'] ?? ''),
            'approved' => '0',
        ]);
        samaneh_json_ok($saved, ['url' => SAMANEH_CORE_URL . 'uploads/' . $name]);
    }
}
