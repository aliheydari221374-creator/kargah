<?php
if (!defined('ABSPATH')) {
    exit;
}

class Samaneh_Modules {
    private static $registered = [];

    public static function register(string $slug, array $info): void {
        self::$registered[$slug] = array_merge([
            'name' => $slug, 'version' => '1.0.0', 'menus' => [], 'actions' => [],
        ], $info);
    }

    public static function all(): array {
        return self::$registered;
    }

    public static function load(): void {
        $dir = SAMANEH_CORE_DIR . 'modules';
        if (is_dir($dir)) {
            foreach (glob($dir . '/*/module.php') ?: [] as $f) {
                require_once $f;
            }
        }
        do_action('samaneh_register_modules');
    }

    public static function extra_menus(string $role): array {
        $m = [];
        foreach (self::$registered as $mod) {
            if (!empty($mod['menus'][$role])) {
                $m = array_merge($m, (array) $mod['menus'][$role]);
            }
        }
        return array_unique($m);
    }

    public static function extra_actions(string $role): array {
        $a = [];
        foreach (self::$registered as $mod) {
            if (!empty($mod['actions'][$role])) {
                $a = array_merge($a, (array) $mod['actions'][$role]);
            }
        }
        return array_unique($a);
    }
}
