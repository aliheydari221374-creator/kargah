<?php
if (!defined('ABSPATH')) {
    exit;
}

class Samaneh_RBAC {

    public static function role_def(string $role): array {
        return Samaneh_Roles::get($role) ?: [
            'menus' => [], 'can_delete' => false, 'can_settings' => false,
        ];
    }

    public static function can_action(string $role, string $action): bool {
        // حذف از جدول فعال فقط مدیر مجموعه (اول بایگانی می‌شود)
        if ($action === 'delete') {
            return $role === 'management';
        }
        $base = ['all', 'save', 'upload', 'export', 'archive', 'dismiss_lead'];
        if ($role === 'management') {
            $base = array_merge($base, ['settings', 'send_directive', 'roles', 'upload_logo', 'upload_theme_image', 'upload_font', 'user_perms', 'export', 'import', 'archive', 'delete', 'dismiss_lead']);
        }
        if (in_array($role, ['employee', 'customer'], true)) {
            $base = array_diff($base, ['export', 'import', 'delete']);
        }
        $extra = Samaneh_Modules::extra_actions($role);
        return in_array($action, array_merge($base, $extra), true);
    }

    public static function can_menu(string $role, string $menu_id): bool {
        $menus = self::role_def($role)['menus'] ?? [];
        $extra = Samaneh_Modules::extra_menus($role);
        return in_array($menu_id, array_merge($menus, $extra), true);
    }

    public static function can_write(string $role, string $table): bool {
        if ($role === 'management') {
            return true;
        }
        // دستورات فقط مدیر ایجاد/ویرایش می‌کند
        if ($table === 'directives') {
            return false;
        }
        $allowed = [
            'warehouse' => ['stock_items', 'stock_moves', 'stock_usage', 'purchases', 'suppliers', 'checks_received', 'checks_paid', 'messages', 'leave_requests', 'overtime', 'attendance', 'salary_payments', 'day_notes', 'cash_boxes', 'bank_accounts', 'expenses', 'incomes', 'sales_invoices', 'stock_transfers', 'account_payments'],
            'employee'  => ['daily_reports', 'leave_requests', 'overtime', 'attendance', 'stock_usage', 'photos', 'messages', 'day_notes'],
            'supervisor'=> ['customers', 'stock_items', 'stock_usage', 'daily_reports', 'messages', 'leave_requests', 'overtime', 'day_notes'],
            'customer'  => ['messages', 'checks_received'],
        ];
        $list = $allowed[$role] ?? ['daily_reports', 'attendance', 'leave_requests', 'messages', 'day_notes'];
        return in_array($table, $list, true);
    }

    public static function can_delete(string $role): bool {
        return $role === 'management';
    }

    public static function filter_boot(array $boot, string $role): array {
        if (class_exists('Samaneh_Auth') && !Samaneh_Auth::can_see_deleted()) {
            foreach ($boot as $k => $rows) {
                if (!is_array($rows) || in_array($k, ['settings', 'panel_roles', 'instances', 'extra'], true)) {
                    continue;
                }
                $boot[$k] = array_values(array_filter($rows, function ($r) {
                    if (!is_array($r)) {
                        return true;
                    }
                    return empty($r['_deleted']) && empty($r['deleted_at']);
                }));
            }
        }
        // یادداشت تقویم شخصی — فقط یادداشت‌های خود کاربر
        $my_name = class_exists('Samaneh_Auth') ? (string) Samaneh_Auth::personnel_name() : '';
        if ($my_name !== '' && !empty($boot['day_notes']) && is_array($boot['day_notes'])) {
            $boot['day_notes'] = array_values(array_filter($boot['day_notes'], function ($r) use ($my_name) {
                return (string) ($r['created_by'] ?? '') === $my_name;
            }));
        }
        if ($role === 'management') {
            return $boot;
        }
        if ($role === 'warehouse') {
            $name = Samaneh_Auth::personnel_name();
            foreach (['leave_requests', 'overtime', 'attendance'] as $k) {
                if (!empty($boot[$k])) {
                    $boot[$k] = array_values(array_filter($boot[$k], function ($r) use ($name) {
                        return ($r['personnel_name'] ?? '') === $name || $name === '';
                    }));
                }
            }
            foreach (['fines'] as $k) {
                $boot[$k] = [];
            }
            $boot = self::filter_warehouses_for_user($boot, $name);
            return $boot;
        }
        if ($role === 'customer') {
            $cname = Samaneh_Auth::personnel_name();
            $cid = (int) ((Samaneh_Auth::get_panel_user() ?? [])['customer_id'] ?? 0);
            if (!empty($boot['customers'])) {
                $boot['customers'] = array_values(array_filter($boot['customers'], function ($c) use ($cname, $cid) {
                    return (int) ($c['id'] ?? 0) === $cid || ($c['name'] ?? '') === $cname;
                }));
            }
            foreach (['personnel', 'checks_paid', 'purchases', 'suppliers', 'fines', 'stock_items', 'directives'] as $k) {
                if ($k === 'directives' && !empty($boot[$k])) {
                    $boot[$k] = array_values(array_filter($boot[$k], function ($d) use ($cname) {
                        return ($d['target_name'] ?? '') === $cname;
                    }));
                } elseif ($k !== 'directives') {
                    $boot[$k] = [];
                }
            }
            if (!empty($boot['messages']) && $cname !== '') {
                $boot['messages'] = array_values(array_filter($boot['messages'], function ($m) use ($cname) {
                    $sn = $m['sender_name'] ?? '';
                    $rn = $m['recipient_name'] ?? '';
                    $proj = $m['project'] ?? '';
                    return $sn === $cname || $rn === $cname || $proj === $cname;
                }));
            }
            return $boot;
        }
        $name = Samaneh_Auth::personnel_name();
        foreach (['checks_paid', 'purchases', 'suppliers', 'fines'] as $k) {
            if ($role !== 'supervisor') {
                $boot[$k] = [];
            }
        }
        // پرسنل فقط داده خودش
        if ($role === 'employee') {
            foreach (['daily_reports', 'leave_requests', 'overtime', 'attendance', 'stock_usage'] as $k) {
                if (!empty($boot[$k])) {
                    $boot[$k] = array_values(array_filter($boot[$k], function ($r) use ($name) {
                        return ($r['personnel_name'] ?? '') === $name;
                    }));
                }
            }
            $my_projects = [];
            if (!empty($boot['customers'])) {
                $boot['customers'] = array_values(array_filter($boot['customers'], function ($c) use ($name, &$my_projects) {
                    $inst = $c['installer'] ?? '';
                    $ok = $inst === '' || $inst === $name || strpos((string) $inst, $name) !== false;
                    if ($ok && !empty($c['name'])) {
                        $my_projects[] = $c['name'];
                    }
                    return $ok;
                }));
            }
            if (!empty($boot['messages']) && $name !== '') {
                $boot['messages'] = array_values(array_filter($boot['messages'], function ($m) use ($name, $my_projects) {
                    $sn = $m['sender_name'] ?? '';
                    $rn = $m['recipient_name'] ?? '';
                    $proj = $m['project'] ?? '';
                    $mt = $m['msg_type'] ?? '';
                    if ($sn === $name || $rn === $name) {
                        return true;
                    }
                    if ($mt === 'staff' || $rn === '__staff__') {
                        return true;
                    }
                    return $proj !== '' && in_array($proj, $my_projects, true);
                }));
            }
            $boot = self::filter_warehouses_for_user($boot, $name);
        }
        if ($role === 'supervisor') {
            $boot = self::filter_warehouses_for_user($boot, $name);
        }
        return $boot;
    }

    public static function policy(string $role): array {
        $def = self::role_def($role);
        $menus = array_merge($def['menus'] ?? [], Samaneh_Modules::extra_menus($role));
        $name = Samaneh_Auth::personnel_name();
        $instance_id = Samaneh_DB::instance_id();
        $user_perms = get_option('samaneh_user_perms_' . $instance_id, []);
        if (!is_array($user_perms)) {
            $user_perms = [];
        }
        $can_message = [];
        $my_warehouses = [];
        $warehouse_actions = ['view', 'withdraw', 'return']; // پیش‌فرض
        if ($role === 'management') {
            $my_warehouses = ['*']; // همه انبارها
            $warehouse_actions = ['view', 'withdraw', 'return', 'purchase', 'edit_stock'];
        }
        if ($name && !empty($user_perms[$name])) {
            $up = $user_perms[$name];
            if (!empty($up['menus']) && is_array($up['menus'])) {
                $menus = array_values(array_unique(array_merge($menus, $up['menus'])));
            }
            $can_message = (array) ($up['can_message'] ?? []);
            if (!empty($up['warehouses']) && is_array($up['warehouses'])) {
                $my_warehouses = array_values($up['warehouses']);
            }
            if (!empty($up['warehouse_actions']) && is_array($up['warehouse_actions'])) {
                $warehouse_actions = array_values($up['warehouse_actions']);
            }
        } elseif (in_array($role, ['warehouse', 'supervisor'], true) && empty($my_warehouses)) {
            $my_warehouses = ['*']; // اگر محدود نشده، همه
        }
        $is_net  = Samaneh_Auth::is_network_admin();
        $is_main = Samaneh_Auth::is_main_manager();
        if (class_exists('Samaneh_Grants')) {
            $menus = Samaneh_Grants::filter_menus($menus);
        }
        return [
            'role'               => $role,
            'can_delete'         => self::can_delete($role),
            'can_settings'       => ($role === 'management'),
            'menus'              => $menus,
            'modules'            => array_keys(Samaneh_Modules::all()),
            'granted_modules'    => class_exists('Samaneh_Grants') ? Samaneh_Grants::granted_modules() : [],
            'role_labels'        => Samaneh_Roles::labels(),
            'all_menus'          => Samaneh_Roles::available_menus(),
            'is_employee'        => $role === 'employee',
            'is_customer'        => $role === 'customer',
            'is_manager'         => $role === 'management',
            'is_network_admin'   => $is_net,
            'is_main_manager'    => $is_main,
            'can_see_deleted'    => Samaneh_Auth::can_see_deleted(),
            'can_purge'          => false,
            /** فقط مدیر شبکه یا مدیر کل می‌تواند مدیر جدید اضافه/ویرایش کند */
            'can_manage_managers'=> $is_net || $is_main,
            'can_message'        => $can_message,
            'my_warehouses'      => $my_warehouses,
            'warehouse_actions'  => $warehouse_actions,
            'user_perms'         => ($role === 'management') ? $user_perms : [],
        ];
    }

    /** آیا کاربر به این انبار دسترسی دارد؟ */
    public static function can_access_warehouse(string $warehouse_name, array $policy): bool {
        $list = $policy['my_warehouses'] ?? [];
        if (in_array('*', $list, true) || empty($list)) {
            return true;
        }
        return in_array($warehouse_name, $list, true);
    }

    /** فیلتر کالاها و حرکات انبار بر اساس دسترسی کاربر */
    private static function filter_warehouses_for_user(array $boot, string $name): array {
        $instance_id = Samaneh_DB::instance_id();
        $user_perms = get_option('samaneh_user_perms_' . $instance_id, []);
        if (!is_array($user_perms) || empty($user_perms[$name]['warehouses'])) {
            return $boot; // محدودیتی تعریف نشده
        }
        $allowed = (array) $user_perms[$name]['warehouses'];
        if (in_array('*', $allowed, true)) {
            return $boot;
        }
        if (!empty($boot['stock_items'])) {
            $boot['stock_items'] = array_values(array_filter($boot['stock_items'], function ($r) use ($allowed) {
                $w = $r['category'] ?? $r['warehouse'] ?? 'انبار اصلی';
                return in_array($w, $allowed, true) || $w === '';
            }));
        }
        if (!empty($boot['stock_usage'])) {
            $boot['stock_usage'] = array_values(array_filter($boot['stock_usage'], function ($r) use ($allowed) {
                // اگر پروژه/کالا به انبار خاصی وابسته نیست، نگه دار
                return true;
            }));
        }
        if (!empty($boot['purchases'])) {
            $boot['purchases'] = array_values(array_filter($boot['purchases'], function ($r) use ($allowed) {
                $w = $r['warehouse'] ?? '';
                return $w === '' || in_array($w, $allowed, true);
            }));
        }
        return $boot;
    }
}
