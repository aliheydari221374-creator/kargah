<?php
/**
 * بکاپ / خروجی / درون‌ریزی
 * JSON و CSV (Excel) — PDF فقط خروجی چاپ است
 */
if (!defined('ABSPATH')) {
    exit;
}

class Samaneh_Backup {

    public static function export_table_csv(string $table): void {
        $rows = self::get_rows($table);
        $fields = array_keys(Samaneh_DB::fields()[$table] ?? []);
        if (!$fields) {
            $fields = Samaneh_DB::fields()[$table] ?? [];
        }
        $fields = Samaneh_DB::fields()[$table] ?? [];
        $filename = $table . '_' . date('Y-m-d_His') . '.csv';
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        echo "\xEF\xBB\xBF";
        $out = fopen('php://output', 'w');
        $cols = array_merge(['id'], $fields);
        fputcsv($out, $cols);
        foreach ($rows as $row) {
            $line = [];
            foreach ($cols as $c) {
                $line[] = isset($row[$c]) ? (string) $row[$c] : '';
            }
            fputcsv($out, $line);
        }
        fclose($out);
        exit;
    }

    public static function export_table_json(string $table): void {
        $rows = self::get_rows($table);
        $payload = [
            'format'      => 'samaneh-table-v1',
            'table'       => $table,
            'instance_id' => Samaneh_DB::instance_id(),
            'exported_at' => gmdate('c'),
            'rows'        => $rows,
        ];
        $filename = $table . '_' . date('Y-m-d_His') . '.json';
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        echo wp_json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }

    public static function export_table_html_pdf(string $table): void {
        $rows = self::get_rows($table);
        $fields = Samaneh_DB::fields()[$table] ?? [];
        $cols = array_merge(['id'], $fields);
        $title = $table . ' — ' . date('Y-m-d H:i');
        header('Content-Type: text/html; charset=utf-8');
        echo '<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><title>' . esc_html($title) . '</title>';
        echo '<style>body{font-family:Tahoma,sans-serif;padding:24px;font-size:12px}h1{font-size:16px}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccc;padding:6px 8px;text-align:right}th{background:#f1f5f9}@media print{button{display:none}}</style></head><body>';
        echo '<button onclick="window.print()">چاپ / ذخیره PDF</button>';
        echo '<h1>' . esc_html($title) . '</h1><table><thead><tr>';
        foreach ($cols as $c) {
            echo '<th>' . esc_html($c) . '</th>';
        }
        echo '</tr></thead><tbody>';
        foreach ($rows as $row) {
            echo '<tr>';
            foreach ($cols as $c) {
                echo '<td>' . esc_html((string) ($row[$c] ?? '')) . '</td>';
            }
            echo '</tr>';
        }
        echo '</tbody></table></body></html>';
        exit;
    }

    public static function export_full_json(): void {
        $data = Samaneh_DB::fetch_all();
        // رمزها را در بکاپ نگه می‌داریم (هش شده‌اند)
        $payload = [
            'format'      => 'samaneh-full-v1',
            'instance_id' => Samaneh_DB::instance_id(),
            'exported_at' => gmdate('c'),
            'site'        => home_url('/'),
            'data'        => $data,
        ];
        $filename = 'samaneh_backup_i' . Samaneh_DB::instance_id() . '_' . date('Y-m-d_His') . '.json';
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        echo wp_json_encode($payload, JSON_UNESCAPED_UNICODE);
        exit;
    }

    /** برچسب فارسی شیت‌ها */
    /** ترتیب شیت‌ها مطابق منوی پنل — نام شیت فارسی */
    public static function sheet_order(): array {
        return [
            'settings' => '01_داشبورد_تنظیمات',
            'customers' => '02_مشتریان',
            'personnel' => '03_پرسنل',
            'directives' => '04_دستورات',
            'stock_items' => '05_انبار',
            'stock_usage' => '06_مصرف_مواد',
            'hardware_lists' => '07_لیست_یراق',
            'suppliers' => '08_تامین_کنندگان',
            'purchases' => '09_خریدها',
            'checks_received' => '10_چک_دریافتنی',
            'checks_paid' => '11_چک_پرداختنی',
            'salary_payments' => '12_حقوق',
            'fines' => '13_جریمه_پاداش',
            'attendance' => '14_ورود_خروج',
            'leave_requests' => '15_مرخصی',
            'overtime' => '16_اضافه_کاری',
            'daily_reports' => '17_گزارش_روزانه',
            'day_notes' => '18_یادداشت_روز',
            'messages' => '19_پیامها',
            'photos' => '20_عکسها',
            'leads' => '21_سرنخها',
            'stock_moves' => '22_حرکت_انبار',
            'debt_purchases' => '23_خرید_نسیه',
            'account_payments' => '24_پرداخت_حساب',
        ];
    }

    public static function sheet_labels(): array {
        return self::sheet_order();
    }

    /** نگاشت نام شیت فارسی → کلید جدول */
    public static function sheet_to_table(): array {
        $map = [];
        foreach (self::sheet_order() as $table => $label) {
            $map[$label] = $table;
            $map[$table] = $table;
            // بدون شماره پیشوند
            $bare = preg_replace('/^\d+_/', '', $label);
            $map[$bare] = $table;
        }
        // نام‌های ساده
        $map['مشتریان'] = 'customers';
        $map['پرسنل'] = 'personnel';
        $map['داشبورد'] = 'settings';
        $map['تنظیمات'] = 'settings';
        $map['انبار'] = 'stock_items';
        $map['دستورات'] = 'directives';
        return $map;
    }

    /**
     * اکسل چندشیتی (SpreadsheetML) — هر جدول یک شیت
     * با داده‌های فعلی کارگاه برای نمونه آفلاین
     */
    public static function export_full_excel_xml(bool $with_data = true): void {
        $labels = self::sheet_labels();
        $all_fields = Samaneh_DB::fields();
        $data = $with_data ? Samaneh_DB::fetch_all() : [];

        $xml = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        $xml .= '<?mso-application progid="Excel.Sheet"?>' . "\n";
        $xml .= '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"' . "\n";
        $xml .= ' xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">' . "\n";
        $xml .= '<Styles><Style ss:ID="hdr"><Font ss:Bold="1"/><Interior ss:Color="#E2E8F0" ss:Pattern="Solid"/></Style></Styles>' . "\n";

        // شیت راهنما
        $xml .= '<Worksheet ss:Name="00_راهنما"><Table>' . "\n";
        $guide = [
            ['راهنمای فایل اکسل سامانه'],
            ['هر شیت = یک بخش از منوی پنل'],
            ['ردیف ۱ = کلید انگلیسی ستون‌ها (عوض نکنید)'],
            ['ردیف ۲ = معنی فارسی (فقط راهنما — می‌توانید حذف کنید هنگام درون‌ریزی)'],
            ['از ردیف ۳ به بعد = داده'],
            ['شیت 01 = داشبورد/تنظیمات | 02 = مشتریان | 03 = پرسنل | بقیه به ترتیب منو'],
            ['برای درون‌ریزی: همین فایل اکسل را بعد از ویرایش در تنظیمات → آپلود بکاپ بارگذاری کنید'],
            ['اگر ردیف تکراری باشد سیستم هشدار می‌دهد و می‌پرسد جایگزین شود یا نه'],
            ['تاریخ خروجی: ' . date('Y-m-d H:i:s')],
            ['instance: ' . Samaneh_DB::instance_id()],
        ];
        foreach ($guide as $row) {
            $xml .= '<Row><Cell><Data ss:Type="String">' . self::xml_esc($row[0]) . '</Data></Cell></Row>' . "\n";
        }
        $xml .= '</Table></Worksheet>' . "\n";

        foreach (self::sheet_order() as $table => $sheet_name) {
            $fields = $all_fields[$table] ?? null;
            if (!is_array($fields)) continue;
            // Excel sheet name max 31 chars, no special chars
            $sheet_name = mb_substr(preg_replace('/[\\\/\*\?\[\]:]/u', '_', $sheet_name), 0, 31);
            $cols = array_merge(['id'], $fields);
            $rows = $with_data ? (isset($data[$table]) && is_array($data[$table]) ? $data[$table] : []) : [];

            $xml .= '<Worksheet ss:Name="' . self::xml_esc($sheet_name) . '"><Table>' . "\n";
            // header keys
            $xml .= '<Row>';
            foreach ($cols as $c) {
                $xml .= '<Cell ss:StyleID="hdr"><Data ss:Type="String">' . self::xml_esc($c) . '</Data></Cell>';
            }
            $xml .= '</Row>' . "\n";
            // persian labels row
            $xml .= '<Row>';
            foreach ($cols as $c) {
                $xml .= '<Cell><Data ss:Type="String">' . self::xml_esc($c === 'id' ? 'شناسه' : $c) . '</Data></Cell>';
            }
            $xml .= '</Row>' . "\n";
            // data rows (skip password hashes display partially)
            foreach ($rows as $row) {
                if (!is_array($row)) continue;
                if (!empty($row['deleted_at']) && $row['deleted_at'] !== '0000-00-00 00:00:00') continue;
                $xml .= '<Row>';
                foreach ($cols as $c) {
                    $val = isset($row[$c]) ? (string) $row[$c] : '';
                    if ($c === 'password' && $val !== '') $val = '********';
                    $type = is_numeric($val) && $val !== '' ? 'Number' : 'String';
                    if ($type === 'Number' && (strpos($val, '/') !== false || !is_numeric(str_replace(['.', '-'], '', $val)))) $type = 'String';
                    $xml .= '<Cell><Data ss:Type="' . $type . '">' . self::xml_esc($val) . '</Data></Cell>';
                }
                $xml .= '</Row>' . "\n";
            }
            // empty sample rows if no data
            if (!$rows) {
                $xml .= '<Row>';
                foreach ($cols as $c) {
                    $xml .= '<Cell><Data ss:Type="String"></Data></Cell>';
                }
                $xml .= '</Row>' . "\n";
            }
            $xml .= '</Table></Worksheet>' . "\n";
        }
        $xml .= '</Workbook>';

        $filename = 'samaneh_excel_i' . Samaneh_DB::instance_id() . '_' . date('Y-m-d_His') . '.xls';
        header('Content-Type: application/vnd.ms-excel; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Pragma: no-cache');
        echo $xml;
        exit;
    }

    private static function xml_esc(string $s): string {
        return htmlspecialchars($s, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }


    /**
     * درون‌ریزی از آرایه یا تشخیص خودکار فایل
     */
    public static function import_file(string $tmp_path, string $original_name, string $table_hint = '', bool $replace = false): array {
        if (!is_readable($tmp_path)) {
            throw new RuntimeException('فایل قابل خواندن نیست');
        }
        $raw = file_get_contents($tmp_path);
        if ($raw === false || $raw === '') {
            throw new RuntimeException('فایل خالی است');
        }

        $ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
        $name_lower = strtolower($original_name);

        // PDF قابل درون‌ریزی ساختاری نیست
        if ($ext === 'pdf' || strpos($name_lower, '.pdf') !== false) {
            throw new RuntimeException('فایل PDF فقط برای چاپ/خروجی است و قابل درون‌ریزی نیست. از Excel (CSV) یا JSON استفاده کنید.');
        }

        // JSON
        if ($ext === 'json' || (isset($raw[0]) && ($raw[0] === '{' || $raw[0] === '['))) {
            $payload = json_decode(self::strip_bom($raw), true);
            if (!is_array($payload)) {
                throw new RuntimeException('JSON نامعتبر است: ' . json_last_error_msg());
            }
            return self::import_payload($payload, $table_hint, $replace);
        }

        // اکسل چندشیتی SpreadsheetML (خروجی همین سامانه)
        if (in_array($ext, ['xls', 'xlsx', 'xml'], true) || strpos($raw, 'urn:schemas-microsoft-com:office:spreadsheet') !== false || strpos($raw, '<Workbook') !== false) {
            if (strpos($raw, '<Workbook') !== false || strpos($raw, 'office:spreadsheet') !== false) {
                return self::import_spreadsheet_ml($raw, $replace);
            }
            // xlsx باینری واقعی — هنوز نیاز به CSV
            if ($ext === 'xlsx') {
                throw new RuntimeException('فایل xlsx باینری پشتیبانی نمی‌شود. از «دانلود اکسل نمونه» همین پنل استفاده کنید (.xls) یا Save As → XML Spreadsheet / CSV.');
            }
        }

        // CSV / Excel-exported
        if (in_array($ext, ['csv', 'txt', 'xls', 'xlsx'], true) || strpos($raw, ',') !== false || strpos($raw, ';') !== false) {
            if (in_array($ext, ['xls', 'xlsx'], true) && strpos($raw, '<Workbook') === false) {
                throw new RuntimeException('این فایل اکسل قابل خواندن نیست. از دانلود اکسل نمونه پنل استفاده کنید یا CSV UTF-8 ذخیره کنید.');
            }
            if ($table_hint === '' || $table_hint === 'full') {
                throw new RuntimeException('برای CSV باید جدول مقصد مشخص باشد (مثلاً customers). از دکمه درون‌ریزی همان بخش استفاده کنید.');
            }
            $rows = self::parse_csv(self::strip_bom($raw));
            if (empty($rows)) {
                throw new RuntimeException('هیچ ردیفی در CSV پیدا نشد');
            }
            return self::import_rows($table_hint, $rows, $replace);
        }

        throw new RuntimeException('فرمت فایل پشتیبانی نمی‌شود. فقط JSON یا CSV');
    }

    public static function import_payload(array $payload, string $table_hint = '', bool $replace = false): array {
        $format = $payload['format'] ?? '';

        if ($format === 'samaneh-table-v1' || (isset($payload['table']) && isset($payload['rows']))) {
            $table = sanitize_key($payload['table'] ?? $table_hint);
            if ($table === '' || !isset(Samaneh_DB::fields()[$table])) {
                throw new RuntimeException('جدول در فایل مشخص نیست یا نامعتبر است');
            }
            if ($table_hint !== '' && $table_hint !== 'full' && $table_hint !== $table) {
                throw new RuntimeException('این فایل برای جدول «' . $table . '» است نه «' . $table_hint . '». از دکمه درون‌ریزی همان بخش استفاده کنید.');
            }
            $rows = $payload['rows'] ?? [];
            if (!is_array($rows)) {
                throw new RuntimeException('ردیف‌های فایل نامعتبر است');
            }
            return self::import_rows($table, $rows, $replace);
        }

        if ($format === 'samaneh-full-v1' || isset($payload['data'])) {
            $data = $payload['data'] ?? [];
            if (!is_array($data)) {
                throw new RuntimeException('ساختار بکاپ کامل نامعتبر است');
            }
            $stats = ['tables' => 0, 'rows' => 0, 'errors' => []];
            foreach (Samaneh_DB::fields() as $table => $_fields) {
                if (empty($data[$table]) || !is_array($data[$table])) {
                    continue;
                }
                try {
                    $s = self::import_rows($table, $data[$table], $replace);
                    $stats['tables']++;
                    $stats['rows'] += $s['rows'];
                } catch (Throwable $e) {
                    $stats['errors'][] = $table . ': ' . $e->getMessage();
                }
            }
            if ($stats['rows'] < 1 && empty($stats['errors'])) {
                throw new RuntimeException('در بکاپ هیچ ردیف قابل وارد کردنی نبود');
            }
            return $stats;
        }

        // آرایه ساده ردیف‌ها + table_hint
        if ($table_hint !== '' && $table_hint !== 'full' && self::is_list($payload)) {
            return self::import_rows($table_hint, $payload, $replace);
        }

        throw new RuntimeException('فرمت بکاپ شناخته نشد. فایل باید خروجی همین پنل (JSON/CSV) باشد.');
    }


    /**
     * درون‌ریزی فایل اکسل چندشیتی SpreadsheetML — هر شیت یک جدول
     */
    public static function import_spreadsheet_ml(string $raw, bool $replace = false): array {
        $raw = self::strip_bom($raw);
        $prev = libxml_use_internal_errors(true);
        $xml = simplexml_load_string($raw);
        libxml_clear_errors();
        libxml_use_internal_errors($prev);
        if ($xml === false) {
            throw new RuntimeException('فایل اکسل XML نامعتبر است');
        }
        $xml->registerXPathNamespace('ss', 'urn:schemas-microsoft-com:office:spreadsheet');
        $sheets = $xml->xpath('//ss:Worksheet');
        if (!$sheets) {
            $sheets = $xml->xpath('//Worksheet');
        }
        if (!$sheets) {
            $sheets = [];
            foreach ($xml->children() as $child) {
                $n = strtolower($child->getName());
                if ($n === 'worksheet' || substr($n, -9) === 'worksheet') {
                    $sheets[] = $child;
                }
            }
        }
        if (!$sheets) {
            throw new RuntimeException('هیچ شیتی در فایل اکسل یافت نشد');
        }
        $map = self::sheet_to_table();
        $total_rows = 0;
        $tables_ok = 0;
        $all_errors = [];
        $all_dups = [];
        foreach ($sheets as $sheet) {
            $attrs = $sheet->attributes('urn:schemas-microsoft-com:office:spreadsheet');
            if (!$attrs || !isset($attrs['Name'])) {
                $attrs = $sheet->attributes();
            }
            $name = ($attrs && isset($attrs['Name'])) ? (string) $attrs['Name'] : '';
            if ($name === '' || strpos($name, 'راهنما') !== false || strpos($name, '00_') === 0) {
                continue;
            }
            $table = $map[$name] ?? null;
            if (!$table) {
                $bare = preg_replace('/^\d+_/', '', $name);
                $table = $map[$bare] ?? null;
            }
            if (!$table || !isset(Samaneh_DB::fields()[$table])) {
                $all_errors[] = 'شیت ناشناخته رد شد: ' . $name;
                continue;
            }
            $rows_grid = self::parse_ss_sheet($sheet);
            if (count($rows_grid) < 1) {
                continue;
            }
            $header = [];
            foreach ($rows_grid[0] as $h) {
                $header[] = trim(sanitize_key((string) $h));
            }
            $data_rows = [];
            for ($i = 1; $i < count($rows_grid); $i++) {
                $cols = $rows_grid[$i];
                $first = isset($cols[0]) ? (string) $cols[0] : '';
                if ($i === 1 && ($first === 'شناسه' || $first === 'id')) {
                    continue;
                }
                if ($i === 1 && preg_match('/[\x{0600}-\x{06FF}]/u', $first) && !is_numeric($first)) {
                    // ردیف برچسب فارسی
                    continue;
                }
                $row = [];
                foreach ($header as $j => $key) {
                    if ($key === '') {
                        continue;
                    }
                    $row[$key] = isset($cols[$j]) ? trim((string) $cols[$j]) : '';
                }
                $nonempty = false;
                foreach ($row as $v) {
                    if ($v !== '') {
                        $nonempty = true;
                        break;
                    }
                }
                if ($nonempty) {
                    $data_rows[] = $row;
                }
            }
            if (!$data_rows) {
                continue;
            }
            try {
                $stats = self::import_rows($table, $data_rows, $replace);
                $total_rows += (int) ($stats['rows'] ?? 0);
                $tables_ok++;
                if (!empty($stats['duplicates'])) {
                    $all_dups = array_merge($all_dups, $stats['duplicates']);
                }
                if (!empty($stats['errors'])) {
                    $all_errors = array_merge($all_errors, $stats['errors']);
                }
            } catch (Throwable $e) {
                $all_errors[] = $name . ': ' . $e->getMessage();
            }
        }
        if ($tables_ok < 1 && $total_rows < 1) {
            throw new RuntimeException('هیچ داده‌ای وارد نشد. ' . implode(' | ', array_slice($all_errors, 0, 5)));
        }
        return [
            'tables' => $tables_ok,
            'rows' => $total_rows,
            'duplicates' => $all_dups,
            'errors' => $all_errors,
            'message' => $all_dups ? ('تکراری‌ها: ' . implode('، ', array_slice($all_dups, 0, 10))) : '',
        ];
    }

    private static function parse_ss_sheet($sheet): array {
        $rows = [];
        $sheet->registerXPathNamespace('ss', 'urn:schemas-microsoft-com:office:spreadsheet');
        $tr_list = $sheet->xpath('.//ss:Row');
        if (!$tr_list) {
            $tr_list = $sheet->xpath('.//Row');
        }
        if (!$tr_list) {
            $tr_list = [];
            foreach ($sheet->children() as $ch) {
                $cn = strtolower($ch->getName());
                if ($cn === 'table' || substr($cn, -5) === 'table') {
                    foreach ($ch->children() as $row) {
                        $rn = strtolower($row->getName());
                        if ($rn === 'row' || substr($rn, -3) === 'row') {
                            $tr_list[] = $row;
                        }
                    }
                }
            }
        }
        foreach ($tr_list as $tr) {
            $cells = [];
            $col_idx = 0;
            foreach ($tr->children() as $cell) {
                $cn = strtolower($cell->getName());
                if ($cn !== 'cell' && substr($cn, -4) !== 'cell') {
                    continue;
                }
                $attrs = $cell->attributes('urn:schemas-microsoft-com:office:spreadsheet');
                if (!$attrs) {
                    $attrs = $cell->attributes();
                }
                if ($attrs && isset($attrs['Index'])) {
                    $want = (int) $attrs['Index'] - 1;
                    while ($col_idx < $want) {
                        $cells[] = '';
                        $col_idx++;
                    }
                }
                $val = '';
                foreach ($cell->children() as $data) {
                    $val = (string) $data;
                    break;
                }
                $cells[] = $val;
                $col_idx++;
            }
            $rows[] = $cells;
        }
        return $rows;
    }

        public static function import_rows(string $table, array $rows, bool $replace = false): array {
        if (!isset(Samaneh_DB::fields()[$table])) {
            throw new RuntimeException('جدول نامعتبر: ' . $table);
        }
        $fields = Samaneh_DB::fields()[$table];
        if ($replace) {
            self::truncate($table);
        }
        $count = 0;
        $skipped = 0;
        $replaced = 0;
        $errors = [];
        $duplicates = [];
        $existing = self::get_rows($table);
        // کلید یکتا تقریبی بر اساس name / phone / item
        $uniq_keys = [];
        foreach ($existing as $ex) {
            $k = self::row_uniq_key($table, $ex);
            if ($k !== '') {
                $uniq_keys[$k] = (int) ($ex['id'] ?? 0);
            }
        }
        foreach ($rows as $i => $row) {
            if (!is_array($row)) {
                continue;
            }
            // رد کردن ردیف برچسب فارسی (ردیف ۲ قالب)
            $first_vals = array_values($row);
            if ($first_vals && (strpos((string) $first_vals[0], 'نام') !== false || (string) $first_vals[0] === 'شناسه')) {
                continue;
            }
            $clean = [];
            foreach ($fields as $f) {
                if (array_key_exists($f, $row)) {
                    $clean[$f] = $row[$f];
                }
            }
            if (isset($clean['password']) && $clean['password'] !== '' && $clean['password'] !== '********' && strpos((string) $clean['password'], '$') !== 0) {
                $clean['password'] = wp_hash_password((string) $clean['password']);
            }
            if (isset($clean['password']) && $clean['password'] === '********') {
                unset($clean['password']);
            }
            if (empty($clean)) {
                $errors[] = 'ردیف ' . ($i + 1) . ': فیلد معتبری نداشت';
                continue;
            }
            $uk = self::row_uniq_key($table, $clean);
            try {
                unset($clean['created_at'], $clean['updated_at']);
                if ($uk !== '' && isset($uniq_keys[$uk]) && !$replace) {
                    $duplicates[] = $uk;
                    // اگر id در فایل آمده باشد به‌روزرسانی
                    if (!empty($row['id'])) {
                        $clean['id'] = (int) $row['id'];
                        Samaneh_DB::save($table, $clean);
                        $replaced++;
                        $count++;
                    } else {
                        $skipped++;
                        $errors[] = 'تکراری: ' . $uk . ' — برای جایگزینی تیک «جایگزینی کامل» را بزنید یا id را در فایل بگذارید';
                    }
                    continue;
                }
                unset($clean['id']);
                Samaneh_DB::save($table, $clean);
                $count++;
                if ($uk !== '') {
                    $uniq_keys[$uk] = 1;
                }
            } catch (Throwable $e) {
                $errors[] = 'ردیف ' . ($i + 1) . ': ' . $e->getMessage();
            }
        }
        if ($count < 1 && $skipped < 1) {
            throw new RuntimeException('هیچ ردیفی وارد نشد. ' . implode(' | ', array_slice($errors, 0, 5)));
        }
        $msg_extra = '';
        if ($duplicates) {
            $msg_extra = ' تکراری‌ها: ' . implode('، ', array_slice($duplicates, 0, 10));
            if (count($duplicates) > 10) {
                $msg_extra .= ' و ' . (count($duplicates) - 10) . ' مورد دیگر';
            }
        }
        return [
            'tables' => 1,
            'rows' => $count,
            'skipped' => $skipped,
            'replaced' => $replaced,
            'duplicates' => $duplicates,
            'errors' => $errors,
            'table' => $table,
            'message' => $msg_extra,
        ];
    }

    /** کلید یکتای تقریبی برای تشخیص تکراری */
    private static function row_uniq_key(string $table, array $row): string {
        if ($table === 'personnel' || $table === 'customers' || $table === 'suppliers') {
            $n = trim((string) ($row['name'] ?? ''));
            $p = trim((string) ($row['phone'] ?? ''));
            return $n !== '' ? ($n . ($p !== '' ? '|' . $p : '')) : '';
        }
        if ($table === 'stock_items') {
            return trim((string) ($row['item'] ?? ''));
        }
        if ($table === 'directives') {
            return trim((string) ($row['title'] ?? '')) . '|' . trim((string) ($row['target_name'] ?? ''));
        }
        return '';
    }

    private static function parse_csv(string $raw): array {
        $raw = self::strip_bom($raw);
        $lines = preg_split('/\r\n|\n|\r/', $raw);
        $lines = array_values(array_filter($lines, function ($l) {
            return trim($l) !== '';
        }));
        if (count($lines) < 2) {
            return [];
        }
        // تشخیص جداکننده
        $delim = (substr_count($lines[0], ';') > substr_count($lines[0], ',')) ? ';' : ',';
        $header = str_getcsv($lines[0], $delim);
        $header = array_map(function ($h) {
            return trim(sanitize_key($h));
        }, $header);
        $rows = [];
        for ($i = 1; $i < count($lines); $i++) {
            $cols = str_getcsv($lines[$i], $delim);
            $row = [];
            foreach ($header as $j => $key) {
                if ($key === '') {
                    continue;
                }
                $row[$key] = isset($cols[$j]) ? trim($cols[$j]) : '';
            }
            if ($row) {
                $rows[] = $row;
            }
        }
        return $rows;
    }

    private static function strip_bom(string $s): string {
        if (substr($s, 0, 3) === "\xEF\xBB\xBF") {
            return substr($s, 3);
        }
        return $s;
    }

    private static function is_list(array $a): bool {
        if ($a === []) {
            return true;
        }
        return array_keys($a) === range(0, count($a) - 1);
    }

    private static function get_rows(string $table): array {
        global $wpdb;
        $t = Samaneh_DB::table($table);
        // phpcs:ignore
        $rows = $wpdb->get_results("SELECT * FROM `{$t}` ORDER BY id ASC", ARRAY_A);
        return is_array($rows) ? $rows : [];
    }

    private static function truncate(string $table): void {
        global $wpdb;
        $t = Samaneh_DB::table($table);
        // phpcs:ignore
        $wpdb->query("DELETE FROM `{$t}`");
        // reset autoincrement if possible
        // phpcs:ignore
        $wpdb->query("ALTER TABLE `{$t}` AUTO_INCREMENT = 1");
    }

    // ═══════════════════════════════════════════════════════════
    //  بکاپ خودکار هر ۱۲ ساعت — جدا برای هر کارگاه (instance)
    // ═══════════════════════════════════════════════════════════

    public static function backup_dir(): string {
        $dir = SAMANEH_CORE_DIR . 'data/auto-backups';
        if (!is_dir($dir)) {
            wp_mkdir_p($dir);
        }
        // محافظت از دسترسی وب
        $ht = $dir . '/.htaccess';
        if (!file_exists($ht)) {
            file_put_contents($ht, "Deny from all\n");
        }
        $idx = $dir . '/index.php';
        if (!file_exists($idx)) {
            file_put_contents($idx, "<?php\n// Silence is golden.\n");
        }
        return $dir;
    }

    public static function instance_backup_dir(int $instance_id): string {
        $dir = self::backup_dir() . '/i' . max(1, $instance_id);
        if (!is_dir($dir)) {
            wp_mkdir_p($dir);
        }
        return $dir;
    }

    /** ساخت payload کامل برای یک instance */
    public static function build_full_payload(int $instance_id): array {
        $prev = 1;
        try {
            $prev = Samaneh_DB::instance_id();
        } catch (Throwable $e) {
            $prev = 1;
        }
        $data = [];
        try {
            Samaneh_DB::set_instance($instance_id);
            $data = self::fetch_all_for_instance($instance_id);
        } catch (Throwable $e) {
            $data = ['_error' => $e->getMessage()];
        } finally {
            try {
                Samaneh_DB::set_instance((int) $prev);
            } catch (Throwable $e) {
                // ignore
            }
        }
        return [
            'format'       => 'samaneh-full-v1',
            'auto'         => true,
            'instance_id'  => $instance_id,
            'exported_at'  => gmdate('c'),
            'site'         => home_url('/'),
            'version'      => defined('SAMANEH_CORE_VERSION') ? SAMANEH_CORE_VERSION : '',
            'data'         => $data,
        ];
    }

    private static function fetch_all_for_instance(int $instance_id): array {
        global $wpdb;
        // Determine prefix
        if (class_exists('Samaneh_Instances') && method_exists('Samaneh_Instances', 'table_prefix')) {
            $prefix = Samaneh_Instances::table_prefix($instance_id);
        } else {
            $prefix = $wpdb->prefix . ($instance_id <= 1 ? 'sc_' : ('sc' . $instance_id . '_'));
        }
        $out = [];
        $tables = method_exists('Samaneh_DB', 'table_names') ? Samaneh_DB::table_names() : [];
        foreach ($tables as $name) {
            $t = $prefix . $name;
            // phpcs:ignore
            $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t));
            if (!$exists) {
                $out[$name] = [];
                continue;
            }
            // phpcs:ignore
            $rows = $wpdb->get_results("SELECT * FROM `{$t}` ORDER BY id ASC", ARRAY_A);
            $out[$name] = is_array($rows) ? $rows : [];
        }
        // settings option per instance
        $out['settings'] = get_option('samaneh_settings_' . $instance_id, get_option('samaneh_settings', []));
        $out['warehouse_mothers'] = get_option('samaneh_warehouse_mothers_' . $instance_id, []);
        return $out;
    }

    /**
     * ذخیره یک بکاپ خودکار برای instance مشخص
     * @return array{ok:bool,path?:string,error?:string,bytes?:int}
     */
    public static function save_auto_backup(int $instance_id): array {
        try {
            $payload = self::build_full_payload($instance_id);
            $dir = self::instance_backup_dir($instance_id);
            $filename = 'auto_i' . $instance_id . '_' . date('Y-m-d_His') . '.json';
            $path = $dir . '/' . $filename;
            $json = wp_json_encode($payload, JSON_UNESCAPED_UNICODE);
            if ($json === false) {
                return ['ok' => false, 'error' => 'json encode failed'];
            }
            $written = file_put_contents($path, $json);
            if ($written === false) {
                return ['ok' => false, 'error' => 'write failed'];
            }
            // فشرده‌سازی gzip اگر ممکن باشد
            if (function_exists('gzencode')) {
                $gz = $path . '.gz';
                $gz_data = gzencode($json, 6);
                if ($gz_data !== false) {
                    file_put_contents($gz, $gz_data);
                    // فایل خام را نگه می‌داریم یا فقط gz — هر دو برای اطمینان gz + حذف json بزرگ
                    @unlink($path);
                    $path = $gz;
                    $written = strlen($gz_data);
                }
            }
            self::prune_old_backups($instance_id, 14); // حداکثر ۱۴ نسخه (~ یک هفته با فاصله ۱۲س)
            update_option('samaneh_last_auto_backup_' . $instance_id, [
                'time' => time(),
                'path' => $path,
                'bytes' => $written,
                'at' => gmdate('c'),
                'kind' => 'auto',
            ], false);
            return ['ok' => true, 'path' => $path, 'bytes' => (int) $written];
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }


    /**
     * بکاپ دستی روی سرور (همان پوشه instance، با پیشوند manual_)
     */
    public static function save_manual_backup(int $instance_id): array {
        try {
            $payload = self::build_full_payload($instance_id);
            $payload['manual'] = true;
            $payload['auto'] = false;
            $dir = self::instance_backup_dir($instance_id);
            $filename = 'manual_i' . $instance_id . '_' . date('Y-m-d_His') . '.json';
            $path = $dir . '/' . $filename;
            $json = wp_json_encode($payload, JSON_UNESCAPED_UNICODE);
            if ($json === false) {
                return ['ok' => false, 'error' => 'json encode failed'];
            }
            $written = file_put_contents($path, $json);
            if ($written === false) {
                return ['ok' => false, 'error' => 'write failed'];
            }
            $final = $path;
            if (function_exists('gzencode')) {
                $gz = $path . '.gz';
                $gz_data = gzencode($json, 6);
                if ($gz_data !== false) {
                    file_put_contents($gz, $gz_data);
                    @unlink($path);
                    $final = $gz;
                    $written = strlen($gz_data);
                }
            }
            // prune includes both auto and manual — keep more for mixed
            self::prune_old_backups($instance_id, 20);
            update_option('samaneh_last_auto_backup_' . $instance_id, [
                'time' => time(),
                'path' => $final,
                'bytes' => $written,
                'at' => gmdate('c'),
                'kind' => 'manual',
            ], false);
            return [
                'ok' => true,
                'path' => $final,
                'file' => basename($final),
                'bytes' => (int) $written,
            ];
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    /** حذف نسخه‌های قدیمی — نگه‌داشتن $keep تای آخر */
    public static function prune_old_backups(int $instance_id, int $keep = 14): void {
        $dir = self::instance_backup_dir($instance_id);
        $files = array_merge(
            glob($dir . '/auto_i' . $instance_id . '_*.json') ?: [],
            glob($dir . '/auto_i' . $instance_id . '_*.json.gz') ?: [],
            glob($dir . '/manual_i' . $instance_id . '_*.json') ?: [],
            glob($dir . '/manual_i' . $instance_id . '_*.json.gz') ?: []
        );
        if (count($files) <= $keep) {
            return;
        }
        usort($files, function ($a, $b) {
            return filemtime($b) - filemtime($a);
        });
        foreach (array_slice($files, $keep) as $f) {
            @unlink($f);
        }
    }

    /** اجرای بکاپ خودکار برای همه کارگاه‌ها */
    public static function run_auto_all(): array {
        $results = [];
        $ids = [1];
        if (class_exists('Samaneh_Instances') && method_exists('Samaneh_Instances', 'all')) {
            $all = Samaneh_Instances::all();
            if (is_array($all) && $all) {
                $ids = [];
                foreach ($all as $inst) {
                    $id = (int) ($inst['id'] ?? 0);
                    if ($id > 0) {
                        $ids[] = $id;
                    }
                }
                if (!$ids) {
                    $ids = [1];
                }
            }
        }
        $ids = array_unique(array_map('intval', $ids));
        foreach ($ids as $id) {
            $results[$id] = self::save_auto_backup($id);
        }
        update_option('samaneh_last_auto_backup_run', time(), false);
        return $results;
    }

    public static function list_auto_backups(int $instance_id, int $limit = 20): array {
        $dir = self::instance_backup_dir($instance_id);
        $files = array_merge(
            glob($dir . '/auto_i' . $instance_id . '_*.json') ?: [],
            glob($dir . '/auto_i' . $instance_id . '_*.json.gz') ?: [],
            glob($dir . '/manual_i' . $instance_id . '_*.json') ?: [],
            glob($dir . '/manual_i' . $instance_id . '_*.json.gz') ?: []
        );
        usort($files, function ($a, $b) {
            return filemtime($b) - filemtime($a);
        });
        $out = [];
        foreach (array_slice($files, 0, $limit) as $f) {
            $out[] = [
                'file' => basename($f),
                'path' => $f,
                'bytes' => filesize($f),
                'mtime' => filemtime($f),
                'at' => date('Y-m-d H:i:s', filemtime($f)),
                'kind' => (strpos(basename($f), 'manual_') === 0) ? 'manual' : 'auto',
            ];
        }
        return $out;
    }

    public static function schedule_hooks(): void {
        // بازه ۱۲ ساعته سفارشی
        add_filter('cron_schedules', function ($schedules) {
            if (!isset($schedules['samaneh_12hours'])) {
                $schedules['samaneh_12hours'] = [
                    'interval' => 12 * HOUR_IN_SECONDS,
                    'display'  => 'هر ۱۲ ساعت (سامانه)',
                ];
            }
            return $schedules;
        });
        add_action('samaneh_auto_backup_event', [__CLASS__, 'run_auto_all']);
        if (!wp_next_scheduled('samaneh_auto_backup_event')) {
            wp_schedule_event(time() + 120, 'samaneh_12hours', 'samaneh_auto_backup_event');
        }
    }

    public static function unschedule_hooks(): void {
        $ts = wp_next_scheduled('samaneh_auto_backup_event');
        while ($ts) {
            wp_unschedule_event($ts, 'samaneh_auto_backup_event');
            $ts = wp_next_scheduled('samaneh_auto_backup_event');
        }
    }

}
