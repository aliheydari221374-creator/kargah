<?php
/**
 * اعطای ماژول‌ها به سایت‌های شبکه.
 *
 * پیش‌فرض: هیچ سایتی به افزونه دسترسی ندارد تا مدیر شبکه صریحاً بخش‌ها را باز کند.
 * مدیر شبکه (سوپرادمین) همیشه به همه بخش‌ها دسترسی دارد.
 */
if (!defined('ABSPATH')) {
    exit;
}

class Samaneh_Grants {

    const OPT = 'samaneh_site_grants';

    /** کاتالوگ بخش‌هایی که مدیر شبکه می‌تواند به هر سایت بدهد */
    public static function catalog(): array {
        return [
            'dashboard'  => [
                'label' => 'داشبورد',
                'menus' => ['dashboard', 'emp_dashboard'],
                'tables' => [],
            ],
            'customers'  => [
                'label' => 'مشتریان',
                'menus' => ['customers', 'cust_home', 'cust_project', 'cust_finance'],
                'tables' => ['customers', 'leads'],
            ],
            'personnel'  => [
                'label' => 'پرسنل',
                'menus' => ['personnel'],
                'tables' => ['personnel'],
            ],
            'finance'    => [
                'label' => 'مالی و چک‌ها',
                'menus' => ['finance'],
                'tables' => ['checks_received', 'checks_paid'],
            ],
            'warehouse'  => [
                'label' => 'انبار',
                'menus' => ['warehouse', 'emp_stock'],
                'tables' => ['stock_items', 'stock_moves', 'stock_usage'],
            ],
            'suppliers'  => [
                'label' => 'تأمین‌کنندگان',
                'menus' => ['suppliers'],
                'tables' => ['suppliers'],
            ],
            'purchases'  => [
                'label' => 'خریدها',
                'menus' => ['purchases'],
                'tables' => ['purchases'],
            ],
            'directives' => [
                'label' => 'دستورات',
                'menus' => ['directives'],
                'tables' => ['directives'],
            ],
            'fines'      => [
                'label' => 'جریمه و پاداش',
                'menus' => ['fines'],
                'tables' => ['fines'],
            ],
            'salary'     => [
                'label' => 'حقوق',
                'menus' => ['salary'],
                'tables' => ['salary_payments'],
            ],
            'attendance' => [
                'label' => 'حضور، مرخصی، اضافه‌کاری',
                'menus' => ['emp_attendance', 'emp_leave', 'emp_overtime', 'emp_report'],
                'tables' => ['attendance', 'leave_requests', 'overtime', 'daily_reports'],
            ],
            'chat'       => [
                'label' => 'چت و مکاتبات',
                'menus' => ['chat_history', 'emp_messages'],
                'tables' => ['messages'],
            ],
            'settings'   => [
                'label' => 'تنظیمات و نقش‌ها',
                'menus' => ['settings', 'roles'],
                'tables' => [],
            ],
        ];
    }

    public static function all(): array {
        $raw = is_multisite() ? get_site_option(self::OPT, []) : get_option(self::OPT, []);
        return is_array($raw) ? $raw : [];
    }

    public static function save_all(array $map): void {
        if (is_multisite()) {
            update_site_option(self::OPT, $map);
        } else {
            update_option(self::OPT, $map, false);
        }
    }

    public static function get_for_site(int $blog_id): array {
        $all = self::all();
        $row = $all[(string) $blog_id] ?? $all[$blog_id] ?? [];
        if (!is_array($row)) {
            $row = [];
        }
        $modules = [];
        foreach ((array) ($row['modules'] ?? []) as $m) {
            $m = sanitize_key((string) $m);
            if ($m !== '' && isset(self::catalog()[$m])) {
                $modules[] = $m;
            }
        }
        return [
            'enabled' => !empty($row['enabled']) && !empty($modules),
            'modules' => array_values(array_unique($modules)),
        ];
    }

    public static function save_for_site(int $blog_id, bool $enabled, array $modules): array {
        $clean = [];
        $catalog = self::catalog();
        foreach ($modules as $m) {
            $m = sanitize_key((string) $m);
            if (isset($catalog[$m])) {
                $clean[] = $m;
            }
        }
        $clean = array_values(array_unique($clean));
        if ($enabled && empty($clean)) {
            $enabled = false;
        }
        $all = self::all();
        $all[(string) $blog_id] = [
            'enabled' => $enabled ? 1 : 0,
            'modules' => $clean,
        ];
        self::save_all($all);
        return self::get_for_site($blog_id);
    }

    /** در نصب تکی (غیرشبکه) افزونه مثل قبل باز است */
    public static function is_single_site_open(): bool {
        return !is_multisite();
    }

    public static function site_is_enabled(?int $blog_id = null): bool {
        if (self::is_single_site_open()) {
            return true;
        }
        $blog_id = $blog_id ?: get_current_blog_id();
        $g = self::get_for_site((int) $blog_id);
        return !empty($g['enabled']);
    }

    public static function site_has_module(string $module, ?int $blog_id = null): bool {
        if (self::is_single_site_open()) {
            return true;
        }
        if (class_exists('Samaneh_Auth') && Samaneh_Auth::is_network_admin()) {
            return true;
        }
        $blog_id = $blog_id ?: get_current_blog_id();
        $g = self::get_for_site((int) $blog_id);
        if (empty($g['enabled'])) {
            return false;
        }
        return in_array(sanitize_key($module), $g['modules'], true);
    }

    public static function granted_modules(?int $blog_id = null): array {
        if (self::is_single_site_open()) {
            return array_keys(self::catalog());
        }
        if (class_exists('Samaneh_Auth') && Samaneh_Auth::is_network_admin()) {
            return array_keys(self::catalog());
        }
        $blog_id = $blog_id ?: get_current_blog_id();
        $g = self::get_for_site((int) $blog_id);
        return $g['enabled'] ? $g['modules'] : [];
    }

    public static function granted_menus(?int $blog_id = null): array {
        $menus = [];
        foreach (self::granted_modules($blog_id) as $mod) {
            $info = self::catalog()[$mod] ?? null;
            if ($info) {
                $menus = array_merge($menus, (array) $info['menus']);
            }
        }
        if (!in_array('dashboard', $menus, true)) {
            $menus[] = 'dashboard';
        }
        return array_values(array_unique($menus));
    }

    public static function can_use_table(string $table, ?int $blog_id = null): bool {
        $table = sanitize_key($table);
        // جداول سیستمی همیشه (اگر سایت فعال باشد)
        if (in_array($table, ['photos', 'archives'], true)) {
            return self::site_is_enabled($blog_id) || (class_exists('Samaneh_Auth') && Samaneh_Auth::is_network_admin());
        }
        foreach (self::granted_modules($blog_id) as $mod) {
            $tables = self::catalog()[$mod]['tables'] ?? [];
            if (in_array($table, $tables, true)) {
                return true;
            }
        }
        if (class_exists('Samaneh_Auth') && Samaneh_Auth::is_network_admin()) {
            return true;
        }
        return self::is_single_site_open();
    }

    public static function filter_menus(array $menus, ?int $blog_id = null): array {
        $allowed = self::granted_menus($blog_id);
        return array_values(array_filter($menus, function ($m) use ($allowed) {
            return in_array($m, $allowed, true);
        }));
    }

    public static function panel_locked_payload(): array {
        return [
            'locked'  => true,
            'title'   => 'افزونه روی این سایت فعال نیست',
            'message' => 'دسترسی این سایت به کارگاه آماده هنوز توسط مدیر شبکه زاگرس داده نشده است. با پشتیبانی تماس بگیرید.',
        ];
    }
}
