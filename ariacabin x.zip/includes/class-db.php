<?php
if (!defined('ABSPATH')) {
    exit;
}

class Samaneh_DB {

    private static $instance_id = 1;

    public static function set_instance(int $id): void {
        self::$instance_id = max(1, $id);
    }

    public static function instance_id(): int {
        return self::$instance_id;
    }

    public static function prefix(): string {
        return Samaneh_Instances::table_prefix(self::$instance_id);
    }

    public static function table(string $name): string {
        return self::prefix() . $name;
    }

    public static function fields(): array {
        $base = [
            'personnel'       => ['name', 'role', 'leave_days', 'phone', 'password', 'bank_card', 'bank_shaba', 'start_date', 'notes', 'salary_amount', 'salary_day', 'is_main'],
            'customers'       => ['name', 'phone', 'password', 'address', 'status', 'balance', 'project_amount', 'installer', 'note', 'design_files', 'sub_stage', 'stage_done_at', 'stage_photos', 'stage_remind_at', 'stage_action', 'install_progress', 'cancelled_at'],
            'salary_payments' => ['personnel_name', 'amount', 'pay_date', 'payment_type', 'notes', 'period'],
            'checks_received' => ['name', 'check_date', 'amount', 'bank', 'num', 'payee', 'for_what', 'photo', 'approval', 'kind', 'ref_no', 'note', 'check_status', 'status_note', 'passed_date'],
            'checks_paid'     => ['name', 'check_date', 'amount', 'bank', 'num', 'payee', 'shaba', 'description', 'photo', 'approval', 'kind', 'ref_no', 'check_status', 'status_note', 'passed_date'],
            'debt_purchases'  => ['name', 'check_date', 'amount', 'bank', 'num', 'payee', 'approval', 'note', 'photo', 'ref_no'],
            'account_payments'=> ['person_type', 'person_name', 'amount', 'pay_date', 'notes', 'direction', 'method', 'account_name', 'ref_type', 'ref_id'],
            'cash_boxes'       => ['name', 'opening_balance', 'notes'],
            'bank_accounts'    => ['name', 'bank_name', 'account_no', 'shaba', 'opening_balance', 'notes'],
            'expenses'         => ['title', 'category', 'amount', 'expense_date', 'account_type', 'account_name', 'party_name', 'notes', 'photo'],
            'incomes'          => ['title', 'category', 'amount', 'income_date', 'account_type', 'account_name', 'party_name', 'notes', 'photo'],
            'sales_invoices'   => ['customer_name', 'invoice_date', 'invoice_no', 'items_json', 'subtotal', 'discount', 'total', 'paid_amount', 'status', 'warehouse', 'notes'],
            'stock_transfers'  => ['item_name', 'qty', 'unit', 'from_warehouse', 'to_warehouse', 'transfer_date', 'notes', 'personnel_name'],
            'stock_items'     => ['category', 'item', 'qty', 'min_qty', 'unit', 'unit2', 'unit_ratio', 'prior_stock', 'prior_date', 'price'],
            'stock_moves'     => ['kind', 'item', 'qty', 'party', 'notes', 'move_date', 'warehouse'],
            'stock_usage'     => ['project', 'item_name', 'qty', 'notes', 'stage', 'used_at', 'personnel_name', 'kind', 'status', 'prod_stage', 'unit', 'transfer_to'],
            'suppliers'       => ['name', 'phone', 'notes'],
            'purchases'       => ['supplier', 'item', 'qty', 'amount', 'price', 'invoice_date', 'invoice_no', 'warehouse', 'payment_type', 'carrier', 'photo', 'notes'],
            'daily_reports'   => ['personnel_name', 'project', 'stage', 'qty', 'hours', 'notes', 'photo', 'report_date'],
            'attendance'      => ['personnel_name', 'check_in', 'check_out', 'att_date', 'notes', 'lat', 'lng', 'accuracy_m', 'site_name', 'site_id', 'ip_addr', 'geo_ok', 'device_info'],
            'leave_requests'  => ['personnel_name', 'from_date', 'to_date', 'reason', 'status', 'leave_type', 'hours'],
            'overtime'        => ['personnel_name', 'project', 'hours', 'notes', 'ot_date', 'status', 'from_time', 'to_time', 'reason'],
            'photos'          => ['project', 'stage', 'filename', 'caption', 'approved'],
            'messages'        => ['sender_role', 'sender_name', 'recipient_name', 'recipient_role', 'body', 'msg_type', 'file_path', 'project', 'payment_type', 'amount'],
            'directives'      => ['title', 'body', 'status', 'target_name', 'target_role', 'priority', 'project', 'due_date', 'reminder_count', 'reminder_interval', 'reminder_unit', 'reminders_sent', 'attachment'],
            'leads'           => ['phone', 'note', 'status', 'source'],
            'fines'           => ['personnel_name', 'amount', 'reason', 'fine_date', 'status', 'type'],
            'day_notes'       => ['note_date', 'body', 'file_path', 'created_by', 'note_kind', 'status', 'snooze_until'],
            'hardware_lists'  => ['customer_name', 'list_date', 'items_json', 'personnel_name', 'notes', 'status'],
        ];
        return apply_filters('samaneh_table_fields_map', $base);
    }

    private static function ddl_for(string $p, string $c): array {
        return [
            'personnel' => "CREATE TABLE {$p}personnel (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                name VARCHAR(255) NOT NULL DEFAULT '',
                role VARCHAR(64) NOT NULL DEFAULT 'employee',
                leave_days DECIMAL(8,1) NOT NULL DEFAULT 0,
                phone VARCHAR(64) DEFAULT '',
                password VARCHAR(255) DEFAULT '',
                bank_card VARCHAR(32) DEFAULT '',
                bank_shaba VARCHAR(64) DEFAULT '',
                start_date VARCHAR(32) DEFAULT '',
                notes TEXT,
                wp_user_id BIGINT UNSIGNED DEFAULT 0,
                is_main TINYINT(1) NOT NULL DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'customers' => "CREATE TABLE {$p}customers (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                name VARCHAR(255) NOT NULL DEFAULT '',
                phone VARCHAR(64) DEFAULT '',
                password VARCHAR(255) DEFAULT '',
                address TEXT,
                status VARCHAR(64) NOT NULL DEFAULT 'new',
                balance BIGINT NOT NULL DEFAULT 0,
                project_amount BIGINT NOT NULL DEFAULT 0,
                installer VARCHAR(255) DEFAULT '',
                note TEXT,
                wp_user_id BIGINT UNSIGNED DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                                sub_stage VARCHAR(64) DEFAULT '',
                stage_done_at VARCHAR(32) DEFAULT '',
                stage_photos TEXT,
                stage_remind_at VARCHAR(32) DEFAULT '',
                stage_action VARCHAR(32) DEFAULT '',
                install_progress TEXT,
                cancelled_at VARCHAR(32) DEFAULT '',
PRIMARY KEY (id)
            ) $c",
            'checks_received' => "CREATE TABLE {$p}checks_received (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                name VARCHAR(255) NOT NULL DEFAULT '',
                check_date VARCHAR(32) NOT NULL DEFAULT '',
                amount BIGINT NOT NULL DEFAULT 0,
                bank VARCHAR(128) DEFAULT '',
                num VARCHAR(64) DEFAULT '',
                payee VARCHAR(255) DEFAULT '',
                for_what TEXT,
                photo VARCHAR(255) DEFAULT '',
                approval VARCHAR(32) DEFAULT 'pending',
                kind VARCHAR(32) DEFAULT 'check',
                ref_no VARCHAR(64) DEFAULT '',
                note TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'checks_paid' => "CREATE TABLE {$p}checks_paid (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                name VARCHAR(255) DEFAULT '',
                check_date VARCHAR(32) NOT NULL DEFAULT '',
                amount BIGINT NOT NULL DEFAULT 0,
                bank VARCHAR(128) DEFAULT '',
                num VARCHAR(64) DEFAULT '',
                payee VARCHAR(255) DEFAULT '',
                shaba VARCHAR(64) DEFAULT '',
                description TEXT,
                photo VARCHAR(255) DEFAULT '',
                approval VARCHAR(32) DEFAULT 'pending',
                kind VARCHAR(32) DEFAULT 'check',
                ref_no VARCHAR(64) DEFAULT '',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'debt_purchases' => "CREATE TABLE {$p}debt_purchases (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                name VARCHAR(255) DEFAULT '',
                check_date VARCHAR(32) NOT NULL DEFAULT '',
                amount BIGINT NOT NULL DEFAULT 0,
                bank VARCHAR(128) DEFAULT '',
                num VARCHAR(64) DEFAULT '',
                payee VARCHAR(255) DEFAULT '',
                approval VARCHAR(32) DEFAULT 'pending',
                note TEXT,
                photo VARCHAR(255) DEFAULT '',
                ref_no VARCHAR(64) DEFAULT '',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'account_payments' => "CREATE TABLE {$p}account_payments (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                person_type VARCHAR(32) DEFAULT 'other',
                person_name VARCHAR(255) DEFAULT '',
                amount BIGINT NOT NULL DEFAULT 0,
                pay_date VARCHAR(64) DEFAULT '',
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'stock_items' => "CREATE TABLE {$p}stock_items (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                category VARCHAR(128) NOT NULL DEFAULT '',
                item VARCHAR(255) NOT NULL DEFAULT '',
                qty VARCHAR(64) NOT NULL DEFAULT '0',
                min_qty VARCHAR(64) DEFAULT '0',
                unit VARCHAR(32) DEFAULT '',
                unit2 VARCHAR(32) DEFAULT '',
                unit_ratio VARCHAR(32) DEFAULT '',
                prior_stock VARCHAR(16) DEFAULT 'ندارد',
                prior_date VARCHAR(32) DEFAULT '',
                price BIGINT DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'stock_moves' => "CREATE TABLE {$p}stock_moves (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                kind VARCHAR(32) DEFAULT 'in',
                item VARCHAR(255) DEFAULT '',
                qty VARCHAR(64) DEFAULT '',
                party VARCHAR(255) DEFAULT '',
                notes TEXT,
                move_date VARCHAR(32) DEFAULT '',
                warehouse VARCHAR(64) DEFAULT '',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'stock_usage' => "CREATE TABLE {$p}stock_usage (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                project VARCHAR(255) DEFAULT '',
                item_name VARCHAR(255) DEFAULT '',
                qty VARCHAR(64) DEFAULT '',
                notes TEXT,
                stage VARCHAR(64) DEFAULT '',
                used_at VARCHAR(32) DEFAULT '',
                personnel_name VARCHAR(255) DEFAULT '',
                kind VARCHAR(32) DEFAULT 'برداشت',
                status VARCHAR(32) DEFAULT 'تأییدشده',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'suppliers' => "CREATE TABLE {$p}suppliers (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                name VARCHAR(255) NOT NULL DEFAULT '',
                phone VARCHAR(64) DEFAULT '',
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'purchases' => "CREATE TABLE {$p}purchases (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                supplier VARCHAR(255) DEFAULT '',
                item VARCHAR(255) DEFAULT '',
                qty VARCHAR(64) DEFAULT '',
                amount BIGINT NOT NULL DEFAULT 0,
                price BIGINT DEFAULT 0,
                invoice_date VARCHAR(32) DEFAULT '',
                invoice_no VARCHAR(64) DEFAULT '',
                warehouse VARCHAR(64) DEFAULT '',
                payment_type VARCHAR(64) DEFAULT '',
                carrier VARCHAR(255) DEFAULT '',
                photo VARCHAR(255) DEFAULT '',
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'daily_reports' => "CREATE TABLE {$p}daily_reports (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                personnel_name VARCHAR(255) DEFAULT '',
                project VARCHAR(255) DEFAULT '',
                stage VARCHAR(64) DEFAULT '',
                qty VARCHAR(64) DEFAULT '',
                hours DECIMAL(8,2) DEFAULT 0,
                notes TEXT,
                photo VARCHAR(255) DEFAULT '',
                report_date VARCHAR(32) DEFAULT '',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'attendance' => "CREATE TABLE {$p}attendance (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                personnel_name VARCHAR(255) DEFAULT '',
                check_in VARCHAR(32) DEFAULT '',
                check_out VARCHAR(32) DEFAULT '',
                att_date VARCHAR(32) DEFAULT '',
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'leave_requests' => "CREATE TABLE {$p}leave_requests (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                personnel_name VARCHAR(255) DEFAULT '',
                from_date VARCHAR(32) DEFAULT '',
                to_date VARCHAR(32) DEFAULT '',
                reason TEXT,
                status VARCHAR(32) DEFAULT 'در انتظار',
                leave_type VARCHAR(32) DEFAULT 'روزانه',
                hours DECIMAL(8,2) DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'overtime' => "CREATE TABLE {$p}overtime (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                personnel_name VARCHAR(255) DEFAULT '',
                project VARCHAR(255) DEFAULT '',
                hours DECIMAL(8,2) DEFAULT 0,
                notes TEXT,
                ot_date VARCHAR(32) DEFAULT '',
                status VARCHAR(32) DEFAULT 'در انتظار',
                from_time VARCHAR(16) DEFAULT '',
                to_time VARCHAR(16) DEFAULT '',
                reason VARCHAR(64) DEFAULT '',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'photos' => "CREATE TABLE {$p}photos (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                project VARCHAR(255) DEFAULT '',
                stage VARCHAR(64) DEFAULT '',
                filename VARCHAR(255) NOT NULL DEFAULT '',
                caption TEXT,
                approved VARCHAR(8) DEFAULT '0',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'messages' => "CREATE TABLE {$p}messages (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                sender_role VARCHAR(32) DEFAULT '',
                sender_name VARCHAR(255) DEFAULT '',
                recipient_name VARCHAR(255) DEFAULT '',
                recipient_role VARCHAR(32) DEFAULT '',
                body TEXT,
                msg_type VARCHAR(16) DEFAULT 'text',
                file_path VARCHAR(255) DEFAULT '',
                project VARCHAR(255) DEFAULT '',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'directives' => "CREATE TABLE {$p}directives (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                title VARCHAR(255) DEFAULT '',
                body TEXT,
                status VARCHAR(32) DEFAULT 'باز',
                target_name VARCHAR(255) DEFAULT '',
                target_role VARCHAR(32) DEFAULT '',
                priority VARCHAR(64) DEFAULT 'مهم',
                project VARCHAR(255) DEFAULT '',
                due_date VARCHAR(32) DEFAULT '',
                reminder_count INT DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'fines' => "CREATE TABLE {$p}fines (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                personnel_name VARCHAR(255) DEFAULT '',
                amount BIGINT NOT NULL DEFAULT 0,
                reason TEXT,
                fine_date VARCHAR(32) DEFAULT '',
                status VARCHAR(32) DEFAULT 'ثبت‌شده',
                type VARCHAR(16) DEFAULT 'fine',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'leads' => "CREATE TABLE {$p}leads (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                phone VARCHAR(64) DEFAULT '',
                note TEXT,
                status VARCHAR(32) DEFAULT 'new',
                source VARCHAR(64) DEFAULT 'login',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'salary_payments' => "CREATE TABLE {$p}salary_payments (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                personnel_name VARCHAR(255) DEFAULT '',
                amount BIGINT NOT NULL DEFAULT 0,
                pay_date VARCHAR(32) DEFAULT '',
                payment_type VARCHAR(32) DEFAULT 'نقدی',
                notes TEXT,
                period VARCHAR(64) DEFAULT '',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY personnel_name (personnel_name)
            ) $c",

            'cash_boxes' => "CREATE TABLE {$p}cash_boxes (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                name VARCHAR(128) NOT NULL DEFAULT '',
                opening_balance BIGINT DEFAULT 0,
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'bank_accounts' => "CREATE TABLE {$p}bank_accounts (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                name VARCHAR(128) NOT NULL DEFAULT '',
                bank_name VARCHAR(128) DEFAULT '',
                account_no VARCHAR(64) DEFAULT '',
                shaba VARCHAR(64) DEFAULT '',
                opening_balance BIGINT DEFAULT 0,
                notes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'expenses' => "CREATE TABLE {$p}expenses (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                title VARCHAR(255) DEFAULT '',
                category VARCHAR(128) DEFAULT '',
                amount BIGINT NOT NULL DEFAULT 0,
                expense_date VARCHAR(32) DEFAULT '',
                account_type VARCHAR(16) DEFAULT 'cash',
                account_name VARCHAR(128) DEFAULT '',
                party_name VARCHAR(255) DEFAULT '',
                notes TEXT,
                photo VARCHAR(255) DEFAULT '',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'incomes' => "CREATE TABLE {$p}incomes (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                title VARCHAR(255) DEFAULT '',
                category VARCHAR(128) DEFAULT '',
                amount BIGINT NOT NULL DEFAULT 0,
                income_date VARCHAR(32) DEFAULT '',
                account_type VARCHAR(16) DEFAULT 'cash',
                account_name VARCHAR(128) DEFAULT '',
                party_name VARCHAR(255) DEFAULT '',
                notes TEXT,
                photo VARCHAR(255) DEFAULT '',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'sales_invoices' => "CREATE TABLE {$p}sales_invoices (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                customer_name VARCHAR(255) DEFAULT '',
                invoice_date VARCHAR(32) DEFAULT '',
                invoice_no VARCHAR(64) DEFAULT '',
                items_json LONGTEXT,
                subtotal BIGINT DEFAULT 0,
                discount BIGINT DEFAULT 0,
                total BIGINT DEFAULT 0,
                paid_amount BIGINT DEFAULT 0,
                status VARCHAR(32) DEFAULT 'open',
                warehouse VARCHAR(128) DEFAULT '',
                notes TEXT,
                stock_applied TINYINT(1) DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",
            'stock_transfers' => "CREATE TABLE {$p}stock_transfers (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                item_name VARCHAR(255) DEFAULT '',
                qty VARCHAR(64) DEFAULT '0',
                unit VARCHAR(32) DEFAULT '',
                from_warehouse VARCHAR(128) DEFAULT '',
                to_warehouse VARCHAR(128) DEFAULT '',
                transfer_date VARCHAR(32) DEFAULT '',
                notes TEXT,
                personnel_name VARCHAR(255) DEFAULT '',
                stock_applied TINYINT(1) DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id)
            ) $c",

            'day_notes' => "CREATE TABLE {$p}day_notes (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                note_date VARCHAR(32) DEFAULT '',
                body TEXT,
                file_path VARCHAR(512) DEFAULT '',
                created_by VARCHAR(255) DEFAULT '',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY note_date (note_date)
            ) $c",
            'hardware_lists' => "CREATE TABLE {$p}hardware_lists (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                customer_name VARCHAR(255) DEFAULT '',
                list_date VARCHAR(32) DEFAULT '',
                items_json LONGTEXT,
                personnel_name VARCHAR(255) DEFAULT '',
                notes TEXT,
                status VARCHAR(32) DEFAULT 'ثبت‌شده',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                deleted_at DATETIME DEFAULT NULL,
                deleted_by VARCHAR(64) DEFAULT '',
                PRIMARY KEY (id),
                KEY customer_name (customer_name)
            ) $c",
        ];
    }

    public static function create_tables_for(int $instance_id): void {
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        global $wpdb;
        $c = $wpdb->get_charset_collate();
        $p = Samaneh_Instances::table_prefix($instance_id);
        foreach (self::ddl_for($p, $c) as $sql) {
            dbDelta($sql);
        }
        self::ensure_soft_delete_on_prefix($p);
        self::seed_default_stock_items($instance_id);
        self::purge_legacy_stock_items_once($instance_id);
        Samaneh_Stock::ensure_innodb($p, $instance_id);
        do_action('samaneh_create_tables', $instance_id);
    }

    /**
     * انبار بدون کالای از پیش‌تعریف‌شده — مدیر انبار مادر و کالا را خودش وارد می‌کند
     */
    public static function seed_default_stock_items(int $instance_id): void {
        // عمداً خالی: هیچ نام انبار و هیچ نام کالای پیش‌فرضی ثبت نمی‌شود
        return;
    }

    /** یک‌بار کالاهای قدیمی انبار را پاک می‌کند تا فقط با افزودن تازه ثبت شوند */
    public static function purge_legacy_stock_items_once(int $instance_id): void {
        $flag = 'samaneh_stock_items_purged_v2_' . $instance_id;
        if (get_option($flag)) {
            return;
        }
        global $wpdb;
        $prev = self::$instance_id;
        self::$instance_id = $instance_id;
        $t = self::table('stock_items');
        // phpcs:ignore
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t));
        if ($exists) {
            // phpcs:ignore
            $wpdb->query("DELETE FROM `{$t}`");
        }
        update_option($flag, 1, false);
        self::$instance_id = $prev;
    }

    public static function create_tables(): void {
        foreach (array_keys(Samaneh_Instances::all()) as $id) {
            self::create_tables_for((int) $id);
        }
    }

    public static function table_names(): array {
        $names = array_keys(self::fields());
        $extra = apply_filters('samaneh_extra_tables', []);
        return array_unique(array_merge($names, $extra));
    }

    public static function fetch_all(): array {
        global $wpdb;
        // اطمینان از وجود جداول جدید (مثل حقوق)
        try {
            self::create_tables_for(self::instance_id());
            self::purge_legacy_stock_items_once(self::instance_id());
            self::ensure_extra_columns('stock_items');
            self::ensure_extra_columns('stock_usage');
            self::ensure_extra_columns('attendance');
            self::ensure_extra_columns('day_notes');
            self::ensure_extra_columns('checks_received');
            self::ensure_extra_columns('checks_paid');
            self::ensure_extra_columns('stock_transfers');
            self::ensure_extra_columns('sales_invoices');
            self::ensure_extra_columns('incomes');
            self::ensure_extra_columns('expenses');
            self::ensure_extra_columns('bank_accounts');
            self::ensure_extra_columns('cash_boxes');
            self::ensure_extra_columns('account_payments');
        } catch (Throwable $e) {
            // نادیده
        }
        // شارژ ماهانه مرخصی (۲.۵ روز در هر ماه کاری)
        try {
            self::accrue_monthly_leave();
        } catch (Throwable $e) {
            // نادیده
        }
        $out = [];
        foreach (self::table_names() as $name) {
            $t = self::table($name);
            // phpcs:ignore
            $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t));
            if (!$exists) {
                $out[$name] = [];
                continue;
            }
            self::ensure_soft_delete_column($t);
            $include_deleted = class_exists('Samaneh_Auth') && Samaneh_Auth::can_see_deleted();
            $sql = "SELECT * FROM `{$t}`";
            if (!$include_deleted && self::table_has_column($t, 'deleted_at')) {
                $sql .= " WHERE (deleted_at IS NULL OR deleted_at = '' OR deleted_at = '0000-00-00 00:00:00')";
            }
            $sql .= ' ORDER BY id ASC';
            // phpcs:ignore
            $rows = $wpdb->get_results($sql, ARRAY_A);
            $out[$name] = is_array($rows) ? $rows : [];
            foreach ($out[$name] as &$row) {
                $row['_deleted'] = self::row_is_deleted($row);
                foreach (['balance', 'amount', 'project_amount', 'price', 'reminder_count', 'wp_user_id'] as $num) {
                    if (isset($row[$num]) && $row[$num] !== '' && $row[$num] !== null) {
                        $row[$num] = (int) $row[$num];
                    }
                }
                if (isset($row['leave_days'])) {
                    $row['leave_days'] = (float) $row['leave_days'];
                }
                if (isset($row['hours'])) {
                    $row['hours'] = (float) $row['hours'];
                }
                // نمایش دو واحدی مانده انبار
                if ($name === 'stock_items') {
                    $row['qty_display'] = Samaneh_Stock::format_remaining($row);
                    $row['_is_low'] = Samaneh_Stock::is_low($row);
                }
            }
            unset($row);
        }

        $inst = Samaneh_Instances::get(self::$instance_id) ?: [];
        $theme = is_array($inst['theme'] ?? null) ? $inst['theme'] : [];
        $out['settings'] = [
            'company_name'      => (string) ($inst['name'] ?? get_option('samaneh_company_name', '')),
            'panel_slug'        => (string) ($inst['slug'] ?? 'panel'),
            'logo'              => (string) ($inst['logo'] ?? get_option('samaneh_logo', '')),
            'currency'          => (string) get_option('samaneh_currency', 'تومان'),
            'report_fine'       => (string) get_option('samaneh_report_fine', '250000'),
            'warning_count'     => (string) get_option('samaneh_warning_count', '3'),
            'min_stock_alert'   => (string) get_option('samaneh_min_stock_alert', '10'),
            'max_monthly_leave' => (string) get_option('samaneh_max_monthly_leave', '2.5'),
            'standard_hours'    => (string) get_option('samaneh_standard_hours', '8'),
            'instance_id'       => self::$instance_id,
            'max_slots'         => Samaneh_Instances::max_slots(),
            'used_slots'        => count(Samaneh_Instances::all()),
            'manager_wp_user_id'=> (int) ($inst['manager_wp_user_id'] ?? 0),
            'theme'             => $theme,
            'wp_datetime'       => Samaneh_Auth::wp_datetime(),
            'wp_date_format'    => get_option('date_format'),
            'wp_time_format'    => get_option('time_format'),
            // شبکه‌های اجتماعی مجموعه
            'social_instagram'  => (string) get_option('samaneh_social_instagram_' . self::$instance_id, get_option('samaneh_social_instagram', '')),
            'social_telegram'   => (string) get_option('samaneh_social_telegram_' . self::$instance_id, get_option('samaneh_social_telegram', '')),
            'social_whatsapp'   => (string) get_option('samaneh_social_whatsapp_' . self::$instance_id, get_option('samaneh_social_whatsapp', '')),
            'social_linkedin'   => (string) get_option('samaneh_social_linkedin_' . self::$instance_id, get_option('samaneh_social_linkedin', '')),
            'social_website'    => (string) get_option('samaneh_social_website_' . self::$instance_id, get_option('samaneh_social_website', '')),
            'social_aparat'     => (string) get_option('samaneh_social_aparat_' . self::$instance_id, get_option('samaneh_social_aparat', '')),
            'cameras_url'       => (string) get_option('samaneh_cameras_url_' . self::$instance_id, ''),
            'installments'      => get_option('samaneh_installments_' . self::$instance_id, []),
            'work_sites'        => get_option('samaneh_work_sites_' . self::$instance_id, []),
            'neshan_api_key'    => (string) get_option('samaneh_neshan_api_key_' . self::$instance_id, ''),
            'new_lead'          => get_option('samaneh_new_lead_' . self::$instance_id, null),
            'allow_peer_chat'   => get_option('samaneh_allow_peer_chat', '1'),
            'chat_avatars'      => get_option('samaneh_chat_avatars', []),
            'chat_access'       => get_option('samaneh_chat_access', []),
            'warehouse_mothers' => get_option('samaneh_warehouse_mothers_' . self::$instance_id, []),
            'invoice_rates'     => get_option('samaneh_invoice_rates_' . self::$instance_id, ''),
            'new_leads'         => (function () {
                $list = get_option('samaneh_new_leads_' . self::$instance_id, []);
                if (!is_array($list)) {
                    $list = [];
                }
                $one = get_option('samaneh_new_lead_' . self::$instance_id, null);
                if (is_array($one) && !empty($one['phone'])) {
                    $has = false;
                    foreach ($list as $L) {
                        if (($L['id'] ?? 0) == ($one['id'] ?? -1) || (($L['phone'] ?? '') === ($one['phone'] ?? '') && ($L['time'] ?? '') === ($one['time'] ?? ''))) {
                            $has = true;
                            break;
                        }
                    }
                    if (!$has) {
                        $list[] = $one;
                    }
                }
                return array_values($list);
            })(),
            'company_phone'     => (string) get_option('samaneh_company_phone_' . self::$instance_id, get_option('samaneh_company_phone', '')),
        ];
        $out['settings'] = apply_filters('samaneh_settings_boot', $out['settings']);
        $out['panel_roles'] = Samaneh_Roles::all();
        $out['instances'] = array_values(Samaneh_Instances::all());
        
        // رمز را به فرانت نفرست
        foreach (['customers', 'personnel'] as $pt) {
            if (!empty($out[$pt])) {
                foreach ($out[$pt] as &$pr) {
                    if (isset($pr['password'])) {
                        $pr['password'] = $pr['password'] !== '' ? '********' : '';
                    }
                }
                unset($pr);
            }
        }
        return apply_filters('samaneh_fetch_all', $out);
    }

    /** جدول‌هایی که روی موجودی انبار اثر دارند */
    private static function is_stock_effect_table(string $table): bool {
        return $table === 'stock_usage' || $table === 'purchases';
    }

    /**
     * ذخیره رکورد. برای مصرف/خرید انبار، کل عملیات (تغییر موجودی + ذخیره ردیف)
     * داخل یک تراکنش انجام می‌شود تا یا کامل اعمال شود یا هیچ.
     */
    public static function save(string $table, array $payload): array {
        if (!self::is_stock_effect_table($table)) {
            return self::save_inner($table, $payload);
        }
        // ALTER باعث commit ضمنی می‌شود؛ پیش از شروع تراکنش انجام شود
        self::ensure_extra_columns($table);
        self::ensure_soft_delete_column(self::table($table));
        self::ensure_extra_columns('stock_items');
        self::ensure_soft_delete_column(self::table('stock_items'));
        Samaneh_Stock::begin();
        try {
            $out = self::save_inner($table, $payload);
            Samaneh_Stock::commit();
            return $out;
        } catch (Throwable $e) {
            Samaneh_Stock::rollback();
            throw $e;
        }
    }

    private static function save_inner(string $table, array $payload): array {
        global $wpdb;
        $fields = self::fields()[$table] ?? apply_filters('samaneh_table_fields', null, $table);
        if (!is_array($fields)) {
            throw new RuntimeException('جدول نامعتبر');
        }
        self::ensure_password_column($table);
        self::ensure_extra_columns($table);
        self::ensure_soft_delete_column(self::table($table));

        $t = self::table($table);
        $id = isset($payload['id']) ? (int) $payload['id'] : 0;
        $old_row = null;
        if ($id > 0) {
            // برای مصرف/خرید، ردیف با قفل خوانده می‌شود تا دو ویرایش هم‌زمان با هم قاطی نشوند
            $old_row = self::is_stock_effect_table($table)
                ? Samaneh_Stock::lock_row($table, $id)
                : self::get_row($table, $id, true);
        }
        if ($old_row && self::row_is_deleted($old_row) && !(class_exists('Samaneh_Auth') && Samaneh_Auth::can_see_deleted())) {
            throw new RuntimeException('این رکورد حذف شده و قابل ویرایش نیست.');
        }
        $data = [];
        $plain_password = null;
        foreach ($fields as $f) {
            if (array_key_exists($f, $payload)) {
                $val = $payload[$f];
                if ($f === 'password') {
                    $val = samaneh_normalize_digits(trim((string) $val));
                    // خالی یا ماسک فرانت → رمز قبلی را دست نزن
                    if ($val === '' || $val === '********' || preg_match('/^\*+$/', $val)) {
                        continue;
                    }
                    $plain_password = $val;
                    // اگر از قبل هش وردپرس است، دوباره هش نکن
                    if (
                        strpos($val, '$P$') === 0
                        || strpos($val, '$2y$') === 0
                        || strpos($val, '$wp') === 0
                        || strpos($val, '$2a$') === 0
                    ) {
                        // نگه دار
                    } else {
                        $val = wp_hash_password($val);
                    }
                }
                if ($f === 'phone') {
                    $val = samaneh_normalize_digits(trim((string) $val));
                    // یکدست: فقط ارقام و + در ابتدا
                    $digits = samaneh_phone_digits($val);
                    if ($digits !== '') {
                        // فرم استاندارد ایران: 09xxxxxxxxx اگر 10 رقم با 9 شروع شود
                        if (strlen($digits) === 10 && $digits[0] === '9') {
                            $digits = '0' . $digits;
                        }
                        if (strlen($digits) === 12 && strpos($digits, '98') === 0) {
                            $digits = '0' . substr($digits, 2);
                        }
                        $val = $digits;
                    }
                }
                if ($f === 'name') {
                    $val = trim((string) $val);
                }
                if ($f === 'role') {
                    $val = trim((string) $val);
                    $map = [
                        'مدیر' => 'management',
                        'مدیر کل' => 'management',
                        'حسابدار' => 'warehouse',
                        'حسابدار / انباردار' => 'warehouse',
                        'انباردار' => 'warehouse',
                        'پرسنل' => 'employee',
                        'پرسنل / نصاب' => 'employee',
                        'نصاب' => 'employee',
                        'سرپرست' => 'supervisor',
                        'سرپرست کارگاه' => 'supervisor',
                        'مشتری' => 'customer',
                    ];
                    if (isset($map[$val])) {
                        $val = $map[$val];
                    }
                    $val = sanitize_key($val);
                }
                if ($f === 'is_main') {
                    $val = !empty($val) ? 1 : 0;
                }
                $data[$f] = $val;
            }
        }
        if (empty($data) && $id < 1) {
            throw new RuntimeException('داده‌ای برای ذخیره نیست');
        }
        // پرسنل جدید حتماً نام داشته باشد
        if ($table === 'personnel' && $id < 1 && empty($data['name'])) {
            throw new RuntimeException('نام پرسنل الزامی است');
        }
        // پرسنل جدید: اگر رمز در payload بود ولی بعد از فیلتر رفت، خطا
        if ($table === 'personnel' && $id < 1 && $plain_password === null && array_key_exists('password', $payload)) {
            $raw = trim((string) $payload['password']);
            if ($raw === '' || $raw === '********') {
                throw new RuntimeException('رمز عبور را وارد کنید');
            }
        }

        // جلوگیری از تکراری (به‌جز انبار که ادغام می‌شود)
        if ($id < 1) {
            $dup = self::check_duplicate($table, $data, $payload);
            if ($dup === 'reject') {
                throw new RuntimeException('این مورد تکراری است و قبلاً ثبت شده.');
            }
            if ($dup === 'merged') {
                // موجودی به ردیف قبلی اضافه شد
                if (isset($data['password'])) {
                    $data['password'] = '';
                }
                return $data;
            }
        }

        // پیش‌فرض‌ها + اعتبارسنجی قوی انبار
        if ($table === 'stock_items') {
            $existing_item = $id > 0 ? self::get_row('stock_items', $id) : null;
            Samaneh_Stock::validate_item($data, $existing_item);
            // تغییر نام نباید با کالای دیگری هم‌نام شود (اتصال مصرف/خرید به کالا یکتا بماند)
            if ($id > 0 && !empty($data['item'])) {
                // phpcs:ignore
                $dup_id = $wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM `{$t}` WHERE item = %s AND id <> %d AND (deleted_at IS NULL OR deleted_at = '' OR deleted_at = '0000-00-00 00:00:00') LIMIT 1",
                    trim((string) $data['item']), $id
                ));
                if ($dup_id) {
                    throw new RuntimeException('کالای دیگری با نام «' . trim((string) $data['item']) . '» وجود دارد.');
                }
            }
        }
        if ($table === 'stock_usage' && $id < 1) {
            if (empty($data['kind'])) {
                $data['kind'] = 'برداشت';
            }
            if (($data['kind'] ?? '') === 'بازگشت') {
                $data['status'] = $data['status'] ?? 'در انتظار تأیید';
            } else {
                $data['status'] = $data['status'] ?? 'تأییدشده';
            }
            // بررسی موجودی دیگر اینجا انجام نمی‌شود (در برابر هم‌زمانی ایمن نیست)؛
            // کسر اتمیک و بررسی کمبود در Samaneh_Stock::plan/execute انجام می‌شود.
        }
        if ($table === 'leave_requests' && $id < 1) {
            $data['status'] = 'در انتظار';
            $data['leave_type'] = $data['leave_type'] ?? 'روزانه';
            unset($payload['status']); // کاربر نمی‌تواند وضعیت بگذارد
        }
        if ($table === 'overtime' && $id < 1) {
            $data['status'] = $data['status'] ?? 'در انتظار';
            // محاسبه ساعت از from_time / to_time
            if (!empty($data['from_time']) && !empty($data['to_time'])) {
                $data['hours'] = self::hours_between($data['from_time'], $data['to_time']);
            }
        }

        // مصرف/خرید: اول موجودی (اتمیک و مشروط)، بعد خود ردیف — همه داخل تراکنش save()
        if (self::is_stock_effect_table($table)) {
            $stock_plan = Samaneh_Stock::plan($table, $data, $old_row);
            Samaneh_Stock::execute($stock_plan);
            $data = array_merge($data, $stock_plan['row']);
        }

        if ($id > 0) {
            $ok = $wpdb->update($t, $data, ['id' => $id]);
            if ($ok === false && $wpdb->last_error) {
                throw new RuntimeException('خطای دیتابیس: ' . $wpdb->last_error);
            }
            $data['id'] = $id;
        } else {
            $ok = $wpdb->insert($t, $data);
            if (!$ok) {
                throw new RuntimeException('خطای دیتابیس: ' . ($wpdb->last_error ?: 'insert failed'));
            }
            $data['id'] = (int) $wpdb->insert_id;
        }

        // تأیید قطعی رمز + مدیرکل اول
        if ($table === 'personnel' && !empty($data['id'])) {
            if ($plain_password !== null) {
                self::set_personnel_password((int) $data['id'], $plain_password);
            }
            $role_saved = sanitize_key($data['role'] ?? ($payload['role'] ?? ''));
            if ($role_saved === 'management') {
                // phpcs:ignore
                $has_main = (int) $wpdb->get_var("SELECT COUNT(*) FROM `{$t}` WHERE is_main = 1");
                if ($has_main < 1) {
                    // phpcs:ignore
                    $wpdb->update($t, ['is_main' => 1], ['id' => (int) $data['id']]);
                    $data['is_main'] = 1;
                }
            }
        } elseif (in_array($table, ['customers'], true) && $plain_password !== null && !empty($data['id'])) {
            self::set_customer_password((int) $data['id'], $plain_password);
        }

        if ($table === 'leave_requests' && $id > 0) {
            self::apply_leave_approval($data, $old_row);
        }

        // فاکتور فروش: کسر موجودی از اقلام + به‌روزرسانی مانده مشتری
        if ($table === 'sales_invoices' && empty($payload['_skip_effects'])) {
            self::apply_sales_invoice_effects($data, $old_row);
        }
        // حواله انبار: انتقال موجودی بین انبارها
        if ($table === 'stock_transfers' && empty($payload['_skip_effects'])) {
            self::apply_stock_transfer_effects($data, $old_row);
        }


        if (isset($data['password'])) {
            $data['password'] = '';
        }
        return $data;
    }

    /** بررسی تکراری — برای پرسنل/مشتری/تأمین‌کننده رد؛ برای کالای انبار ادغام با تأیید */
    private static function check_duplicate(string $table, array &$data, array $payload) {
        global $wpdb;
        $name_field = null;
        if (in_array($table, ['personnel', 'customers', 'suppliers'], true)) {
            $name_field = 'name';
        }
        if ($table === 'stock_items') {
            $name_field = 'item';
        }
        if (!$name_field || empty($data[$name_field])) {
            return null;
        }
        $name = trim((string) $data[$name_field]);
        $t = self::table($table);
        // phpcs:ignore
        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE `{$name_field}` = %s LIMIT 1", $name), ARRAY_A);
        if (!$existing) {
            // پرسنل: موبایل تکراری هم رد شود
            if ($table === 'personnel' && !empty($data['phone'])) {
                $phone = trim((string) $data['phone']);
                // phpcs:ignore
                $by_phone = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE phone = %s AND phone != '' LIMIT 1", $phone), ARRAY_A);
                if ($by_phone) {
                    throw new RuntimeException('پرسنلی با این موبایل («' . $phone . '») قبلاً ثبت شده. نام یا موبایل را تغییر دهید.');
                }
            }
            return null;
        }
        if ($table === 'stock_items') {
            // merge=1 از کلاینت یعنی به موجودی قبلی اضافه کن
            if (!empty($payload['merge_stock'])) {
                $add_qty = (float) ($data['qty'] ?? 0);
                // phpcs:ignore
                $wpdb->query($wpdb->prepare(
                    "UPDATE `{$t}` SET qty = CAST(qty AS DECIMAL(14,2)) + %f WHERE id = %d",
                    $add_qty, (int) $existing['id']
                ));
                $data = $existing;
                $data['id'] = (int) $existing['id'];
                $data['qty'] = (string) ((float) $existing['qty'] + $add_qty);
                $data['_merged'] = true;
                return 'merged';
            }
            throw new RuntimeException('کالای تکراری: «' . $name . '». اگر می‌خواهید به موجودی قبلی اضافه شود، تأیید کنید.');
        }
        $label = $table === 'personnel' ? 'پرسنل' : ($table === 'customers' ? 'مشتری' : 'تأمین‌کننده');
        throw new RuntimeException($label . ' با نام «' . $name . '» قبلاً ثبت شده. اگر می‌خواهید ویرایش کنید از لیست همان ردیف را باز کنید.');
    }

    private static function hours_between(string $from, string $to): float {
        $p1 = array_map('intval', explode(':', $from));
        $p2 = array_map('intval', explode(':', $to));
        $m1 = ($p1[0] ?? 0) * 60 + ($p1[1] ?? 0);
        $m2 = ($p2[0] ?? 0) * 60 + ($p2[1] ?? 0);
        if ($m2 < $m1) {
            $m2 += 24 * 60; // شب‌کاری
        }
        return round(($m2 - $m1) / 60, 2);
    }

    private static function apply_leave_approval(array $row, ?array $old_row): void {
        if (!$old_row) {
            return;
        }
        $old_st = $old_row['status'] ?? '';
        $new_st = $row['status'] ?? $old_st;
        if (in_array($old_st, ['در انتظار', 'pending'], true) && in_array($new_st, ['تأیید', 'تأییدشده', 'approved'], true)) {
            $name = $row['personnel_name'] ?? $old_row['personnel_name'] ?? '';
            $type = $row['leave_type'] ?? $old_row['leave_type'] ?? 'روزانه';
            $hours = (float) ($row['hours'] ?? $old_row['hours'] ?? 0);
            $from = $row['from_date'] ?? $old_row['from_date'] ?? '';
            $to = $row['to_date'] ?? $old_row['to_date'] ?? '';
            $days = 0;
            if ($type === 'ساعتی') {
                // هر ۸ ساعت کاری = ۱ روز
                $days = $hours > 0 ? round($hours / 8, 2) : 0.125;
            } else {
                $days = self::jalali_day_span($from, $to);
            }
            if ($name && $days > 0) {
                global $wpdb;
                $pt = self::table('personnel');
                // phpcs:ignore
                $wpdb->query($wpdb->prepare(
                    "UPDATE `{$pt}` SET leave_days = GREATEST(0, CAST(leave_days AS DECIMAL(8,1)) - %f) WHERE name = %s",
                    $days, $name
                ));
            }
        }
    }

    /** اختلاف روز بین دو تاریخ شمسی YYYY/MM/DD (حداقل ۱) */
    private static function jalali_day_span(string $from, string $to): float {
        $from = trim($from);
        $to = trim($to);
        if ($from === '' && $to === '') {
            return 1;
        }
        if ($to === '' || $to === $from) {
            return 1;
        }
        $p1 = array_map('intval', preg_split('#[/\-.]#', $from));
        $p2 = array_map('intval', preg_split('#[/\-.]#', $to));
        if (count($p1) < 3 || count($p2) < 3) {
            return 1;
        }
        // تقریب: تبدیل به شماره روز سال
        $d1 = $p1[0] * 365 + $p1[1] * 30 + $p1[2];
        $d2 = $p2[0] * 365 + $p2[1] * 30 + $p2[2];
        $diff = abs($d2 - $d1) + 1;
        return max(1, (float) $diff);
    }

    /** هر ماه کاری ۲.۵ روز به مانده مرخصی همه پرسنل اضافه می‌شود */
    public static function accrue_monthly_leave(): void {
        $key = 'samaneh_leave_accrual_' . self::instance_id();
        $now = current_time('Y-m');
        $last = get_option($key, '');
        if ($last === $now) {
            return;
        }
        global $wpdb;
        $pt = self::table('personnel');
        // phpcs:ignore
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $pt));
        if (!$exists) {
            return;
        }
        $amount = (float) get_option('samaneh_max_monthly_leave', '2.5');
        if ($amount <= 0) {
            $amount = 2.5;
        }
        // phpcs:ignore
        $wpdb->query($wpdb->prepare(
            "UPDATE `{$pt}` SET leave_days = CAST(leave_days AS DECIMAL(8,1)) + %f",
            $amount
        ));
        update_option($key, $now, false);
    }

    /** ستون‌های جدید روی جداول قدیمی */
    private static function ensure_extra_columns(string $table): void {
        global $wpdb;
        $t = self::table($table);
        $adds = [];
        if ($table === 'leave_requests') {
            $adds = [
                'leave_type' => "VARCHAR(32) DEFAULT 'روزانه'",
                'hours'      => 'DECIMAL(8,2) DEFAULT 0',
            ];
        }
        if ($table === 'stock_usage') {
            $adds = [
                'kind'   => "VARCHAR(32) DEFAULT 'برداشت'",
                'status' => "VARCHAR(32) DEFAULT 'تأییدشده'",
            ];
        }
        if ($table === 'overtime') {
            $adds = [
                'from_time' => "VARCHAR(16) DEFAULT ''",
                'to_time'   => "VARCHAR(16) DEFAULT ''",
                'reason'    => "VARCHAR(64) DEFAULT ''",
            ];
        }
        if ($table === 'customers') {
            $adds = [
                'design_files' => 'LONGTEXT',
                'sub_stage' => "VARCHAR(64) DEFAULT ''",
                'stage_done_at' => "VARCHAR(32) DEFAULT ''",
                'stage_photos' => 'LONGTEXT',
                'stage_remind_at' => "VARCHAR(32) DEFAULT ''",
                'stage_action' => "VARCHAR(32) DEFAULT ''",
                'install_progress' => 'LONGTEXT',
                'cancelled_at' => "VARCHAR(32) DEFAULT ''",
            ];
        }
        if ($table === 'personnel') {
            $adds = [
                'salary_amount' => 'BIGINT DEFAULT 0',
                'salary_day'    => 'INT DEFAULT 1',
                'is_main'       => 'TINYINT(1) NOT NULL DEFAULT 0',
            ];
        }
        if ($table === 'messages') {
            $adds = [
                'payment_type' => "VARCHAR(32) DEFAULT ''",
                'amount'       => 'BIGINT DEFAULT 0',
            ];
        }
        if ($table === 'directives') {
            $adds = [
                'attachment' => "VARCHAR(512) DEFAULT ''",
                'reminder_interval' => 'INT DEFAULT 0',
                'reminder_unit' => "VARCHAR(16) DEFAULT 'day'",
                'reminders_sent' => 'INT DEFAULT 0',
            ];
        }
        if ($table === 'stock_items') {
            $adds = [
                'unit2' => "VARCHAR(32) DEFAULT ''",
                'unit_ratio' => "VARCHAR(32) DEFAULT ''",
                'prior_stock' => "VARCHAR(16) DEFAULT 'ندارد'",
                'prior_date' => "VARCHAR(32) DEFAULT ''",
            ];
        }
        if ($table === 'stock_usage') {
            // (قبلاً این بلوک $adds را بازنویسی می‌کرد و kind/status هرگز بررسی نمی‌شد)
            $adds = array_merge($adds, [
                'unit'         => "VARCHAR(32) DEFAULT ''",
                'prod_stage'   => "VARCHAR(64) DEFAULT ''",
                'transfer_to'  => "VARCHAR(128) DEFAULT ''",
            ]);
        }
        if ($table === 'stock_usage' || $table === 'purchases') {
            // اتصال به کالا با شناسه + اثری که روی موجودی اعمال شده
            $adds = array_merge($adds, [
                'item_id'       => 'BIGINT UNSIGNED NOT NULL DEFAULT 0',
                'stock_effect'  => 'DECIMAL(14,4) NOT NULL DEFAULT 0',
                'stock_applied' => 'TINYINT(1) NOT NULL DEFAULT 0',
            ]);
        }

        if ($table === 'account_payments') {
            $adds = array_merge($adds, [
                'direction'    => "VARCHAR(16) DEFAULT 'out'",
                'method'       => "VARCHAR(16) DEFAULT 'cash'",
                'account_name' => "VARCHAR(128) DEFAULT ''",
                'ref_type'     => "VARCHAR(32) DEFAULT ''",
                'ref_id'       => "BIGINT DEFAULT 0",
            ]);
        }

        if ($table === 'checks_received' || $table === 'checks_paid') {
            $adds = array_merge($adds, [
                'check_status' => "VARCHAR(32) DEFAULT ''",
                'status_note'  => "VARCHAR(255) DEFAULT ''",
                'passed_date'  => "VARCHAR(32) DEFAULT ''",
            ]);
        }
        if ($table === 'day_notes') {

            $adds = array_merge($adds, [
                'note_kind'    => "VARCHAR(32) DEFAULT 'remind'",
                'status'       => "VARCHAR(32) DEFAULT 'pending'",
                'snooze_until' => "VARCHAR(32) DEFAULT ''",
            ]);
        }
        if ($table === 'attendance') {

            $adds = array_merge($adds, [
                'lat'         => 'VARCHAR(32) DEFAULT \'\'',
                'lng'         => 'VARCHAR(32) DEFAULT \'\'',
                'accuracy_m'  => 'VARCHAR(16) DEFAULT \'\'',
                'site_name'   => 'VARCHAR(128) DEFAULT \'\'',
                'site_id'     => 'BIGINT UNSIGNED NOT NULL DEFAULT 0',
                'ip_addr'     => 'VARCHAR(64) DEFAULT \'\'',
                'geo_ok'      => 'TINYINT(1) NOT NULL DEFAULT 0',
                'device_info' => 'VARCHAR(255) DEFAULT \'\'',
            ]);
        }
        foreach ($adds as $col => $def) {
            // phpcs:ignore
            $exists = $wpdb->get_results("SHOW COLUMNS FROM `{$t}` LIKE '{$col}'");
            if (empty($exists)) {
                // phpcs:ignore
                $wpdb->query("ALTER TABLE `{$t}` ADD COLUMN `{$col}` {$def}");
            }
        }
    }


    /** پیدا کردن پرسنل با موبایل یا نام — نرمال‌سازی رقم */
    public static function find_personnel_for_login(string $login): ?array {
        global $wpdb;
        self::ensure_password_column_public('personnel');
        $t = self::table('personnel');
        // phpcs:ignore
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t));
        if (!$exists) {
            return null;
        }
        $login = trim(samaneh_normalize_digits($login));
        $digits = samaneh_phone_digits($login);
        if (strlen($digits) === 10 && isset($digits[0]) && $digits[0] === '9') {
            $digits = '0' . $digits;
        }
        if (strlen($digits) === 12 && strpos($digits, '98') === 0) {
            $digits = '0' . substr($digits, 2);
        }
        // phpcs:ignore
        $rows = $wpdb->get_results("SELECT * FROM `{$t}` ORDER BY id ASC LIMIT 2000", ARRAY_A);
        if (!is_array($rows)) {
            return null;
        }
        foreach ($rows as $row) {
            if (self::row_is_deleted($row)) {
                continue;
            }
            $name = trim((string) ($row['name'] ?? ''));
            $phone = samaneh_normalize_digits(trim((string) ($row['phone'] ?? '')));
            $pd = samaneh_phone_digits($phone);
            if (strlen($pd) === 10 && isset($pd[0]) && $pd[0] === '9') {
                $pd = '0' . $pd;
            }
            if (strlen($pd) === 12 && strpos($pd, '98') === 0) {
                $pd = '0' . substr($pd, 2);
            }
            if ($name !== '' && mb_strtolower($name) === mb_strtolower($login)) {
                return $row;
            }
            if ($digits !== '' && $pd !== '' && ($digits === $pd || ltrim($digits, '0') === ltrim($pd, '0'))) {
                return $row;
            }
            if ($phone !== '' && $phone === $login) {
                return $row;
            }
        }
        return null;
    }

    /** تنظیم قطعی رمز پرسنل */
    public static function set_personnel_password(int $id, string $plain): void {
        global $wpdb;
        self::ensure_password_column_public('personnel');
        $t = self::table('personnel');
        $plain = samaneh_normalize_digits(trim($plain));
        if ($plain === '' || $id < 1) {
            return;
        }
        $hash = wp_hash_password($plain);
        // phpcs:ignore
        $wpdb->update($t, ['password' => $hash], ['id' => $id]);
        // phpcs:ignore
        $stored = (string) $wpdb->get_var($wpdb->prepare("SELECT password FROM `{$t}` WHERE id = %d", $id));
        if ($stored === '' || !wp_check_password($plain, $stored)) {
            // تلاش دوم با SQL خام
            // phpcs:ignore
            $wpdb->query($wpdb->prepare("UPDATE `{$t}` SET password = %s WHERE id = %d", $hash, $id));
        }
    }

    /** عمومی — برای ورود و مهاجرت ستون رمز */
    public static function ensure_password_column_public(string $table): void {
        self::ensure_password_column($table);
        if ($table === 'personnel') {
            self::ensure_extra_columns('personnel');
        }
    }

    private static function ensure_password_column(string $table): void {
        if (!in_array($table, ['customers', 'personnel'], true)) {
            return;
        }
        global $wpdb;
        $t = self::table($table);
        // phpcs:ignore
        $col = $wpdb->get_results("SHOW COLUMNS FROM `{$t}` LIKE 'password'");
        if (empty($col)) {
            // phpcs:ignore
            $wpdb->query("ALTER TABLE `{$t}` ADD COLUMN password VARCHAR(255) DEFAULT '' AFTER phone");
        }
    }

    /**
     * حذف از نمایش پنل — رکورد در دیتابیس می‌ماند.
     * فقط مدیر شبکه می‌تواند آن را ببیند (کمرنگ) و فقط از پیشخوان وردپرس پاک نهایی کند.
     */
    public static function delete(string $table, int $id, string $by = 'manager'): array {
        if (!self::is_stock_effect_table($table)) {
            return self::delete_inner($table, $id, $by);
        }
        // DDL پیش از تراکنش (commit ضمنی)
        self::ensure_extra_columns($table);
        self::ensure_extra_columns('stock_items');
        self::ensure_soft_delete_column(self::table($table));
        self::ensure_archive_table();
        Samaneh_Stock::begin();
        try {
            $out = self::delete_inner($table, $id, $by);
            Samaneh_Stock::commit();
            return $out;
        } catch (Throwable $e) {
            Samaneh_Stock::rollback();
            throw $e;
        }
    }

    private static function delete_inner(string $table, int $id, string $by = 'manager'): array {
        if ($table === 'archives') {
            throw new RuntimeException('حذف مستقیم بایگانی فقط از پیشخوان شبکه مجاز است');
        }
        $row = self::is_stock_effect_table($table)
            ? Samaneh_Stock::lock_row($table, $id)
            : self::get_row($table, $id, true);
        if (!$row) {
            throw new RuntimeException('رکورد یافت نشد');
        }
        if (self::row_is_deleted($row)) {
            throw new RuntimeException('این رکورد قبلاً از نمایش خارج شده است');
        }
        $arch = self::archive_row($table, $row, $by);
        global $wpdb;
        $t = self::table($table);
        self::ensure_soft_delete_column($t);
        $now = current_time('mysql');
        // phpcs:ignore
        $ok = $wpdb->update($t, [
            'deleted_at' => $now,
            'deleted_by' => sanitize_text_field($by),
        ], ['id' => $id]);
        if ($ok === false && $wpdb->last_error) {
            throw new RuntimeException('خطای دیتابیس: ' . $wpdb->last_error);
        }
        // مصرف/خرید حذف‌شده نباید روی موجودی اثر بگذارد
        if (self::is_stock_effect_table($table)) {
            Samaneh_Stock::release_row($table, $row);
        }
        return [
            'soft_deleted' => true,
            'id'           => $id,
            'table'        => $table,
            'archive_id'   => $arch['archive_id'] ?? 0,
            'deleted_at'   => $now,
        ];
    }

    public static function get_row(string $table, int $id, bool $include_deleted = false): ?array {
        global $wpdb;
        $t = self::table($table);
        // phpcs:ignore
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM `{$t}` WHERE id = %d", $id), ARRAY_A);
        if (!is_array($row)) {
            return null;
        }
        if (!$include_deleted && self::row_is_deleted($row)) {
            if (!(class_exists('Samaneh_Auth') && Samaneh_Auth::can_see_deleted())) {
                return null;
            }
        }
        $row['_deleted'] = self::row_is_deleted($row);
        return $row;
    }

    public static function row_is_deleted(array $row): bool {
        $v = $row['deleted_at'] ?? null;
        if ($v === null || $v === '' || $v === '0000-00-00 00:00:00' || $v === '0') {
            return false;
        }
        return true;
    }

    public static function restore(string $table, int $id): array {
        if (!self::is_stock_effect_table($table)) {
            return self::restore_inner($table, $id);
        }
        self::ensure_extra_columns($table);
        self::ensure_extra_columns('stock_items');
        self::ensure_soft_delete_column(self::table($table));
        Samaneh_Stock::begin();
        try {
            $out = self::restore_inner($table, $id);
            Samaneh_Stock::commit();
            return $out;
        } catch (Throwable $e) {
            Samaneh_Stock::rollback();
            throw $e;
        }
    }

    private static function restore_inner(string $table, int $id): array {
        if (!class_exists('Samaneh_Auth') || !Samaneh_Auth::can_purge()) {
            throw new RuntimeException('فقط مدیر شبکه از پیشخوان وردپرس می‌تواند بازگردانی کند');
        }
        global $wpdb;
        $t = self::table($table);
        self::ensure_soft_delete_column($t);
        // phpcs:ignore
        $ok = $wpdb->update($t, ['deleted_at' => null, 'deleted_by' => ''], ['id' => $id]);
        if ($ok === false) {
            throw new RuntimeException('بازگردانی ناموفق: ' . ($wpdb->last_error ?: ''));
        }
        $row = self::get_row($table, $id, true);
        if (!$row) {
            throw new RuntimeException('رکورد یافت نشد');
        }
        // بازگردانی مصرف/خرید: اثرش دوباره روی موجودی اعمال می‌شود (اگر موجودی کافی نباشد خطا و برگشت)
        if (self::is_stock_effect_table($table)) {
            Samaneh_Stock::reapply_row($table, $row);
            $row = self::get_row($table, $id, true) ?: $row;
        }
        return $row;
    }

    /** حذف نهایی — فقط از پیشخوان وردپرس توسط مدیر شبکه */
    public static function purge_forever(string $table, int $id): bool {
        if (!self::is_stock_effect_table($table)) {
            return self::purge_forever_inner($table, $id);
        }
        self::ensure_extra_columns($table);
        self::ensure_extra_columns('stock_items');
        self::ensure_soft_delete_column(self::table($table));
        self::ensure_archive_table();
        Samaneh_Stock::begin();
        try {
            $out = self::purge_forever_inner($table, $id);
            Samaneh_Stock::commit();
            return $out;
        } catch (Throwable $e) {
            Samaneh_Stock::rollback();
            throw $e;
        }
    }

    private static function purge_forever_inner(string $table, int $id): bool {
        if (!class_exists('Samaneh_Auth') || !Samaneh_Auth::can_purge()) {
            throw new RuntimeException('حذف برای همیشه فقط از پیشخوان وردپرس و فقط برای مدیر شبکه مجاز است');
        }
        global $wpdb;
        $t = self::table($table);
        $row = self::get_row($table, $id, true);
        if (!$row) {
            throw new RuntimeException('رکورد یافت نشد');
        }
        // اگر ردیف هنوز فعال بود، اثرش را از انبار بردار
        if (self::is_stock_effect_table($table) && !self::row_is_deleted($row)) {
            Samaneh_Stock::release_row($table, $row);
        }
        // phpcs:ignore
        $ok = $wpdb->delete($t, ['id' => $id], ['%d']);
        if ($ok) {
            self::ensure_archive_table();
            $arch = self::table('archives');
            // phpcs:ignore
            $wpdb->delete($arch, ['source_table' => sanitize_key($table), 'source_id' => $id]);
        }
        return (bool) $ok;
    }

    public static function list_soft_deleted(int $limit = 200): array {
        global $wpdb;
        $out = [];
        foreach (self::table_names() as $name) {
            $t = self::table($name);
            // phpcs:ignore
            $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t));
            if (!$exists || !self::table_has_column($t, 'deleted_at')) {
                continue;
            }
            // phpcs:ignore
            $rows = $wpdb->get_results(
                "SELECT * FROM `{$t}` WHERE deleted_at IS NOT NULL AND deleted_at != '' AND deleted_at != '0000-00-00 00:00:00' ORDER BY deleted_at DESC LIMIT 80",
                ARRAY_A
            );
            if (!is_array($rows)) {
                continue;
            }
            foreach ($rows as $row) {
                $preview = $row['name'] ?? $row['title'] ?? $row['item'] ?? $row['phone'] ?? '';
                $out[] = [
                    'source_table' => $name,
                    'source_id'    => (int) ($row['id'] ?? 0),
                    'preview'      => is_string($preview) ? $preview : wp_json_encode($row, JSON_UNESCAPED_UNICODE),
                    'deleted_by'   => $row['deleted_by'] ?? '',
                    'deleted_at'   => $row['deleted_at'] ?? '',
                ];
                if (count($out) >= $limit) {
                    return $out;
                }
            }
        }
        return $out;
    }

    /** لیست کامل رکوردهای حذف‌شده یک جدول (برای صندوق حذف مدیر کارگاه) */
    public static function list_soft_deleted_table(string $table, int $limit = 200): array {
        global $wpdb;
        $table = sanitize_key($table);
        if (!in_array($table, self::table_names(), true)) {
            return [];
        }
        $t = self::table($table);
        // phpcs:ignore
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t));
        if (!$exists) {
            return [];
        }
        self::ensure_soft_delete_column($t);
        if (!self::table_has_column($t, 'deleted_at')) {
            return [];
        }
        $limit = max(1, min(500, $limit));
        // phpcs:ignore
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM `{$t}` WHERE deleted_at IS NOT NULL AND deleted_at != '' AND deleted_at != '0000-00-00 00:00:00' ORDER BY deleted_at DESC LIMIT %d",
            $limit
        ), ARRAY_A);
        if (!is_array($rows)) {
            return [];
        }
        foreach ($rows as &$row) {
            $row['_deleted'] = true;
            if (isset($row['password'])) {
                $row['password'] = $row['password'] !== '' ? '********' : '';
            }
        }
        unset($row);
        return $rows;
    }

    public static function table_has_column(string $table, string $col): bool {
        global $wpdb;
        // phpcs:ignore
        $exists = $wpdb->get_results($wpdb->prepare("SHOW COLUMNS FROM `{$table}` LIKE %s", $col));
        return !empty($exists);
    }

    public static function ensure_soft_delete_on_prefix(string $p): void {
        global $wpdb;
        // phpcs:ignore
        $tables = $wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($p) . '%'));
        if (!is_array($tables)) {
            return;
        }
        foreach ($tables as $t) {
            self::ensure_soft_delete_column($t);
        }
    }

    public static function ensure_soft_delete_column(string $t): void {
        global $wpdb;
        if ($t === '') {
            return;
        }
        if (!self::table_has_column($t, 'deleted_at')) {
            // phpcs:ignore
            $wpdb->query("ALTER TABLE `{$t}` ADD COLUMN `deleted_at` DATETIME NULL DEFAULT NULL");
        }
        if (!self::table_has_column($t, 'deleted_by')) {
            // phpcs:ignore
            $wpdb->query("ALTER TABLE `{$t}` ADD COLUMN `deleted_by` VARCHAR(255) NOT NULL DEFAULT ''");
        }
    }

    /** مشتری با موبایل یا نام — بدون ردیف‌های حذف‌شده */
    public static function find_customer_for_login(string $login): ?array {
        global $wpdb;
        self::ensure_password_column_public('customers');
        $t = self::table('customers');
        // phpcs:ignore
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t));
        if (!$exists) {
            return null;
        }
        $login = trim(samaneh_normalize_digits($login));
        $digits = samaneh_phone_digits($login);
        if (strlen($digits) === 10 && isset($digits[0]) && $digits[0] === '9') {
            $digits = '0' . $digits;
        }
        if (strlen($digits) === 12 && strpos($digits, '98') === 0) {
            $digits = '0' . substr($digits, 2);
        }
        // phpcs:ignore
        $rows = $wpdb->get_results("SELECT * FROM `{$t}` ORDER BY id ASC LIMIT 2000", ARRAY_A);
        if (!is_array($rows)) {
            return null;
        }
        foreach ($rows as $row) {
            if (self::row_is_deleted($row)) {
                continue;
            }
            $name = trim((string) ($row['name'] ?? ''));
            $phone = samaneh_normalize_digits(trim((string) ($row['phone'] ?? '')));
            $pd = samaneh_phone_digits($phone);
            if (strlen($pd) === 10 && isset($pd[0]) && $pd[0] === '9') {
                $pd = '0' . $pd;
            }
            if (strlen($pd) === 12 && strpos($pd, '98') === 0) {
                $pd = '0' . substr($pd, 2);
            }
            if ($name !== '' && mb_strtolower($name) === mb_strtolower($login)) {
                return $row;
            }
            if ($digits !== '' && $pd !== '' && ($digits === $pd || ltrim($digits, '0') === ltrim($pd, '0'))) {
                return $row;
            }
            if ($phone !== '' && $phone === $login) {
                return $row;
            }
        }
        return null;
    }

    public static function set_customer_password(int $id, string $plain): void {
        global $wpdb;
        self::ensure_password_column_public('customers');
        $t = self::table('customers');
        $plain = samaneh_normalize_digits(trim($plain));
        if ($plain === '' || $id < 1) {
            return;
        }
        $hash = wp_hash_password($plain);
        // phpcs:ignore
        $wpdb->update($t, ['password' => $hash], ['id' => $id]);
        // phpcs:ignore
        $stored = (string) $wpdb->get_var($wpdb->prepare("SELECT password FROM `{$t}` WHERE id = %d", $id));
        if ($stored === '' || !wp_check_password($plain, $stored)) {
            // phpcs:ignore
            $wpdb->query($wpdb->prepare("UPDATE `{$t}` SET password = %s WHERE id = %d", $hash, $id));
        }
    }

    /** ثبت کپی در جدول بایگانی — فقط سوپرادمین شبکه می‌تواند بایگانی را ببیند/پاک کند */
    public static function archive_row(string $table, array $row, string $by): array {
        global $wpdb;
        self::ensure_archive_table();
        $arch = self::table('archives');
        $payload = [
            'source_table' => sanitize_key($table),
            'source_id'    => (int) ($row['id'] ?? 0),
            'payload_json' => wp_json_encode($row, JSON_UNESCAPED_UNICODE),
            'archived_by'  => sanitize_text_field($by),
            'instance_id'  => self::instance_id(),
        ];
        $wpdb->insert($arch, $payload);
        return [
            'archive_id' => (int) $wpdb->insert_id,
            'source_table' => $table,
            'source_id' => (int) ($row['id'] ?? 0),
        ];
    }

    /** لیست بایگانی — فقط برای سوپرادمین شبکه */
    public static function list_archives(int $limit = 200): array {
        global $wpdb;
        self::ensure_archive_table();
        $arch = self::table('archives');
        // phpcs:ignore
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, source_table, source_id, archived_by, instance_id, created_at, LEFT(payload_json, 200) AS preview FROM `{$arch}` ORDER BY id DESC LIMIT %d",
            $limit
        ), ARRAY_A);
        return is_array($rows) ? $rows : [];
    }

    /** پاکسازی نهایی یک رکورد بایگانی — فقط سوپرادمین شبکه */
    public static function purge_archive(int $archive_id): bool {
        global $wpdb;
        self::ensure_archive_table();
        $arch = self::table('archives');
        // phpcs:ignore
        return (bool) $wpdb->delete($arch, ['id' => $archive_id], ['%d']);
    }

    private static function ensure_archive_table(): void {
        global $wpdb;
        $p = self::prefix();
        $c = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE IF NOT EXISTS {$p}archives (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            source_table VARCHAR(64) NOT NULL DEFAULT '',
            source_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            payload_json LONGTEXT,
            archived_by VARCHAR(255) DEFAULT '',
            instance_id INT NOT NULL DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY source (source_table, source_id)
        ) $c";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /** کسر موجودی و به‌روزرسانی مانده مشتری برای فاکتور فروش */
    private static function apply_sales_invoice_effects(array $row, ?array $old): void {
        global $wpdb;
        // فقط برای فاکتورهای جدید یا وقتی stock_applied نبود
        $already = (int) ($row['stock_applied'] ?? 0);
        if ($old && (int) ($old['stock_applied'] ?? 0) === 1 && $already === 1) {
            // اگر قبلاً اعمال شده، فقط مانده مشتری را در صورت تغییر مبلغ تنظیم کن
            $old_total = (int) ($old['total'] ?? 0) - (int) ($old['paid_amount'] ?? 0);
            $new_total = (int) ($row['total'] ?? 0) - (int) ($row['paid_amount'] ?? 0);
            $delta_bal = $new_total - $old_total;
            if ($delta_bal !== 0) {
                self::adjust_customer_balance((string) ($row['customer_name'] ?? ''), $delta_bal);
            }
            return;
        }
        if (self::row_is_deleted($row)) {
            return;
        }
        $items = [];
        $raw = $row['items_json'] ?? '';
        if (is_string($raw) && $raw !== '') {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                $items = $decoded;
            }
        } elseif (is_array($raw)) {
            $items = $raw;
        }
        $warehouse = trim((string) ($row['warehouse'] ?? ''));
        foreach ($items as $it) {
            $name = trim((string) ($it['item'] ?? $it['name'] ?? ''));
            $qty = (float) ($it['qty'] ?? 0);
            $unit = trim((string) ($it['unit'] ?? ''));
            if ($name === '' || $qty <= 0) {
                continue;
            }
            if (class_exists('Samaneh_Stock')) {
                try {
                    Samaneh_Stock::assert_available($name, $qty, $unit);
                    $item = Samaneh_Stock::find_item($name);
                    if ($item) {
                        $primary = Samaneh_Stock::to_primary($qty, $unit, $item);
                        Samaneh_Stock::deposit((int) $item['id'], -$primary);
                    }
                } catch (Throwable $e) {
                    throw $e;
                }
            }
        }
        // مانده مشتری: بدهی = total - paid
        $debt = (int) ($row['total'] ?? 0) - (int) ($row['paid_amount'] ?? 0);
        if ($debt > 0) {
            self::adjust_customer_balance((string) ($row['customer_name'] ?? ''), $debt);
        }
        // علامت stock_applied
        $id = (int) ($row['id'] ?? 0);
        if ($id > 0) {
            $tname = self::table('sales_invoices');
            // phpcs:ignore
            $wpdb->update($tname, ['stock_applied' => 1], ['id' => $id]);
        }
    }

    /** انتقال موجودی بین دو انبار (دسته‌بندی کالا) */
    private static function apply_stock_transfer_effects(array $row, ?array $old): void {
        global $wpdb;
        if ($old && (int) ($old['stock_applied'] ?? 0) === 1) {
            return;
        }
        if (self::row_is_deleted($row)) {
            return;
        }
        $name = trim((string) ($row['item_name'] ?? ''));
        $qty = (float) ($row['qty'] ?? 0);
        $unit = trim((string) ($row['unit'] ?? ''));
        $from = trim((string) ($row['from_warehouse'] ?? ''));
        $to = trim((string) ($row['to_warehouse'] ?? ''));
        if ($name === '' || $qty <= 0 || $from === '' || $to === '' || $from === $to) {
            throw new RuntimeException('حواله نامعتبر: کالا، مقدار و انبار مبدأ/مقصد الزامی است.');
        }
        if (!class_exists('Samaneh_Stock')) {
            return;
        }
        // کالای مبدأ: نام + دسته = from
        $src = self::find_stock_in_warehouse($name, $from);
        if (!$src) {
            // fallback: هر کالای با این نام
            $src = Samaneh_Stock::find_item($name);
        }
        if (!$src) {
            throw new RuntimeException('کالای «' . $name . '» در انبار «' . $from . '» یافت نشد.');
        }
        $primary = Samaneh_Stock::to_primary($qty, $unit, $src);
        Samaneh_Stock::assert_available($name, $qty, $unit);
        Samaneh_Stock::deposit((int) $src['id'], -$primary);

        // مقصد: اگر کالا با همین نام در انبار to هست افزایش بده، وگرنه بساز
        $dst = self::find_stock_in_warehouse($name, $to);
        if ($dst) {
            Samaneh_Stock::deposit((int) $dst['id'], $primary);
        } else {
            $items_t = self::table('stock_items');
            $ok = $wpdb->insert($items_t, [
                'category' => $to,
                'item'     => $name,
                'qty'      => Samaneh_Stock::format_qty($primary),
                'unit'     => (($src['unit'] ?? '') !== '' ? $src['unit'] : ($unit !== '' ? $unit : 'عدد')),
                'unit2'    => $src['unit2'] ?? '',
                'unit_ratio' => $src['unit_ratio'] ?? '',
                'min_qty'  => '0',
                'price'    => (int) ($src['price'] ?? 0),
            ]);
            if (!$ok) {
                // rollback src
                Samaneh_Stock::deposit((int) $src['id'], $primary);
                throw new RuntimeException('ساخت کالا در انبار مقصد ناموفق بود.');
            }
        }
        $id = (int) ($row['id'] ?? 0);
        if ($id > 0) {
            // phpcs:ignore
            $wpdb->update(self::table('stock_transfers'), ['stock_applied' => 1], ['id' => $id]);
        }
    }

    private static function find_stock_in_warehouse(string $name, string $warehouse): ?array {
        global $wpdb;
        $t = self::table('stock_items');
        // phpcs:ignore
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM `{$t}` WHERE item = %s AND category = %s LIMIT 1",
            $name,
            $warehouse
        ), ARRAY_A);
        if ($row && !self::row_is_deleted($row)) {
            return $row;
        }
        return null;
    }

    private static function adjust_customer_balance(string $name, int $delta): void {
        global $wpdb;
        $name = trim($name);
        if ($name === '' || $delta === 0) {
            return;
        }
        $t = self::table('customers');
        // phpcs:ignore
        $c = $wpdb->get_row($wpdb->prepare("SELECT id, balance FROM `{$t}` WHERE name = %s LIMIT 1", $name), ARRAY_A);
        if (!$c) {
            return;
        }
        $bal = (int) ($c['balance'] ?? 0) + $delta;
        // phpcs:ignore
        $wpdb->update($t, ['balance' => $bal], ['id' => (int) $c['id']]);
    }


}
