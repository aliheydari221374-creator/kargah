<?php
/**
 * رزرو اسلاگ پنل کارگاه تا وردپرس شبکه نتواند همان مسیر را به‌عنوان سایت بسازد.
 * مثال: اگر پنل در zagroos.com/kargah باشد، ساخت سایت /kargah مسدود است.
 */
if (!defined('ABSPATH')) {
    exit;
}

class Samaneh_Reserved_Slugs {

    const OPT = 'samaneh_reserved_slugs';

    public static function init(): void {
        add_filter('subdirectory_reserved_names', [__CLASS__, 'filter_reserved_names'], 20);
        add_filter('wpmu_validate_blog_signup', [__CLASS__, 'validate_blog_signup'], 20);
        add_filter('wp_validate_site_data', [__CLASS__, 'validate_site_data'], 10, 3);
        add_action('wp_initialize_site', [__CLASS__, 'block_conflicting_new_site'], 1, 2);
        add_filter('new_site_email', [__CLASS__, 'maybe_note_conflict'], 10, 1);
    }

    public static function all(): array {
        $stored = is_multisite() ? get_site_option(self::OPT, []) : get_option(self::OPT, []);
        if (!is_array($stored)) {
            $stored = [];
        }
        $out = [];
        foreach ($stored as $slug) {
            $slug = sanitize_title((string) $slug);
            if ($slug !== '') {
                $out[$slug] = $slug;
            }
        }
        // همیشه اسلاگ‌های زنده پنل‌ها را هم اضافه کن
        foreach (self::collect_live_slugs() as $slug) {
            $out[$slug] = $slug;
        }
        return array_values($out);
    }

    public static function collect_live_slugs(): array {
        $slugs = [];
        if (!class_exists('Samaneh_Instances')) {
            return $slugs;
        }
        if (is_multisite()) {
            $sites = get_sites(['fields' => 'ids', 'number' => 0]);
            $current = get_current_blog_id();
            foreach ($sites as $blog_id) {
                switch_to_blog((int) $blog_id);
                foreach (self::slugs_on_current_blog() as $s) {
                    $slugs[$s] = $s;
                }
                restore_current_blog();
            }
            if (get_current_blog_id() !== $current) {
                switch_to_blog($current);
            }
        } else {
            foreach (self::slugs_on_current_blog() as $s) {
                $slugs[$s] = $s;
            }
        }
        return array_values($slugs);
    }

    private static function slugs_on_current_blog(): array {
        $out = [];
        $list = get_option('samaneh_instances', []);
        if (!is_array($list)) {
            return $out;
        }
        foreach ($list as $inst) {
            $slug = sanitize_title((string) ($inst['slug'] ?? ''));
            if ($slug !== '') {
                $out[] = $slug;
            }
        }
        return $out;
    }

    public static function persist(array $extra = []): void {
        $slugs = [];
        foreach (array_merge(self::all(), $extra) as $s) {
            $s = sanitize_title((string) $s);
            if ($s !== '') {
                $slugs[$s] = $s;
            }
        }
        $list = array_values($slugs);
        if (is_multisite()) {
            update_site_option(self::OPT, $list);
        } else {
            update_option(self::OPT, $list, false);
        }
    }

    public static function add(string $slug): void {
        $slug = sanitize_title($slug);
        if ($slug === '') {
            return;
        }
        $all = self::all();
        if (!in_array($slug, $all, true)) {
            $all[] = $slug;
        }
        self::persist($all);
    }

    public static function is_reserved(string $slug): bool {
        $slug = sanitize_title($slug);
        if ($slug === '') {
            return false;
        }
        return in_array($slug, self::all(), true);
    }

    /** مسیر سایت شبکه مثل /kargah/ با اسلاگ پنل تداخل دارد؟ */
    public static function path_conflicts(string $path): bool {
        $path = trim($path, '/');
        if ($path === '') {
            return false;
        }
        $first = sanitize_title(explode('/', $path)[0] ?? '');
        return self::is_reserved($first);
    }

    /** اسلاگ پنل با سایت موجود شبکه تداخل دارد؟ */
    public static function slug_taken_by_site(string $slug): bool {
        if (!is_multisite()) {
            return false;
        }
        $slug = sanitize_title($slug);
        if ($slug === '') {
            return false;
        }
        $sites = get_sites([
            'number' => 1,
            'path'   => '/' . $slug . '/',
            'fields' => 'ids',
        ]);
        if (!empty($sites)) {
            return true;
        }
        // بعضی شبکه‌ها path را بدون اسلش انتهایی ذخیره می‌کنند
        $sites = get_sites([
            'number' => 1,
            'path'   => '/' . $slug,
            'fields' => 'ids',
        ]);
        return !empty($sites);
    }

    public static function filter_reserved_names($names) {
        if (!is_array($names)) {
            $names = [];
        }
        return array_values(array_unique(array_merge($names, self::all())));
    }

    public static function validate_blog_signup($result) {
        if (!is_array($result)) {
            return $result;
        }
        $blogname = isset($result['blogname']) ? sanitize_title((string) $result['blogname']) : '';
        if ($blogname !== '' && self::is_reserved($blogname)) {
            if (!isset($result['errors']) || !is_wp_error($result['errors'])) {
                $result['errors'] = new WP_Error();
            }
            $result['errors']->add(
                'blogname',
                'این آدرس برای پنل کارگاه آماده رزرو شده و نمی‌توان سایت شبکه‌ای روی آن ساخت.'
            );
        }
        return $result;
    }

    /**
     * @param WP_Error $errors
     */
    public static function validate_site_data($errors, $data = null, $old = null) {
        if (!is_wp_error($errors)) {
            return $errors;
        }
        $path = '';
        if (is_array($data) && isset($data['path'])) {
            $path = (string) $data['path'];
        } elseif (is_object($data) && isset($data->path)) {
            $path = (string) $data->path;
        }
        if ($path !== '' && self::path_conflicts($path)) {
            $errors->add(
                'site_taken',
                'مسیر «' . esc_html(trim($path, '/')) . '» برای پنل کارگاه رزرو است و ساخت سایت روی آن مجاز نیست.'
            );
        }
        return $errors;
    }

    public static function block_conflicting_new_site($site, $args = null): void {
        if (!is_object($site) || empty($site->path)) {
            return;
        }
        if (!self::path_conflicts((string) $site->path)) {
            return;
        }
        // سایت تازه ساخته‌شده را فوراً برنگردانیم اگر از مسیر UI آمده؛
        // wp_validate_site_data جلوی ساخت را می‌گیرد. اینجا فقط لاگ.
        error_log('Samaneh: blocked/flagged reserved path ' . $site->path);
    }

    public static function maybe_note_conflict($email) {
        return $email;
    }
}
